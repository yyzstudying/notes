package com.ruijie.rcos.base.sysmanage.module.web.ctrl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.UUID;

import com.ruijie.rcos.sk.base.batch.BatchTaskBuilder;
import com.ruijie.rcos.sk.base.batch.BatchTaskHandler;
import com.ruijie.rcos.sk.base.batch.BatchTaskItem;
import com.ruijie.rcos.sk.base.i18n.LocaleI18nResolver;
import com.ruijie.rcos.sk.webmvc.api.optlog.ProgrammaticOptLogRecorder;
import mockit.*;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.ruijie.rcos.base.sysmanage.module.def.api.Log4jConfigAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.log4jconfig.BaseAddLog4jConfigRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.log4jconfig.BaseDetailLog4jConfigRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.log4jconfig.BaseEditLog4jConfigRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.log4jconfig.BaseListLog4jConfigRequest;
import com.ruijie.rcos.base.sysmanage.module.def.dto.Log4jConfigDTO;
import com.ruijie.rcos.base.sysmanage.module.web.request.log4jconfig.BaseAddLog4jConfigWebRequest;
import com.ruijie.rcos.base.sysmanage.module.web.request.log4jconfig.BaseDetailLog4jConfigWebRequest;
import com.ruijie.rcos.base.sysmanage.module.web.request.log4jconfig.BaseEditLog4jConfigWebRequest;
import com.ruijie.rcos.base.sysmanage.module.web.request.log4jconfig.BaseListLog4jConfigWebRequest;
import com.ruijie.rcos.base.sysmanage.module.web.request.log4jconfig.BaseRemoveLog4jConfigWebRequest;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.test.GetSetTester;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultPageResponse;
import com.ruijie.rcos.sk.webmvc.api.response.DefaultWebResponse;

import mockit.integration.junit4.JMockit;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年02月20日
 *
 * @author GuoZhouYue
 */
@RunWith(JMockit.class)
public class Log4jConfigCtrlTest {

    @Tested
    Log4jConfigCtrl ctrl;

    @Injectable
    Log4jConfigAPI log4jConfigAPI;

    @Injectable
    private ProgrammaticOptLogRecorder logRecorder;

    @Injectable
    private BatchTaskBuilder taskBuilder;

    /**
     * testPOJO
     */
    @Test
    public void testPOJO() {
        GetSetTester tester = new GetSetTester(BaseListLog4jConfigWebRequest.class);
        tester.runTest();

        GetSetTester tester2 = new GetSetTester(BaseAddLog4jConfigWebRequest.class);
        tester2.runTest();

        GetSetTester tester3 = new GetSetTester(BaseRemoveLog4jConfigWebRequest.class);
        tester3.runTest();

        GetSetTester tester4 = new GetSetTester(BaseEditLog4jConfigWebRequest.class);
        tester4.runTest();

        assertTrue(true);
    }

    /**
     * testListLog4jConfig
     *
     * @param webRequest webRequest
     * @param response response
     */
    @Test
    public void testListLog4jConfig(@Injectable BaseListLog4jConfigWebRequest webRequest
        , @Injectable DefaultPageResponse<Log4jConfigDTO> response) {
        Deencapsulation.setField(ctrl, "log4jConfigAPI", log4jConfigAPI);

        final DefaultWebResponse defaultWebResponse = ctrl.listLog4jConfig(webRequest);
        assertEquals(response, defaultWebResponse.getContent());

        new Verifications(){
            {
                log4jConfigAPI.getAll((BaseListLog4jConfigRequest) any);
                times = 1;
            }
        };
    }

    /**
     * testAddLog4jConfig
     *
     * @param webRequest webRequest
     * @throws BusinessException BusinessException
     */
    @Test
    public void testAddLog4jConfig(@Injectable BaseAddLog4jConfigWebRequest webRequest) throws BusinessException {

        Deencapsulation.setField(ctrl, "log4jConfigAPI", log4jConfigAPI);
        ctrl.addLog4jConfig(webRequest, logRecorder);

        new Verifications(){
            {
                log4jConfigAPI.addConfig((BaseAddLog4jConfigRequest) any);
                times = 1;
            }
        };
    }

    /**
     * testDeleteLog4jConfig
     *
     * @param webRequest webRequest
     * @throws BusinessException BusinessException
     */
    @Test
    public void testDeleteLog4jConfig(@Injectable BaseRemoveLog4jConfigWebRequest webRequest) throws BusinessException {
        new Expectations() {
            {
                webRequest.getIdArr();
                result = new UUID[]{UUID.randomUUID()};
            }
        };

        new Expectations(LocaleI18nResolver.class) {
            {
                LocaleI18nResolver.resolve(anyString);
                result = "itemName";
            }
        };

        Deencapsulation.setField(ctrl, "log4jConfigAPI", log4jConfigAPI);
        ctrl.deleteLog4jConfig(webRequest, taskBuilder, logRecorder);

        new Verifications(){
            {
                taskBuilder.setTaskName(anyString);
                times = 1;

                taskBuilder.setTaskDesc(anyString);
                times = 1;

                taskBuilder.registerHandler((BatchTaskHandler<BatchTaskItem>) any);
                times = 1;

                taskBuilder.start();
                times = 1;
            }
        };
    }

    /**
     * testEditLog4jConfig
     *
     * @param webRequest webRequest
     * @throws BusinessException BusinessException
     */
    @Test
    public void testEditLog4jConfig(@Injectable BaseEditLog4jConfigWebRequest webRequest) throws BusinessException {
        Deencapsulation.setField(ctrl, "log4jConfigAPI", log4jConfigAPI);
        ctrl.editLog4jConfig(webRequest, logRecorder);

        new Verifications(){
            {
                log4jConfigAPI.editConfig((BaseEditLog4jConfigRequest) any);
                times = 1;
            }
        };
    }

    /**
     * testDetailLog4jConfig
     *
     * @param webRequest webRequest
     * @throws BusinessException BusinessException
     */
    @Test
    public void testDetailLog4jConfig(@Injectable BaseDetailLog4jConfigWebRequest webRequest) throws BusinessException {
        Deencapsulation.setField(ctrl, "log4jConfigAPI", log4jConfigAPI);
        ctrl.detailLog4jConfig(webRequest);

        new Verifications(){
            {
                log4jConfigAPI.getOne((BaseDetailLog4jConfigRequest) any);
                times = 1;
            }
        };
    }
}
