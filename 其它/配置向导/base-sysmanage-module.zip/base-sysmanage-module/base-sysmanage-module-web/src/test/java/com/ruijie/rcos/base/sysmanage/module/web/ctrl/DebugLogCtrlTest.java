package com.ruijie.rcos.base.sysmanage.module.web.ctrl;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.UUID;

import com.ruijie.rcos.sk.base.batch.BatchTaskSubmitResult;
import com.ruijie.rcos.sk.webmvc.api.response.DefaultWebResponse;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.ruijie.rcos.base.sysmanage.module.def.api.DebugLogAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.debuglog.BaseDetailDebugLogRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.debuglog.BaseListDebugLogRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.debuglog.BaseCreateDebugLogResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.debuglog.BaseDetailDebugLogResponse;
import com.ruijie.rcos.base.sysmanage.module.web.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.web.request.debuglog.BaseCreateDebugLogWebRequest;
import com.ruijie.rcos.base.sysmanage.module.web.request.debuglog.BaseDeleteDebugLogWebRequest;
import com.ruijie.rcos.base.sysmanage.module.web.request.debuglog.BaseDownloadDebugLogWebRequest;
import com.ruijie.rcos.base.sysmanage.module.web.request.debuglog.BaseListDebugLogWebRequest;
import com.ruijie.rcos.sk.base.batch.BatchTaskBuilder;
import com.ruijie.rcos.sk.base.batch.BatchTaskHandler;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.i18n.LocaleI18nResolver;
import com.ruijie.rcos.sk.base.test.GetSetTester;
import com.ruijie.rcos.sk.webmvc.api.optlog.ProgrammaticOptLogRecorder;
import com.ruijie.rcos.sk.webmvc.api.response.DownloadWebResponse;

import mockit.*;
import mockit.integration.junit4.JMockit;

/**
 * Description: 调试日志CTRL
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月25日
 *
 * @author fyq
 */

@RunWith(JMockit.class)
public class DebugLogCtrlTest {

    @Tested
    private DebugLogCtrl debugLogCtrl;

    @Injectable
    private DebugLogAPI debugLogAPI;

    @Mocked
    private ProgrammaticOptLogRecorder logRecorder;

    @Mocked
    private BatchTaskBuilder taskBuilder;

    @Mocked
    private LocaleI18nResolver localeI18nResolver;

    /**
     * 实体
     */
    @Test
    public void testPojo() {

        GetSetTester tester = new GetSetTester(BaseCreateDebugLogWebRequest.class);
        tester.runTest();

        tester = new GetSetTester(BaseDeleteDebugLogWebRequest.class);
        tester.runTest();

        tester = new GetSetTester(BaseDownloadDebugLogWebRequest.class);
        tester.runTest();

        tester = new GetSetTester(BaseListDebugLogWebRequest.class);
        tester.runTest();

        assertTrue(true);
    }

    /**
     * 创建
     * 
     * @param webRequest 请求
     * @throws BusinessException 异常
     */
    @Test
    public void testCreateDebugLog(@Tested BaseCreateDebugLogWebRequest webRequest) throws BusinessException {
        BatchTaskSubmitResult batchTaskSubmitResult = new BatchTaskSubmitResultTest();
        BaseCreateDebugLogResponse apiResponse = new BaseCreateDebugLogResponse();
        apiResponse.setFileName("log.zip");

        new Expectations(LocaleI18nResolver.class) {
            {
                LocaleI18nResolver.resolve(BusinessKey.BASE_SYS_MANAGE_DEBUG_LOG_BATCH_CREATE_ITEM_NAME);
                result = "itemName";
                taskBuilder.start();
                result = batchTaskSubmitResult;
            }
        };


        DefaultWebResponse defaultWebResponse = debugLogCtrl.createDebugLog(webRequest, taskBuilder, logRecorder);
        Assert.assertEquals(defaultWebResponse.getContent(), batchTaskSubmitResult);
        new Verifications() {
            {
                taskBuilder.setTaskName(BusinessKey.BASE_SYS_MANAGE_DEBUG_LOG_BATCH_CREATE_NAME);
                times = 1;
                taskBuilder.setTaskDesc(BusinessKey.BASE_SYS_MANAGE_DEBUG_LOG_BATCH_CREATE_DESC);
                times = 1;
                taskBuilder.registerHandler((BatchTaskHandler) any);
                times = 1;
                taskBuilder.start();
                times = 1;
            }
        };

    }


    /**
     * 删除
     * 
     * @param webRequest 请求
     * @throws BusinessException 异常
     */
    @Test
    public void testDeleteDebugLog(@Tested BaseDeleteDebugLogWebRequest webRequest) throws BusinessException {
        BatchTaskSubmitResult batchTaskSubmitResult = new BatchTaskSubmitResultTest();
        webRequest.setIdArr(new UUID[] {UUID.randomUUID(), UUID.randomUUID()});

        new Expectations(LocaleI18nResolver.class) {
            {
                LocaleI18nResolver.resolve(BusinessKey.BASE_SYS_MANAGE_DEBUG_LOG_BATCH_DELETE_ITEM_NAME);
                result = "itemName";
                taskBuilder.start();
                result = batchTaskSubmitResult;
            }
        };

        DefaultWebResponse defaultWebResponse = debugLogCtrl.deleteDebugLog(webRequest, taskBuilder, logRecorder);
        Assert.assertEquals(defaultWebResponse.getContent(), batchTaskSubmitResult);
        new Verifications() {
            {
                taskBuilder.setTaskName(BusinessKey.BASE_SYS_MANAGE_DEBUG_LOG_BATCH_DELETE_NAME);
                times = 1;
                taskBuilder.setTaskDesc(BusinessKey.BASE_SYS_MANAGE_DEBUG_LOG_BATCH_DELETE_DESC);
                times = 1;
                taskBuilder.registerHandler((BatchTaskHandler) any);
                times = 1;
                taskBuilder.start();
                times = 1;
            }
        };

    }


    /**
     * 下载日志
     * 
     * @param webRequest 请求
     */
    @Test
    public void testDownloadDebugLog(@Tested BaseDownloadDebugLogWebRequest webRequest) throws BusinessException {

        String fileName = "log.zip";

        BaseDetailDebugLogResponse apiResponse = new BaseDetailDebugLogResponse();
        apiResponse.setFilePath(fileName);
        apiResponse.setFileName("test");

        new Expectations() {
            {
                debugLogAPI.detailDebugLog((BaseDetailDebugLogRequest) any);
                result = apiResponse;
            }
        };

        new MockUp<File>() {
            @Mock
            public boolean exists() {
                return true;
            }
        };

        new MockUp<File>() {
            @Mock
            public boolean exists() {
                return true;
            }
        };

        new MockUp<DownloadWebResponse.Builder>() {
            @Mock
            protected DownloadWebResponse.Builder setFile(Invocation invocation, File file) {
                return invocation.getInvokedInstance();
            }
        };

        DownloadWebResponse webResponse = debugLogCtrl.downloadDebugLog(webRequest);
        new Verifications() {
            {
                debugLogAPI.detailDebugLog((BaseDetailDebugLogRequest) any);
                times = 1;
            }
        };
        Assert.assertEquals(webResponse.getFileName(), "test");
    }

    /**
     * 日志列表
     * 
     * @param webRequest 请求
     */
    @Test
    public void testListDebugLog(@Mocked BaseListDebugLogWebRequest webRequest) {
        new Expectations() {
            {
                debugLogAPI.listDebugLog((BaseListDebugLogRequest) any);
            }
        };

        debugLogCtrl.listDebugLog(webRequest);

        new Verifications() {
            {
                debugLogAPI.listDebugLog((BaseListDebugLogRequest) any);
                times = 1;
            }
        };
    }


}
