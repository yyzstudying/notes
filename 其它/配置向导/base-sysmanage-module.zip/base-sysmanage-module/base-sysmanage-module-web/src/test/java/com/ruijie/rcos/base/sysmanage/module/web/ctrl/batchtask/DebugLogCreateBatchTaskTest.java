package com.ruijie.rcos.base.sysmanage.module.web.ctrl.batchtask;

import org.junit.Assert;
import org.junit.Test;

import com.ruijie.rcos.base.sysmanage.module.def.api.DebugLogAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.debuglog.BaseCreateDebugLogRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.debuglog.BaseCreateDebugLogResponse;
import com.ruijie.rcos.base.sysmanage.module.web.BusinessKey;
import com.ruijie.rcos.sk.base.batch.*;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.webmvc.api.optlog.ProgrammaticOptLogRecorder;

import mockit.*;

/**
 * Description: 打包调试日志任务
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月25日
 *
 * @author fyq
 */

public class DebugLogCreateBatchTaskTest {

    @Tested
    private DebugLogCreateBatchTask debugLogCreateBatchTask;

    @Injectable
    private BatchTaskItem batchTaskItem;

    @Injectable
    private DebugLogAPI debugLogAPI;

    @Mocked
    @Injectable
    private ProgrammaticOptLogRecorder logRecorder;

    /**
     * 创建
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testCreateDebugLog() throws BusinessException {

        String fileName = "bak.zip";

        BaseCreateDebugLogResponse apiResponse = new BaseCreateDebugLogResponse();
        apiResponse.setFileName(fileName);

        new MockUp<BusinessException>() {
            @Mock
            public String getI18nMessage() {
                return "";
            }
        };

        new Expectations() {
            {
                debugLogAPI.createDebugLog((BaseCreateDebugLogRequest) any);
                result = apiResponse;
            }
        };

        BatchTaskItemResult taskItemResult = debugLogCreateBatchTask.processItem(batchTaskItem);

        new Verifications() {
            {
                debugLogAPI.createDebugLog((BaseCreateDebugLogRequest) any);
                times = 1;
                logRecorder.saveOptLog(BusinessKey.BASE_SYS_MANAGE_DEBUG_LOG_CREATE, fileName);
                times = 1;
            }
        };

        Assert.assertEquals(taskItemResult.getItemStatus(), BatchTaskItemStatus.SUCCESS);
        Assert.assertEquals(taskItemResult.getMsgKey(), BusinessKey.BASE_SYS_MANAGE_BATCH_ITEM_CREATE);
    }

    /**
     * 创建失败
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testCreateDebugLogApiFail() throws BusinessException {

        new MockUp<BusinessException>() {
            @Mock
            public String getI18nMessage() {
                return "";
            }
        };

        new Expectations() {
            {
                debugLogAPI.createDebugLog((BaseCreateDebugLogRequest) any);
                result = new BusinessException(BusinessKey.BASE_SYS_MANAGE_BATCH_ITEM_FAIL);
            }
        };

        try {
            debugLogCreateBatchTask.processItem(batchTaskItem);
        } catch (BusinessException e) {
            Assert.assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_BATCH_ITEM_FAIL);
        }
    }

    /**
     * 完成
     */
    @Test
    public void testOnFinish() {
        BatchTaskFinishResult taskFinishResult = debugLogCreateBatchTask.onFinish(1, 0);
        Assert.assertEquals(taskFinishResult.getStatus(), BatchTaskStatus.SUCCESS);
        Assert.assertEquals(taskFinishResult.getMsgKey(), BusinessKey.BASE_SYS_MANAGE_DEBUG_LOG_BATCH_CREATE_SUCCESS);
    }

    /**
     * 完成失败
     */
    @Test
    public void testOnFinishFail() {
        BatchTaskFinishResult taskFinishResult = debugLogCreateBatchTask.onFinish(0, 1);
        Assert.assertEquals(taskFinishResult.getStatus(), BatchTaskStatus.FAILURE);
        Assert.assertEquals(taskFinishResult.getMsgKey(), BusinessKey.BASE_SYS_MANAGE_DEBUG_LOG_BATCH_CREATE_FAIL);
    }
}
