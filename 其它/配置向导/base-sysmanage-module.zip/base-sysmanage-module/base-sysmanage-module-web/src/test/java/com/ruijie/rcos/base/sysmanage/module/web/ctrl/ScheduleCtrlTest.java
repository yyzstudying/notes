package com.ruijie.rcos.base.sysmanage.module.web.ctrl;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.ruijie.rcos.base.sysmanage.module.def.api.ScheduleAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.schedule.*;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.schedule.BaseBatchQueryScheduleResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.schedule.BaseListTaskTypeResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.schedule.BaseQueryScheduleResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.schedule.BaseQueryTaskTypeResponse;
import com.ruijie.rcos.base.sysmanage.module.def.dto.ScheduleDTO;
import com.ruijie.rcos.base.sysmanage.module.def.dto.ScheduleTypeDTO;
import com.ruijie.rcos.base.sysmanage.module.def.enums.TaskCycle;
import com.ruijie.rcos.base.sysmanage.module.web.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.web.request.schedule.*;
import com.ruijie.rcos.base.sysmanage.module.web.vo.ScheduleResponseVO;
import com.ruijie.rcos.sk.base.batch.BatchTaskHandler;
import com.ruijie.rcos.sk.base.batch.BatchTaskItem;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.i18n.LocaleI18nResolver;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.test.GetSetTester;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultPageResponse;
import com.ruijie.rcos.sk.webmvc.api.optlog.ProgrammaticOptLogRecorder;
import com.ruijie.rcos.sk.webmvc.api.response.DefaultWebResponse;

import mockit.*;
import mockit.integration.junit4.JMockit;

@RunWith(JMockit.class)
public class ScheduleCtrlTest {

    @Tested
    private ScheduleCtrl scheduleCtrl;

    @Injectable
    private ScheduleAPI scheduleAPI;

    @Injectable
    private ProgrammaticOptLogRecorder logRecorder;

    private BatchTaskBuilderTest batchTaskBuilder = new BatchTaskBuilderTest();

    /**
     * 测试实体类
     */
    @Test
    public void testPojo() {

        GetSetTester getSetTester = new GetSetTester(BaseCreateScheduleWebRequest.class);
        getSetTester.runTest();
        getSetTester = new GetSetTester(BaseDeleteScheduleWebRequest.class);
        getSetTester.runTest();
        getSetTester = new GetSetTester(BaseEditScheduleWebRequest.class);
        getSetTester.runTest();
        getSetTester = new GetSetTester(BaseListTaskTypeWebRequest.class);
        getSetTester.runTest();
        getSetTester = new GetSetTester(BaseListTaskTypeWebRequest.class);
        getSetTester.runTest();
        getSetTester = new GetSetTester(BaseQueryScheduleWebRequest.class);
        getSetTester.runTest();

        getSetTester = new GetSetTester(ScheduleResponseVO.class);
        getSetTester.runTest();

        Assert.assertTrue(true);
    }

    /**
     * 测试创建一次性定时任务
     * 
     * @param webRequest 请求对象
     * @throws BusinessException 业务异常
     */
    @Test
    public void testCreateScheduleTaskByOnce(@Tested BaseCreateScheduleWebRequest webRequest) throws BusinessException {

        webRequest.setTaskCycle(TaskCycle.ONCE);
        webRequest.setScheduleTime("12:12:12");
        webRequest.setScheduleDate("2018-12-12");

        BaseQueryTaskTypeResponse apiResponse = new BaseQueryTaskTypeResponse();
        apiResponse.setLabel("label");

        new Expectations() {
            {
                scheduleAPI.queryTaskType((BaseQueryTaskTypeRequest) any);
                result = apiResponse;
                scheduleAPI.createSchedule((BaseCreateScheduleRequest) any);
                result = null;
            }
        };

        scheduleCtrl.createScheduleTask(webRequest, logRecorder);

        new Verifications() {
            {
                scheduleAPI.queryTaskType((BaseQueryTaskTypeRequest) any);
                times = 1;
                scheduleAPI.createSchedule((BaseCreateScheduleRequest) any);
                times = 1;
            }
        };
    }

    /**
     * 测试创建周周期任务
     * 
     * @param webRequest 请求对象
     * @throws BusinessException 业务异常
     */
    @Test
    public void testCreateScheduleTaskByWeek(@Mocked BaseCreateScheduleWebRequest webRequest) throws BusinessException {

        webRequest.setTaskCycle(TaskCycle.WEEK);
        webRequest.setScheduleTime("12:12:12");
        webRequest.setDayOfWeekArr(new Integer[] {1, 2});

        BaseQueryTaskTypeResponse apiResponse = new BaseQueryTaskTypeResponse();
        apiResponse.setLabel("label");

        new Expectations() {
            {
                scheduleAPI.queryTaskType((BaseQueryTaskTypeRequest) any);
                result = apiResponse;
                scheduleAPI.createSchedule((BaseCreateScheduleRequest) any);
                result = null;
            }
        };

        scheduleCtrl.createScheduleTask(webRequest, logRecorder);

        new Verifications() {
            {
                scheduleAPI.queryTaskType((BaseQueryTaskTypeRequest) any);
                times = 1;
                scheduleAPI.createSchedule((BaseCreateScheduleRequest) any);
                times = 1;
            }
        };
    }

    /**
     * 测试创建任务失败
     * 
     * @param webRequest 请求对象
     * @throws BusinessException 业务异常
     */
    @Test
    public void testCreateScheduleTaskApiFail(@Mocked BaseCreateScheduleWebRequest webRequest) throws BusinessException {

        webRequest.setTaskCycle(TaskCycle.DAY);
        webRequest.setScheduleTime("12:12:12");
        webRequest.setScheduleDate("2018-12-12");

        BaseQueryTaskTypeResponse apiResponse = new BaseQueryTaskTypeResponse();
        apiResponse.setLabel("label");

        new Expectations(LocaleI18nResolver.class) {
            {
                scheduleAPI.queryTaskType((BaseQueryTaskTypeRequest) any);
                result = apiResponse;
                scheduleAPI.createSchedule((BaseCreateScheduleRequest) any);
                result = new BusinessException(BusinessKey.BASE_SYS_MANAGE_BATCH_ITEM_FAIL);
                logRecorder.saveOptLog(anyString, anyString, anyString);
                LocaleI18nResolver.resolve(anyString);
                result = "";
            }
        };

        try {
            scheduleCtrl.createScheduleTask(webRequest, logRecorder);
            Assert.fail();
        } catch (BusinessException e) {
            Assert.assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_BATCH_ITEM_FAIL);
        }
    }


    /**
     * 测试删除定时任务
     * 
     * @param response 响应对象
     * @param baseListTaskTypeResponse 任务类型列表响应对象
     * @throws BusinessException 业务异常
     */
    @Test
    public void testDeleteScheduleTask(@Mocked BaseBatchQueryScheduleResponse response, @Mocked BaseListTaskTypeResponse baseListTaskTypeResponse)
            throws BusinessException {
        new MockUp<DefaultWebResponse.Builder>() {
            @Mock
            public DefaultWebResponse success(Object content) {
                //
                return null;
            }
        };
        BaseDeleteScheduleWebRequest webRequest = new BaseDeleteScheduleWebRequest();
        webRequest.setIdArr(new UUID[] {UUID.randomUUID(), UUID.randomUUID()});
        Map<UUID, UUID> taskId2taskTypeIdMap = Arrays.stream(webRequest.getIdArr()).collect(Collectors.toMap(item -> item, item -> item));
        Map<UUID, String> taskType2NameMap = Arrays.stream(webRequest.getIdArr()).collect(Collectors.toMap(item -> item, item -> item.toString()));

        new Expectations() {
            {
                scheduleAPI.batchQueryTask((BaseBatchQueryScheduleRequest) any);
                result = response;
                response.toTaskIdTaskTypeIdMap();
                result = taskId2taskTypeIdMap;
                scheduleAPI.deleteSchedule((BaseDeleteScheduleRequest) any);
                scheduleAPI.listTaskType((BaseListTaskTypeRequest) any);
                result = baseListTaskTypeResponse;
                baseListTaskTypeResponse.toIdLabelMap();
                result = taskType2NameMap;
            }
        };

        scheduleCtrl.deleteSchedule(webRequest, batchTaskBuilder, logRecorder);

        new Verifications() {
            {
                batchTaskBuilder.setTaskName(anyString);
                times = 1;
                batchTaskBuilder.setTaskDesc(anyString);
                times = 1;
                batchTaskBuilder.registerHandler((BatchTaskHandler<BatchTaskItem>) any);
                times = 1;

            }
        };

        batchTaskBuilder.assertResult(2, 0, BusinessKey.BASE_SYS_MANAGE_BATCH_ITEM_DELETE, BusinessKey.BASE_SYS_MANAGE_BATCH_ITEM_DELETE);
    }

    /**
     * 测试删除定时任务当查不到时
     * 
     * @param baseBatchQueryScheduleResponse 查询任务列表响应对象
     */
    @Test
    public void testDeleteScheduleTaskWhileQueryNot(@Mocked BaseBatchQueryScheduleResponse baseBatchQueryScheduleResponse) {
        BaseDeleteScheduleWebRequest webRequest = new BaseDeleteScheduleWebRequest();
        webRequest.setIdArr(new UUID[] {});
        new MockUp<ScheduleCtrl>() {
            Map<UUID, String> getScheduleTypeToScheduleTypeNameMap() {
                return new HashMap<>();
            }
        };
        new Expectations() {
            {
                scheduleAPI.batchQueryTask((BaseBatchQueryScheduleRequest) any);
                result = baseBatchQueryScheduleResponse;
            }
        };
        try {
            scheduleCtrl.deleteSchedule(webRequest, batchTaskBuilder, logRecorder);
            Assert.fail();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), BusinessKey.BASE_SYS_MANAGE_BATCH_DELETE_TASK_ALL_NOT_EXIST);
        }
    }

    /**
     * 测试删除定时任务失败
     * 
     * @param response 响应对象
     * @param baseListTaskTypeResponse 任务类型列表响应对象
     * @throws BusinessException 业务异常
     */
    @Test
    public void testDeleteScheduleTaskFail(@Mocked BaseBatchQueryScheduleResponse response, @Mocked BaseListTaskTypeResponse baseListTaskTypeResponse)
            throws BusinessException {
        new MockUp<DefaultWebResponse.Builder>() {
            @Mock
            public DefaultWebResponse success(Object content) {
                //
                return null;
            }
        };
        BaseDeleteScheduleWebRequest webRequest = new BaseDeleteScheduleWebRequest();
        webRequest.setIdArr(new UUID[] {UUID.randomUUID(), UUID.randomUUID()});
        Map<UUID, UUID> taskId2taskTypeIdMap = Arrays.stream(webRequest.getIdArr()).collect(Collectors.toMap(item -> item, item -> item));
        Map<UUID, String> taskType2NameMap = Arrays.stream(webRequest.getIdArr()).collect(Collectors.toMap(item -> item, item -> item.toString()));


        new Expectations(LocaleI18nResolver.class) {
            {
                scheduleAPI.batchQueryTask((BaseBatchQueryScheduleRequest) any);
                result = response;
                response.toTaskIdTaskTypeIdMap();
                result = taskId2taskTypeIdMap;
                scheduleAPI.listTaskType((BaseListTaskTypeRequest) any);
                result = baseListTaskTypeResponse;
                baseListTaskTypeResponse.toIdLabelMap();
                result = taskType2NameMap;
                scheduleAPI.deleteSchedule((BaseDeleteScheduleRequest) any);
                result = new BusinessException(BusinessKey.BASE_SYS_MANAGE_BATCH_ITEM_FAIL);
                LocaleI18nResolver.resolve(anyString);
            }
        };

        scheduleCtrl.deleteSchedule(webRequest, batchTaskBuilder, logRecorder);

        new Verifications() {
            {
                scheduleAPI.deleteSchedule((BaseDeleteScheduleRequest) any);
                times = 2;
            }
        };

        batchTaskBuilder.assertResult(0, 2, BusinessKey.BASE_SYS_MANAGE_BATCH_ITEM_FAIL, BusinessKey.BASE_SYS_MANAGE_BATCH_ITEM_FAIL);
    }


    /**
     * 测试查询定时任务
     * 
     * @param webRequest 请求对象
     * @throws BusinessException 业务异常
     */
    @Test
    public void testQueryScheduleTask(@Tested BaseQueryScheduleWebRequest webRequest) throws BusinessException {

        BaseQueryScheduleResponse apiResponse = new BaseQueryScheduleResponse();
        apiResponse.setTaskCycle(TaskCycle.DAY);
        apiResponse.setScheduleTime(LocalTime.now().format(DateTimeFormatter.ofPattern("hh:mm:ss")));
        apiResponse.setScheduleDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));

        new Expectations() {
            {
                scheduleAPI.querySchedule((BaseQueryScheduleRequest) any);
                result = apiResponse;
            }
        };

        scheduleCtrl.queryScheduleTask(webRequest);

        new Verifications() {
            {
                scheduleAPI.querySchedule((BaseQueryScheduleRequest) any);
                times = 1;
            }
        };
    }

    /**
     * 测试查询定时任务当时间为空时
     * 
     * @param webRequest 请求对象
     * @throws BusinessException 业务异常
     */
    @Test
    public void testQueryScheduleTaskDateNull(@Tested BaseQueryScheduleWebRequest webRequest) throws BusinessException {

        BaseQueryScheduleResponse apiResponse = new BaseQueryScheduleResponse();
        apiResponse.setTaskCycle(TaskCycle.DAY);
        apiResponse.setScheduleTime("10:10:10");
        apiResponse.setScheduleDate(null);

        new Expectations() {
            {
                scheduleAPI.querySchedule((BaseQueryScheduleRequest) any);
            }
        };

        scheduleCtrl.queryScheduleTask(webRequest);

        new Verifications() {
            {
                scheduleAPI.querySchedule((BaseQueryScheduleRequest) any);
                times = 1;
            }
        };
    }


    /**
     * 测试编辑定时任务
     * 
     * @param webRequest 请求对象
     * @throws BusinessException 业务异常
     */
    @Test
    public void testEditScheduleTask(@Tested BaseEditScheduleWebRequest webRequest) throws BusinessException {

        UUID id = UUID.randomUUID();
        UUID taskId = UUID.randomUUID();
        webRequest.setId(id);
        webRequest.setTaskCycle(TaskCycle.DAY);
        webRequest.setScheduleTime("11:11:11");
        webRequest.setTaskTypeId(taskId);

        BaseQueryTaskTypeResponse taskTypeResponse = new BaseQueryTaskTypeResponse();
        taskTypeResponse.setLabel("label");

        new Expectations() {
            {
                scheduleAPI.editSchedule((BaseEditScheduleRequest) any);
                result = null;
                scheduleAPI.queryTaskType((BaseQueryTaskTypeRequest) any);
                result = taskTypeResponse;
            }
        };

        scheduleCtrl.editSchedule(webRequest, logRecorder);

        new Verifications() {
            {
                scheduleAPI.editSchedule((BaseEditScheduleRequest) any);
                times = 1;
            }
        };
    }

    /**
     * 测试编辑一次性任务
     * 
     * @param webRequest 请求对象
     * @throws BusinessException 业务异常
     */
    @Test
    public void testEditScheduleTaskOnce(@Tested BaseEditScheduleWebRequest webRequest) throws BusinessException {

        UUID id = UUID.randomUUID();
        UUID taskId = UUID.randomUUID();
        webRequest.setId(id);
        webRequest.setTaskCycle(TaskCycle.ONCE);
        webRequest.setScheduleTime("11:11:11");
        webRequest.setScheduleDate("2018-12-12");
        webRequest.setTaskTypeId(taskId);

        BaseQueryTaskTypeResponse taskTypeResponse = new BaseQueryTaskTypeResponse();
        taskTypeResponse.setLabel("label");

        new Expectations() {
            {
                scheduleAPI.editSchedule((BaseEditScheduleRequest) any);
                result = null;
                scheduleAPI.queryTaskType((BaseQueryTaskTypeRequest) any);
                result = taskTypeResponse;
            }
        };

        scheduleCtrl.editSchedule(webRequest, logRecorder);

        new Verifications() {
            {
                scheduleAPI.editSchedule((BaseEditScheduleRequest) any);
                times = 1;
            }
        };
    }

    /**
     * 测试编辑定时任务失败情况
     * 
     * @param webRequest 请求对象
     * @throws BusinessException 业务异常
     */
    @Test
    public void testEditScheduleTaskApiFail(@Tested BaseEditScheduleWebRequest webRequest) throws BusinessException {

        UUID id = UUID.randomUUID();
        UUID taskId = UUID.randomUUID();
        webRequest.setId(id);
        webRequest.setTaskCycle(TaskCycle.ONCE);
        webRequest.setScheduleTime("11:11:11");
        webRequest.setScheduleDate("2018-12-12");
        webRequest.setTaskTypeId(taskId);

        BaseQueryTaskTypeResponse taskTypeResponse = new BaseQueryTaskTypeResponse();
        taskTypeResponse.setLabel("label");

        new Expectations(LocaleI18nResolver.class) {
            {
                scheduleAPI.editSchedule((BaseEditScheduleRequest) any);
                result = new BusinessException(BusinessKey.BASE_SYS_MANAGE_BATCH_ITEM_FAIL);
                scheduleAPI.queryTaskType((BaseQueryTaskTypeRequest) any);
                result = taskTypeResponse;
                logRecorder.saveOptLog(anyString, anyString, anyString);
                LocaleI18nResolver.resolve(anyString);
                result = "";
            }
        };

        try {
            scheduleCtrl.editSchedule(webRequest, logRecorder);
            Assert.fail();
        } catch (BusinessException e) {
            Assert.assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_BATCH_ITEM_FAIL);
        }

    }


    /**
     * 测试获取定时任务列表
     * 
     * @param webRequest 请求对象
     * @throws BusinessException 业务异常
     */
    @Test
    public void testListSchedule(@Mocked BaseListScheduleWebRequest webRequest) throws BusinessException {

        int limit = 10;
        int total = 100;

        List<ScheduleDTO> scheduleDTOList = new ArrayList<>();
        List<ScheduleTypeDTO> scheduleTypeDTOList = new ArrayList<>();

        for (int i = 0; i < limit; i++) {

            UUID taskTypeID = UUID.randomUUID();

            ScheduleDTO scheduleDTO = new ScheduleDTO();
            scheduleDTO.setId(UUID.randomUUID());
            scheduleDTO.setTaskTypeId(taskTypeID);
            scheduleDTO.setScheduleDate("2018-10-10");
            scheduleDTO.setScheduleTime("12:12:12");
            scheduleDTOList.add(scheduleDTO);

            ScheduleTypeDTO scheduleTypeDTO = new ScheduleTypeDTO();
            scheduleTypeDTO.setId(taskTypeID);
            scheduleTypeDTO.setLabel("label" + i);
            scheduleTypeDTOList.add(scheduleTypeDTO);
        }
        DefaultPageResponse<ScheduleDTO> pageResponse = new DefaultPageResponse<>();
        pageResponse.setTotal(total);
        pageResponse.setItemArr(scheduleDTOList.toArray(new ScheduleDTO[0]));

        BaseListTaskTypeResponse baseListTaskTypeResponse = new BaseListTaskTypeResponse();
        baseListTaskTypeResponse.setItemArr(scheduleTypeDTOList.toArray(new ScheduleTypeDTO[0]));

        new Expectations() {
            {
                scheduleAPI.listSchedule((BaseListScheduleRequest) any);
                result = pageResponse;
                scheduleAPI.listTaskType((BaseListTaskTypeRequest) any);
                result = baseListTaskTypeResponse;
            }
        };


        DefaultWebResponse response = scheduleCtrl.listSchedule(webRequest);
        DefaultPageResponse<ScheduleDTO> content = (DefaultPageResponse<ScheduleDTO>) response.getContent();
        Assert.assertEquals(content.getTotal(), total);
        ScheduleDTO[] scheduleResponseVOArr = content.getItemArr();
        for (int i = 0; i < limit; i++) {
            ScheduleDTO scheduleDTO = scheduleResponseVOArr[i];
            ScheduleTypeDTO scheduleTypeDTO = scheduleTypeDTOList.get(i);
            Assert.assertEquals(scheduleDTO.getTaskTypeName(), scheduleTypeDTO.getLabel());
        }
    }


    /**
     * 测试获取定时任务列表
     * 
     * @param webRequest 请求对象
     * @throws BusinessException 业务异常
     */
    @Test
    public void testListScheduleTask(@Tested BaseListTaskTypeWebRequest webRequest) throws BusinessException {

        int size = 10;

        List<ScheduleTypeDTO> scheduleTypeDTOList = new ArrayList<>();

        for (int i = 0; i < size; i++) {

            UUID taskTypeID = UUID.randomUUID();

            ScheduleTypeDTO scheduleTypeDTO = new ScheduleTypeDTO();
            scheduleTypeDTO.setId(taskTypeID);
            scheduleTypeDTO.setLabel("label" + i);
            scheduleTypeDTOList.add(scheduleTypeDTO);
        }

        BaseListTaskTypeResponse baseListTaskTypeResponse = new BaseListTaskTypeResponse();
        baseListTaskTypeResponse.setItemArr(scheduleTypeDTOList.toArray(new ScheduleTypeDTO[0]));

        new Expectations() {
            {
                scheduleAPI.listTaskType((BaseListTaskTypeRequest) any);
                result = baseListTaskTypeResponse;
            }
        };


        DefaultWebResponse response = scheduleCtrl.listTaskType(webRequest);
        BaseListTaskTypeResponse content = (BaseListTaskTypeResponse) response.getContent();
        Assert.assertEquals(content.getItemArr().length, size);
    }


    /**
     * 测试创建一次性定时任务当开启debug日志输出级别时
     * 
     * @param logger 日志对象
     * @throws BusinessException 业务异常
     */
    @Test
    public void testCreateScheduleTaskByOnceDebug(@Capturing Logger logger) throws BusinessException {

        new Expectations() {
            {
                logger.isDebugEnabled();
                result = true;
            }
        };

        testCreateScheduleTaskByOnce(new BaseCreateScheduleWebRequest());

        new Verifications() {
            {
                logger.isDebugEnabled();
                times = 1;
            }
        };
    }


    /**
     * 测试删除定时任务当debug级别开启时
     * 
     * @param logger 日志对象
     * @param response 响应对象
     * @param baseListTaskTypeResponse 任务类型列表响应对象
     * @throws BusinessException 业务异常
     */
    @Test
    public void testDeleteScheduleTaskDebug(@Capturing Logger logger, @Mocked BaseBatchQueryScheduleResponse response,
            @Mocked BaseListTaskTypeResponse baseListTaskTypeResponse) throws BusinessException {
        new MockUp<DefaultWebResponse.Builder>() {
            @Mock
            public DefaultWebResponse success(Object content) {
                //
                return null;
            }
        };
        new Expectations() {
            {
                logger.isDebugEnabled();
                result = true;
            }
        };

        testDeleteScheduleTask(response, baseListTaskTypeResponse);

        new Verifications() {
            {
                logger.debug("删除定时器请求开始：{}", any);
                times = 1;
            }
        };
    }

    /**
     * 测试查询定时任务当开启debug日志级别
     * 
     * @param logger 日志对象
     * @throws BusinessException 业务异常
     */
    @Test
    public void testQueryScheduleTaskDebug(@Capturing Logger logger) throws BusinessException {

        new Expectations() {
            {
                logger.isDebugEnabled();
                result = true;
            }
        };

        testQueryScheduleTask(new BaseQueryScheduleWebRequest());

        new Verifications() {
            {
                logger.isDebugEnabled();
                times = 2;
            }
        };
    }

    /**
     * 测试编辑定时任务当日志级别为debug时
     * 
     * @param logger 日志对象
     * @throws BusinessException 业务异常
     */
    @Test
    public void testEditScheduleTaskDebug(@Capturing Logger logger) throws BusinessException {

        new Expectations() {
            {
                logger.isDebugEnabled();
                result = true;
            }
        };

        testEditScheduleTask(new BaseEditScheduleWebRequest());

        new Verifications() {
            {
                logger.isDebugEnabled();
                times = 2;
            }
        };
    }

    /**
     * 测试获取定时任务列表当日志输出级别为debug
     * 
     * @param logger 日志对象
     * @throws BusinessException 业务异常
     */
    @Test
    public void testListScheduleDebug(@Capturing Logger logger) throws BusinessException {

        new Expectations() {
            {
                logger.isDebugEnabled();
                result = true;
            }
        };

        testListSchedule(new BaseListScheduleWebRequest());

        new Verifications() {
            {
                logger.isDebugEnabled();
                times = 3;
            }
        };
    }

    /**
     * 测试获取定时任务列表当日志级别为debug
     * 
     * @param logger 日志对象
     * @throws BusinessException 业务异常
     */
    @Test
    public void testListScheduleTaskDebug(@Capturing Logger logger) throws BusinessException {

        new Expectations() {
            {
                logger.isDebugEnabled();
                result = true;
            }
        };

        testListScheduleTask(new BaseListTaskTypeWebRequest());

        new Verifications() {
            {
                logger.isDebugEnabled();
                times = 1;
            }
        };
    }


}
