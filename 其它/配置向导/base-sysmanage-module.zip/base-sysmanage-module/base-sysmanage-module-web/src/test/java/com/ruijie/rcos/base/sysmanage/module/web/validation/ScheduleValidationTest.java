package com.ruijie.rcos.base.sysmanage.module.web.validation;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.ruijie.rcos.base.sysmanage.module.def.common.Constant;
import com.ruijie.rcos.base.sysmanage.module.def.enums.TaskCycle;
import com.ruijie.rcos.base.sysmanage.module.web.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.web.request.schedule.BaseCreateScheduleWebRequest;
import com.ruijie.rcos.base.sysmanage.module.web.request.schedule.BaseEditScheduleWebRequest;
import com.ruijie.rcos.sk.base.exception.BusinessException;

import mockit.Tested;
import mockit.Verifications;
import mockit.integration.junit4.JMockit;

/**
 * Description:
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月25日
 *
 * @author fyq
 */

@RunWith(JMockit.class)
public class ScheduleValidationTest {

    @Tested
    private ScheduleValidation scheduleValidation;

    /**
     * 创建计划任务按日错误时间验证
     * 
     * @param webRequest 请求
     */
    @Test
    public void testCreateScheduleTaskValidateByDayBadTime(@Tested BaseCreateScheduleWebRequest webRequest) {
        webRequest.setTaskCycle(TaskCycle.DAY);
        webRequest.setScheduleTime("12");

        try {
            scheduleValidation.createScheduleTaskValidate(webRequest);
            Assert.fail();
        } catch (BusinessException e) {
            Assert.assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_ILLEGAL_TIME_FORMAT);
        }
    }

    /**
     * 创建计划任务按天验证
     * 
     * @param webRequest 请求
     * @throws BusinessException 异常
     */
    @Test
    public void testCreateScheduleTaskValidateByDay(@Tested BaseCreateScheduleWebRequest webRequest) throws BusinessException {
        webRequest.setTaskCycle(TaskCycle.DAY);
        webRequest.setScheduleTime("12:12:12");

        scheduleValidation.createScheduleTaskValidate(webRequest);

        new Verifications() {
            {
                LocalTime.parse("12:12:12", DateTimeFormatter.ofPattern(Constant.HH_MM_SS));
                times = 1;
            }
        };
    }

    /**
     * 创建计划任务一次验证日期为空
     * 
     * @param webRequest 请求
     */
    @Test
    public void testCreateScheduleTaskValidateByOnceDateEmpty(@Tested BaseCreateScheduleWebRequest webRequest) {
        webRequest.setTaskCycle(TaskCycle.ONCE);
        webRequest.setScheduleTime("12:12:12");
        webRequest.setScheduleDate("");

        try {
            scheduleValidation.createScheduleTaskValidate(webRequest);
            Assert.fail();
        } catch (BusinessException e) {
            Assert.assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_ARG_NOT_EMPTY);
        }
    }

    /**
     * 创建计划任务验证一次错误日期
     * 
     * @param webRequest 请求
     */
    @Test
    public void testCreateScheduleTaskValidateByOnceBadDate(@Tested BaseCreateScheduleWebRequest webRequest) {
        webRequest.setTaskCycle(TaskCycle.ONCE);
        webRequest.setScheduleTime("12:12:12");
        webRequest.setScheduleDate("2018-12");

        try {
            scheduleValidation.createScheduleTaskValidate(webRequest);
            Assert.fail();
        } catch (BusinessException e) {
            Assert.assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_ILLEGAL_DATE_FORMAT);
        }
    }

    /**
     * 创建计划任务一次验证
     * 
     * @param webRequest 请求
     * @throws BusinessException 异常
     */
    @Test
    public void testCreateScheduleTaskValidateByOnce(@Tested BaseCreateScheduleWebRequest webRequest) throws BusinessException {
        webRequest.setTaskCycle(TaskCycle.ONCE);
        webRequest.setScheduleTime("12:12:12");
        webRequest.setScheduleDate("2018-12-12");

        scheduleValidation.createScheduleTaskValidate(webRequest);

        new Verifications() {
            {
                LocalDate.parse("2018-12-12", DateTimeFormatter.ofPattern(Constant.YYYY_MM_DD));
                times = 1;
            }
        };
    }

    /**
     * 创建计划任务按周清空
     * 
     * @param webRequest 请求
     */
    @Test
    public void testCreateScheduleTaskValidateByWeekEmpty(@Tested BaseCreateScheduleWebRequest webRequest) {
        webRequest.setTaskCycle(TaskCycle.WEEK);
        webRequest.setScheduleTime("12:12:12");
        webRequest.setDayOfWeekArr(new Integer[] {});

        try {
            scheduleValidation.createScheduleTaskValidate(webRequest);
            Assert.fail();
        } catch (BusinessException e) {
            Assert.assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_ARG_NOT_EMPTY);
        }
    }

    /**
     * 创建计划任务按周验证包含空
     * 
     * @param webRequest 请求
     */
    @Test
    public void testCreateScheduleTaskValidateByWeekContainEmpty(@Tested BaseCreateScheduleWebRequest webRequest) {
        webRequest.setTaskCycle(TaskCycle.WEEK);
        webRequest.setScheduleTime("12:12:12");
        webRequest.setDayOfWeekArr(new Integer[] {null, 1});

        try {
            scheduleValidation.createScheduleTaskValidate(webRequest);
            Assert.fail();
        } catch (BusinessException e) {
            Assert.assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_ARG_NOT_CONTAIN_EMPTY);
        }
    }

    /**
     * 创建计划任务按周进行验证包含周
     * 
     * @param webRequest 请求
     */
    @Test
    public void testCreateScheduleTaskValidateByWeekContainOutWeek(@Tested BaseCreateScheduleWebRequest webRequest) {
        webRequest.setTaskCycle(TaskCycle.WEEK);
        webRequest.setScheduleTime("12:12:12");
        webRequest.setDayOfWeekArr(new Integer[] {1, 2, 8});

        try {
            scheduleValidation.createScheduleTaskValidate(webRequest);
            Assert.fail();
        } catch (BusinessException e) {
            Assert.assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_WEEK_ARG_RANGE_ERROR);
        }
    }

    /**
     * 创建计划任务按周验证包含周
     * 
     * @param webRequest 请求
     */
    @Test
    public void testCreateScheduleTaskValidateByWeekContainOutWeekLeft(@Tested BaseCreateScheduleWebRequest webRequest) {
        webRequest.setTaskCycle(TaskCycle.WEEK);
        webRequest.setScheduleTime("12:12:12");
        webRequest.setDayOfWeekArr(new Integer[] {1, 2, -1});

        try {
            scheduleValidation.createScheduleTaskValidate(webRequest);
            Assert.fail();
        } catch (BusinessException e) {
            Assert.assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_WEEK_ARG_RANGE_ERROR);
        }
    }

    /**
     * 创建计划任务按周验证
     * 
     * @param webRequest 请求
     * @throws BusinessException 异常
     */
    @Test
    public void testCreateScheduleTaskValidateByWeek(@Tested BaseCreateScheduleWebRequest webRequest) throws BusinessException {
        webRequest.setTaskCycle(TaskCycle.WEEK);
        webRequest.setScheduleTime("12:12:12");
        webRequest.setDayOfWeekArr(new Integer[] {1, 2, 7});

        scheduleValidation.createScheduleTaskValidate(webRequest);

        Assert.assertTrue(true);
    }

    /**
     * 编辑计划验证
     * 
     * @param webRequest 请求
     * @throws BusinessException 异常
     */
    @Test
    public void testEditScheduleValidate(@Tested BaseEditScheduleWebRequest webRequest) throws BusinessException {
        webRequest.setTaskCycle(TaskCycle.WEEK);
        webRequest.setScheduleTime("12:12:12");
        webRequest.setDayOfWeekArr(new Integer[] {1, 2, 7});

        scheduleValidation.editScheduleValidate(webRequest);

        Assert.assertTrue(true);
    }
}
