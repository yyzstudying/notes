package com.ruijie.rcos.base.sysmanage.module.web.ctrl;

import static org.junit.Assert.assertTrue;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.ruijie.rcos.base.sysmanage.module.def.api.NetworkAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.network.BaseDetailNetworkRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.network.BaseUpdateNetworkRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.network.BaseDetailNetworkInfoResponse;
import com.ruijie.rcos.base.sysmanage.module.def.dto.BaseNetworkDTO;
import com.ruijie.rcos.base.sysmanage.module.web.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.web.request.network.BaseDetailNetworkWebRequest;
import com.ruijie.rcos.base.sysmanage.module.web.request.network.BaseUpdateNetworkWebRequest;
import com.ruijie.rcos.base.sysmanage.module.web.request.systemtime.BaseGetSystemTimeWebRequest;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.test.GetSetTester;
import com.ruijie.rcos.sk.webmvc.api.optlog.ProgrammaticOptLogRecorder;

import mockit.*;
import mockit.integration.junit4.JMockit;

/**
 * Description: 网卡操作Controller
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月25日
 *
 * @author fyq
 */

@RunWith(JMockit.class)
public class NetworkCtrlTest {

    @Tested
    private NetworkCtrl networkCtrl;

    @Injectable
    private NetworkAPI networkAPI;

    @Mocked
    private ProgrammaticOptLogRecorder optLogRecorder;

    /**
     * 实体
     */
    @Test
    public void testPojo() {

        GetSetTester tester = new GetSetTester(BaseGetSystemTimeWebRequest.class);
        tester.runTest();

        tester = new GetSetTester(BaseUpdateNetworkWebRequest.class);
        tester.runTest();

        assertTrue(true);
    }

    /**
     * 获取网络初始化
     * 
     * @param webRequest 请求
     * @throws BusinessException 异常
     */
    @Test
    public void testGetNetworkInfo(@Tested BaseDetailNetworkWebRequest webRequest) throws BusinessException {

        BaseDetailNetworkInfoResponse apiResponse = new BaseDetailNetworkInfoResponse();
        apiResponse.setNetworkDTO(new BaseNetworkDTO());

        new Expectations() {
            {
                networkAPI.detailNetwork((BaseDetailNetworkRequest) any);
                result = apiResponse;
            }
        };

        networkCtrl.getNetworkInfo(webRequest);

        new Verifications() {
            {
                networkAPI.detailNetwork((BaseDetailNetworkRequest) any);
                times = 1;
            }
        };
    }

    /**
     * 更新网络信息
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testUpdateNetworkInfo() throws BusinessException {

        BaseUpdateNetworkWebRequest webRequest = new BaseUpdateNetworkWebRequest();
        webRequest.setIp("192.168.1.2");
        webRequest.setNetmask("255.255.255.0");
        webRequest.setGateway("192.168.1.1");
        webRequest.setDns("114.114.114");

        new Expectations() {
            {
                networkAPI.updateNetwork((BaseUpdateNetworkRequest) any);
                result = null;
            }
        };

        networkCtrl.updateNetwork(webRequest, optLogRecorder);

        new Verifications() {
            {
                networkAPI.updateNetwork((BaseUpdateNetworkRequest) any);
                times = 1;
            }
        };
    }

    /**
     * 更新网络信息 失败
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testUpdateNetworkInfoApiFail() throws BusinessException {

        BaseUpdateNetworkWebRequest webRequest = new BaseUpdateNetworkWebRequest();
        webRequest.setIp("192.168.1.2");
        webRequest.setNetmask("255.255.255.0");
        webRequest.setGateway("192.168.1.1");
        webRequest.setDns("114.114.114");

        new MockUp<BusinessException>() {
            @Mock
            public String getI18nMessage() {
                return BusinessKey.BASE_SYS_MANAGE_NETWORK_UPDATE_FAIL;
            }
        };

        new Expectations() {
            {
                networkAPI.updateNetwork((BaseUpdateNetworkRequest) any);
                result = new BusinessException(BusinessKey.BASE_SYS_MANAGE_NETWORK_UPDATE_FAIL);
            }
        };

        try {
            networkCtrl.updateNetwork(webRequest, optLogRecorder);
            Assert.fail();
        } catch (BusinessException e) {
            Assert.assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_NETWORK_UPDATE_FAIL);
        }

        new Verifications() {
            {
                networkAPI.updateNetwork((BaseUpdateNetworkRequest) any);
                times = 1;
                optLogRecorder.saveOptLog(BusinessKey.BASE_SYS_MANAGE_NETWORK_UPDATE_FAIL, BusinessKey.BASE_SYS_MANAGE_NETWORK_UPDATE_FAIL);
                times = 1;
            }
        };
    }
}
