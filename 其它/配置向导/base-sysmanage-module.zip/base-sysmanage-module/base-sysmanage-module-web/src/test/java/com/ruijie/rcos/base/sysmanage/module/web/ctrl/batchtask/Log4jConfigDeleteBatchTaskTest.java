package com.ruijie.rcos.base.sysmanage.module.web.ctrl.batchtask;

import java.util.Iterator;
import java.util.UUID;

import com.ruijie.rcos.base.sysmanage.module.def.api.response.log4j.BaseDeleteLog4jConfigResponse;
import com.ruijie.rcos.base.sysmanage.module.web.BusinessKey;
import com.ruijie.rcos.sk.base.batch.BatchTaskFinishResult;
import com.ruijie.rcos.sk.base.batch.BatchTaskStatus;
import org.junit.Test;

import com.ruijie.rcos.base.sysmanage.module.def.api.Log4jConfigAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.log4jconfig.BaseRemoveLog4jConfigRequest;
import com.ruijie.rcos.sk.base.batch.BatchTaskItem;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.webmvc.api.optlog.ProgrammaticOptLogRecorder;

import mockit.*;

import static org.junit.Assert.assertEquals;

/**
 * Description: 批量删除log4j配置任务handler
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月16日
 *
 * @author GuoZhouYue
 */
public class Log4jConfigDeleteBatchTaskTest {

    @Tested
    private Log4jConfigDeleteBatchTask log4jConfigDeleteBatchTask;

    @Injectable
    private Iterator<BatchTaskItem> iterator;

    @Injectable
    private Log4jConfigAPI log4jConfigAPI;

    @Mocked
    @Injectable
    private ProgrammaticOptLogRecorder logRecorder;

    @Test
    public void testProcessItem(@Injectable BatchTaskItem batchTaskItem, @Injectable BaseDeleteLog4jConfigResponse response) throws BusinessException {
        new Expectations() {
            {
                batchTaskItem.getItemID();
                result = UUID.randomUUID();

                log4jConfigAPI.removeConfig((BaseRemoveLog4jConfigRequest) any);
                result = response;

                response.getLoggerName();
                result = "loggerName";
            }
        };

        log4jConfigDeleteBatchTask.processItem(batchTaskItem);

        new Verifications() {
            {
                batchTaskItem.getItemID();
                times = 1;

                log4jConfigAPI.removeConfig((BaseRemoveLog4jConfigRequest) any);
                times = 1;

                response.getLoggerName();
                times = 1;
            }
        };
    }

    @Test(expected = BusinessException.class)
    public void testProcessItemBusizExp(@Injectable BatchTaskItem batchTaskItem) throws BusinessException {
        new Expectations() {
            {
                batchTaskItem.getItemID();
                result = UUID.randomUUID();

                log4jConfigAPI.removeConfig((BaseRemoveLog4jConfigRequest) any);
                result = new BusinessException(BusinessKey.BASE_SYS_MANAGE_LOG4J_CONFIG_DELETE);
            }
        };

        new MockUp<BusinessException>() {
            @Mock
            public String getI18nMessage() {
                return "";
            }
        };

        log4jConfigDeleteBatchTask.processItem(batchTaskItem);

        new Verifications() {
            {
                batchTaskItem.getItemID();
                times = 1;

                log4jConfigAPI.removeConfig((BaseRemoveLog4jConfigRequest) any);
                times = 1;
            }
        };
    }

    @Test
    public void testOnFinish() {
        BatchTaskFinishResult result = log4jConfigDeleteBatchTask.onFinish(1, 0);

        assertEquals(BatchTaskStatus.SUCCESS, result.getStatus());
        assertEquals(BusinessKey.BASE_SYS_MANAGE_LOG4J_CONFIG_BATCH_DELETE_RESULT, result.getMsgKey());
        assertEquals(2, result.getMsgArgs().length);
        assertEquals("1", result.getMsgArgs()[0]);
        assertEquals("0", result.getMsgArgs()[1]);
    }
}
