package com.ruijie.rcos.base.sysmanage.module.web.ctrl;

import static org.junit.Assert.assertTrue;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.ruijie.rcos.base.sysmanage.module.def.api.NetworkAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.SystemTimeAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.systemtime.BaseUpdateSystemTimeFromNtpRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.systemtime.BaseUpdateSystemTimeRequest;
import com.ruijie.rcos.base.sysmanage.module.def.dto.BaseNetworkDTO;
import com.ruijie.rcos.base.sysmanage.module.web.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.web.enums.SystemTimeConfigType;
import com.ruijie.rcos.base.sysmanage.module.web.request.systemtime.BaseGetSystemTimeWebRequest;
import com.ruijie.rcos.base.sysmanage.module.web.request.systemtime.BaseUpdateSystemTimeWebRequest;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.test.GetSetTester;
import com.ruijie.rcos.sk.webmvc.api.optlog.ProgrammaticOptLogRecorder;

import mockit.*;
import mockit.integration.junit4.JMockit;

/**
 * Description: 系统时间操作Controller
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月25日
 *
 * @author fyq
 */

@RunWith(JMockit.class)
public class SystemTimeCtrlTest {

    @Tested
    private SystemTimeCtrl systemTimeCtrl;

    @Injectable
    private SystemTimeAPI systemTimeAPI;

    @Injectable
    private NetworkAPI networkAPI;

    @Mocked
    private ProgrammaticOptLogRecorder logRecorder;

    @Capturing
    private BaseNetworkDTO baseNetworkDTO;

    /**
     * 实体
     */
    @Test
    public void testPojo() {

        GetSetTester tester = new GetSetTester(BaseUpdateSystemTimeWebRequest.class);
        tester.runTest();

        tester = new GetSetTester(BaseGetSystemTimeWebRequest.class);
        tester.runTest();

        assertTrue(true);
    }

    /**
     * 更新
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testUpdateSystemTime() throws BusinessException {

        BaseUpdateSystemTimeWebRequest webRequest = new BaseUpdateSystemTimeWebRequest();
        webRequest.setType(SystemTimeConfigType.SET);
        webRequest.setTime(System.currentTimeMillis());

        new Expectations() {
            {
                systemTimeAPI.updateSystemTime((BaseUpdateSystemTimeRequest) any);
            }
        };

        systemTimeCtrl.updateSystemTime(webRequest, logRecorder);

        new Verifications() {
            {
                systemTimeAPI.updateSystemTime((BaseUpdateSystemTimeRequest) any);
                times = 1;
            }
        };
    }

    /**
     * 更新失败
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testUpdateSystemTimeApiFail() throws BusinessException {

        BaseUpdateSystemTimeWebRequest webRequest = new BaseUpdateSystemTimeWebRequest();

        webRequest.setType(SystemTimeConfigType.SET);
        webRequest.setTime(System.currentTimeMillis());

        new MockUp<BusinessException>() {
            @Mock
            public String getI18nMessage() {
                return "";
            }
        };
        new Expectations() {
            {
                systemTimeAPI.updateSystemTime((BaseUpdateSystemTimeRequest) any);
                result = new BusinessException(BusinessKey.BASE_SYS_MANAGE_SYSTEM_TIME_UPDATE_FAIL);
            }
        };

        try {
            systemTimeCtrl.updateSystemTime(webRequest, logRecorder);
            Assert.fail();
        } catch (BusinessException e) {
            Assert.assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_SYSTEM_TIME_UPDATE_FAIL);
        }

        new Verifications() {
            {
                systemTimeAPI.updateSystemTime((BaseUpdateSystemTimeRequest) any);
                times = 1;
                logRecorder.saveOptLog(BusinessKey.BASE_SYS_MANAGE_SYSTEM_TIME_UPDATE_FAIL, anyString);
                times = 1;
            }
        };
    }

    /**
     * 更新系统时间 ntp
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testUpdateSystemTimeFromNtp() throws BusinessException {

        BaseUpdateSystemTimeWebRequest webRequest = new BaseUpdateSystemTimeWebRequest();
        webRequest.setType(SystemTimeConfigType.NTP);
        webRequest.setNtpServer("ntp://x.com");

        new Expectations() {
            {
                systemTimeAPI.updateSystemTimeFromNtp((BaseUpdateSystemTimeFromNtpRequest) any);
                baseNetworkDTO.getDns();
                result = "114.114.114.114";
            }
        };

        systemTimeCtrl.updateSystemTime(webRequest, logRecorder);

        new Verifications() {
            {
                systemTimeAPI.updateSystemTimeFromNtp((BaseUpdateSystemTimeFromNtpRequest) any);
                times = 1;
            }
        };
    }

    /**
     * 更新失败 ntp
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testUpdateSystemTimeFromNtpApiFail() throws BusinessException {

        BaseUpdateSystemTimeWebRequest webRequest = new BaseUpdateSystemTimeWebRequest();
        webRequest.setType(SystemTimeConfigType.NTP);
        webRequest.setNtpServer("ntp://x.com");

        new MockUp<BusinessException>() {
            @Mock
            public String getI18nMessage() {
                return "";
            }
        };
        new Expectations() {
            {
                systemTimeAPI.updateSystemTimeFromNtp((BaseUpdateSystemTimeFromNtpRequest) any);
                result = new BusinessException(BusinessKey.BASE_SYS_MANAGE_SYSTEM_TIME_UPDATE_FROM_NTP_FAIL);
                baseNetworkDTO.getDns();
                result = "114.114.114.114";
            }
        };

        try {
            systemTimeCtrl.updateSystemTime(webRequest, logRecorder);
            Assert.fail();
        } catch (BusinessException e) {
            Assert.assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_SYSTEM_TIME_UPDATE_FROM_NTP_FAIL);
        }

        new Verifications() {
            {
                systemTimeAPI.updateSystemTimeFromNtp((BaseUpdateSystemTimeFromNtpRequest) any);
                times = 1;
                logRecorder.saveOptLog(BusinessKey.BASE_SYS_MANAGE_SYSTEM_TIME_UPDATE_FROM_NTP_FAIL, anyString);
                times = 1;
            }
        };
    }

    /**
     * 获取系统时间
     */
    @Test
    public void testGetSystemTime() {

        BaseGetSystemTimeWebRequest webRequest = new BaseGetSystemTimeWebRequest();

        systemTimeCtrl.getSystemTime(webRequest);

        new Verifications() {
            {
                System.currentTimeMillis();
                times = 1;
            }
        };
    }

}
