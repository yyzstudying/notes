package com.ruijie.rcos.base.sysmanage.module.web.ctrl;

import static org.junit.Assert.assertTrue;

import java.util.UUID;

import com.ruijie.rcos.sk.base.batch.BatchTaskStatus;
import org.junit.Assert;
import org.junit.Test;

import com.ruijie.rcos.base.sysmanage.module.def.api.DataBackupAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.databackup.BaseListDataBackupRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.databackup.BaseDeleteDataBackupResponse;
import com.ruijie.rcos.base.sysmanage.module.def.dto.BaseDataBackupDTO;
import com.ruijie.rcos.base.sysmanage.module.web.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.web.request.databackup.BaseCreateDataBackupWebRequest;
import com.ruijie.rcos.base.sysmanage.module.web.request.databackup.BaseDeleteDataBackupWebRequest;
import com.ruijie.rcos.base.sysmanage.module.web.request.databackup.BaseListDataBackupWebRequest;
import com.ruijie.rcos.sk.base.batch.BatchTaskBuilder;
import com.ruijie.rcos.sk.base.batch.BatchTaskHandler;
import com.ruijie.rcos.sk.base.batch.BatchTaskSubmitResult;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.i18n.LocaleI18nResolver;
import com.ruijie.rcos.sk.base.test.GetSetTester;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultPageResponse;
import com.ruijie.rcos.sk.webmvc.api.optlog.ProgrammaticOptLogRecorder;
import com.ruijie.rcos.sk.webmvc.api.response.DefaultWebResponse;

import mockit.*;

/**
 * Description: 数据库备份CTRL
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月25日
 *
 * @author fyq
 */

public class DataBackupCtrlTest {

    @Tested
    private DataBackupCtrl dataBackupCtrl;

    @Injectable
    private DataBackupAPI dataBackupAPI;

    @Mocked
    private ProgrammaticOptLogRecorder logRecorder;

    @Mocked
    private BatchTaskBuilder taskBuilder;

    /**
     * 测试实体
     */
    @Test
    public void testPojo() {

        GetSetTester tester = new GetSetTester(BaseCreateDataBackupWebRequest.class);
        tester.runTest();

        tester = new GetSetTester(BaseDeleteDataBackupWebRequest.class);
        tester.runTest();

        tester = new GetSetTester(BaseListDataBackupWebRequest.class);
        tester.runTest();

        assertTrue(true);
    }

    /**
     * 创建被封
     * 
     * @param webRequest 请求
     * @throws BusinessException 业务异常
     */
    @Test
    public void testCreateBackup(@Tested BaseCreateDataBackupWebRequest webRequest) throws BusinessException {
        BatchTaskSubmitResult batchTaskSubmitResult = new BatchTaskSubmitResultTest();
        new Expectations(LocaleI18nResolver.class) {
            {
                LocaleI18nResolver.resolve(BusinessKey.BASE_SYS_MANAGE_DATA_BACKUP_BATCH_CREATE_ITEM_NAME);
                result = "itemName";
                taskBuilder.start();
                result = batchTaskSubmitResult;
            }
        };
        DefaultWebResponse defaultWebResponse = dataBackupCtrl.createDataBackup(webRequest, taskBuilder, logRecorder);
        Assert.assertEquals(defaultWebResponse.getContent(), batchTaskSubmitResult);
        new Verifications() {
            {
                taskBuilder.setTaskName(BusinessKey.BASE_SYS_MANAGE_DATA_BACKUP_BATCH_CREATE_NAME);
                times = 1;
                taskBuilder.setTaskDesc(BusinessKey.BASE_SYS_MANAGE_DATA_BACKUP_BATCH_CREATE_DESC);
                times = 1;
                taskBuilder.registerHandler((BatchTaskHandler) any);
                times = 1;
                taskBuilder.start();
                times = 1;
            }
        };
    }

    /**
     * 删除备份数据
     * 
     * @param webRequest 请求
     * @throws BusinessException 异常
     */
    @Test
    public void testDeleteDataBackup(@Tested BaseDeleteDataBackupWebRequest webRequest) throws BusinessException {
        BatchTaskSubmitResult batchTaskSubmitResult = new BatchTaskSubmitResultTest();
        webRequest.setIdArr(new UUID[] {UUID.randomUUID(), UUID.randomUUID()});

        BaseDeleteDataBackupResponse apiResponse = new BaseDeleteDataBackupResponse();
        apiResponse.setFileName("log.zip");

        new Expectations(LocaleI18nResolver.class) {
            {
                LocaleI18nResolver.resolve(BusinessKey.BASE_SYS_MANAGE_DATA_BACKUP_BATCH_DELETE_ITEM_NAME);
                result = "itemName";
                taskBuilder.start();
                result = batchTaskSubmitResult;
            }
        };

        DefaultWebResponse defaultWebResponse = dataBackupCtrl.deleteDataBackup(webRequest, taskBuilder, logRecorder);
        Assert.assertEquals(defaultWebResponse.getContent(), batchTaskSubmitResult);
        new Verifications() {
            {
                taskBuilder.setTaskName(BusinessKey.BASE_SYS_MANAGE_DATA_BACKUP_BATCH_DELETE_NAME);
                times = 1;
                taskBuilder.setTaskDesc(BusinessKey.BASE_SYS_MANAGE_DATA_BACKUP_BATCH_DELETE_DESC);
                times = 1;
                taskBuilder.registerHandler((BatchTaskHandler) any);
                times = 1;
                taskBuilder.start();
                times = 1;
            }
        };
    }

    /**
     * 获取备份列表
     * 
     * @param webRequest 请求
     */
    @Test
    public void testListBackup(@Tested BaseListDataBackupWebRequest webRequest) {

        webRequest.setPage(1);
        webRequest.setLimit(10);

        DefaultPageResponse apiResponse = new DefaultPageResponse();
        apiResponse.setTotal(10);
        apiResponse.setItemArr(new BaseDataBackupDTO[10]);

        new Expectations() {
            {
                dataBackupAPI.listDataBackup((BaseListDataBackupRequest) any);
                result = apiResponse;
            }
        };

        dataBackupCtrl.listDataBackup(webRequest);

        new Verifications() {
            {
                dataBackupAPI.listDataBackup((BaseListDataBackupRequest) any);
                times = 1;
            }
        };
    }

}
