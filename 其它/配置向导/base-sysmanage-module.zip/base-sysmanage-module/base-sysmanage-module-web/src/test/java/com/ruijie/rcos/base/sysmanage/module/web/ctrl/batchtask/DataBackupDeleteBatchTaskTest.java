package com.ruijie.rcos.base.sysmanage.module.web.ctrl.batchtask;

import java.util.Iterator;
import java.util.UUID;

import org.junit.Assert;
import org.junit.Test;

import com.ruijie.rcos.base.sysmanage.module.def.api.DataBackupAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.databackup.BaseDeleteDataBackupRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.databackup.BaseDeleteDataBackupResponse;
import com.ruijie.rcos.base.sysmanage.module.web.BusinessKey;
import com.ruijie.rcos.sk.base.batch.*;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.webmvc.api.optlog.ProgrammaticOptLogRecorder;

import mockit.*;

/**
 * Description: 批量删除数据库备份任务
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月25日
 *
 * @author fyq
 */

public class DataBackupDeleteBatchTaskTest {

    @Tested
    private DataBackupDeleteBatchTask dataBackupDeleteBatchTask;

    @Injectable
    private Iterator<BatchTaskItem> iterator;

    @Injectable
    private DataBackupAPI dataBackupAPI;

    @Mocked
    @Injectable
    private ProgrammaticOptLogRecorder logRecorder;

    /**
     * 删除备份
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testDeleteDataBackup() throws BusinessException {

        DefaultBatchTaskItem batchTaskItem = new DefaultBatchTaskItem(UUID.randomUUID(), "itemName");

        String fileName = "bak.zip";

        BaseDeleteDataBackupResponse apiResponse = new BaseDeleteDataBackupResponse();
        apiResponse.setFileName(fileName);

        new MockUp<BusinessException>() {
            @Mock
            public String getI18nMessage() {
                return "";
            }
        };

        new Expectations() {
            {
                dataBackupAPI.deleteDataBackup((BaseDeleteDataBackupRequest) any);
                result = apiResponse;
            }
        };

        BatchTaskItemResult taskItemResult = dataBackupDeleteBatchTask.processItem(batchTaskItem);

        Assert.assertEquals(taskItemResult.getItemStatus(), BatchTaskItemStatus.SUCCESS);
        Assert.assertEquals(taskItemResult.getMsgKey(), BusinessKey.BASE_SYS_MANAGE_BATCH_ITEM_DELETE);

        new Verifications() {
            {
                dataBackupAPI.deleteDataBackup((BaseDeleteDataBackupRequest) any);
                times = 1;
                logRecorder.saveOptLog(BusinessKey.BASE_SYS_MANAGE_DATA_BACKUP_DELETE, fileName);
                times = 1;
            }
        };
    }

    /**
     * 删除备份异常
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testDeleteDataBackupApiFail() throws BusinessException {

        DefaultBatchTaskItem batchTaskItem = new DefaultBatchTaskItem(UUID.randomUUID(), "itemName");

        new MockUp<BusinessException>() {
            @Mock
            public String getI18nMessage() {
                return "";
            }
        };

        new Expectations() {
            {
                dataBackupAPI.deleteDataBackup((BaseDeleteDataBackupRequest) any);
                result = new BusinessException(BusinessKey.BASE_SYS_MANAGE_BATCH_ITEM_FAIL);
            }
        };

        try {
            dataBackupDeleteBatchTask.processItem(batchTaskItem);
        } catch (BusinessException e) {
            Assert.assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_BATCH_ITEM_FAIL);
        }
    }

    /**
     * 删除完成
     */
    @Test
    public void testOnFinish() {
        BatchTaskFinishResult taskFinishResult = dataBackupDeleteBatchTask.onFinish(1, 0);
        Assert.assertEquals(taskFinishResult.getStatus(), BatchTaskStatus.SUCCESS);
        Assert.assertEquals(taskFinishResult.getMsgKey(), BusinessKey.BASE_SYS_MANAGE_DATA_BACKUP_BATCH_DELETE_RESULT);
    }

    /**
     * 完成失败
     */
    @Test
    public void testOnFinishFail() {
        BatchTaskFinishResult taskFinishResult = dataBackupDeleteBatchTask.onFinish(0, 1);
        Assert.assertEquals(taskFinishResult.getStatus(), BatchTaskStatus.FAILURE);
        Assert.assertEquals(taskFinishResult.getMsgKey(), BusinessKey.BASE_SYS_MANAGE_DATA_BACKUP_BATCH_DELETE_RESULT);
    }
}
