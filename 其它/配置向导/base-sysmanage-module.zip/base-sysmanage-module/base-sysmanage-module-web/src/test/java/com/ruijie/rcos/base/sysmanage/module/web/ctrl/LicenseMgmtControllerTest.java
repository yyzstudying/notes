package com.ruijie.rcos.base.sysmanage.module.web.ctrl;

import static org.junit.Assert.assertTrue;
import org.junit.Test;
import com.ruijie.rcos.base.sysmanage.module.def.api.BaseLicenseMgmtAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.BaseCreateDatFileRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.BaseLicenseListRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.BaseUploadLicFileRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.CheckDuplicationWebRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.license.BaseCreateDatFileResponse;
import com.ruijie.rcos.base.sysmanage.module.web.request.license.BaseLicenseListWebRequest;
import com.ruijie.rcos.base.sysmanage.module.web.request.license.CreateDatFileWebRequest;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.test.ThrowExceptionTester;
import com.ruijie.rcos.sk.webmvc.api.request.ChunkUploadFile;
import mockit.Expectations;
import mockit.Injectable;
import mockit.Tested;
import mockit.Verifications;

/**
 * Description: License管理组件对外controller 测试类
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月25日
 *
 * @author fyq
 */

public class LicenseMgmtControllerTest {

    @Tested
    private LicenseMgmtController licenseMgmtController;

    @Injectable
    private BaseLicenseMgmtAPI baseLicenseMgmtAPI;

    /**
     * 验证uploadLicFile()方法入参
     * 
     * @throws Exception 异常
     */
    @Test
    public void testUploadLicFileValidateParams() throws Exception {

        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseMgmtController.uploadLicFile(null), "ChunkUploadFile is null");

        assertTrue(true);
    }
    
    /**
     * uploadLicFile 测试方法
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testUploadLicFile() throws BusinessException {

        ChunkUploadFile file = new ChunkUploadFile();
        
        licenseMgmtController.uploadLicFile(file);

        new Verifications() {
            {
                baseLicenseMgmtAPI.uploadLicFile((BaseUploadLicFileRequest)any);
                times = 1;
            }
        };
    }
    
    /**
     * 验证createDatFile()方法入参
     * 
     * @throws Exception 异常
     */
    @Test
    public void testCreateDatFileValidateParams() throws Exception {

        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseMgmtController.createDatFile(null), "请求参数不能为空");

        assertTrue(true);
    }
    
    /**
     * createDatFile 测试方法
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testCreateDatFile() throws BusinessException {

        CreateDatFileWebRequest request = new CreateDatFileWebRequest();
        BaseCreateDatFileResponse baseCreateDatFileResponse = new BaseCreateDatFileResponse();
        baseCreateDatFileResponse.setFiieName("123456.dat");
        baseCreateDatFileResponse.setFileContent("123456");
        new Expectations() {
            {
                baseLicenseMgmtAPI.createDatFile((BaseCreateDatFileRequest)any);
                result = baseCreateDatFileResponse;
            }
        };
        
        licenseMgmtController.createDatFile(request);

        new Verifications() {
            {
                baseLicenseMgmtAPI.createDatFile((BaseCreateDatFileRequest)any);
                times = 1;
            }
        };
    }
    
    /**
     * 验证listLicenseFeature()方法入参
     * 
     * @throws Exception 异常
     */
    @Test
    public void testListLicenseFeatureValidateParams() throws Exception {

        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseMgmtController.listLicenseFeature(null), "请求参数不能为空");

        assertTrue(true);
    }
    
    /**
     * listLicenseFeature 测试方法
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testListLicenseFeature() throws BusinessException {

        BaseLicenseListWebRequest webRequest = new BaseLicenseListWebRequest();
        licenseMgmtController.listLicenseFeature(webRequest);

        new Verifications() {
            {
                baseLicenseMgmtAPI.listLicenseFeature((BaseLicenseListRequest)any);
                times = 1;
            }
        };
    }
    
    /**
     * 验证checkDuplication()方法入参
     * 
     * @throws Exception 异常
     */
    @Test
    public void testCheckDuplicationValidateParams() throws Exception {

        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseMgmtController.checkDuplication(null), "CheckDuplicationWebRequest is null");

        assertTrue(true);
    }
    
    /**
     * checkDuplication 测试方法
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testCheckDuplication() throws BusinessException {

        CheckDuplicationWebRequest webRequest = new CheckDuplicationWebRequest();
        licenseMgmtController.checkDuplication(webRequest);

        new Verifications() {
            {
                baseLicenseMgmtAPI.validationLicenseFeature((CheckDuplicationWebRequest)any);
                times = 1;
            }
        };
    }
    
}
