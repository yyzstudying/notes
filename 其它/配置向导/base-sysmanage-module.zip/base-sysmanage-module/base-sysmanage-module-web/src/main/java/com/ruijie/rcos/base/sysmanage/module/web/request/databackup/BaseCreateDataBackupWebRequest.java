package com.ruijie.rcos.base.sysmanage.module.web.request.databackup;

import com.ruijie.rcos.sk.webmvc.api.request.WebRequest;

/**
 * Description: 数据库备份web请求
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月06日
 *
 * @author fyq
 */
public class BaseCreateDataBackupWebRequest implements WebRequest {
}
