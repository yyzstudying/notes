package com.ruijie.rcos.base.sysmanage.module.web.request.log4jconfig;

import com.ruijie.rcos.sk.webmvc.api.request.PageWebRequest;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年02月18日
 *
 * @author GuoZhouYue
 */
public class BaseListLog4jConfigWebRequest extends PageWebRequest {
}
