package com.ruijie.rcos.base.sysmanage.module.web.ctrl;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ruijie.rcos.base.sysmanage.module.def.api.NetworkAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.SystemTimeAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.network.BaseDetailNetworkRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.systemtime.BaseUpdateSystemTimeFromNtpRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.systemtime.BaseUpdateSystemTimeRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.network.BaseDetailNetworkInfoResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.systemtime.BaseUpdateSystemTimeResponse;
import com.ruijie.rcos.base.sysmanage.module.def.common.Constant;
import com.ruijie.rcos.base.sysmanage.module.def.dto.BaseNetworkDTO;
import com.ruijie.rcos.base.sysmanage.module.web.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.web.enums.SystemTimeConfigType;
import com.ruijie.rcos.base.sysmanage.module.web.request.systemtime.BaseGetSystemTimeWebRequest;
import com.ruijie.rcos.base.sysmanage.module.web.request.systemtime.BaseUpdateSystemTimeWebRequest;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.webmvc.api.optlog.ProgrammaticOptLogRecorder;
import com.ruijie.rcos.sk.webmvc.api.response.DefaultWebResponse;

/**
 * Description: 系统时间操作Controller
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年11月29日
 *
 * @author fyq
 */
@Controller
@RequestMapping("systemConfig/systemTime")
public class SystemTimeCtrl {

    @Autowired
    private SystemTimeAPI systemTimeAPI;

    @Autowired
    private NetworkAPI networkAPI;

    /**
     * 更新系统时间接口
     * 
     * @param webRequest 更新请求
     * @param optLogRecorder 日志记录接口
     * @return 更新结果
     * @throws BusinessException 业务异常
     */
    protected DefaultWebResponse updateSystemTime(BaseUpdateSystemTimeWebRequest webRequest, ProgrammaticOptLogRecorder optLogRecorder)
            throws BusinessException {

        Assert.notNull(webRequest, "请求参数不能为空");
        Assert.notNull(optLogRecorder, "optLogRecorder参数不能为空");

        SystemTimeConfigType configType = webRequest.getType();

        if (configType == SystemTimeConfigType.NTP) {
            BaseDetailNetworkInfoResponse baseDetailNetworkInfoResponse = networkAPI.detailNetwork(new BaseDetailNetworkRequest());
            BaseNetworkDTO networkDTO = baseDetailNetworkInfoResponse.getNetworkDTO();
            if (null == networkDTO || !StringUtils.hasText(networkDTO.getDns())) {
                throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_SYSTEM_TIME_UPDATE_FAIL_BY_DNS_NOT_CONFIG);
            }

            return updateSystemTimeFromNtp(webRequest, optLogRecorder);
        } else {
            return updateSystemTimeBySet(webRequest, optLogRecorder);
        }
    }

    private DefaultWebResponse updateSystemTimeBySet(BaseUpdateSystemTimeWebRequest webRequest, ProgrammaticOptLogRecorder logRecorder)
            throws BusinessException {

        BaseUpdateSystemTimeRequest apiRequest = new BaseUpdateSystemTimeRequest();
        apiRequest.setTime(webRequest.getTime());

        try {
            BaseUpdateSystemTimeResponse apiResponse = systemTimeAPI.updateSystemTime(apiRequest);

            SimpleDateFormat sdf = new SimpleDateFormat(Constant.YYYY_MM_DD_HH_MM_SS);
            logRecorder.saveOptLog(BusinessKey.BASE_SYS_MANAGE_SYSTEM_TIME_UPDATE, sdf.format(new Date(apiRequest.getTime())));

            return DefaultWebResponse.Builder.success(apiResponse);

        } catch (BusinessException e) {
            logRecorder.saveOptLog(BusinessKey.BASE_SYS_MANAGE_SYSTEM_TIME_UPDATE_FAIL, e.getI18nMessage());
            throw e;
        }
    }

    private DefaultWebResponse updateSystemTimeFromNtp(BaseUpdateSystemTimeWebRequest webRequest, ProgrammaticOptLogRecorder logRecorder)
            throws BusinessException {

        BaseUpdateSystemTimeFromNtpRequest apiRequest = new BaseUpdateSystemTimeFromNtpRequest();
        apiRequest.setNtpServer(webRequest.getNtpServer());

        try {
            BaseUpdateSystemTimeResponse apiResponse = systemTimeAPI.updateSystemTimeFromNtp(apiRequest);

            SimpleDateFormat sdf = new SimpleDateFormat(Constant.YYYY_MM_DD_HH_MM_SS);
            logRecorder.saveOptLog(BusinessKey.BASE_SYS_MANAGE_SYSTEM_TIME_UPDATE_FROM_NTP, webRequest.getNtpServer(), sdf.format(new Date()));

            return DefaultWebResponse.Builder.success(apiResponse);

        } catch (BusinessException e) {
            logRecorder.saveOptLog(BusinessKey.BASE_SYS_MANAGE_SYSTEM_TIME_UPDATE_FROM_NTP_FAIL, e.getI18nMessage());
            throw e;
        }
    }


    /**
     * 获取系统时间接口
     * 
     * @param webRequest 更新请求
     * @return 更新结果
     */
    @RequestMapping(value = "get")
    public DefaultWebResponse getSystemTime(BaseGetSystemTimeWebRequest webRequest) {

        Assert.notNull(webRequest, "请求不能为空");

        return DefaultWebResponse.Builder.success(System.currentTimeMillis());
    }
}
