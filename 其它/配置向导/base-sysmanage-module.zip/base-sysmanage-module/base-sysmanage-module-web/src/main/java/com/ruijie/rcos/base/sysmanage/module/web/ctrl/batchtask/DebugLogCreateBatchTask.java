package com.ruijie.rcos.base.sysmanage.module.web.ctrl.batchtask;

import com.ruijie.rcos.base.sysmanage.module.def.api.DebugLogAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.debuglog.BaseCreateDebugLogRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.debuglog.BaseCreateDebugLogResponse;
import com.ruijie.rcos.base.sysmanage.module.web.BusinessKey;
import com.ruijie.rcos.sk.base.batch.*;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.webmvc.api.optlog.ProgrammaticOptLogRecorder;

/**
 * Description: 打包调试日志任务
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月16日
 *
 * @author fyq
 */
public class DebugLogCreateBatchTask extends AbstractSingleTaskHandler {

    private DebugLogAPI debugLogAPI;

    private ProgrammaticOptLogRecorder logRecorder;

    public DebugLogCreateBatchTask(BatchTaskItem batchTaskItem, DebugLogAPI debugLogAPI, ProgrammaticOptLogRecorder logRecorder) {
        super(batchTaskItem);
        this.debugLogAPI = debugLogAPI;
        this.logRecorder = logRecorder;
    }

    @Override
    public BatchTaskItemResult processItem(BatchTaskItem batchTaskItem) throws BusinessException {

        createDebugLog(logRecorder);

        return DefaultBatchTaskItemResult.builder()//
                .batchTaskItemStatus(BatchTaskItemStatus.SUCCESS)//
                .msgKey(BusinessKey.BASE_SYS_MANAGE_BATCH_ITEM_CREATE)//
                .build();
    }

    @Override
    public BatchTaskFinishResult onFinish(int successCount, int failCount) {
        if (failCount == 0) {
            return DefaultBatchTaskFinishResult.builder()//
                    .batchTaskStatus(BatchTaskStatus.SUCCESS)//
                    .msgKey(BusinessKey.BASE_SYS_MANAGE_DEBUG_LOG_BATCH_CREATE_SUCCESS)//
                    .build();
        } else {
            return DefaultBatchTaskFinishResult.builder()//
                    .batchTaskStatus(BatchTaskStatus.FAILURE)//
                    .msgKey(BusinessKey.BASE_SYS_MANAGE_DEBUG_LOG_BATCH_CREATE_FAIL)//
                    .build();
        }
    }

    private void createDebugLog(ProgrammaticOptLogRecorder optLogRecorder) throws BusinessException {

        BaseCreateDebugLogRequest apiRequest = new BaseCreateDebugLogRequest();

        try {
            BaseCreateDebugLogResponse apiResponse = debugLogAPI.createDebugLog(apiRequest);
            optLogRecorder.saveOptLog(BusinessKey.BASE_SYS_MANAGE_DEBUG_LOG_CREATE, apiResponse.getFileName());
        } catch (BusinessException e) {
            optLogRecorder.saveOptLog(BusinessKey.BASE_SYS_MANAGE_DEBUG_LOG_CREATE_FAIL, e.getI18nMessage());
            throw e;
        }
    }
}
