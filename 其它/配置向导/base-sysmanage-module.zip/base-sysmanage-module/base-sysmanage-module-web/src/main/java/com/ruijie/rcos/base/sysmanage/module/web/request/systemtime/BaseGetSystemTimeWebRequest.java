package com.ruijie.rcos.base.sysmanage.module.web.request.systemtime;

import com.ruijie.rcos.sk.webmvc.api.request.WebRequest;

/**
 * Description: 获取系统时间web请求
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年11月30日
 *
 * @author fyq
 */
public class BaseGetSystemTimeWebRequest implements WebRequest {
}
