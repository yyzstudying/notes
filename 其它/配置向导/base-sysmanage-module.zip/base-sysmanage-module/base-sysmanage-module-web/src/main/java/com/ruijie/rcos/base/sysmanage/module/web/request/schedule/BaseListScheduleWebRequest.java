package com.ruijie.rcos.base.sysmanage.module.web.request.schedule;

import com.ruijie.rcos.sk.webmvc.api.request.PageWebRequest;

/**
 * Description: 翻页请求
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月06日
 *
 * @author xgx
 */
public class BaseListScheduleWebRequest extends PageWebRequest {
}
