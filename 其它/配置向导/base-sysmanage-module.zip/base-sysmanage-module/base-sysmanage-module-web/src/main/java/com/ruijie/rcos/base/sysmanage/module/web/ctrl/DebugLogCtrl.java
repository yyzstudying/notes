package com.ruijie.rcos.base.sysmanage.module.web.ctrl;

import java.io.File;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.UUID;
import java.util.stream.Stream;

import com.ruijie.rcos.sk.base.batch.BatchTaskSubmitResult;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ruijie.rcos.base.sysmanage.module.def.api.DebugLogAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.debuglog.BaseDetailDebugLogRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.debuglog.BaseListDebugLogRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.debuglog.BaseDetailDebugLogResponse;
import com.ruijie.rcos.base.sysmanage.module.def.dto.BaseDebugLogDTO;
import com.ruijie.rcos.base.sysmanage.module.web.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.web.ctrl.batchtask.DebugLogCreateBatchTask;
import com.ruijie.rcos.base.sysmanage.module.web.ctrl.batchtask.DebugLogDeleteBatchTask;
import com.ruijie.rcos.base.sysmanage.module.web.request.debuglog.BaseCreateDebugLogWebRequest;
import com.ruijie.rcos.base.sysmanage.module.web.request.debuglog.BaseDeleteDebugLogWebRequest;
import com.ruijie.rcos.base.sysmanage.module.web.request.debuglog.BaseDownloadDebugLogWebRequest;
import com.ruijie.rcos.base.sysmanage.module.web.request.debuglog.BaseListDebugLogWebRequest;
import com.ruijie.rcos.sk.base.batch.BatchTaskBuilder;
import com.ruijie.rcos.sk.base.batch.BatchTaskItem;
import com.ruijie.rcos.sk.base.batch.DefaultBatchTaskItem;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.i18n.LocaleI18nResolver;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultPageResponse;
import com.ruijie.rcos.sk.webmvc.api.optlog.ProgrammaticOptLogRecorder;
import com.ruijie.rcos.sk.webmvc.api.response.DefaultWebResponse;
import com.ruijie.rcos.sk.webmvc.api.response.DownloadWebResponse;

/**
 * Description: 调试日志CTRL
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月19日
 *
 * @author fyq
 */
@Controller
@RequestMapping("/maintenance/debugLog")
public class DebugLogCtrl {

    @Autowired
    private DebugLogAPI debugLogAPI;

    private static final UUID CREATE_DEBUG_LOG_TASK_ID = UUID.nameUUIDFromBytes("base_sysmanage_debug_log".getBytes(Charset.forName("UTF-8")));

    /**
     * 创建调试日志压缩文件接口
     * 
     * @param webRequest web请求
     * @param logRecorder 日志接口
     * @param taskBuilder 比任务接口
     * @return 请求结果
     * @throws BusinessException 业务异常
     */
    @RequestMapping(value = "create")
    public DefaultWebResponse createDebugLog(BaseCreateDebugLogWebRequest webRequest, BatchTaskBuilder taskBuilder,
            ProgrammaticOptLogRecorder logRecorder) throws BusinessException {

        Assert.notNull(webRequest, "请求参数不能为空");
        Assert.notNull(logRecorder, "logRecorder参数不能为空");

        final String itemName = LocaleI18nResolver.resolve(BusinessKey.BASE_SYS_MANAGE_DEBUG_LOG_BATCH_CREATE_ITEM_NAME);
        final BatchTaskItem batchTaskItem = new DefaultBatchTaskItem(UUID.randomUUID(), itemName);
        final DebugLogCreateBatchTask debugLogCreateBatchTask = new DebugLogCreateBatchTask(batchTaskItem, debugLogAPI, logRecorder);

        BatchTaskSubmitResult batchTaskSubmitResult = taskBuilder.setTaskName(BusinessKey.BASE_SYS_MANAGE_DEBUG_LOG_BATCH_CREATE_NAME)//
                .setTaskDesc(BusinessKey.BASE_SYS_MANAGE_DEBUG_LOG_BATCH_CREATE_DESC)//
                .registerHandler(debugLogCreateBatchTask)//
                .setUniqueId(CREATE_DEBUG_LOG_TASK_ID)
                .start();

        return DefaultWebResponse.Builder.success(batchTaskSubmitResult);
    }

    /**
     * 删除调试日志压缩文件接口
     * 
     * @param webRequest web请求
     * @param optLogRecorder 日志接口
     * @param batchTaskBuilder 批任务接口
     * @return 请求结果
     * @throws BusinessException 业务异常
     */
    @RequestMapping(value = "delete")
    public DefaultWebResponse deleteDebugLog(BaseDeleteDebugLogWebRequest webRequest, BatchTaskBuilder batchTaskBuilder,
            ProgrammaticOptLogRecorder optLogRecorder) throws BusinessException {

        Assert.notNull(webRequest, "请求参数不能为空");
        Assert.notNull(optLogRecorder, "optLogRecorder参数不能为空");

        final UUID[] idArr = webRequest.getIdArr();
        final String itemName = LocaleI18nResolver.resolve(BusinessKey.BASE_SYS_MANAGE_DEBUG_LOG_BATCH_DELETE_ITEM_NAME);
        final Iterator<BatchTaskItem> iterator = Stream.of(idArr).map(id -> (BatchTaskItem) DefaultBatchTaskItem.builder()//
                .itemId(id)//
                .itemName(itemName)//
                .build()).iterator();

        final DebugLogDeleteBatchTask debugLogDeleteBatchTask = new DebugLogDeleteBatchTask(iterator, debugLogAPI, optLogRecorder);

        BatchTaskSubmitResult batchTaskSubmitResult = batchTaskBuilder.setTaskName(BusinessKey.BASE_SYS_MANAGE_DEBUG_LOG_BATCH_DELETE_NAME)//
                .setTaskDesc(BusinessKey.BASE_SYS_MANAGE_DEBUG_LOG_BATCH_DELETE_DESC)//
                .registerHandler(debugLogDeleteBatchTask)//
                .start();

        return DefaultWebResponse.Builder.success(batchTaskSubmitResult);
    }


    /**
     * 获取调试日志列表接口
     * 
     * @param webRequest web请求
     * @return 请求结果
     */
    @RequestMapping(value = "list")
    public DefaultWebResponse listDebugLog(BaseListDebugLogWebRequest webRequest) {

        Assert.notNull(webRequest, "请求参数不能为空");

        BaseListDebugLogRequest apiRequest = new BaseListDebugLogRequest();
        BeanUtils.copyProperties(webRequest, apiRequest);

        DefaultPageResponse<BaseDebugLogDTO> response = debugLogAPI.listDebugLog(apiRequest);

        return DefaultWebResponse.Builder.success(response);
    }


    /**
     * 下载调试日志压缩文件接口
     * 
     * @param webRequest web请求
     * @throws BusinessException 业务异常
     * @return 请求结果
     */
    @RequestMapping(value = "download")
    public DownloadWebResponse downloadDebugLog(BaseDownloadDebugLogWebRequest webRequest) throws BusinessException {

        Assert.notNull(webRequest, "请求参数不能为空");

        BaseDetailDebugLogRequest apiRequest = new BaseDetailDebugLogRequest();
        apiRequest.setId(webRequest.getId());

        BaseDetailDebugLogResponse apiResponse = debugLogAPI.detailDebugLog(apiRequest);

        File file = new File(apiResponse.getFilePath());

        String fileName = file.getName();
        String suffix = fileName.substring(fileName.indexOf(".") + 1);

        return new DownloadWebResponse.Builder()//
                .setContentType("application/octet-stream")//
                .setName(apiResponse.getFileName(), suffix)//
                .setFile(file)//
                .build();
    }

}
