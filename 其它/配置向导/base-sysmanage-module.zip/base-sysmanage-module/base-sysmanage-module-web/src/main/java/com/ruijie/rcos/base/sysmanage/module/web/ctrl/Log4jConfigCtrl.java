package com.ruijie.rcos.base.sysmanage.module.web.ctrl;

import java.util.Iterator;
import java.util.UUID;
import java.util.stream.Stream;

import com.ruijie.rcos.base.sysmanage.module.web.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.web.ctrl.batchtask.Log4jConfigDeleteBatchTask;
import com.ruijie.rcos.sk.base.batch.BatchTaskBuilder;
import com.ruijie.rcos.sk.base.batch.BatchTaskItem;
import com.ruijie.rcos.sk.base.batch.DefaultBatchTaskItem;
import com.ruijie.rcos.sk.base.i18n.LocaleI18nResolver;
import com.ruijie.rcos.sk.webmvc.api.optlog.ProgrammaticOptLogRecorder;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ruijie.rcos.base.sysmanage.module.def.api.Log4jConfigAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.log4jconfig.BaseAddLog4jConfigRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.log4jconfig.BaseDetailLog4jConfigRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.log4jconfig.BaseEditLog4jConfigRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.log4jconfig.BaseListLog4jConfigRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.log4j.BaseDetailLog4jConfigResponse;
import com.ruijie.rcos.base.sysmanage.module.def.dto.Log4jConfigDTO;
import com.ruijie.rcos.base.sysmanage.module.web.request.log4jconfig.BaseAddLog4jConfigWebRequest;
import com.ruijie.rcos.base.sysmanage.module.web.request.log4jconfig.BaseDetailLog4jConfigWebRequest;
import com.ruijie.rcos.base.sysmanage.module.web.request.log4jconfig.BaseEditLog4jConfigWebRequest;
import com.ruijie.rcos.base.sysmanage.module.web.request.log4jconfig.BaseListLog4jConfigWebRequest;
import com.ruijie.rcos.base.sysmanage.module.web.request.log4jconfig.BaseRemoveLog4jConfigWebRequest;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultPageResponse;
import com.ruijie.rcos.sk.webmvc.api.response.DefaultWebResponse;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年02月18日
 *
 * @author GuoZhouYue
 */
@Controller
@RequestMapping("/systemConfig/log4j")
public class Log4jConfigCtrl {

    @Autowired
    Log4jConfigAPI log4jConfigAPI;

    /**
     * 列出所有log配置
     *
     * @param webRequest webRequest
     * @return DefaultWebResponse
     */
    @RequestMapping(value = "list")
    public DefaultWebResponse listLog4jConfig(BaseListLog4jConfigWebRequest webRequest) {
        final BaseListLog4jConfigRequest request = new BaseListLog4jConfigRequest();
        BeanUtils.copyProperties(webRequest, request);
        DefaultPageResponse<Log4jConfigDTO> response = log4jConfigAPI.getAll(request);

        return DefaultWebResponse.Builder.success(response);
    }

    /**
     * 列出一个log配置
     *
     * @param webRequest webRequest
     * @return DefaultWebResponse
     * @throws BusinessException BusinessException
     */
    @RequestMapping(value = "detail")
    public DefaultWebResponse detailLog4jConfig(BaseDetailLog4jConfigWebRequest webRequest) throws BusinessException {

        final BaseDetailLog4jConfigRequest request = new BaseDetailLog4jConfigRequest();
        BeanUtils.copyProperties(webRequest, request);
        final BaseDetailLog4jConfigResponse result = log4jConfigAPI.getOne(request);

        return DefaultWebResponse.Builder.success(result);
    }

    /**
     * 添加log配置
     *
     * @param webRequest webRequest
     * @param logRecorder logRecorder
     * @return DefaultWebResponse
     * @throws BusinessException BusinessException
     */
    @RequestMapping(value = "create")
    public DefaultWebResponse addLog4jConfig(BaseAddLog4jConfigWebRequest webRequest,
            ProgrammaticOptLogRecorder logRecorder) throws BusinessException {

        final BaseAddLog4jConfigRequest request = new BaseAddLog4jConfigRequest();
        BeanUtils.copyProperties(webRequest, request);

        log4jConfigAPI.addConfig(request);
        logRecorder.saveOptLog(BusinessKey.BASE_SYS_MANAGE_LOG4J_CONFIG_CREATE, webRequest.getLoggerName());

        return DefaultWebResponse.Builder.success();
    }

    /**
     * 删除log配置
     *
     * @param webRequest webRequest
     * @param batchTaskBuilder batchTaskBuilder
     * @param logRecorder logRecorder
     * @return DefaultWebResponse
     * @throws BusinessException BusinessException
     */
    @RequestMapping(value = "delete", method = RequestMethod.POST)
    public DefaultWebResponse deleteLog4jConfig(BaseRemoveLog4jConfigWebRequest webRequest,
            BatchTaskBuilder batchTaskBuilder, ProgrammaticOptLogRecorder logRecorder) throws BusinessException {

        final UUID[] idArr = webRequest.getIdArr();
        final String itemName =
                LocaleI18nResolver.resolve(BusinessKey.BASE_SYS_MANAGE_LOG4J_CONFIG_BATCH_DELETE_ITEM_NAME);

        final Iterator<BatchTaskItem> iterator = Stream.of(idArr)
                .map(id -> (BatchTaskItem) DefaultBatchTaskItem.builder()//
                        .itemId(id)//
                        .itemName(itemName)//
                        .build())
                .iterator();

        Log4jConfigDeleteBatchTask batchTask = new Log4jConfigDeleteBatchTask(iterator, log4jConfigAPI, logRecorder);

        UUID taskUniqueId = UUID.nameUUIDFromBytes("deleteLog4jConfigBatchTask".getBytes());
        batchTaskBuilder.setUniqueId(taskUniqueId)
                .setTaskName(BusinessKey.BASE_SYS_MANAGE_LOG4J_CONFIG_BATCH_DELETE_NAME) //
                .setTaskDesc(BusinessKey.BASE_SYS_MANAGE_LOG4J_CONFIG_BATCH_DELETE_DESC) //
                .registerHandler(batchTask) //
                .start();

        return DefaultWebResponse.Builder.success();
    }

    /**
     * 编辑log配置
     *
     * @param webRequest webRequest
     * @param logRecorder logRecorder
     * @return DefaultWebResponse
     * @throws BusinessException BusinessException
     */
    @RequestMapping(value = "edit")
    public DefaultWebResponse editLog4jConfig(BaseEditLog4jConfigWebRequest webRequest,
            ProgrammaticOptLogRecorder logRecorder) throws BusinessException {
        final BaseEditLog4jConfigRequest request = new BaseEditLog4jConfigRequest();
        BeanUtils.copyProperties(webRequest, request);

        log4jConfigAPI.editConfig(request);
        logRecorder.saveOptLog(BusinessKey.BASE_SYS_MANAGE_LOG4J_CONFIG_EDIT, webRequest.getLoggerName());
        return DefaultWebResponse.Builder.success();
    }
}
