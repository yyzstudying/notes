package com.ruijie.rcos.base.sysmanage.module.web.request.network;

import com.ruijie.rcos.sk.webmvc.api.request.WebRequest;

/**
 * Description: 获取网卡信息web请求
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年11月29日
 *
 * @author fyq
 */

public class BaseDetailNetworkWebRequest implements WebRequest {
}
