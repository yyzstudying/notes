package com.ruijie.rcos.base.sysmanage.module.web.ctrl.batchtask;

import java.util.Iterator;
import java.util.UUID;

import org.springframework.util.Assert;

import com.ruijie.rcos.base.sysmanage.module.def.api.DebugLogAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.debuglog.BaseDeleteDebugLogRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.debuglog.BaseDeleteDebugLogResponse;
import com.ruijie.rcos.base.sysmanage.module.web.BusinessKey;
import com.ruijie.rcos.sk.base.batch.*;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.webmvc.api.optlog.ProgrammaticOptLogRecorder;

/**
 * Description: 批量删除调试日志任务
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月16日
 *
 * @author fyq
 */
public class DebugLogDeleteBatchTask extends AbstractBatchTaskHandler {

    private DebugLogAPI debugLogAPI;

    private ProgrammaticOptLogRecorder logRecorder;

    public DebugLogDeleteBatchTask(Iterator<BatchTaskItem> iterator, DebugLogAPI debugLogAPI, ProgrammaticOptLogRecorder logRecorder) {
        super(iterator);
        this.debugLogAPI = debugLogAPI;
        this.logRecorder = logRecorder;
    }

    @Override
    public BatchTaskItemResult processItem(BatchTaskItem item) throws BusinessException {

        Assert.notNull(item, "item must not be null");

        deleteDebugLog(item.getItemID(), logRecorder);

        return DefaultBatchTaskItemResult.builder()//
                .batchTaskItemStatus(BatchTaskItemStatus.SUCCESS)//
                .msgKey(BusinessKey.BASE_SYS_MANAGE_BATCH_ITEM_DELETE)//
                .build();
    }

    @Override
    public BatchTaskFinishResult onFinish(int successCount, int failCount) {

        return DefaultBatchTaskFinishResult.builder()//
                .batchTaskStatus(failCount == 0 ? BatchTaskStatus.SUCCESS : BatchTaskStatus.FAILURE)//
                .msgKey(BusinessKey.BASE_SYS_MANAGE_DEBUG_LOG_BATCH_DELETE_RESULT)//
                .msgArgs(new String[] {String.valueOf(successCount), String.valueOf(failCount)})//
                .build();
    }

    private void deleteDebugLog(UUID id, ProgrammaticOptLogRecorder optLogRecorder) throws BusinessException {

        BaseDeleteDebugLogRequest apiRequest = new BaseDeleteDebugLogRequest();
        apiRequest.setId(id);

        try {
            BaseDeleteDebugLogResponse apiResponse = debugLogAPI.deleteDebugLog(apiRequest);
            optLogRecorder.saveOptLog(BusinessKey.BASE_SYS_MANAGE_DEBUG_LOG_DELETE, apiResponse.getFileName());
        } catch (BusinessException e) {
            optLogRecorder.saveOptLog(BusinessKey.BASE_SYS_MANAGE_DEBUG_LOG_DELETE_FAIL, e.getI18nMessage());
            throw e;
        }
    }
}
