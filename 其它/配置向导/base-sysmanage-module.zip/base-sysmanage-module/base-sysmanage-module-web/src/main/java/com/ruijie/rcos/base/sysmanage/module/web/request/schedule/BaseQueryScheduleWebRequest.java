package com.ruijie.rcos.base.sysmanage.module.web.request.schedule;

import java.util.UUID;

import com.ruijie.rcos.sk.base.annotation.NotNull;

import com.ruijie.rcos.sk.webmvc.api.request.WebRequest;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月07日
 *
 * @author xgx
 */
public class BaseQueryScheduleWebRequest implements WebRequest {
    @NotNull
    private UUID id;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}
