package com.ruijie.rcos.base.sysmanage.module.web.ctrl.batchtask;

import com.ruijie.rcos.base.sysmanage.module.def.api.DataBackupAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.databackup.BaseCreateDataBackupRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.databackup.BaseCreateDataBackupResponse;
import com.ruijie.rcos.base.sysmanage.module.web.BusinessKey;
import com.ruijie.rcos.sk.base.batch.*;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.webmvc.api.optlog.ProgrammaticOptLogRecorder;

/**
 * Description: 创建数据库任务
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月16日
 *
 * @author fyq
 */
public class DataBackupCreateBatchTask extends AbstractSingleTaskHandler {

    private DataBackupAPI dataBackupAPI;

    private ProgrammaticOptLogRecorder logRecorder;

    public DataBackupCreateBatchTask(BatchTaskItem batchTaskItem, DataBackupAPI dataBackupAPI, ProgrammaticOptLogRecorder logRecorder) {
        super(batchTaskItem);
        this.dataBackupAPI = dataBackupAPI;
        this.logRecorder = logRecorder;
    }

    @Override
    public BatchTaskItemResult processItem(BatchTaskItem item) throws BusinessException {

        createDataBackup(logRecorder);

        return DefaultBatchTaskItemResult.builder()//
                .batchTaskItemStatus(BatchTaskItemStatus.SUCCESS)//
                .msgKey(BusinessKey.BASE_SYS_MANAGE_BATCH_ITEM_CREATE)//
                .build();
    }

    @Override
    public BatchTaskFinishResult onFinish(int successCount, int failCount) {

        if (failCount == 0) {
            return DefaultBatchTaskFinishResult.builder()//
                    .batchTaskStatus(BatchTaskStatus.SUCCESS)//
                    .msgKey(BusinessKey.BASE_SYS_MANAGE_DATA_BACKUP_BATCH_CREATE_SUCCESS)//
                    .build();
        } else {
            return DefaultBatchTaskFinishResult.builder()//
                    .batchTaskStatus(BatchTaskStatus.FAILURE)//
                    .msgKey(BusinessKey.BASE_SYS_MANAGE_DATA_BACKUP_BATCH_CREATE_FAIL)//
                    .build();
        }
    }

    private void createDataBackup(ProgrammaticOptLogRecorder logRecorder) throws BusinessException {

        BaseCreateDataBackupRequest apiRequest = new BaseCreateDataBackupRequest();

        try {
            BaseCreateDataBackupResponse apiResponse = dataBackupAPI.createDataBackup(apiRequest);
            logRecorder.saveOptLog(BusinessKey.BASE_SYS_MANAGE_DATA_BACKUP_CREATE, apiResponse.getFileName());
        } catch (BusinessException e) {
            logRecorder.saveOptLog(BusinessKey.BASE_SYS_MANAGE_DATA_BACKUP_CREATE_FAIL, e.getI18nMessage());
            throw e;
        }
    }
}
