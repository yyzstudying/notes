package com.ruijie.rcos.base.sysmanage.module.web.request.schedule;

import java.util.UUID;

import org.springframework.lang.Nullable;

import com.alibaba.fastjson.annotation.JSONField;
import com.ruijie.rcos.base.sysmanage.module.def.enums.TaskCycle;
import com.ruijie.rcos.sk.base.annotation.NotBlank;
import com.ruijie.rcos.sk.base.annotation.NotNull;
import com.ruijie.rcos.sk.base.annotation.TextMedium;
import com.ruijie.rcos.sk.webmvc.api.request.WebRequest;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月06日
 *
 * @author xgx
 */
public class BaseCreateScheduleWebRequest implements WebRequest {

    @NotNull
    private UUID taskTypeId;

    @NotNull
    @JSONField(name = "cycle")
    private TaskCycle taskCycle;

    @TextMedium
    private String description;

    @Nullable
    private String scheduleDate;

    @NotBlank
    private String scheduleTime;

    @Nullable
    private Integer[] dayOfWeekArr;

    public UUID getTaskTypeId() {
        return taskTypeId;
    }

    public void setTaskTypeId(UUID taskTypeId) {
        this.taskTypeId = taskTypeId;
    }

    public TaskCycle getTaskCycle() {
        return taskCycle;
    }

    public void setTaskCycle(TaskCycle taskCycle) {
        this.taskCycle = taskCycle;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getScheduleDate() {
        return scheduleDate;
    }

    public void setScheduleDate(String scheduleDate) {
        this.scheduleDate = scheduleDate;
    }

    public String getScheduleTime() {
        return scheduleTime;
    }

    public void setScheduleTime(String scheduleTime) {
        this.scheduleTime = scheduleTime;
    }

    public Integer[] getDayOfWeekArr() {
        return dayOfWeekArr;
    }

    public void setDayOfWeekArr(Integer[] dayOfWeekArr) {
        this.dayOfWeekArr = dayOfWeekArr;
    }
}
