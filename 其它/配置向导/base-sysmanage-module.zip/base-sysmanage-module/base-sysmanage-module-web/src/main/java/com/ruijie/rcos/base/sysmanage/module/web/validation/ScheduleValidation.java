package com.ruijie.rcos.base.sysmanage.module.web.validation;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.ObjectUtils;

import com.ruijie.rcos.base.sysmanage.module.def.common.Constant;
import com.ruijie.rcos.base.sysmanage.module.def.enums.TaskCycle;
import com.ruijie.rcos.base.sysmanage.module.web.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.web.request.schedule.BaseCreateScheduleWebRequest;
import com.ruijie.rcos.base.sysmanage.module.web.request.schedule.BaseEditScheduleWebRequest;
import com.ruijie.rcos.sk.base.exception.BusinessException;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月27日
 *
 * @author xgx validation
 */
@Service
public class ScheduleValidation {
    /**
     * 创建定时任务参数校验
     * 
     * @param baseCreateScheduleWebRequest 请求参数
     * @throws BusinessException 业务异常
     */
    public void createScheduleTaskValidate(BaseCreateScheduleWebRequest baseCreateScheduleWebRequest) throws BusinessException {
        Assert.notNull(baseCreateScheduleWebRequest, "请求不能为空");

        TaskCycle cycle = baseCreateScheduleWebRequest.getTaskCycle();
        String scheduleTime = baseCreateScheduleWebRequest.getScheduleTime();
        Integer[] dayOfWeekArr = baseCreateScheduleWebRequest.getDayOfWeekArr();
        String scheduleDate = baseCreateScheduleWebRequest.getScheduleDate();
        validateScheduleArgs(cycle, scheduleTime, dayOfWeekArr, scheduleDate);
    }

    /**
     * 编辑参数校验
     * 
     * @param baseEditScheduleWebRequest 请求参数
     * @throws BusinessException 业务异常
     */
    public void editScheduleValidate(BaseEditScheduleWebRequest baseEditScheduleWebRequest) throws BusinessException {
        Assert.notNull(baseEditScheduleWebRequest, "请求不能为空");

        TaskCycle cycle = baseEditScheduleWebRequest.getTaskCycle();
        Integer[] dayOfWeekArr = baseEditScheduleWebRequest.getDayOfWeekArr();
        String scheduleDate = baseEditScheduleWebRequest.getScheduleDate();
        String scheduleTime = baseEditScheduleWebRequest.getScheduleTime();
        validateScheduleArgs(cycle, scheduleTime, dayOfWeekArr, scheduleDate);

    }

    private void validateScheduleArgs(TaskCycle cycle, String scheduleTime, Integer[] dayOfWeekArr, String scheduleDate) throws BusinessException {
        validateLocalTime(scheduleTime);
        if (cycle == TaskCycle.ONCE) {
            validateLocalDate(scheduleDate);
        } else if (cycle == TaskCycle.WEEK) {
            validateDayOfWeekArr(dayOfWeekArr);
        }
    }


    private void validateLocalTime(String localTime) throws BusinessException {
        try {
            LocalTime.parse(localTime, DateTimeFormatter.ofPattern(Constant.HH_MM_SS));
        } catch (DateTimeParseException e) {
            throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_ILLEGAL_TIME_FORMAT, e, localTime);
        }
    }

    private void validateLocalDate(String localDate) throws BusinessException {
        if (StringUtils.isBlank(localDate)) {
            throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_ARG_NOT_EMPTY, "scheduleDate");
        }
        try {
            LocalDate.parse(localDate, DateTimeFormatter.ofPattern(Constant.YYYY_MM_DD));
        } catch (DateTimeParseException e) {
            throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_ILLEGAL_DATE_FORMAT, e, localDate);
        }
    }

    private void validateDayOfWeekArr(Integer[] dayOfWeekArr) throws BusinessException {
        if (ObjectUtils.isEmpty(dayOfWeekArr)) {
            throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_ARG_NOT_EMPTY, "dayOfWeekArr");
        }
        for (Integer dayOfWeek : dayOfWeekArr) {
            if (null == dayOfWeek) {
                throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_ARG_NOT_CONTAIN_EMPTY, dayOfWeekArr.toString());
            }
            if (dayOfWeek <= 0 || dayOfWeek > 7) {
                throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_WEEK_ARG_RANGE_ERROR, dayOfWeekArr.toString());
            }
        }
    }
}
