package com.ruijie.rcos.base.sysmanage.module.web.ctrl;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import com.ruijie.rcos.base.sysmanage.module.def.api.BaseLicenseMgmtAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.BaseCreateDatFileRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.BaseLicenseListRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.BaseUploadLicFileRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.CheckDuplicationWebRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.license.BaseCreateDatFileResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.license.CheckDuplicationResponse;
import com.ruijie.rcos.base.sysmanage.module.def.dto.license.BaseLicenseFeatureDTO;
import com.ruijie.rcos.base.sysmanage.module.web.request.license.BaseLicenseListWebRequest;
import com.ruijie.rcos.base.sysmanage.module.web.request.license.CreateDatFileWebRequest;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultPageResponse;
import com.ruijie.rcos.sk.webmvc.api.request.ChunkUploadFile;
import com.ruijie.rcos.sk.webmvc.api.response.DefaultWebResponse;
import com.ruijie.rcos.sk.webmvc.api.response.DownloadWebResponse;

/**
 * Description: License管理组件对外controller
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月4日
 * 
 * @author zouqi
 */
@Controller
@RequestMapping("/license")
public class LicenseMgmtController {
    /**导出平台唯一码的后缀名*/
    private static final String FILE_SUFFIX = "dat";
    
    @Autowired
    private BaseLicenseMgmtAPI baseLicenseMgmtAPI;
    
    /**
     * l 获取平台唯一码请求
     * 
     * @param request 获取平台唯一码的request
     * 
     * @return 请求结果
     * @throws BusinessException 
     */
    @RequestMapping("/createDatFile")
    public DownloadWebResponse createDatFile(CreateDatFileWebRequest request) throws BusinessException {
        Assert.notNull(request, "请求参数不能为空");
        
        BaseCreateDatFileResponse baseCreateDatFileResponse = baseLicenseMgmtAPI.createDatFile(new BaseCreateDatFileRequest());
        return new DownloadWebResponse.Builder() //创建者模式
                .setContentType("application/octet-stream") //返回类型
                .setName(baseCreateDatFileResponse.getFiieName(), FILE_SUFFIX) //设置文件下载名称
                .setInputStream(baseCreateDatFileResponse.toInputStream(), baseCreateDatFileResponse.getFileContent().length())//设置文件流
                .build();
        
    }
    
    /**
     * license文件导入
     * 
     * @param file 上传的文件
     * 
     * @return 请求结果
     * @throws BusinessException 
     */
    @RequestMapping("/uploadLicFile")
    public DefaultWebResponse uploadLicFile(ChunkUploadFile file) throws BusinessException {
        Assert.notNull(file, "ChunkUploadFile is null");
        
        BaseUploadLicFileRequest request = new BaseUploadLicFileRequest();
        request.setFileName(file.getFileName());
        request.setFileMd5(file.getFileMD5());
        request.setFilePath(file.getFilePath());
        baseLicenseMgmtAPI.uploadLicFile(request);
        return DefaultWebResponse.Builder.success();
    }
    
    /**
     * license文件列表
     * 
     * @param webRequest web请求
     * @return 请求结果
     * @throws BusinessException 
     */
    @RequestMapping(value = "list")
    public DefaultWebResponse listLicenseFeature(BaseLicenseListWebRequest webRequest) throws BusinessException {

        Assert.notNull(webRequest, "请求参数不能为空");

        BaseLicenseListRequest apiRequest = new BaseLicenseListRequest();
        BeanUtils.copyProperties(webRequest, apiRequest);

        DefaultPageResponse<BaseLicenseFeatureDTO> response = baseLicenseMgmtAPI.listLicenseFeature(apiRequest);

        return DefaultWebResponse.Builder.success(response);
    }
    
    /**
     * license文件名校验
     * 
     * @param request 请求参数
     * 
     * @return 请求结果
     * @throws BusinessException 
     */
    @RequestMapping("/checkDuplication")
    public DefaultWebResponse checkDuplication(CheckDuplicationWebRequest request) throws BusinessException {
        Assert.notNull(request, "CheckDuplicationWebRequest is null");
        CheckDuplicationResponse response = baseLicenseMgmtAPI.validationLicenseFeature(request);
        return DefaultWebResponse.Builder.success(response);
    }

}
