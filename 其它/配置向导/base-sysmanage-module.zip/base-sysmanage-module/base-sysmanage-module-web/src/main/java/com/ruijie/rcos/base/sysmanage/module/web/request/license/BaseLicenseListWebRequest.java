package com.ruijie.rcos.base.sysmanage.module.web.request.license;

import com.ruijie.rcos.sk.webmvc.api.request.PageWebRequest;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月19日
 * 
 * @author zouqi
 */
public class BaseLicenseListWebRequest extends PageWebRequest {

}
