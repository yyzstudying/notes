package com.ruijie.rcos.base.sysmanage.module.web.ctrl.batchtask;

import com.ruijie.rcos.base.sysmanage.module.def.api.Log4jConfigAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.log4jconfig.BaseRemoveLog4jConfigRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.log4j.BaseDeleteLog4jConfigResponse;
import com.ruijie.rcos.base.sysmanage.module.web.BusinessKey;
import com.ruijie.rcos.sk.base.batch.*;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.webmvc.api.optlog.ProgrammaticOptLogRecorder;
import org.springframework.util.Assert;

import java.util.Iterator;
import java.util.UUID;

/**
 * Description: 批量删除log4j配置任务
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月16日
 *
 * @author GuoZhouYue
 */
public class Log4jConfigDeleteBatchTask extends AbstractBatchTaskHandler {

    private Log4jConfigAPI log4jConfigAPI;

    private ProgrammaticOptLogRecorder logRecorder;

    public Log4jConfigDeleteBatchTask(Iterator<BatchTaskItem> iterator, Log4jConfigAPI log4jConfigAPI, ProgrammaticOptLogRecorder logRecorder) {
        super(iterator);
        this.log4jConfigAPI = log4jConfigAPI;
        this.logRecorder = logRecorder;
    }

    @Override
    public BatchTaskItemResult processItem(BatchTaskItem batchTaskItem) throws BusinessException {
        Assert.notNull(batchTaskItem, "batchTaskItem must not be null");

        UUID itemID = batchTaskItem.getItemID();

        BaseRemoveLog4jConfigRequest request = new BaseRemoveLog4jConfigRequest();
        request.setId(itemID);
        try {
            BaseDeleteLog4jConfigResponse response = log4jConfigAPI.removeConfig(request);
            logRecorder.saveOptLog(BusinessKey.BASE_SYS_MANAGE_LOG4J_CONFIG_DELETE, response.getLoggerName());
        } catch (BusinessException e) {
            logRecorder.saveOptLog(BusinessKey.BASE_SYS_MANAGE_LOG4J_CONFIG_DELETE_FAIL, e.getI18nMessage());
            throw e;
        }

        return DefaultBatchTaskItemResult.builder() //
                .batchTaskItemStatus(BatchTaskItemStatus.SUCCESS) //
                .msgKey(BusinessKey.BASE_SYS_MANAGE_BATCH_ITEM_DELETE) //
                .build();
    }

    @Override
    public BatchTaskFinishResult onFinish(int successCount, int failCount) {
        return DefaultBatchTaskFinishResult.builder()//
                .batchTaskStatus(failCount == 0 ? BatchTaskStatus.SUCCESS : BatchTaskStatus.FAILURE)//
                .msgKey(BusinessKey.BASE_SYS_MANAGE_LOG4J_CONFIG_BATCH_DELETE_RESULT)//
                .msgArgs(new String[] {String.valueOf(successCount), String.valueOf(failCount)})//
                .build();
    }
}
