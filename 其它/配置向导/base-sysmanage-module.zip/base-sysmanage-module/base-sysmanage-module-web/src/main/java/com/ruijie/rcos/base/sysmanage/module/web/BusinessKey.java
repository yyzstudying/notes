package com.ruijie.rcos.base.sysmanage.module.web;

/**
 * Description: 国际化字符串常量
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月24日
 *
 * @author fyq
 */
public interface BusinessKey {

    /****************************** 公用批量删除创建成功与失败KEY *********************************/
    String BASE_SYS_MANAGE_BATCH_ITEM_DELETE = "base-sys_manage_batch_item_delete";
    String BASE_SYS_MANAGE_BATCH_ITEM_CREATE = "base-sys_manage_batch_item_create";
    String BASE_SYS_MANAGE_BATCH_ITEM_FAIL = "base-sys_manage_batch_item_fail";

    /****************************** 更新系统时间KEY *********************************/
    String BASE_SYS_MANAGE_SYSTEM_TIME_UPDATE = "base-sys_manage_system_time_update";
    String BASE_SYS_MANAGE_SYSTEM_TIME_UPDATE_FAIL = "base-sys_manage_system_time_update_fail";

    String BASE_SYS_MANAGE_SYSTEM_TIME_UPDATE_FROM_NTP = "base-sys_manage_system_time_update_from_ntp";
    String BASE_SYS_MANAGE_SYSTEM_TIME_UPDATE_FROM_NTP_FAIL = "base-sys_manage_system_time_update_from_ntp_fail";

    String BASE_SYS_MANAGE_SYSTEM_TIME_UPDATE_FAIL_BY_DNS_NOT_CONFIG = "base-sys_manage_system_time_update_fail_by_dns_not_config";

    /****************************** 网卡配置KEY *********************************/
    String BASE_SYS_MANAGE_NETWORK_UPDATE = "base-sys_manage_network_update";
    String BASE_SYS_MANAGE_NETWORK_UPDATE_FAIL = "base-sys_manage_network_update_fail";


    /****************************** 调试日志KEY *********************************/
    String BASE_SYS_MANAGE_DEBUG_LOG_CREATE = "base-sys_manage_debug_log_create";
    String BASE_SYS_MANAGE_DEBUG_LOG_CREATE_FAIL = "base-sys_manage_debug_log_create_fail";
    String BASE_SYS_MANAGE_DEBUG_LOG_BATCH_CREATE_ITEM_NAME = "base-sys_manage_debug_log_batch_create_item_name";
    String BASE_SYS_MANAGE_DEBUG_LOG_BATCH_CREATE_NAME = "base-sys_manage_debug_log_batch_create_name";
    String BASE_SYS_MANAGE_DEBUG_LOG_BATCH_CREATE_DESC = "base-sys_manage_debug_log_batch_create_desc";
    String BASE_SYS_MANAGE_DEBUG_LOG_BATCH_CREATE_SUCCESS = "base-sys_manage_debug_log_batch_create_success";
    String BASE_SYS_MANAGE_DEBUG_LOG_BATCH_CREATE_FAIL = "base-sys_manage_debug_log_batch_create_fail";

    String BASE_SYS_MANAGE_DEBUG_LOG_DELETE = "base-sys_manage_debug_log_delete";
    String BASE_SYS_MANAGE_DEBUG_LOG_DELETE_FAIL = "base-sys_manage_debug_log_delete_fail";
    String BASE_SYS_MANAGE_DEBUG_LOG_BATCH_DELETE_ITEM_NAME = "base-sys_manage_debug_log_batch_delete_item_name";
    String BASE_SYS_MANAGE_DEBUG_LOG_BATCH_DELETE_NAME = "base-sys_manage_debug_log_batch_delete_name";
    String BASE_SYS_MANAGE_DEBUG_LOG_BATCH_DELETE_DESC = "base-sys_manage_debug_log_batch_delete_desc";
    String BASE_SYS_MANAGE_DEBUG_LOG_BATCH_DELETE_RESULT = "base-sys_manage_debug_log_batch_delete_result";

    /****************************** 数据库备份KEY *********************************/
    String BASE_SYS_MANAGE_DATA_BACKUP_CREATE = "base-sys_manage_data_backup_create";
    String BASE_SYS_MANAGE_DATA_BACKUP_CREATE_FAIL = "base-sys_manage_data_backup_create_fail";
    String BASE_SYS_MANAGE_DATA_BACKUP_BATCH_CREATE_ITEM_NAME = "base-sys_manage_data_backup_batch_create_item_name";
    String BASE_SYS_MANAGE_DATA_BACKUP_BATCH_CREATE_NAME = "base-sys_manage_data_backup_batch_create_name";
    String BASE_SYS_MANAGE_DATA_BACKUP_BATCH_CREATE_DESC = "base-sys_manage_data_backup_batch_create_desc";
    String BASE_SYS_MANAGE_DATA_BACKUP_BATCH_CREATE_SUCCESS = "base-sys_manage_data_backup_batch_create_success";
    String BASE_SYS_MANAGE_DATA_BACKUP_BATCH_CREATE_FAIL = "base-sys_manage_data_backup_batch_create_fail";

    String BASE_SYS_MANAGE_DATA_BACKUP_DELETE = "base-sys_manage_data_backup_delete";
    String BASE_SYS_MANAGE_DATA_BACKUP_DELETE_FAIL = "base-sys_manage_data_backup_delete_fail";
    String BASE_SYS_MANAGE_DATA_BACKUP_BATCH_DELETE_ITEM_NAME = "base-sys_manage_data_backup_batch_delete_item_name";
    String BASE_SYS_MANAGE_DATA_BACKUP_BATCH_DELETE_NAME = "base-sys_manage_data_backup_batch_delete_name";
    String BASE_SYS_MANAGE_DATA_BACKUP_BATCH_DELETE_DESC = "base-sys_manage_data_backup_batch_delete_desc";
    String BASE_SYS_MANAGE_DATA_BACKUP_BATCH_DELETE_RESULT = "base-sys_manage_data_backup_batch_delete_result";

    String BASE_SYS_MANAGE_ILLEGAL_TIME_FORMAT = "base-sys_manage_illegal_time_format";
    String BASE_SYS_MANAGE_ILLEGAL_DATE_FORMAT = "base-sys_manage_illegal_date_format";
    String BASE_SYS_MANAGE_ARG_NOT_EMPTY = "base-sys_manage_arg_not_empty";
    String BASE_SYS_MANAGE_ARG_NOT_CONTAIN_EMPTY = "base-sys_manage_arg_not_contain_empty";
    String BASE_SYS_MANAGE_WEEK_ARG_RANGE_ERROR = "base-sys_manage_week_arg_range_error";

    String BASE_SYS_MANAGE_CREATE_TASK_SUCCESS_LOG = "base-sys_manage_create_task_success_log";
    String BASE_SYS_MANAGE_CREATE_TASK_FAIL_LOG = "base-sys_manage_create_task_fail_log";
    String BASE_SYS_MANAGE_EDIT_TASK_SUCCESS_LOG = "base-sys_manage_edit_task_success_log";
    String BASE_SYS_MANAGE_EDIT_TASK_FAIL_LOG = "base-sys_manage_edit_task_fail_log";

    String BASE_SYS_MANAGE_BATCH_DELETE_TASK_SUCCESS_LOG = "base-sys_manage_batch_delete_task_success_log";
    String BASE_SYS_MANAGE_BATCH_DELETE_TASK_FAIL_LOG = "base-sys_manage_batch_delete_task_fail_log";
    String BASE_SYS_MANAGE_BATCH_DELETE_TASK_NAME = "base-sys_manage_batch_delete_task_name";
    String BASE_SYS_MANAGE_BATCH_DELETE_TASK_DESC = "base-sys_manage_batch_delete_task_desc";
    String BASE_SYS_MANAGE_BATCH_DELETE_TASK = "base-sys_manage_batch_delete_task";
    String BASE_SYS_MANAGE_BATCH_DELETE_TASK_ALL_NOT_EXIST = "base-sys_manage_batch_delete_task_all_not_exist";
    
    /********************** License功能KEY *****************************/
    String BASE_SYS_MANAGE_LICENSE_SYSTEM_ERROR = "base-sys_manage_license_system_error";

    /****************************** log4j配置KEY *********************************/
    String BASE_SYS_MANAGE_LOG4J_CONFIG_CREATE = "base-sys_manage_log4j_config_create";
    String BASE_SYS_MANAGE_LOG4J_CONFIG_EDIT = "base-sys_manage_log4j_config_edit";
    String BASE_SYS_MANAGE_LOG4J_CONFIG_BATCH_DELETE_ITEM_NAME = "base-sys_manage_log4j_config_batch_delete_item_name";
    String BASE_SYS_MANAGE_LOG4J_CONFIG_BATCH_DELETE_NAME = "base-sys_manage_log4j_config_batch_delete_name";
    String BASE_SYS_MANAGE_LOG4J_CONFIG_BATCH_DELETE_DESC = "base-sys_manage_log4j_config_batch_delete_desc";
    String BASE_SYS_MANAGE_LOG4J_CONFIG_DELETE = "base-sys_manage_log4j_config_delete";
    String BASE_SYS_MANAGE_LOG4J_CONFIG_DELETE_FAIL = "base-sys_manage_log4j_config_delete_fail";
    String BASE_SYS_MANAGE_LOG4J_CONFIG_BATCH_DELETE_RESULT = "base-sys_manage_log4j_config_batch_delete_result";
}
