package com.ruijie.rcos.base.sysmanage.module.web.enums;

/**
 * Description: 系统时间设置类型
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月19日
 *
 * @author fyq
 */
public enum SystemTimeConfigType {
    SET, NTP;
}
