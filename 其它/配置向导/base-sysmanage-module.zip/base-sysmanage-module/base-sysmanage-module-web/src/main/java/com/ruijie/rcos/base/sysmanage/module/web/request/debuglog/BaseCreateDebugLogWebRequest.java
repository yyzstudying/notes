package com.ruijie.rcos.base.sysmanage.module.web.request.debuglog;

import com.ruijie.rcos.sk.webmvc.api.request.WebRequest;

/**
 * Description: 创建调试日志web请求
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月19日
 *
 * @author fyq
 */
public class BaseCreateDebugLogWebRequest implements WebRequest {
}
