package com.ruijie.rcos.base.sysmanage.module.web.ctrl.batchtask;

import java.util.Iterator;
import java.util.UUID;

import org.springframework.util.Assert;

import com.ruijie.rcos.base.sysmanage.module.def.api.DataBackupAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.databackup.BaseDeleteDataBackupRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.databackup.BaseDeleteDataBackupResponse;
import com.ruijie.rcos.base.sysmanage.module.web.BusinessKey;
import com.ruijie.rcos.sk.base.batch.*;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.webmvc.api.optlog.ProgrammaticOptLogRecorder;

/**
 * Description: 批量删除数据库备份任务
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月16日
 *
 * @author fyq
 */
public class DataBackupDeleteBatchTask extends AbstractBatchTaskHandler {

    private DataBackupAPI dataBackupAPI;

    private ProgrammaticOptLogRecorder logRecorder;

    public DataBackupDeleteBatchTask(Iterator<BatchTaskItem> iterator, DataBackupAPI dataBackupAPI, ProgrammaticOptLogRecorder logRecorder) {
        super(iterator);
        this.dataBackupAPI = dataBackupAPI;
        this.logRecorder = logRecorder;
    }

    @Override
    public BatchTaskItemResult processItem(BatchTaskItem item) throws BusinessException {

        Assert.notNull(item, "item must not be null");

        deleteDataBackup(item.getItemID(), logRecorder);

        return DefaultBatchTaskItemResult.builder()//
                .batchTaskItemStatus(BatchTaskItemStatus.SUCCESS)//
                .msgKey(BusinessKey.BASE_SYS_MANAGE_BATCH_ITEM_DELETE)//
                .build();
    }

    @Override
    public BatchTaskFinishResult onFinish(int successCount, int failCount) {

        return DefaultBatchTaskFinishResult.builder()//
                .batchTaskStatus(failCount == 0 ? BatchTaskStatus.SUCCESS : BatchTaskStatus.FAILURE)//
                .msgKey(BusinessKey.BASE_SYS_MANAGE_DATA_BACKUP_BATCH_DELETE_RESULT)//
                .msgArgs(new String[] {String.valueOf(successCount), String.valueOf(failCount)})//
                .build();
    }

    private void deleteDataBackup(UUID id, ProgrammaticOptLogRecorder logRecorder) throws BusinessException {

        BaseDeleteDataBackupRequest apiRequest = new BaseDeleteDataBackupRequest();
        apiRequest.setId(id);

        try {
            BaseDeleteDataBackupResponse apiResponse = dataBackupAPI.deleteDataBackup(apiRequest);
            logRecorder.saveOptLog(BusinessKey.BASE_SYS_MANAGE_DATA_BACKUP_DELETE, apiResponse.getFileName());
        } catch (BusinessException e) {
            logRecorder.saveOptLog(BusinessKey.BASE_SYS_MANAGE_DATA_BACKUP_DELETE_FAIL, e.getI18nMessage());
            throw e;
        }
    }
}
