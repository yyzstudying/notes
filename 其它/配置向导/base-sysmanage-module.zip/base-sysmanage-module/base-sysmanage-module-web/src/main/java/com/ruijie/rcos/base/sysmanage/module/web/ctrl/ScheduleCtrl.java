package com.ruijie.rcos.base.sysmanage.module.web.ctrl;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ruijie.rcos.base.sysmanage.module.def.api.ScheduleAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.schedule.*;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.schedule.BaseBatchQueryScheduleResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.schedule.BaseListTaskTypeResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.schedule.BaseQueryScheduleResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.schedule.BaseQueryTaskTypeResponse;
import com.ruijie.rcos.base.sysmanage.module.def.dto.ScheduleDTO;
import com.ruijie.rcos.base.sysmanage.module.web.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.web.request.schedule.*;
import com.ruijie.rcos.base.sysmanage.module.web.validation.ScheduleValidation;
import com.ruijie.rcos.sk.base.batch.*;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.log.LoggerFactory;
import com.ruijie.rcos.sk.base.validation.EnableCustomValidate;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultPageResponse;
import com.ruijie.rcos.sk.webmvc.api.optlog.ProgrammaticOptLogRecorder;
import com.ruijie.rcos.sk.webmvc.api.response.DefaultWebResponse;

/**
 * 
 * Description: 任务调度类
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年11月9日
 * 
 * @author hhx
 */
@Controller
@EnableCustomValidate(validateClass = ScheduleValidation.class)
@RequestMapping("systemConfig/schedule")
public class ScheduleCtrl {

    protected final static Logger LOGGER = LoggerFactory.getLogger(ScheduleCtrl.class);

    @Autowired
    private ScheduleAPI scheduleAPI;

    /**
     * 创建定时器
     * 
     * @param baseCreateScheduleWebRequest 请求参数
     * @param optLogRecorder 日志记录
     * @return 响应
     * @throws BusinessException 业务异常
     */
    @RequestMapping(value = "/create")
    @EnableCustomValidate(validateMethod = "createScheduleTaskValidate")
    public DefaultWebResponse createScheduleTask(BaseCreateScheduleWebRequest baseCreateScheduleWebRequest, ProgrammaticOptLogRecorder optLogRecorder)
            throws BusinessException {
        Assert.notNull(baseCreateScheduleWebRequest, "请求参数不能为空");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("创建定时器请求开始：{}", JSONObject.toJSONString(baseCreateScheduleWebRequest));
        }
        BaseCreateScheduleRequest createScheduleRequest = new BaseCreateScheduleRequest();
        BeanUtils.copyProperties(baseCreateScheduleWebRequest, createScheduleRequest);
        BaseQueryTaskTypeResponse queryTaskTypeResponse = getBaseQueryTaskTypeResponse(createScheduleRequest.getTaskTypeId());

        try {
            scheduleAPI.createSchedule(createScheduleRequest);
            LOGGER.debug("创建定时器成功");
            optLogRecorder.saveOptLog(BusinessKey.BASE_SYS_MANAGE_CREATE_TASK_SUCCESS_LOG, queryTaskTypeResponse.getLabel());
            return DefaultWebResponse.Builder.success();

        } catch (BusinessException e) {
            optLogRecorder.saveOptLog(BusinessKey.BASE_SYS_MANAGE_CREATE_TASK_FAIL_LOG, queryTaskTypeResponse.getLabel(), e.getI18nMessage());
            throw e;
        }
    }

    /**
     * 删除定时任务
     * 
     * @param baseDeleteScheduleWebRequest 请求参数
     * @param batchTaskBuilder 批量任务建造者
     * @param optLogRecorder 日志记录者
     * @throws BusinessException 业务异常
     * @return 响应
     */
    @RequestMapping(value = "/delete")
    public DefaultWebResponse deleteSchedule(BaseDeleteScheduleWebRequest baseDeleteScheduleWebRequest, BatchTaskBuilder batchTaskBuilder,
            ProgrammaticOptLogRecorder optLogRecorder) throws BusinessException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("删除定时器请求开始：{}", JSONObject.toJSONString(baseDeleteScheduleWebRequest));
        }
        Assert.notNull(baseDeleteScheduleWebRequest, "请求参数不能为空");
        final Map<UUID, String> taskTypeId2NameMap = getScheduleTypeToScheduleTypeNameMap();

        BaseBatchQueryScheduleResponse baseBatchQueryScheduleResponse =
                scheduleAPI.batchQueryTask(new BaseBatchQueryScheduleRequest(baseDeleteScheduleWebRequest.getIdArr()));

        final Map<UUID, UUID> taskId2TaskTypeIdMap = baseBatchQueryScheduleResponse.toTaskIdTaskTypeIdMap();

        List<BatchTaskItem> defaultBatchTaskItemList = Stream.of(baseDeleteScheduleWebRequest.getIdArr())
                .filter(id -> taskId2TaskTypeIdMap.containsKey(id)).map(id -> DefaultBatchTaskItem.builder().itemId(id) //
                        .itemName(taskTypeId2NameMap.get(taskId2TaskTypeIdMap.get(id))) //
                        .build()) //
                .collect(Collectors.toList());
        if (ObjectUtils.isEmpty(defaultBatchTaskItemList)) {
            throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_BATCH_DELETE_TASK_ALL_NOT_EXIST);
        }
        BatchTaskHandler<BatchTaskItem> batchDeleteTaskHandle = new BatchDeleteScheduleTaskHandle(defaultBatchTaskItemList, optLogRecorder);

        BatchTaskSubmitResult batchTaskSubmitResult = batchTaskBuilder.setTaskName(BusinessKey.BASE_SYS_MANAGE_BATCH_DELETE_TASK_NAME)
                .setTaskDesc(BusinessKey.BASE_SYS_MANAGE_BATCH_DELETE_TASK_DESC) //
                .registerHandler(batchDeleteTaskHandle) //
                .start();

        return DefaultWebResponse.Builder.success(batchTaskSubmitResult);
    }

    /**
     * 根据id查询定时器信息
     *
     * @param baseQueryScheduleWebRequest 请求参数
     * @return 响应
     * @throws BusinessException 业务异常
     */
    @RequestMapping(value = "/detail")
    public DefaultWebResponse queryScheduleTask(BaseQueryScheduleWebRequest baseQueryScheduleWebRequest) throws BusinessException {
        Assert.notNull(baseQueryScheduleWebRequest, "请求参数不能为空");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("获取定时器请求开始：{}", JSONObject.toJSONString(baseQueryScheduleWebRequest));
        }
        BaseQueryScheduleRequest queryScheduleRequest = new BaseQueryScheduleRequest();
        BeanUtils.copyProperties(baseQueryScheduleWebRequest, queryScheduleRequest);
        BaseQueryScheduleResponse baseQueryScheduleResponse = scheduleAPI.querySchedule(queryScheduleRequest);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("获取定时器请求结束：{}", JSONObject.toJSONString(baseQueryScheduleResponse));
        }
        return DefaultWebResponse.Builder.success(baseQueryScheduleResponse);
    }

    /**
     * 编辑定时任务
     * 
     * @param baseEditScheduleWebRequest 请求参数
     * @param optLogRecorder 操作日志
     * @return 响应
     * @throws BusinessException 业务异常
     */
    @RequestMapping(value = "/edit")
    public DefaultWebResponse editSchedule(BaseEditScheduleWebRequest baseEditScheduleWebRequest, ProgrammaticOptLogRecorder optLogRecorder)
            throws BusinessException {
        Assert.notNull(baseEditScheduleWebRequest, "请求参数不能为空");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("编辑定时器请求开始：{}", JSONObject.toJSONString(baseEditScheduleWebRequest));
        }
        BaseEditScheduleRequest editScheduleRequest = new BaseEditScheduleRequest();
        BeanUtils.copyProperties(baseEditScheduleWebRequest, editScheduleRequest);

        BaseQueryTaskTypeResponse queryTaskTypeResponse = getBaseQueryTaskTypeResponse(editScheduleRequest.getTaskTypeId());
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("编辑定时器获取定时器：{}", JSONObject.toJSONString(queryTaskTypeResponse));
        }
        try {
            scheduleAPI.editSchedule(editScheduleRequest);
            optLogRecorder.saveOptLog(BusinessKey.BASE_SYS_MANAGE_EDIT_TASK_SUCCESS_LOG, queryTaskTypeResponse.getLabel());
            LOGGER.debug("编辑定时器请求结束");
        } catch (BusinessException e) {
            optLogRecorder.saveOptLog(BusinessKey.BASE_SYS_MANAGE_EDIT_TASK_FAIL_LOG, queryTaskTypeResponse.getLabel(), e.getI18nMessage());
            throw e;
        }

        return DefaultWebResponse.Builder.success();
    }

    private BaseQueryTaskTypeResponse getBaseQueryTaskTypeResponse(UUID taskTypeId) throws BusinessException {
        BaseQueryTaskTypeRequest queryTaskTypeRequest = new BaseQueryTaskTypeRequest();
        queryTaskTypeRequest.setId(taskTypeId);
        return scheduleAPI.queryTaskType(queryTaskTypeRequest);
    }

    /**
     * 获取定时任务列表
     * 
     * @param baseListScheduleWebRequest 请求参数
     * @return 定时任务列表
     */
    @RequestMapping(value = "/list")
    public DefaultWebResponse listSchedule(BaseListScheduleWebRequest baseListScheduleWebRequest) {
        Assert.notNull(baseListScheduleWebRequest, "请求参数不能为空");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("获取定时器列表请求开始：{}", JSONObject.toJSONString(baseListScheduleWebRequest));
        }
        BaseListScheduleRequest listScheduleRequest = new BaseListScheduleRequest();
        BeanUtils.copyProperties(baseListScheduleWebRequest, listScheduleRequest);
        DefaultPageResponse<ScheduleDTO> scheduleDTODefaultPageResponse = scheduleAPI.listSchedule(listScheduleRequest);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("获取定时器列表，获取请求类型列表成功：{}", JSONObject.toJSONString(scheduleDTODefaultPageResponse.getItemArr()));
        }
        Map<UUID, String> id2NameMap = getScheduleTypeToScheduleTypeNameMap();
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("获取定时器列表，类型id到名称映射成功：{}", JSONObject.toJSONString(id2NameMap));
        }

        ScheduleDTO[] scheduleDTOArr = Optional.ofNullable(scheduleDTODefaultPageResponse.getItemArr()).orElse(new ScheduleDTO[1]);

        Arrays.stream(scheduleDTOArr).forEach(scheduleDTO -> {
            String taskTypeName = id2NameMap.get(scheduleDTO.getTaskTypeId());
            scheduleDTO.setTaskTypeName(taskTypeName);
        });

        return DefaultWebResponse.Builder.success(scheduleDTODefaultPageResponse);
    }

    /**
     * 获取定时任务类型列表
     * 
     * @param baseListTaskTypeWebRequest web请求
     * @return 任务类型列表
     */
    @RequestMapping(value = "/type/list")
    public DefaultWebResponse listTaskType(BaseListTaskTypeWebRequest baseListTaskTypeWebRequest) {
        Assert.notNull(baseListTaskTypeWebRequest, "请求参数不能为空");
        LOGGER.debug("获取定时器类型列表开始");
        BaseListTaskTypeRequest listScheduleRequest = new BaseListTaskTypeRequest();
        BaseListTaskTypeResponse baseListTaskTypeResponse = scheduleAPI.listTaskType(listScheduleRequest);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("获取定时器类型列表结束:{}", JSON.toJSONString(baseListTaskTypeResponse.getItemArr()));
        }
        return DefaultWebResponse.Builder.success(baseListTaskTypeResponse);
    }


    private Map<UUID, String> getScheduleTypeToScheduleTypeNameMap() {
        BaseListTaskTypeResponse baseListTaskTypeResponse = scheduleAPI.listTaskType(new BaseListTaskTypeRequest());
        return baseListTaskTypeResponse.toIdLabelMap();
    }

    /**
     * 批量删除任务处理器
     */
    protected class BatchDeleteScheduleTaskHandle extends AbstractBatchTaskHandler {
        private ProgrammaticOptLogRecorder optLogRecorder;


        public BatchDeleteScheduleTaskHandle(Collection<? extends BatchTaskItem> batchTaskItemCollection, ProgrammaticOptLogRecorder optLogRecorder) {
            super(batchTaskItemCollection);
            this.optLogRecorder = optLogRecorder;
        }

        @Override
        public BatchTaskItemResult processItem(BatchTaskItem item) throws BusinessException {
            scheduleAPI.deleteSchedule(new BaseDeleteScheduleRequest(item.getItemID()));

            LOGGER.debug("删除定时任务成功：{}", item.getItemID());
            optLogRecorder.saveOptLog(BusinessKey.BASE_SYS_MANAGE_BATCH_DELETE_TASK_SUCCESS_LOG, item.getItemName());
            return DefaultBatchTaskItemResult.success(BusinessKey.BASE_SYS_MANAGE_BATCH_ITEM_DELETE);
        }

        @Override
        public void afterException(BatchTaskItem item, Exception ex) {
            LOGGER.error("删除定时任务失败：[" + item.getItemID() + "]", ex);
            if (ex instanceof BusinessException) {
                optLogRecorder.saveOptLog(BusinessKey.BASE_SYS_MANAGE_BATCH_DELETE_TASK_FAIL_LOG, item.getItemName(),
                        ((BusinessException) ex).getI18nMessage());
            }
        }

        @Override
        public BatchTaskFinishResult onFinish(int successCount, int failCount) {
            return DefaultBatchTaskFinishResult.builder() //
                    .batchTaskStatus(BatchTaskStatus.SUCCESS) //
                    .msgKey(BusinessKey.BASE_SYS_MANAGE_BATCH_DELETE_TASK) //
                    .msgArgs(new String[] {String.valueOf(successCount), String.valueOf(failCount)}) //
                    .build();
        }
    }

}


