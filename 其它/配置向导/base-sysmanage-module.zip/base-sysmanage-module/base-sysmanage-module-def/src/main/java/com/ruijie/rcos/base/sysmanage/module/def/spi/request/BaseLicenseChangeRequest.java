package com.ruijie.rcos.base.sysmanage.module.def.spi.request;

import com.ruijie.rcos.base.sysmanage.module.def.dto.license.NotifyLicenseChangeDTO;
import com.ruijie.rcos.sk.base.annotation.NotNull;
import com.ruijie.rcos.sk.modulekit.api.comm.DispatcherKey;
import com.ruijie.rcos.sk.modulekit.api.comm.Request;

/**
 * Description: 变更license类型request
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月4日
 * 
 * @author zouqi
 */
public class BaseLicenseChangeRequest implements Request {

    /** License控制项编码 */
    @DispatcherKey
    @NotNull
    private String featureCode;
    
    /** License信息 */
    @NotNull
    private NotifyLicenseChangeDTO[] featureArr;

    
    public String getFeatureCode() {
        return featureCode;
    }

    
    public void setFeatureCode(String featureCode) {
        this.featureCode = featureCode;
    }

    
    public NotifyLicenseChangeDTO[] getFeatureArr() {
        return featureArr;
    }

    
    public void setFeatureArr(NotifyLicenseChangeDTO[] featureArr) {
        this.featureArr = featureArr;
    }
    
    
    
}
