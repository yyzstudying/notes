package com.ruijie.rcos.base.sysmanage.module.def.spi;

import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseValidateLicenseRequest;
import com.ruijie.rcos.base.sysmanage.module.def.spi.response.BaseValidateLicenseResponse;
import com.ruijie.rcos.sk.modulekit.api.comm.DispatcherInterface;
import com.ruijie.rcos.sk.modulekit.api.tx.NoRollback;

/**
 * Description: License业务校验的SPI
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月4日
 * 
 * @author zouqi
 */
@DispatcherInterface
public interface BaseLicenseFeatureValidateSPI {

    /**
     * license的合法性校验
     * @param request 验证License信息request
     * 
     * @return BaseValidateLicenseResponse 应答结果
     */
    @NoRollback
    BaseValidateLicenseResponse checkLicenseViolation(BaseValidateLicenseRequest request);
}
