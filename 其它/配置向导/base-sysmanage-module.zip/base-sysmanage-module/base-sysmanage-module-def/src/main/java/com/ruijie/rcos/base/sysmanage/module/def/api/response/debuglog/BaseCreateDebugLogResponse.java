package com.ruijie.rcos.base.sysmanage.module.def.api.response.debuglog;

import com.ruijie.rcos.sk.modulekit.api.comm.DefaultResponse;

import java.util.UUID;

/**
 * Description: 创建调试日志Response
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月27日
 *
 * @author fyq
 */
public class BaseCreateDebugLogResponse extends DefaultResponse {

    private UUID id;

    private String fileName;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
}
