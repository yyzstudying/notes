package com.ruijie.rcos.base.sysmanage.module.def.spi;

import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseLicenseChangeRequest;
import com.ruijie.rcos.sk.modulekit.api.comm.DispatcherInterface;
import com.ruijie.rcos.sk.modulekit.api.tx.NoRollback;

/**
 * Description: 进行license变更的通知类
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月4日
 * 
 * @author zouqi
 */
@DispatcherInterface
public interface BaseLicenseFeatureNotifySPI {

    /**
     * license 类型变更 请求
     * @param request  request变更license类型 request
     */
    @NoRollback
    void notifyLicenseChange(BaseLicenseChangeRequest request);
}
