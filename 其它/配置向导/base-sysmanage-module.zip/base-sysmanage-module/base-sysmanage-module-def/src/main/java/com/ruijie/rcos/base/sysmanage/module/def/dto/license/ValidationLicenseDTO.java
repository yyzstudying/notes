package com.ruijie.rcos.base.sysmanage.module.def.dto.license;

import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureStatus;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureType;
import com.ruijie.rcos.sk.base.annotation.NotNull;

/**
 * Description: 验证license授权是否有问题的dto
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月4日
 * 
 * @author zouqi
 */
public class ValidationLicenseDTO {
    
    /*** 试用时长 * */
    @NotNull
    private Long trialRemainder;
    
    /*** License控制项编码 * */
    @NotNull
    private String featureCode;
    
    /*** License类型 * */
    @NotNull
    private BaseFeatureType featureType;
    
    /*** License状态* */
    @NotNull
    private BaseFeatureStatus featureStatus;

    public Long getTrialRemainder() {
        return trialRemainder;
    }

    public void setTrialRemainder(Long trialRemainder) {
        this.trialRemainder = trialRemainder;
    }

    public String getFeatureCode() {
        return featureCode;
    }

    public void setFeatureCode(String featureCode) {
        this.featureCode = featureCode;
    }

    public BaseFeatureType getFeatureType() {
        return featureType;
    }

    public void setFeatureType(BaseFeatureType featureType) {
        this.featureType = featureType;
    }

    public BaseFeatureStatus getFeatureStatus() {
        return featureStatus;
    }

    public void setFeatureStatus(BaseFeatureStatus featureStatus) {
        this.featureStatus = featureStatus;
    }

}
