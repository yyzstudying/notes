package com.ruijie.rcos.base.sysmanage.module.def.enums;

/**
 * Description: license授权类型
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月4日
 * 
 * @author zouqi
 */
public enum BaseFeatureType {
    PERPETUAL,//永久授权
    TEMPORARY, //临时授权
}
