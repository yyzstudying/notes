package com.ruijie.rcos.base.sysmanage.module.def.spi;

import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseNetworkChangeBeforeRequest;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.modulekit.api.comm.DispatcherInterface;
import com.ruijie.rcos.sk.modulekit.api.tx.NoRollback;

/**
 * Description: 网卡信息修改前SPI接口
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月06日
 *
 * @author fyq
 */
@DispatcherInterface
public interface BaseNetworkChangeBeforeSPI {

    /**
     * 网卡信息修改前SPI接口，业务不允许修改IP请自行抛异常，带上不允许的理由
     * @param networkChangeBeforeRequest spi请求
     * @throws BusinessException 业务异常
     */
    @NoRollback
    void beforeNetworkChange(BaseNetworkChangeBeforeRequest networkChangeBeforeRequest) throws BusinessException;
}
