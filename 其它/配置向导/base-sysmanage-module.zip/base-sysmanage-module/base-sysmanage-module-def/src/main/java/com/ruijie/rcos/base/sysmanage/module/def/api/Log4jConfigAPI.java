package com.ruijie.rcos.base.sysmanage.module.def.api;

import com.ruijie.rcos.base.sysmanage.module.def.api.request.log4jconfig.BaseAddLog4jConfigRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.log4jconfig.BaseDetailLog4jConfigRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.log4jconfig.BaseEditLog4jConfigRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.log4jconfig.BaseListLog4jConfigRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.log4jconfig.BaseRemoveLog4jConfigRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.log4j.BaseDeleteLog4jConfigResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.log4j.BaseDetailLog4jConfigResponse;
import com.ruijie.rcos.base.sysmanage.module.def.dto.Log4jConfigDTO;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultPageResponse;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultResponse;
import com.ruijie.rcos.sk.modulekit.api.tx.NoRollback;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年02月18日
 *
 * @author GuoZhouYue
 */
public interface Log4jConfigAPI {

    /**
     * 获取所有log配置
     *
     * @param request request
     * @return DefaultPageResponse<Log4jConfigDTO>
     */
    @NoRollback
    DefaultPageResponse<Log4jConfigDTO> getAll(BaseListLog4jConfigRequest request);

    /**
     * 获取一个log配置
     *
     * @param request request
     * @return BaseDetailLog4jConfigResponse
     * @throws BusinessException BusinessException
     */
    @NoRollback
    BaseDetailLog4jConfigResponse getOne(BaseDetailLog4jConfigRequest request) throws BusinessException;

    /**
     * 添加一个log配置
     *
     * @param request request
     * @return DefaultResponse
     * @throws BusinessException BusinessException
     */
    @NoRollback
    DefaultResponse addConfig(BaseAddLog4jConfigRequest request) throws BusinessException;

    /**
     * 删除log配置
     *
     * @param request request
     * @return BaseDeleteLog4jConfigResponse
     * @throws BusinessException BusinessException
     */
    @NoRollback
    BaseDeleteLog4jConfigResponse removeConfig(BaseRemoveLog4jConfigRequest request) throws BusinessException;

    /**
     * 编辑log配置
     *
     * @param request request
     * @return DefaultResponse
     * @throws BusinessException BusinessException
     */
    @NoRollback
    DefaultResponse editConfig(BaseEditLog4jConfigRequest request) throws BusinessException;
}
