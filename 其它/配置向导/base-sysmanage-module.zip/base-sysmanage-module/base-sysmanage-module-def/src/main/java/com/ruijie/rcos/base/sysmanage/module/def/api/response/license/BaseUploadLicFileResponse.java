package com.ruijie.rcos.base.sysmanage.module.def.api.response.license;

import com.ruijie.rcos.sk.modulekit.api.comm.DefaultResponse;

/**
 * Description: 导入License文件response
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月1日
 * 
 * @author zouqi
 */
public class BaseUploadLicFileResponse extends DefaultResponse {
    
}
