package com.ruijie.rcos.base.sysmanage.module.def.api.response.systemtime;

import com.ruijie.rcos.sk.modulekit.api.comm.DefaultResponse;

/**
 * Description: 更新系统时间api Response
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月26日
 *
 * @author fyq
 */
public class BaseUpdateSystemTimeResponse extends DefaultResponse {

    private Boolean shouldReboot;
    
    public BaseUpdateSystemTimeResponse() {
        // 
    }
    
    public BaseUpdateSystemTimeResponse(Boolean shouldReboot) {
        this.shouldReboot = shouldReboot;
    }

    public Boolean getShouldReboot() {
        return shouldReboot;
    }

    public void setShouldReboot(Boolean shouldReboot) {
        this.shouldReboot = shouldReboot;
    }
}
