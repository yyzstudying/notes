package com.ruijie.rcos.base.sysmanage.module.def.api.response.license;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import org.springframework.util.Assert;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultResponse;

/**
 * Description: 获取平台唯一码 response
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月1日
 * 
 * @author zouqi
 */
public class BaseCreateDatFileResponse extends DefaultResponse {

    // 文件内容
    private String fileContent;

    // 文件名
    private String fiieName;

    public String getFileContent() {
        return fileContent;
    }

    public void setFileContent(String fileContent) {
        this.fileContent = fileContent;
    }

    public String getFiieName() {
        return fiieName;
    }

    public void setFiieName(String fiieName) {
        this.fiieName = fiieName;
    }

    /**
     * 文件内容转化为流
     * 
     * @return InputStream
     * 
     * @throws Exception 流处理异常
     */
    public InputStream toInputStream() {
        Assert.notNull(fileContent, "fileContent不能为空");
        try {
            InputStream inputStream = new ByteArrayInputStream(fileContent.getBytes("UTF-8"));
            return inputStream;
        } catch (UnsupportedEncodingException ex) {
            // 不会抛出这个异常
            throw new RuntimeException(ex);
        }
    }

}
