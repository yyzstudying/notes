package com.ruijie.rcos.base.sysmanage.module.def.api;

import com.ruijie.rcos.base.sysmanage.module.def.api.request.systemtime.BaseUpdateSystemTimeFromNtpRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.systemtime.BaseUpdateSystemTimeRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.systemtime.BaseUpdateSystemTimeResponse;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.modulekit.api.tx.NoRollback;

/**
 * Description: 系统时间接口
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年11月28日
 *
 * @author fyq
 */

public interface SystemTimeAPI {

    /**
     * 更新系统时间接口
     * 
     * @param apiRequest 更新系统时间请求
     * @return 更新结果
     * @throws BusinessException 请求异常
     */
    @NoRollback
    BaseUpdateSystemTimeResponse updateSystemTime(BaseUpdateSystemTimeRequest apiRequest) throws BusinessException;

    /**
     * 更新系统时间接口
     *
     * @param apiRequest 从ntp更新系统时间请求
     * @return 更新结果
     * @throws BusinessException 请求异常
     */
    @NoRollback
    BaseUpdateSystemTimeResponse updateSystemTimeFromNtp(BaseUpdateSystemTimeFromNtpRequest apiRequest) throws BusinessException;
}
