package com.ruijie.rcos.base.sysmanage.module.def.api.request.databackup;

import com.ruijie.rcos.sk.modulekit.api.comm.Request;

/**
 * Description: 数据库备份请求
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月06日
 *
 * @author fyq
 */
public class BaseCreateDataBackupRequest implements Request {
}
