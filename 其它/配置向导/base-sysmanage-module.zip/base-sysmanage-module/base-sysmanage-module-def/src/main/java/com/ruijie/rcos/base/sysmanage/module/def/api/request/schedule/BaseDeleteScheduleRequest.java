package com.ruijie.rcos.base.sysmanage.module.def.api.request.schedule;

import java.util.UUID;
import org.springframework.util.Assert;
import com.ruijie.rcos.sk.base.annotation.NotNull;
import com.ruijie.rcos.sk.modulekit.api.comm.Request;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月06日
 *
 * @author xgx
 */
public class BaseDeleteScheduleRequest implements Request {
    @NotNull
    private UUID id;

    public BaseDeleteScheduleRequest() {

    }

    public BaseDeleteScheduleRequest(UUID id) {
        Assert.notNull(id, "id is not null");
        this.id = id;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}
