package com.ruijie.rcos.base.sysmanage.module.def.enums;

/**
 * Description: license授权状态
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月4日
 * 
 * @author zouqi
 */
public enum BaseFeatureStatus {
    AVALIABLE,//可用的
    EXPIRED, //过期的
}
