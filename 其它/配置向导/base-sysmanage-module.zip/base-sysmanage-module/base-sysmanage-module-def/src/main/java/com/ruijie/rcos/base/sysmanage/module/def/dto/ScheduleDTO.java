package com.ruijie.rcos.base.sysmanage.module.def.dto;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;

import com.alibaba.fastjson.annotation.JSONField;
import com.ruijie.rcos.base.sysmanage.module.def.common.Constant;
import com.ruijie.rcos.base.sysmanage.module.def.enums.TaskCycle;
import org.apache.logging.log4j.core.util.CronExpression;
import org.springframework.lang.Nullable;
import org.springframework.util.Assert;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月06日
 *
 * @author xgx
 */
public class ScheduleDTO {
    private UUID id;

    private UUID taskTypeId;

    private String taskTypeName;

    @JSONField(name = "cycle")
    private TaskCycle taskCycle;

    private String scheduleDate;

    private String scheduleTime;

    private Integer[] dayOfWeekArr;

    private String description;

    public ScheduleDTO(TaskCycle taskCycle, @Nullable LocalDate scheduleDate, LocalTime scheduleTime, @Nullable Integer[] dayOfWeekArr) {
        Assert.notNull(taskCycle, "任务周期不能为空");
        Assert.notNull(scheduleTime, "任务时间不能为空");
        this.taskCycle = taskCycle;
        this.scheduleDate = formatLocalDate(scheduleDate);
        this.scheduleTime = formatLocalTime(scheduleTime);
        this.dayOfWeekArr = dayOfWeekArr;
    }

    public ScheduleDTO() {
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public UUID getTaskTypeId() {
        return taskTypeId;
    }

    public void setTaskTypeId(UUID taskTypeId) {
        this.taskTypeId = taskTypeId;
    }

    public TaskCycle getTaskCycle() {
        return taskCycle;
    }

    public void setTaskCycle(TaskCycle taskCycle) {
        this.taskCycle = taskCycle;
    }

    public String getScheduleDate() {
        return scheduleDate;
    }

    public void setScheduleDate(String scheduleDate) {
        this.scheduleDate = scheduleDate;
    }

    public String getScheduleTime() {
        return scheduleTime;
    }

    public void setScheduleTime(String scheduleTime) {
        this.scheduleTime = scheduleTime;
    }

    public Integer[] getDayOfWeekArr() {
        return dayOfWeekArr;
    }

    public void setDayOfWeekArr(Integer[] dayOfWeekArr) {
        this.dayOfWeekArr = dayOfWeekArr;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTaskTypeName() {
        return taskTypeName;
    }

    public void setTaskTypeName(String taskTypeName) {
        this.taskTypeName = taskTypeName;
    }

    private String formatLocalDate(LocalDate scheduleDate) {
        String scheduleDateStr = null;
        if (null != scheduleDate) {
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(Constant.YYYY_MM_DD);
            scheduleDateStr = scheduleDate.format(dateFormatter);
        }
        return scheduleDateStr;
    }

    private String formatLocalTime(LocalTime scheduleTime) {
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern(Constant.HH_MM_SS);
        return scheduleTime.format(timeFormatter);
    }
}
