package com.ruijie.rcos.base.sysmanage.module.def.dto.license;

import org.springframework.lang.Nullable;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureType;
import com.ruijie.rcos.sk.base.annotation.NotNull;

/**
 * Description: License授权变化通知上层业务DTO
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月4日
 * 
 * @author zouqi
 */
public class NotifyLicenseChangeDTO {
    
    /*** 试用时长 * */
    @NotNull
    private Long trialDuration;
    
    /*** 试用剩余时长 * */
    @NotNull
    private Long trialRemainder;
    
    /*** License控制项编码 * */
    @NotNull
    private String featureCode;
    
    /*** License类型 * */
    @NotNull
    private BaseFeatureType featureType;
    
    /** license文件 名称 */
    @Nullable
    private String fileName;
    
    
    public Long getTrialDuration() {
        return trialDuration;
    }

    public void setTrialDuration(Long trialDuration) {
        this.trialDuration = trialDuration;
    }

    public Long getTrialRemainder() {
        return trialRemainder;
    }

    public void setTrialRemainder(Long trialRemainder) {
        this.trialRemainder = trialRemainder;
    }

    public String getFeatureCode() {
        return featureCode;
    }

    public void setFeatureCode(String featureCode) {
        this.featureCode = featureCode;
    }

    public BaseFeatureType getFeatureType() {
        return featureType;
    }

    public void setFeatureType(BaseFeatureType featureType) {
        this.featureType = featureType;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

}
