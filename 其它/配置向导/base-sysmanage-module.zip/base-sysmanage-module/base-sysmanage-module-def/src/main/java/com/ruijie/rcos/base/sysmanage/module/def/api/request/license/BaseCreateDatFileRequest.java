package com.ruijie.rcos.base.sysmanage.module.def.api.request.license;

import com.ruijie.rcos.sk.modulekit.api.comm.Request;

/**
 * Description: 获取平台唯一码请求
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月1日
 * 
 * @author zouqi
 */
public class BaseCreateDatFileRequest implements Request { 

}
