package com.ruijie.rcos.base.sysmanage.module.def.spi.request;

import com.ruijie.rcos.sk.base.annotation.NotNull;
import com.ruijie.rcos.sk.modulekit.api.comm.DispatcherKey;
import com.ruijie.rcos.sk.modulekit.api.comm.Request;

/**
 * Description: 系统时间修改前SPI请求
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月06日
 *
 * @author fyq
 */
public class BaseSystemTimeChangeBeforeRequest implements Request {

    @NotNull
    @DispatcherKey
    private String requestKey;

    public String getRequestKey() {
        return requestKey;
    }

    public void setRequestKey(String requestKey) {
        this.requestKey = requestKey;
    }
}
