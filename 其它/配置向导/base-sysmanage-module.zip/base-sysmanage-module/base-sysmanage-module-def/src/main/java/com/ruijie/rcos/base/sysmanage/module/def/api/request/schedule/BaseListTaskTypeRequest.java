package com.ruijie.rcos.base.sysmanage.module.def.api.request.schedule;

import com.ruijie.rcos.sk.modulekit.api.comm.Request;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月06日
 *
 * @author xgx
 */
public class BaseListTaskTypeRequest implements Request {
}
