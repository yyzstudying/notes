package com.ruijie.rcos.base.sysmanage.module.def.api.request.license;

import org.springframework.lang.Nullable;
import com.ruijie.rcos.sk.modulekit.api.comm.Request;

/**
 * Description: 导入License文件请求
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月1日
 * 
 * @author zouqi
 */
public class BaseUploadLicFileRequest implements Request {

    /** license文件 MD5 */
    @Nullable
    private String fileMd5;
    
    /** license文件 名称 */
    @Nullable
    private String fileName;
    
    /** license文件 路径 */
    @Nullable
    private String filePath;
    
    
    public String getFileMd5() {
        return fileMd5;
    }
    
    
    public void setFileMd5(String fileMd5) {
        this.fileMd5 = fileMd5;
    }
    
   
    public String getFileName() {
        return fileName;
    }
    
    
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    
    
    public String getFilePath() {
        return filePath;
    }
    
    
    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }
    
    
    
}
