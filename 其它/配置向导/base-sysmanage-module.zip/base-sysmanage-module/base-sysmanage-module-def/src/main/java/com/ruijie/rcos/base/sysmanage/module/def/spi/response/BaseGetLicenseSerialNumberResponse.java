package com.ruijie.rcos.base.sysmanage.module.def.spi.response;

import com.ruijie.rcos.sk.modulekit.api.comm.DefaultResponse;

/**
 * Description: 请求硬件序列号接口的应答
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月4日
 * 
 * @author zouqi
 */
public class BaseGetLicenseSerialNumberResponse extends DefaultResponse {
    
    //硬件唯一码ID
    private String  serialId;
    
    
    public String getSerialId() {
        return serialId;
    }

    
    public void setSerialId(String serialId) {
        this.serialId = serialId;
    }

}
