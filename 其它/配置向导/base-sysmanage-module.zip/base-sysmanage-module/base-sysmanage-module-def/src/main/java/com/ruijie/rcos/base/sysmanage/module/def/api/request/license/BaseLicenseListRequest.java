package com.ruijie.rcos.base.sysmanage.module.def.api.request.license;

import com.ruijie.rcos.sk.modulekit.api.comm.DefaultPageRequest;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月19日
 * 
 * @author zouqi
 */
public class BaseLicenseListRequest extends DefaultPageRequest {
    
    
}
