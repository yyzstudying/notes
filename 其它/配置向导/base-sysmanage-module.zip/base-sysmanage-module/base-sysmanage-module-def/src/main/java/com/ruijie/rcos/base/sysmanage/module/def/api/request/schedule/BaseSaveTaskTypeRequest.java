package com.ruijie.rcos.base.sysmanage.module.def.api.request.schedule;

import com.ruijie.rcos.sk.base.annotation.NotBlank;
import com.ruijie.rcos.sk.base.annotation.TextShort;
import com.ruijie.rcos.sk.modulekit.api.comm.Request;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年02月14日
 *
 * @author xgx
 */
public class BaseSaveTaskTypeRequest implements Request {
    /**
     * 任务名称
     */
    @TextShort
    @NotBlank
    private String name;

    /**
     * spring容器对象唯一标识
     */
    @TextShort
    @NotBlank
    private String beanName;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBeanName() {
        return beanName;
    }

    public void setBeanName(String beanName) {
        this.beanName = beanName;
    }
}
