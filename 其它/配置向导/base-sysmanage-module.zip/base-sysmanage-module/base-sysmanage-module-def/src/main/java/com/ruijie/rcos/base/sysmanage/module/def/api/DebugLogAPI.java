package com.ruijie.rcos.base.sysmanage.module.def.api;

import com.ruijie.rcos.base.sysmanage.module.def.api.request.debuglog.BaseCreateDebugLogRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.debuglog.BaseDeleteDebugLogRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.debuglog.BaseDetailDebugLogRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.debuglog.BaseListDebugLogRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.debuglog.BaseCreateDebugLogResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.debuglog.BaseDeleteDebugLogResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.debuglog.BaseDetailDebugLogResponse;
import com.ruijie.rcos.base.sysmanage.module.def.dto.BaseDebugLogDTO;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultPageResponse;
import com.ruijie.rcos.sk.modulekit.api.tx.NoRollback;

/**
 * Description: 调试日志API接口
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月19日
 *
 * @author fyq
 */
public interface DebugLogAPI {

    /**
     * 创建调试日志
     * 
     * @param apiRequest 创建请求
     * @return 创建结果
     * @throws BusinessException 业务异常
     */
    @NoRollback
    BaseCreateDebugLogResponse createDebugLog(BaseCreateDebugLogRequest apiRequest) throws BusinessException;

    /**
     * 删除调试日志
     * 
     * @param apiRequest 删除请求
     * @return 删除结果
     * @throws BusinessException 业务异常
     */
    @NoRollback
    BaseDeleteDebugLogResponse deleteDebugLog(BaseDeleteDebugLogRequest apiRequest) throws BusinessException;

    /**
     * 获取调试日志
     * 
     * @param apiRequest 获取请求
     * @throws BusinessException 业务异常
     * @return 调试日志记录
     */
    @NoRollback
    BaseDetailDebugLogResponse detailDebugLog(BaseDetailDebugLogRequest apiRequest) throws BusinessException;

    /**
     * 调试日志列表
     *
     * @param apiRequest 列表请求
     * @return 列表结果
     */
    @NoRollback
    DefaultPageResponse<BaseDebugLogDTO> listDebugLog(BaseListDebugLogRequest apiRequest);
}
