package com.ruijie.rcos.base.sysmanage.module.def.api.request.log4jconfig;

import java.util.UUID;

import com.ruijie.rcos.sk.base.annotation.NotNull;
import com.ruijie.rcos.sk.modulekit.api.comm.Request;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年02月18日
 *
 * @author GuoZhouYue
 */
public class BaseRemoveLog4jConfigRequest implements Request {

    @NotNull
    UUID id;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}
