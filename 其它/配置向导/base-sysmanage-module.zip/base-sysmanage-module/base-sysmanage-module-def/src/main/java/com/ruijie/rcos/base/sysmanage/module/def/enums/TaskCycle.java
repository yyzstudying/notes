package com.ruijie.rcos.base.sysmanage.module.def.enums;

/**
 * Description: 任务周期
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月05日
 *
 * @author xgx
 */
public enum TaskCycle {
    /**
     * 一次性
     */
    ONCE,

    /**
     * 每日
     */
    DAY,

    /**
     * 每周
     */
    WEEK
}
