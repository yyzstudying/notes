package com.ruijie.rcos.base.sysmanage.module.def.api.response.network;

import com.ruijie.rcos.base.sysmanage.module.def.dto.BaseNetworkDTO;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultResponse;

/**
 * Description: 返回网卡信息
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年11月28日
 *
 * @author fyq
 */

public class BaseDetailNetworkInfoResponse extends DefaultResponse {

    private BaseNetworkDTO networkDTO;

    public BaseNetworkDTO getNetworkDTO() {
        return networkDTO;
    }

    public void setNetworkDTO(BaseNetworkDTO networkDTO) {
        this.networkDTO = networkDTO;
    }
}
