package com.ruijie.rcos.base.sysmanage.module.def.spi.request;

import com.ruijie.rcos.base.sysmanage.module.def.dto.license.ValidationLicenseDTO;
import com.ruijie.rcos.sk.base.annotation.NotNull;
import com.ruijie.rcos.sk.modulekit.api.comm.DispatcherKey;
import com.ruijie.rcos.sk.modulekit.api.comm.Request;

/**
 * Description: License业务校验的SPI 的 response
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月4日
 * 
 * @author zouqi
 */
public class BaseValidateLicenseRequest implements Request {

   
    /** License控制项编码 */
    @DispatcherKey
    @NotNull
    private String featureCode;
    
    /** License文件信息 */
    @NotNull
    private ValidationLicenseDTO[] featureDTOArr;
    

    public String getFeatureCode() {
        return featureCode;
    }

    public void setFeatureCode(String featureCode) {
        this.featureCode = featureCode;
    }

    public ValidationLicenseDTO[] getFeatureDTOArr() {
        return featureDTOArr;
    }

    public void setFeatureDTOArr(ValidationLicenseDTO[] featureDTOArr) {
        this.featureDTOArr = featureDTOArr;
    }
    
    
}
