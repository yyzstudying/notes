package com.ruijie.rcos.base.sysmanage.module.def.api.response.schedule;

import java.util.Arrays;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import com.ruijie.rcos.base.sysmanage.module.def.dto.ScheduleTypeDTO;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultResponse;

/**
 * Description: 任务类型响应
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月07日
 *
 * @author xgx
 */
public class BaseListTaskTypeResponse extends DefaultResponse {
    private ScheduleTypeDTO[] itemArr;

    public ScheduleTypeDTO[] getItemArr() {
        return itemArr;
    }

    public void setItemArr(ScheduleTypeDTO[] itemArr) {
        this.itemArr = itemArr;
    }

    /**
     * 数据类型转换
     * 
     * @return id，名称map
     */
    public Map<UUID, String> toIdLabelMap() {
        final ScheduleTypeDTO[] scheduleTypeDTOArr = Optional.ofNullable(itemArr).orElse(new ScheduleTypeDTO[0]);
        return Arrays.stream(scheduleTypeDTOArr)
                .collect(Collectors.toMap(scheduleType -> scheduleType.getId(), scheduleType -> scheduleType.getLabel()));
    }
}
