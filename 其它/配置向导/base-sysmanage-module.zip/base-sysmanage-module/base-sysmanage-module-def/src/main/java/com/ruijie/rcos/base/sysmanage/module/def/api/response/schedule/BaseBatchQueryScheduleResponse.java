package com.ruijie.rcos.base.sysmanage.module.def.api.response.schedule;

import java.util.Arrays;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import com.ruijie.rcos.base.sysmanage.module.def.dto.ScheduleDTO;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultResponse;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月16日
 *
 * @author xgx
 */
public class BaseBatchQueryScheduleResponse extends DefaultResponse {

    private ScheduleDTO[] itemArr;

    public BaseBatchQueryScheduleResponse() {

    }

    public BaseBatchQueryScheduleResponse(ScheduleDTO[] itemArr) {
        this.itemArr = itemArr;
    }

    public ScheduleDTO[] getItemArr() {
        return itemArr;
    }

    public void setItemArr(ScheduleDTO[] itemArr) {
        this.itemArr = itemArr;
    }

    /**
     * 转换成id到类型id的Map
     * 
     * @return d到类型id的Map
     */
    public Map<UUID, UUID> toTaskIdTaskTypeIdMap() {
        return Arrays.stream(itemArr) //
                .collect(Collectors.toMap(scheduleDTO -> scheduleDTO.getId(), scheduleDTO -> scheduleDTO.getTaskTypeId()));
    }
}
