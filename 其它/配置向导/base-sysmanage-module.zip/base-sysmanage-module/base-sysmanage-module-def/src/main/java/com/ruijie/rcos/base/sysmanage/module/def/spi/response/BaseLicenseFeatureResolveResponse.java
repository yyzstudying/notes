package com.ruijie.rcos.base.sysmanage.module.def.spi.response;

import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureType;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultResponse;

/**
 * Description: License文件解析，应答
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月4日
 * 
 * @author zouqi
 */
public class BaseLicenseFeatureResolveResponse extends DefaultResponse {

    /**license控制项编码*/
    private String featureCode;
    
    /**license授权类型*/
    private BaseFeatureType featureType;

    public String getFeatureCode() {
        return featureCode;
    }

    public void setFeatureCode(String featureCode) {
        this.featureCode = featureCode;
    }

    public BaseFeatureType getFeatureType() {
        return featureType;
    }

    public void setFeatureType(BaseFeatureType featureType) {
        this.featureType = featureType;
    }    
}
