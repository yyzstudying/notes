package com.ruijie.rcos.base.sysmanage.module.def.api;

import com.ruijie.rcos.base.sysmanage.module.def.api.request.databackup.BaseCreateDataBackupRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.databackup.BaseDeleteDataBackupRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.databackup.BaseListDataBackupRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.databackup.BaseCreateDataBackupResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.databackup.BaseDeleteDataBackupResponse;
import com.ruijie.rcos.base.sysmanage.module.def.dto.BaseDataBackupDTO;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultPageResponse;
import com.ruijie.rcos.sk.modulekit.api.tx.NoRollback;

/**
 * Description: 数据库备份API接口
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月06日
 *
 * @author fyq
 */
public interface DataBackupAPI {

    /**
     * 创建数据库备份
     * 
     * @param apiRequest 创建请求
     * @return 创建结果
     * @throws BusinessException 业务异常
     */
    @NoRollback
    BaseCreateDataBackupResponse createDataBackup(BaseCreateDataBackupRequest apiRequest) throws BusinessException;

    /**
     * 删除数据库备份
     *
     * @param apiRequest 删除请求
     * @return 删除结果
     * @throws BusinessException 业务异常
     */
    @NoRollback
    BaseDeleteDataBackupResponse deleteDataBackup(BaseDeleteDataBackupRequest apiRequest) throws BusinessException;

    /**
     * 获取数据库备份列表
     * 
     * @param apiRequest 获取请求
     * @return 备份列表
     */
    @NoRollback
    DefaultPageResponse<BaseDataBackupDTO> listDataBackup(BaseListDataBackupRequest apiRequest);
}
