package com.ruijie.rcos.base.sysmanage.module.def.spi;

import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseLicenseFeatureResolveRequest;
import com.ruijie.rcos.base.sysmanage.module.def.spi.response.BaseLicenseFeatureResolveResponse;
import com.ruijie.rcos.sk.modulekit.api.tx.NoRollback;

/**
 * Description: 解析lic文件SPI
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月7日
 * 
 * @author zouqi
 */
public interface BaseLicenseFeatureResolveSPI {
    
    /**
     * 获取FeatureCode（license控制项编码）
     * @param request 请求硬件序列号接口的request
     * 
     * @return BaseLicenseFeatureResolveResponse 应答结果
     */
    @NoRollback
    BaseLicenseFeatureResolveResponse getLicenseFeatureCode(BaseLicenseFeatureResolveRequest request);

}
