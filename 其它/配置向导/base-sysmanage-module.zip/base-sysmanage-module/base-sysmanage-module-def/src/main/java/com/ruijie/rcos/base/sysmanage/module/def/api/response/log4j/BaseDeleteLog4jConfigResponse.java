package com.ruijie.rcos.base.sysmanage.module.def.api.response.log4j;

import com.ruijie.rcos.sk.base.annotation.TextMedium;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultResponse;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年02月28日
 *
 * @author GuoZhouYue
 */
public class BaseDeleteLog4jConfigResponse extends DefaultResponse {

    @TextMedium
    String loggerName;

    public String getLoggerName() {
        return loggerName;
    }

    public void setLoggerName(String loggerName) {
        this.loggerName = loggerName;
    }
}
