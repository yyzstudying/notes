package com.ruijie.rcos.base.sysmanage.module.def.enums;

/**
 * Description: license验证状态
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月8日
 * 
 * @author zouqi
 */
public enum ValidateLicenseStatus {
    OK,//通过
    ERROR, //异常
}
