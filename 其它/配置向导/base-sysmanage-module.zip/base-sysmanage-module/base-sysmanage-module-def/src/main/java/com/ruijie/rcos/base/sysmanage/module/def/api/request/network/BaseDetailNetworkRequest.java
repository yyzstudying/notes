package com.ruijie.rcos.base.sysmanage.module.def.api.request.network;

import com.ruijie.rcos.sk.modulekit.api.comm.Request;

/**
 * Description: 请求获取网卡信息
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年11月28日
 *
 * @author fyq
 */

public class BaseDetailNetworkRequest implements Request {

}
