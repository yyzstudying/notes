package com.ruijie.rcos.base.sysmanage.module.def.dto;

import java.util.UUID;

/**
 * 
 * Description: 任务dto
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年11月14日
 * 
 * @author hhx
 */
public class ScheduleTypeDTO {
    /**
     * 主键
     */
    private UUID id;

    /**
     * 任务名称
     */
    private String label;


    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }
}
