package com.ruijie.rcos.base.sysmanage.module.def.api.request.schedule;

import java.util.UUID;

import com.ruijie.rcos.sk.base.annotation.NotEmpty;
import com.ruijie.rcos.sk.base.annotation.Size;
import org.springframework.util.Assert;

import com.ruijie.rcos.sk.modulekit.api.comm.Request;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月16日
 *
 * @author xgx
 */
public class BaseBatchQueryScheduleRequest implements Request {
    public BaseBatchQueryScheduleRequest() {

    }

    public BaseBatchQueryScheduleRequest(UUID[] idArr) {
        Assert.notNull(idArr, "id列表不能为空");
        this.idArr = idArr;
    }

    @Size(max = 50)
    @NotEmpty
    private UUID[] idArr;

    public UUID[] getIdArr() {
        return idArr;
    }

    public void setIdArr(UUID[] idArr) {
        this.idArr = idArr;
    }
}
