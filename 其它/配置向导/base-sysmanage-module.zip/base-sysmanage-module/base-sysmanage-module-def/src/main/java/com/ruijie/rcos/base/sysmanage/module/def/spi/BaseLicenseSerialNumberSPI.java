package com.ruijie.rcos.base.sysmanage.module.def.spi;

import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseGetLicenseSerianNumberRequest;
import com.ruijie.rcos.base.sysmanage.module.def.spi.response.BaseGetLicenseSerialNumberResponse;
import com.ruijie.rcos.sk.modulekit.api.tx.NoRollback;

/**
 * Description: 请求硬件序列号的SPI接口
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月4日
 * 
 * @author zouqi
 */
public interface BaseLicenseSerialNumberSPI {

    /**
     * l请求硬件序列号
     * @param request 请求硬件序列号接口的request
     * 
     * @return BaseGetLicenseSerialNumberResponse 应答结果
     */
    @NoRollback
    BaseGetLicenseSerialNumberResponse getLicenseSerialNumber(BaseGetLicenseSerianNumberRequest request);
}
