package com.ruijie.rcos.base.sysmanage.module.def.dto;

import java.util.Date;
import java.util.UUID;

/**
 * Description: 调试日志dto类
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月24日
 *
 * @author fyq
 */
public class BaseDebugLogDTO {

    private UUID id;

    private String fileName;

    private Date createTime;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}
