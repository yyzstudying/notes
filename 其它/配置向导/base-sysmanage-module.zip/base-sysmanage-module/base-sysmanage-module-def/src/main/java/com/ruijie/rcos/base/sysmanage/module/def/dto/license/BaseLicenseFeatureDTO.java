package com.ruijie.rcos.base.sysmanage.module.def.dto.license;

import org.springframework.lang.Nullable;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureStatus;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureType;

/**
 * Description: License授权接口DTO
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月4日
 * 
 * @author zouqi
 */
public class BaseLicenseFeatureDTO {

    /*** 试用时长 * */
    @Nullable
    private Long durationLicense;
    
    /*** License控制项编码 * */
    @Nullable
    private String featureCode;
    
    /*** License类型 * */
    @Nullable
    private BaseFeatureType featureType;
    
    /** license文件 MD5 */
    @Nullable
    private String fileMd5;
    
    /** license文件 名称 */
    @Nullable
    private String fileName;
    
    /** license文件 名称 */
    @Nullable
    private String filePath;

    /**特性的中文名  */
    @Nullable
    private String featureDisplayName;
    
    /**特性的其他描述  */
    @Nullable
    private String featureDescription;
    
    /*** License状态* */
    @Nullable
    private BaseFeatureStatus featureStatus;

    
    public long getDurationLicense() {
        return durationLicense;
    }

    public void setDurationLicense(Long durationLicense) {
        this.durationLicense = durationLicense;
    }

    public String getFeatureCode() {
        return featureCode;
    }

    public void setFeatureCode(String featureCode) {
        this.featureCode = featureCode;
    }

    public BaseFeatureType getFeatureType() {
        return featureType;
    }
 
    public void setFeatureType(BaseFeatureType featureType) {
        this.featureType = featureType;
    }

    public String getFileMd5() {
        return fileMd5;
    }

    public void setFileMd5(String fileMd5) {
        this.fileMd5 = fileMd5;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    
    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getFeatureDisplayName() {
        return featureDisplayName;
    }

    public void setFeatureDisplayName(String featureDisplayName) {
        this.featureDisplayName = featureDisplayName;
    }

    public String getFeatureDescription() {
        return featureDescription;
    }

    public void setFeatureDescription(String featureDescription) {
        this.featureDescription = featureDescription;
    }
    
    public BaseFeatureStatus getFeatureStatus() {
        return featureStatus;
    }

    public void setFeatureStatus(BaseFeatureStatus featureStatus) {
        this.featureStatus = featureStatus;
    }
    
}
