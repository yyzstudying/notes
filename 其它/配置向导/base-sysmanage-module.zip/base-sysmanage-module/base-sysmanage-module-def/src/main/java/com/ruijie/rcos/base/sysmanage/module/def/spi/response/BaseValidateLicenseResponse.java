package com.ruijie.rcos.base.sysmanage.module.def.spi.response;

import com.ruijie.rcos.base.sysmanage.module.def.enums.ValidateLicenseStatus;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultResponse;

/**
 * Description: License业务校验的SPI应答
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月4日
 * 
 * @author zouqi
 */
public class BaseValidateLicenseResponse extends DefaultResponse {

    /** 错误编号 */
    private String messageKey;
    
    /** 验证license 状态 */
    private ValidateLicenseStatus licenseStatus;

    public String getMessageKey() {
        return messageKey;
    }

    public void setMessageKey(String messageKey) {
        this.messageKey = messageKey;
    }

    public ValidateLicenseStatus getLicenseStatus() {
        return licenseStatus;
    }

    public void setLicenseStatus(ValidateLicenseStatus licenseStatus) {
        this.licenseStatus = licenseStatus;
    }

    
}
