package com.ruijie.rcos.base.sysmanage.module.def.api.request.debuglog;

import com.ruijie.rcos.sk.modulekit.api.comm.DefaultPageRequest;
import org.springframework.lang.Nullable;

import java.util.Date;

/**
 * Description: 调试日志列表请求
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月19日
 *
 * @author fyq
 */
public class BaseListDebugLogRequest extends DefaultPageRequest {

    @Nullable
    private Date startTime;

    @Nullable
    private Date endTime;

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }
}
