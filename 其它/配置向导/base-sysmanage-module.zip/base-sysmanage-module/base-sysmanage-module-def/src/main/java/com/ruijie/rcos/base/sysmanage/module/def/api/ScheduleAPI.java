package com.ruijie.rcos.base.sysmanage.module.def.api;

import com.ruijie.rcos.base.sysmanage.module.def.api.request.schedule.*;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.schedule.BaseBatchQueryScheduleResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.schedule.BaseListTaskTypeResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.schedule.BaseQueryScheduleResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.schedule.BaseQueryTaskTypeResponse;
import com.ruijie.rcos.base.sysmanage.module.def.dto.ScheduleDTO;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultPageResponse;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultResponse;
import com.ruijie.rcos.sk.modulekit.api.tx.NoRollback;

/**
 *
 * Description: 任务调度api
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年11月9日
 *
 * @author hhx
 */
public interface ScheduleAPI {

    /**
     * 更新定时任务
     *
     * @param editScheduleRequest 更新任务调度请求信息
     * @return 返回响应信息
     * @throws BusinessException 抛出异常
     */
    @NoRollback
    DefaultResponse editSchedule(BaseEditScheduleRequest editScheduleRequest) throws BusinessException;

    /**
     * 前台展示调用方法
     *
     * @param listScheduleRequest 展示请求对象
     * @return 返回响应对象
     */
    @NoRollback
    DefaultPageResponse<ScheduleDTO> listSchedule(BaseListScheduleRequest listScheduleRequest);

    /**
     * 删除调度
     *
     * @param deleteScheduleRequest 删除任务调度请求对象
     * @return 返回响应对象
     * @throws BusinessException 抛出异常
     */
    @NoRollback
    DefaultResponse deleteSchedule(BaseDeleteScheduleRequest deleteScheduleRequest) throws BusinessException;

    /**
     * 增加任务调度
     *
     * @param createScheduleRequest 增加任务调度请求对象
     * @return 返回响应对象
     * @throws BusinessException 抛出异常
     */
    @NoRollback
    DefaultResponse createSchedule(BaseCreateScheduleRequest createScheduleRequest) throws BusinessException;

    /**
     * 查询定时任务
     * 
     * @param queryScheduleRequest 查询任务参数
     * @return 定时任务信息
     * @throws BusinessException 业务异常
     */
    @NoRollback
    BaseQueryScheduleResponse querySchedule(BaseQueryScheduleRequest queryScheduleRequest) throws BusinessException;

    /**
     * 获取任务
     * 
     * @param listTaskTypeRequest 任务类型请求参数
     * @return 返回获取任务结果
     */
    @NoRollback
    BaseListTaskTypeResponse listTaskType(BaseListTaskTypeRequest listTaskTypeRequest);

    /**
     * 修改或添加任务类型
     *
     * @param saveTaskTypeRequest 任务类型请求参数
     * @return 保存成功
     */
    @NoRollback
    DefaultResponse saveTaskType(BaseSaveTaskTypeRequest saveTaskTypeRequest);

    /**
     * 查询任务类型
     * 
     * @param queryTaskTypeRequest 查询类型参数
     * @return 任务类型响应结果
     * @throws BusinessException 业务异常
     */
    @NoRollback
    BaseQueryTaskTypeResponse queryTaskType(BaseQueryTaskTypeRequest queryTaskTypeRequest) throws BusinessException;

    /**
     * 批量查询任务
     * 
     * @param baseBatchQueryScheduleRequest 查询参数
     * @return 任务列表
     */
    @NoRollback
    BaseBatchQueryScheduleResponse batchQueryTask(BaseBatchQueryScheduleRequest baseBatchQueryScheduleRequest);


}
