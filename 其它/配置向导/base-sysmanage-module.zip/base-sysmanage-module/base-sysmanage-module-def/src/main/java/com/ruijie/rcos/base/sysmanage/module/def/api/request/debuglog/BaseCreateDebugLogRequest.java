package com.ruijie.rcos.base.sysmanage.module.def.api.request.debuglog;

import com.ruijie.rcos.sk.modulekit.api.comm.Request;

/**
 * Description: 创建调试日志请求
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月19日
 *
 * @author fyq
 */
public class BaseCreateDebugLogRequest implements Request {
}
