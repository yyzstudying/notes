package com.ruijie.rcos.base.sysmanage.module.def.api;

import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.BaseCreateDatFileRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.BaseLicenseListRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.BaseUploadLicFileRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.CheckDuplicationWebRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.license.BaseCreateDatFileResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.license.BaseUploadLicFileResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.license.CheckDuplicationResponse;
import com.ruijie.rcos.base.sysmanage.module.def.dto.license.BaseLicenseFeatureDTO;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultPageResponse;
import com.ruijie.rcos.sk.modulekit.api.tx.NoRollback;

/**
 * Description: license base组件对外API接口
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月1日
 * 
 * @author zouqi
 */
public interface BaseLicenseMgmtAPI {

    /**
     * l获取平台唯一码
     * @param request 导出平台唯一码信息request
     * @return BaseCreateDatFileResponse 获取平台唯一码结果
     */
    @NoRollback
    BaseCreateDatFileResponse createDatFile(BaseCreateDatFileRequest request);
    
    /**
     * license 文件导入
     * @param request 验证License信息request
     * 
     * @return BaseUploadLicFileResponse license 文件导入应答结果
     * @throws BusinessException 
     */
    @NoRollback
    BaseUploadLicFileResponse uploadLicFile(BaseUploadLicFileRequest request) throws BusinessException;
    
    /**
     * license 列表
     * @param apiRequest 请求列表的request
     * 
     * @return DefaultPageResponse<BaseLicenseFeatureDTO> 分页查询结果
     * @throws BusinessException 
     */
    @NoRollback
    DefaultPageResponse<BaseLicenseFeatureDTO> listLicenseFeature(BaseLicenseListRequest apiRequest) throws BusinessException;
    
    /**
     * 检查license文件名是否重复
     * @param request 
     * @return CheckDuplicationResponse 
     * @throws BusinessException 
     */
    @NoRollback
    CheckDuplicationResponse validationLicenseFeature(CheckDuplicationWebRequest request) throws BusinessException;
}
