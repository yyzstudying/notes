package com.ruijie.rcos.base.sysmanage.module.def.common;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月12日
 *
 * @author xgx
 */
public interface Constant {

    String YYYY_MM_DD = "yyyy-MM-dd";

    String HH_MM_SS = "HH:mm:ss";

    String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
}
