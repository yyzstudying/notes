package com.ruijie.rcos.base.sysmanage.module.def.spi.request;

import com.ruijie.rcos.sk.modulekit.api.comm.Request;

/**
 * Description: 请求硬件序列号接口的request
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月4日
 * 
 * @author zouqi
 */
public class BaseGetLicenseSerianNumberRequest implements Request {

}
