package com.ruijie.rcos.base.sysmanage.module.def.api.request.schedule;

import java.util.UUID;

import org.springframework.lang.Nullable;

import com.ruijie.rcos.base.sysmanage.module.def.enums.TaskCycle;
import com.ruijie.rcos.sk.base.annotation.NotBlank;
import com.ruijie.rcos.sk.base.annotation.NotNull;
import com.ruijie.rcos.sk.base.annotation.TextMedium;
import com.ruijie.rcos.sk.modulekit.api.comm.Request;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月09日
 *
 * @author xgx
 */
public class BaseScheduleRequest implements Request {
    @NotNull
    private UUID taskTypeId;

    @NotNull
    private TaskCycle taskCycle;

    @TextMedium
    private String description;

    @Nullable
    private String scheduleDate;

    @NotBlank
    private String scheduleTime;

    @Nullable
    private Integer[] dayOfWeekArr;

    public UUID getTaskTypeId() {
        return taskTypeId;
    }

    public void setTaskTypeId(UUID taskTypeId) {
        this.taskTypeId = taskTypeId;
    }

    public TaskCycle getTaskCycle() {
        return taskCycle;
    }

    public void setTaskCycle(TaskCycle taskCycle) {
        this.taskCycle = taskCycle;
    }

    @Nullable
    public String getDescription() {
        return description;
    }

    public void setDescription(@Nullable String description) {
        this.description = description;
    }

    @Nullable
    public String getScheduleDate() {
        return scheduleDate;
    }

    public void setScheduleDate(@Nullable String scheduleDate) {
        this.scheduleDate = scheduleDate;
    }

    public String getScheduleTime() {
        return scheduleTime;
    }

    public void setScheduleTime(String scheduleTime) {
        this.scheduleTime = scheduleTime;
    }

    @Nullable
    public Integer[] getDayOfWeekArr() {
        return dayOfWeekArr;
    }

    public void setDayOfWeekArr(@Nullable Integer[] dayOfWeekArr) {
        this.dayOfWeekArr = dayOfWeekArr;
    }
}
