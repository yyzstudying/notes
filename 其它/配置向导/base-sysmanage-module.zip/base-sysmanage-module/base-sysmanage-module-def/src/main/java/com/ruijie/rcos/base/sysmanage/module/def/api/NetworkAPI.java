package com.ruijie.rcos.base.sysmanage.module.def.api;

import com.ruijie.rcos.base.sysmanage.module.def.api.request.network.BaseDetailNetworkRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.network.BaseUpdateNetworkRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.network.BaseDetailNetworkInfoResponse;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultResponse;
import com.ruijie.rcos.sk.modulekit.api.tx.NoRollback;

/**
 * Description: 网卡配置接口
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年11月28日
 *
 * @author fyq
 */

public interface NetworkAPI {

    /**
     * 获取网卡信息
     * 
     * @param apiRequest 获取网卡信息请求
     * @return 网卡信息
     * @throws BusinessException 请求异常
     */
    @NoRollback
    BaseDetailNetworkInfoResponse detailNetwork(BaseDetailNetworkRequest apiRequest) throws BusinessException;

    /**
     * 更新网卡信息
     * 
     * @param apiRequest 更新网卡信息请求
     * @return 更新结果
     * @throws BusinessException 请求异常
     */
    @NoRollback
    DefaultResponse updateNetwork(BaseUpdateNetworkRequest apiRequest) throws BusinessException;
}
