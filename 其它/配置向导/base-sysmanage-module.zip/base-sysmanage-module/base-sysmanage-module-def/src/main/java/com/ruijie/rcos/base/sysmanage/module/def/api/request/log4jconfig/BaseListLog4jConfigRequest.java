package com.ruijie.rcos.base.sysmanage.module.def.api.request.log4jconfig;

import com.ruijie.rcos.sk.modulekit.api.comm.DefaultPageRequest;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年02月18日
 *
 * @author GuoZhouYue
 */
public class BaseListLog4jConfigRequest extends DefaultPageRequest {

}
