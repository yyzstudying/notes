package com.ruijie.rcos.base.sysmanage.module.def.spi;

import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseNetworkChangeAfterRequest;
import com.ruijie.rcos.sk.modulekit.api.tx.NoRollback;

/**
 * Description: 网卡信息修改后SPI接口
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月06日
 *
 * @author fyq
 */
public interface BaseNetworkChangeAfterSPI {

    /**
     * 网卡信息修改后SPI接口
     * @param networkChangeAfterRequest spi请求
     */
    @NoRollback
    void afterNetworkChange(BaseNetworkChangeAfterRequest networkChangeAfterRequest);
}
