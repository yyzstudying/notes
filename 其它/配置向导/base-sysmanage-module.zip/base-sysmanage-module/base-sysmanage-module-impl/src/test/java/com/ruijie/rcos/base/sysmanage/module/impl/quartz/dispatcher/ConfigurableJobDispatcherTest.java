package com.ruijie.rcos.base.sysmanage.module.impl.quartz.dispatcher;

import java.util.UUID;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;

import com.ruijie.rcos.base.sysmanage.module.impl.common.Constants;
import com.ruijie.rcos.base.sysmanage.module.impl.dao.ScheduleLogDAO;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.ScheduleLogEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.quartz.data.ConfigQuartzTaskData;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.quartz.QuartzTask;

import mockit.*;
import mockit.integration.junit4.JMockit;

/**
 * Description: 调度测试
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月25日
 *
 * @author fyq
 */

@RunWith(JMockit.class)
public class ConfigurableJobDispatcherTest {

    @Tested
    private ConfigurableJobDispatcher configurableJobDispatcher;

    @Injectable
    private ScheduleLogDAO scheduleLogDAO;

    @Capturing
    Logger logger;

    /**
     *
     * @param context 上下文
     * @param jobDetail 任务细节
     * @throws Exception
     */
    @Test
    public void testDispatcher(@Mocked JobExecutionContext context, @Mocked JobDetail jobDetail) {

        UUID id = UUID.randomUUID();
        JobDataMap dataMap = new JobDataMap();
        ConfigQuartzTaskData quartzTaskData = new ConfigQuartzTaskData();
        quartzTaskData.setTaskTypeName("typeName");
        dataMap.put(Constants.SCHEDULE_DATA_KEY, quartzTaskData);
        QuartzTask quartzTask1 = () -> {
        };
        quartzTaskData.setQuartzTask(quartzTask1);
        new Expectations() {
            {

                jobDetail.getJobDataMap();
                result = dataMap;
                jobDetail.getKey().getName();
                result = id.toString();

            }
        };
        configurableJobDispatcher.dispatcher(context);

        new Verifications() {
            {
                scheduleLogDAO.save((ScheduleLogEntity) any);
                times = 1;
            }
        };
    }

    /**
     *
     * @param context 上下文
     * @param jobDetail 任务细节
     * @param quartzTask 任务
     * @throws Exception 异常
     */
    @Test
    public void testDispatcherTaskEntityNotExists(@Mocked JobExecutionContext context, @Mocked JobDetail jobDetail, @Mocked QuartzTask quartzTask)
            throws Exception {
        UUID id = UUID.randomUUID();
        JobDataMap dataMap = new JobDataMap();
        ConfigQuartzTaskData quartzTaskData = new ConfigQuartzTaskData();
        quartzTaskData.setTaskTypeName("typeName");
        dataMap.put(Constants.SCHEDULE_DATA_KEY, quartzTaskData);
        quartzTaskData.setQuartzTask(quartzTask);
        new Expectations() {
            {

                jobDetail.getJobDataMap();
                result = dataMap;
                jobDetail.getKey().getName();
                result = id.toString();
                quartzTask.execute();
                result = new Throwable("error");
                logger.error(anyString, (Throwable) any);

            }
        };
        configurableJobDispatcher.dispatcher(context);

        new Verifications() {
            {
                scheduleLogDAO.save((ScheduleLogEntity) any);
                times = 1;
                logger.error(anyString, (Throwable) any);
                times = 1;
            }
        };
    }

    /**
     *
     * @param context 上下问
     * @param jobDetail 任务细节
     * @param quartzTask 任务
     * @throws Exception 异常
     */
    @Test
    public void testDispatcherTaskEntityNotExistsLength(@Mocked JobExecutionContext context, @Mocked JobDetail jobDetail,
            @Mocked QuartzTask quartzTask) throws Exception {
        UUID id = UUID.randomUUID();
        JobDataMap dataMap = new JobDataMap();
        ConfigQuartzTaskData quartzTaskData = new ConfigQuartzTaskData();
        quartzTaskData.setTaskTypeName("name");
        dataMap.put(Constants.SCHEDULE_DATA_KEY, quartzTaskData);
        quartzTaskData.setQuartzTask(quartzTask);
        UUID uuid = UUID.randomUUID();
        StringBuilder stringBuilder = new StringBuilder("error_");
        for (int i = 0; i < 10; i++) {
            stringBuilder.append(uuid.toString());
        }
        new Expectations() {
            {

                jobDetail.getJobDataMap();
                result = dataMap;
                jobDetail.getKey().getName();
                result = id.toString();
                quartzTask.execute();
                result = new Throwable(stringBuilder.toString());

                logger.error(anyString, (Throwable) any);

            }
        };
        configurableJobDispatcher.dispatcher(context);

        new Verifications() {
            {
                logger.error(anyString, (Throwable) any);
                times = 1;
                scheduleLogDAO.save((ScheduleLogEntity) any);
                times = 1;
            }
        };
    }


}
