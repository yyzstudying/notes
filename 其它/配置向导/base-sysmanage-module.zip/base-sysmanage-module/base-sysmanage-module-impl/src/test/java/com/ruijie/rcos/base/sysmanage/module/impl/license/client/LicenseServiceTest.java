package com.ruijie.rcos.base.sysmanage.module.impl.license.client;

import static org.junit.Assert.assertTrue;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.junit.Test;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;
import com.ruijie.rcos.base.sysmanage.module.impl.license.utils.LicenseUtils;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.test.ThrowExceptionTester;
import mockit.Expectations;
import mockit.Mock;
import mockit.MockUp;
import mockit.Mocked;
import mockit.Tested;

/**
 * Description: LicenseService測試類
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月21日
 * 
 * @author zouqi
 */
public class LicenseServiceTest {

    @Tested
    LicenseService licenseService;
    
    /**
     * 验证pickupLicense()方法入参
     * 
     * @throws Exception 异常
     */
    @Test
    public void testUploadLicenseValidateParams() throws Exception {

        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseService.pickupLicense(""), "licInfo 不能为空");

        assertTrue(true);
    }
    
    /**
     * pickupLicense 测试方法
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testUploadLicense() throws BusinessException {
        
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>75</time_slot>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_onoff>on</cm_onoff>\n" + 
                "</option>";

        licenseService.pickupLicense(fileContent);
        assertTrue(true);
    }
    
    
    /**
     * pickupLicense 测试方法
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testUploadLicense2() throws BusinessException {
        
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>75</time_slot>\n" + 
                "  license.feature.>1</license.feature>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_onoff>on</cm_onoff>\n" + 
                "</option>signature=";
        
        new MockUp<Properties>() {
            @Mock
            public String getProperty(String key) {
                return "123";
            }
            
            @Mock
            public String getProperty(String key, String defaultValue) {
                return defaultValue;
            }
            
        };
        
        licenseService.pickupLicense(fileContent);
        assertTrue(true);
    }
    
    /**
     * pickupLicense 测试方法
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testUploadLicense3() throws BusinessException {
        
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>75</time_slot>\n" + 
                "  license.feature.>1</license.feature>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_onoff>on</cm_onoff>\n" + 
                "</option>signature=";
        
        new MockUp<Properties>() {
            @Mock
            public String getProperty(String key) {
                //
                return null;
            }
            
            @Mock
            public String getProperty(String key, String defaultValue) {
                return defaultValue;
            }
        };
        
        new MockUp<Long>() {
            @Mock
            public long parseLong(String s) throws NumberFormatException {
                return 10L;
            }
        };
        
        licenseService.pickupLicense(fileContent);
        assertTrue(true);
    }
    
    /**
     * pickupLicense 测试方法
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testUploadLicense4() throws BusinessException {
        
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>75</time_slot>\n" + 
                "  license.feature.>1</license.feature>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_onoff>on</cm_onoff>\n" + 
                "</option>signature=";
        
        new MockUp<Properties>() {
            @Mock
            public String getProperty(String key) {
                //
                return null;
            }
            
            @Mock
            public String getProperty(String key, String defaultValue) {
                return defaultValue;
            }
        };
        
        new MockUp<Long>() {
            @Mock
            public long parseLong(String s) throws NumberFormatException {
                return 0;
            }
        };
        
        licenseService.pickupLicense(fileContent);
        assertTrue(true);
    }
    
    /**
     * pickupLicense 测试方法
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testUploadLicense5() throws BusinessException {
        
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>75</time_slot>\n" + 
                "  license.feature.>1</license.feature>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_onoff>on</cm_onoff>\n" + 
                "</option>signature=";
        
        new MockUp<Properties>() {
            @Mock
            public String getProperty(String key) {
                return "ON";
            }
            
            @Mock
            public String getProperty(String key, String defaultValue) {
                return defaultValue;
            }
            
        };
        
        new MockUp<Long>() {
            @Mock
            public long parseLong(String s) throws NumberFormatException {
                return 0;
            }
        };
        
        licenseService.pickupLicense(fileContent);
        assertTrue(true);
    }
    
    /**
     * pickupLicense 测试方法
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testUploadLicense6() throws BusinessException {
        
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>75</time_slot>\n" + 
                "  license.feature.>1</license.feature>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_onoff>on</cm_onoff>\n" + 
                "</option>signature=";
        
        new MockUp<Properties>() {
            @Mock
            public String getProperty(String key) {
                //
                return null;
            }
            
            @Mock
            public String getProperty(String key, String defaultValue) {
                return defaultValue;
            }
            
        };
        
        new MockUp<Long>() {
            @Mock
            public long parseLong(String s) throws NumberFormatException {
                return 0;
            }
        };
        
        licenseService.pickupLicense(fileContent);
        assertTrue(true);
    }
    
    /**
     * pickupLicense 测试方法
     * 
     * @throws IOException 异常
     */
    @Test
    public void testUploadLicense7() throws IOException {
        
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>75</time_slot>\n" + 
                "  license.feature.>1</license.feature>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_onoff>on</cm_onoff>\n" + 
                "</option>signature=";
        
        new MockUp<Properties>() {
            @Mock
            public String getProperty(String key) throws IOException {
                throw new IOException();
            }
            
        };
        
        licenseService.pickupLicense(fileContent);
        assertTrue(true);
    }
    
    /**
     * pickupLicense 测试方法
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testUploadLicense8() throws BusinessException {
        
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>0</time_slot>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_data>on</cm_data>\n" + 
                "</option>";

        licenseService.pickupLicense(fileContent);
        assertTrue(true);
    }
    
    /**
     * pickupLicense 测试方法
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testUploadLicense9() throws BusinessException {
        
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>0</time_slot>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_data>on</cm_data>\n" + 
                "</option>";

        new MockUp<Long>() {
            @Mock
            public long parseLong(String s) throws NumberFormatException {
                throw new NumberFormatException();
            }
        };
        licenseService.pickupLicense(fileContent);
        assertTrue(true);
    }
    
    /**
     * pickupLicense 测试方法
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testUploadLicense10() throws BusinessException {
        
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>0</time_slot>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_onoff>off</cm_onoff>\n" + 
                "</option>";
        licenseService.pickupLicense(fileContent);
        assertTrue(true);
    }
    
    /**
     * pickupLicense 测试方法
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testUploadLicense11() throws BusinessException {
        
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>0</time_slot>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_onoff>off</cm_onoff>\n" + 
                "</option>";
        
        new MockUp<Long>() {
            @Mock
            public long parseLong(String s) throws NumberFormatException {
                throw new NumberFormatException();
            }
        };
        licenseService.pickupLicense(fileContent);
        assertTrue(true);
    }
    
    /**
     * pickupLicense 测试方法
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testUploadLicense12() throws BusinessException {
        
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>12</time_slot>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_data>10</cm_data>\n" + 
                "</option>";
        licenseService.pickupLicense(fileContent);
        assertTrue(true);
    }
    
    /**
     * pickupLicense 测试方法
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testUploadLicense13() throws BusinessException {
        
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
        new MockUp<DocumentBuilderFactory>() {
            @Mock
            public DocumentBuilderFactory newInstance() throws ParserConfigurationException {
                throw new ParserConfigurationException();
            }
        };
        licenseService.pickupLicense(fileContent);
        assertTrue(true);
    }
    
    /**
     * pickupLicense 测试方法
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testUploadLicense14() throws BusinessException {
        
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
        new MockUp<DocumentBuilderFactory>() {
            @Mock
            public DocumentBuilderFactory newInstance() throws IOException {
                throw new IOException();
            }
        };
        licenseService.pickupLicense(fileContent);
        assertTrue(true);
    }
    
    /**
     * pickupLicense 测试方法
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testUploadLicense15() throws BusinessException {
        
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
        new MockUp<DocumentBuilderFactory>() {
            @Mock
            public DocumentBuilderFactory newInstance() throws SAXException {
                throw new SAXException();
            }
        };
        licenseService.pickupLicense(fileContent);
        assertTrue(true);
    }
    
    /**
     * 验证pickupLicense()方法入参
     * 
     * @throws Exception 异常
     */
    @Test
    public void testUploadLicense2ValidateParams() throws Exception {

        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseService.pickupLicense(""), "licInfo 不能为空");

        assertTrue(true);
    }
    
    /**
     * pickupLicense 测试方法
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testUploadLicense16() throws BusinessException {
        File licFile = new File("123");
        licenseService.pickupLicense(licFile);
        assertTrue(true);
    }
    
    /**
     * pickupLicense 测试方法
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testUploadLicense17() throws BusinessException {
        File licFile = new File("123");
        
        new MockUp<FileInputStream>() {
            @Mock
            public void $init(File file) throws IOException {
                throw new IOException();
            }
        };
        licenseService.pickupLicense(licFile);
        assertTrue(true);
    }
    
    /**
     * 验证check()方法入参
     * 
     * @throws Exception 异常
     */
    @Test
    public void testCheckValidateParams() throws Exception {
        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseService.check(null), "licFile 不能为空");

        assertTrue(true);
    }
    
    /**
     * check 测试方法
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testCheckValidate() throws BusinessException {
        File licFile = new File("123");
        

        new MockUp<File>() {
            @Mock
            public boolean isDirectory() {
                return false;
            }
            
        };
        licenseService.check(licFile);
        assertTrue(true);
    }
    
    /**
     * check 测试方法
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testCheckValidate2() throws BusinessException {
        File licFile = new File("123");
        

        new MockUp<File>() {
            @Mock
            public boolean exists() {
                return false;
            }
            
        };
        licenseService.check(licFile);
        assertTrue(true);
    }
    
    /**
     * check 测试方法
     * @param licenseUtils 
     * @param dFactory 
     * @param node  
     * @throws Exception 
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCheckValidate3(@Mocked LicenseUtils licenseUtils, @Mocked DocumentBuilderFactory dFactory, @Mocked Node node) throws Exception {
        File licFile = new File("123");
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>12</time_slot>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_data>10</cm_data>\n" + 
                "</option>";
        byte[] contentArr = fileContent.getBytes();
        new Expectations() {
            {
                licenseUtils.readFile((File)any);
                result = contentArr;
                LicenseUtils.decryptPaLic((File)any);
                result = fileContent;
                node.getNodeValue();
                result = "123";
            }
        };

        new MockUp<File>() {
            
            @Mock
            public boolean exists() {
                return true;
            }

            @Mock
            public boolean isDirectory() {
                return false;
            }
        };
        
        licenseService.check(licFile, "123");
        assertTrue(true);
    }
    
    /**
     * check 测试方法
     * @param licenseUtils 
     * @param dFactory 
     * @throws Exception 
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCheckValidate4(@Mocked LicenseUtils licenseUtils, @Mocked DocumentBuilderFactory dFactory) throws Exception {
        File licFile = new File("123");
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>12</time_slot>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_data>10</cm_data>\n" + 
                "</option>";
        byte[] contentArr = fileContent.getBytes();
        new Expectations() {
            {
                licenseUtils.readFile((File)any);
                result = contentArr;
                LicenseUtils.decryptPaLic((File)any);
                result = fileContent;
            }
        };

        new MockUp<File>() {
            
            @Mock
            public boolean exists() {
                return true;
            }

            @Mock
            public boolean isDirectory() {
                return false;
            }
        };
        
        licenseService.check(licFile, "123");
        assertTrue(true);
    }
    
    /**
     * check 测试方法
     * @param licenseUtils 
     * @param dFactory 
     * @throws Exception 
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCheckValidate5(@Mocked LicenseUtils licenseUtils, @Mocked DocumentBuilderFactory dFactory) throws Exception {
        File licFile = new File("123");
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>12</time_slot>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_data>10</cm_data>\n" + 
                "</option>";
        byte[] contentArr = fileContent.getBytes();
        new Expectations() {
            {
                licenseUtils.readFile((File)any);
                result = contentArr;
                LicenseUtils.decryptPaLic((File)any);
                result = fileContent;
            }
        };

        new MockUp<DocumentBuilderFactory>() {
            
            @Mock
            public DocumentBuilderFactory newInstance() throws ParserConfigurationException {
                throw new ParserConfigurationException();
            }
        };
        new MockUp<File>() {
            
            @Mock
            public boolean exists() {
                return true;
            }

            @Mock
            public boolean isDirectory() {
                return false;
            }
        };
        
        licenseService.check(licFile, "123");
        assertTrue(true);
    }
    
    /**
     * check 测试方法
     * @param licenseUtils 
     * @param dFactory  
     * @param node  
     * @throws Exception 
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCheckValidate6(@Mocked LicenseUtils licenseUtils, @Mocked DocumentBuilderFactory dFactory, @Mocked Node node) throws Exception {
        File licFile = new File("123");
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>12</time_slot>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_data>10</cm_data>\n" + 
                "</option>";
        byte[] contentArr = fileContent.getBytes();
        new Expectations() {
            {
                licenseUtils.readFile((File)any);
                result = contentArr;
                LicenseUtils.decryptPaLic((File)any);
                result = fileContent;
                node.getNodeValue();
                result = "234";
            }
        };

        new MockUp<File>() {
            
            @Mock
            public boolean exists() {
                return true;
            }

            @Mock
            public boolean isDirectory() {
                return false;
            }
        };
        
        licenseService.check(licFile, "123");
        assertTrue(true);
    }
    
    /**
     * check 测试方法
     * @param licenseUtils 
     * @param dFactory  
     * @param node  
     * @throws Exception 
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCheckValidate7(@Mocked LicenseUtils licenseUtils, @Mocked DocumentBuilderFactory dFactory, @Mocked Node node) throws Exception {
        File licFile = new File("123");
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>12</time_slot>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_data>10</cm_data>\n" + 
                "</option>";
        byte[] contentArr = fileContent.getBytes();
        new Expectations() {
            {
                licenseUtils.readFile((File)any);
                result = contentArr;
                LicenseUtils.decryptPaLic((File)any);
                result = fileContent;
                node.getNodeValue();
                result = new SAXException();
            }
        };

        new MockUp<File>() {
            
            @Mock
            public boolean exists() {
                return true;
            }

            @Mock
            public boolean isDirectory() {
                return false;
            }
        };
        
        licenseService.check(licFile, "123");
        assertTrue(true);
    }
    
    /**
     * check 测试方法
     * @param licenseUtils 
     * @param dFactory  
     * @param node  
     * @throws Exception 
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCheckValidate8(@Mocked LicenseUtils licenseUtils, @Mocked DocumentBuilderFactory dFactory, @Mocked Node node) throws Exception {
        File licFile = new File("123");
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>12</time_slot>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_data>10</cm_data>\n" + 
                "</option>";
        byte[] contentArr = fileContent.getBytes();
        new Expectations() {
            {
                licenseUtils.readFile((File)any);
                result = contentArr;
                LicenseUtils.decryptPaLic((File)any);
                result = fileContent;
                node.getNodeValue();
                result = new IOException();
            }
        };

        new MockUp<File>() {
            
            @Mock
            public boolean exists() {
                return true;
            }

            @Mock
            public boolean isDirectory() {
                return false;
            }
        };
        
        licenseService.check(licFile, "123");
        assertTrue(true);
    }
    
    /**
     * check 测试方法
     * @param licenseUtils 
     * @throws Exception 
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCheckValidate9(@Mocked LicenseUtils licenseUtils) throws Exception {
        File licFile = new File("123");
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>12</time_slot>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_data>10</cm_data>\n" + 
                "</option>";
        byte[] contentArr = fileContent.getBytes();
        new Expectations() {
            {
                licenseUtils.readFile((File)any);
                result = contentArr;
                LicenseUtils.decryptPaLic((File)any);
                //
                result = null;

            }
        };

        new MockUp<File>() {
            
            @Mock
            public boolean exists() {
                return true;
            }

            @Mock
            public boolean isDirectory() {
                return false;
            }
        };
        
        licenseService.check(licFile, "123");
        assertTrue(true);
    }
    
    /**
     * check 测试方法
     * @param licenseUtils 
     * @throws Exception 
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCheckValidate10(@Mocked LicenseUtils licenseUtils) throws Exception {
        File licFile = new File("123");
        String fileContent = "license.sn=123 \r license.sn=123 \r  signature=";
        byte[] contentArr = fileContent.getBytes();
        new Expectations() {
            {
                licenseUtils.readFile((File)any);
                result = contentArr;

            }
        };

        new MockUp<File>() {
            
            @Mock
            public boolean exists() {
                return true;
            }

            @Mock
            public boolean isDirectory() {
                return false;
            }
        };
        
        licenseService.check(licFile, "456");
        assertTrue(true);
    }
    
    /**
     * check 测试方法
     * @param licenseUtils 
     * @throws Exception 
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCheckValidate11(@Mocked LicenseUtils licenseUtils) throws Exception {
        File licFile = new File("123");
        String fileContent = "123 \r 123 \r  signature=";
        byte[] contentArr = fileContent.getBytes();
        new Expectations() {
            {
                licenseUtils.readFile((File)any);
                result = contentArr;

            }
        };

        new MockUp<File>() {
            
            @Mock
            public boolean exists() {
                return true;
            }

            @Mock
            public boolean isDirectory() {
                return false;
            }
        };
        
        licenseService.check(licFile, "456");
        assertTrue(true);
    }
    
    /**
     * check 测试方法
     * @param licenseUtils 
     * @throws Exception 
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCheckValidate12(@Mocked LicenseUtils licenseUtils) throws Exception {
        File licFile = new File("123");
        String fileContent = "signature=";
        byte[] contentArr = fileContent.getBytes();
        new Expectations() {
            {
                licenseUtils.readFile((File)any);
                result = contentArr;
                licenseUtils.checkSign((String)any, (String)any);
                result = true;

            }
        };

        new MockUp<File>() {
            
            @Mock
            public boolean exists() {
                return true;
            }

            @Mock
            public boolean isDirectory() {
                return false;
            }
        };
        
        licenseService.check(licFile, "123");
        assertTrue(true);
    }
    
    /**
     * check 测试方法
     * @param licenseUtils 
     * @throws Exception 
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCheckValidate13(@Mocked LicenseUtils licenseUtils) throws Exception {
        File licFile = new File("123");
        String fileContent = "license.sn=123 \r license.sn=123 \r  signature=";
        byte[] contentArr = fileContent.getBytes();
        new Expectations() {
            {
                licenseUtils.readFile((File)any);
                result = contentArr;

            }
        };
        new MockUp<File>() {
            
            @Mock
            public boolean exists() {
                return true;
            }

            @Mock
            public boolean isDirectory() {
                return false;
            }
        };
        
        licenseService.check(licFile, "123");
        assertTrue(true);
    }
    
    /**
     * check 测试方法
     * @param licenseUtils 
     * @throws Exception 
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCheckValidate14(@Mocked LicenseUtils licenseUtils) throws Exception {
        File licFile = new File("123");
        new Expectations() {
            {
                licenseUtils.readFile((File)any);
                result = new FileNotFoundException();

            }
        };
        new MockUp<File>() {
            
            @Mock
            public boolean exists() {
                return true;
            }

            @Mock
            public boolean isDirectory() {
                return false;
            }
        };
        
        licenseService.check(licFile, "123");
        assertTrue(true);
    }
    
    /**
     * check 测试方法
     * @param licenseUtils 
     * @throws Exception 
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCheckValidate15(@Mocked LicenseUtils licenseUtils) throws Exception {
        File licFile = new File("123");
        new Expectations() {
            {
                licenseUtils.readFile((File)any);
                result = new IOException();

            }
        };
        new MockUp<File>() {
            
            @Mock
            public boolean exists() {
                return true;
            }

            @Mock
            public boolean isDirectory() {
                return false;
            }
        };
        
        licenseService.check(licFile, "123");
        assertTrue(true);
    }
    
    /**
     * check 测试方法
     * @param licenseUtils 
     * @throws Exception 
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCheckValidate16(@Mocked LicenseUtils licenseUtils) throws Exception {
        File licFile = new File("123");
        String fileContent = "license.sn=123&123 \r license.sn=123&456 \r  signature=";
        byte[] contentArr = fileContent.getBytes();
        new Expectations() {
            {
                licenseUtils.readFile((File)any);
                result = contentArr;

            }
        };
        new MockUp<File>() {
            
            @Mock
            public boolean exists() {
                return true;
            }

            @Mock
            public boolean isDirectory() {
                return false;
            }
        };
        
        licenseService.check(licFile, "123");
        assertTrue(true);
    }
}
