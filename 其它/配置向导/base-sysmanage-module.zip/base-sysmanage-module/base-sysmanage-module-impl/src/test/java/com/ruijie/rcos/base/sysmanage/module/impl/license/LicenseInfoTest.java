package com.ruijie.rcos.base.sysmanage.module.impl.license;

import static org.junit.Assert.assertTrue;
import java.util.ArrayList;
import java.util.Date;
import org.junit.Test;
import com.ruijie.rcos.base.sysmanage.module.impl.license.enums.LicenseTypeEnum;
import com.ruijie.rcos.base.sysmanage.module.impl.license.vo.LicenseFeature;
import com.ruijie.rcos.base.sysmanage.module.impl.license.vo.LicenseInfo;
import mockit.Tested;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月25日
 * 
 * @author zouqi
 */
public class LicenseInfoTest {

    @Tested 
    LicenseInfo licenseInfo;
    
    @Test
    public void testGetSetMethod() {
        licenseInfo.setDevCode("123");
        licenseInfo.setDevSn("1234");
        licenseInfo.setDuration(1235L);
        licenseInfo.setFeatureList(new ArrayList<>());
        licenseInfo.setProductName("12345");
        licenseInfo.setStartTime(new Date());
        licenseInfo.setType(LicenseTypeEnum.COMMERCIAL);
        licenseInfo.addFeature(new LicenseFeature());
        licenseInfo.getDevCode();
        licenseInfo.getDevSn();
        licenseInfo.getDuration();
        licenseInfo.getFeatureList();
        licenseInfo.getProductName();
        licenseInfo.getStartTime();
        licenseInfo.getType();
        licenseInfo.isNoTimeLimit();
        licenseInfo.setDuration(-1L);
        licenseInfo.isNoTimeLimit();
        assertTrue(true);
    }
    
    
}
