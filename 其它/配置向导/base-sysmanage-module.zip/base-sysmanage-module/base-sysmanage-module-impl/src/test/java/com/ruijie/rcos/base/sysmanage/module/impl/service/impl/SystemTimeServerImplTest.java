package com.ruijie.rcos.base.sysmanage.module.impl.service.impl;

import java.util.Arrays;
import java.util.Date;
import java.util.concurrent.ScheduledFuture;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.ruijie.rcos.base.sysmanage.module.def.spi.BaseSystemTimeChangeAfterSPI;
import com.ruijie.rcos.base.sysmanage.module.def.spi.BaseSystemTimeChangeBeforeSPI;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseSystemTimeChangeAfterRequest;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseSystemTimeChangeBeforeRequest;
import com.ruijie.rcos.base.sysmanage.module.impl.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.impl.common.Constants;
import com.ruijie.rcos.sk.base.concorrent.SkyengineExecutors;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.shell.ShellCommandRunner;
import com.ruijie.rcos.sk.modulekit.api.comm.ModuleCommExpertAPI;

import mockit.*;
import mockit.integration.junit4.JMockit;

/**
 * Description: 系统时间service
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月25日
 *
 * @author fyq
 */

@RunWith(JMockit.class)
public class SystemTimeServerImplTest {

    @Tested
    private SystemTimeServiceImpl systemTimeService;

    @Injectable
    private BaseSystemTimeChangeBeforeSPI systemTimeChangeBeforeSPI;

    @Injectable
    private BaseSystemTimeChangeAfterSPI systemTimeChangeAfterSPI;

    @Injectable
    private ModuleCommExpertAPI moduleCommExpertAPI;

    @Mocked
    private ShellCommandRunner runner;

    /**
     * 更新系统时间
     */
    @Test
    public void testUpdateSystemTimeBadArgTime() {
        try {
            systemTimeService.updateSystemTime(null);
            Assert.fail();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "时间参数不能为空");
        }
    }

    /**
     * 更新系统时间
     *
     * @throws BusinessException 异常
     */
    @Test
    public void testUpdateSystemTime() throws BusinessException {

        Date date = new Date();

        new Expectations() {
            {
                runner.execute();
            }
        };

        systemTimeService.updateSystemTime(date.getTime());

        new Verifications() {
            {
                runner.setCommand(Constants.SH_TIME_CHANGE);
                times = 1;
                runner.appendArgs(anyString);
                times = 2;
                runner.execute();
                times = 1;
            }
        };
    }

    /**
     * 更新系统时间 Ntp
     */
    @Test
    public void testUpdateSystemTimeFromNtpBadArgNtpServer() {
        try {
            systemTimeService.updateSystemTimeFromNtp(null);
            Assert.fail();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "NTP地址参数不能为空");
        }
    }

    /**
     * 更新系统时间
     *
     * @throws BusinessException 异常
     */
    @Test
    public void testUpdateSystemTimeFromNtp() throws BusinessException {

        String ntpServer = "ntp.xxx.xxx.com";

        new Expectations() {
            {
                runner.execute();
            }
        };
        systemTimeService.updateSystemTimeFromNtp(ntpServer);
        new Verifications() {
            {
                runner.setCommand(Constants.SH_TIME_CHANGE_FROM_NTP);
                times = 1;
                runner.appendArgs(ntpServer);
                times = 1;
                runner.execute();
                times = 1;
            }
        };
    }

    /**
     * 从Ntp无法访问测试更新系统时间
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testUpdateSystemTimeFromNtpUnreachable() throws BusinessException {

        String ntpServer = "ntp.xxx.xxx.com";

        new MockUp<ShellCommandRunner>() {

            private ShellCommandRunner.ErrorHandler handler;

            @Mock
            protected ShellCommandRunner addErrorHandler(Invocation invocation, ShellCommandRunner.ErrorHandler handler) {
                this.handler = handler;
                return invocation.getInvokedInstance();
            }

            @Mock
            protected String execute() throws BusinessException {
                handler.handle("", 101, "");
                // mock了不要放回啥
                return null;
            }
        };
        try {
            systemTimeService.updateSystemTimeFromNtp(ntpServer);
        } catch (BusinessException e) {
            Assert.assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_UPDATE_SYSTEM_TIME_UNREACHABLE_NTP);
        }

    }

    /**
     * 从Ntp无法访问测试更新系统时间
     *
     * @throws BusinessException 异常
     */
    @Test
    public void testUpdateSystemTimeFromNtpUnreachableNotEqual() throws BusinessException {

        String ntpServer = "ntp.xxx.xxx.com";

        new MockUp<ShellCommandRunner>() {

            private ShellCommandRunner.ErrorHandler handler;

            @Mock
            protected ShellCommandRunner addErrorHandler(Invocation invocation, ShellCommandRunner.ErrorHandler handler) {
                this.handler = handler;
                return invocation.getInvokedInstance();
            }

            @Mock
            protected String execute() throws BusinessException {
                handler.handle("", 102, "");
                // mock了不要放回啥
                return null;
            }
        };
        try {
            systemTimeService.updateSystemTimeFromNtp(ntpServer);
        } catch (BusinessException e) {
            Assert.assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_UPDATE_SYSTEM_TIME_UNREACHABLE_NTP);
        }

    }

    /**
     * 测试更新系统时间失败 Shell执行
     *
     * @throws BusinessException 异常
     */
    @Test
    public void testUpdateSystemTimeFailShellExecute() throws BusinessException {
        new Expectations() {
            {
                runner.execute();
                result = new BusinessException(BusinessKey.BASE_SYS_MANAGE_UPDATE_SYSTEM_TIME_UNREACHABLE_NTP);
            }
        };
        try {
            systemTimeService.updateSystemTime(System.currentTimeMillis());
            Assert.fail();
        } catch (BusinessException e) {
            Assert.assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_UPDATE_SYSTEM_TIME_UNREACHABLE_NTP);
        }
    }

    /**
     * 更新系统时间重启
     *
     * @param skyengineExecutors sky
     * @throws Exception 异常
     */
    @Test
    public void testUpdateSystemTimeWithReboot(@Mocked SkyengineExecutors skyengineExecutors) throws Exception {

        new Expectations() {
            {
                runner.execute();
            }
        };

        new MockUp<Math>() {
            @Mock
            public long abs(long a) {
                return Constants.ONE_MINUTE_MILLS * 2;
            }
        };

        new MockUp<SkyengineExecutors>() {
            @Mock
            protected ScheduledFuture<?> schedule(Runnable command, long delay, String threadName) {
                command.run();
                // mock了 不用返回什么
                return null;
            }
        };

        systemTimeService.updateSystemTime(System.currentTimeMillis());

        new Verifications() {
            {
                runner.setCommand(Constants.SH_TIME_CHANGE);
                times = 1;
                runner.setCommand(Constants.SH_TIME_CHANGE_RESTART_SYSTEM);
                times = 1;
                runner.execute();
                times = 2;
            }
        };
    }

    /**
     * 更新系统时间重启失败
     *
     * @param logger 日志
     * @throws Exception 异常
     */
    @Test
    public void testUpdateSystemTimeWithRebootFail(@Capturing Logger logger) throws Exception {

        new MockUp<ShellCommandRunner>() {

            private boolean isFirst = true;

            @Mock
            public String execute() {
                if (isFirst) {
                    isFirst = false;
                    //
                    return null;
                } else {
                    throw new RuntimeException();
                }
            }
        };
        new MockUp<Math>() {
            @Mock
            public long abs(long a) {
                return Constants.ONE_MINUTE_MILLS * 2;
            }
        };


        new MockUp<SkyengineExecutors>() {
            @Mock
            protected ScheduledFuture<?> schedule(Runnable command, long delay, String threadName) {
                command.run();
                // mock了 不用返回什么
                return null;
            }
        };

        boolean shouldReboot = systemTimeService.updateSystemTime(System.currentTimeMillis());

        Assert.assertTrue(shouldReboot);

        new Verifications() {
            {
                logger.error("重启系统失败", (Exception) any);
                times = 1;
            }
        };
    }

    /**
     * 在更新系统时间之前测试
     *
     * @throws BusinessException 异常
     */
    @Test
    public void testBeforeUpdateSystemTime() throws BusinessException {

        new Expectations() {
            {
                runner.execute();
            }
        };
        new Expectations() {
            {
                moduleCommExpertAPI.loadDispatcherKeys(BaseSystemTimeChangeBeforeSPI.class);
                result = Arrays.asList("key1", "key2");
                systemTimeChangeBeforeSPI.beforeSystemTimeChange((BaseSystemTimeChangeBeforeRequest) any);
                result = null;
            }
        };

        systemTimeService.updateSystemTimeFromNtp("ntp.xx.xxx");

        new Verifications() {
            {
                systemTimeChangeBeforeSPI.beforeSystemTimeChange((BaseSystemTimeChangeBeforeRequest) any);
                times = 2;
            }
        };
    }

    /**
     * 更新系统时间后测试
     *
     * @throws BusinessException 异常
     */
    @Test
    public void testAfterUpdateSystemTime() throws BusinessException {

        new Expectations() {
            {
                runner.execute();
            }
        };
        new Expectations() {
            {
                systemTimeChangeAfterSPI.afterSystemTimeChange((BaseSystemTimeChangeAfterRequest) any);
                result = null;
            }
        };

        systemTimeService.updateSystemTimeFromNtp("ntp.xx.xxx");

        new Verifications() {
            {
                systemTimeChangeAfterSPI.afterSystemTimeChange((BaseSystemTimeChangeAfterRequest) any);
                times = 1;
            }
        };
    }

    /**
     *
     * @throws BusinessException 异常
     */
    @Test
    public void testAfterUpdateSystemTimeNew() throws BusinessException {

        new Expectations() {
            {
                runner.execute();
            }
        };
        new Expectations() {
            {
                systemTimeChangeAfterSPI.afterSystemTimeChange((BaseSystemTimeChangeAfterRequest) any);
                result = null;
            }
        };



        systemTimeService.updateSystemTimeFromNtp("ntp.xx.xxx");

        new Verifications() {
            {
                systemTimeChangeAfterSPI.afterSystemTimeChange((BaseSystemTimeChangeAfterRequest) any);
                times = 1;
            }
        };
    }
}
