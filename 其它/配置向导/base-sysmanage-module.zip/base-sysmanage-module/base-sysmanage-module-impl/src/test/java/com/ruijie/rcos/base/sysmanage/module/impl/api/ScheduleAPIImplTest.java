package com.ruijie.rcos.base.sysmanage.module.impl.api;

import java.lang.reflect.InvocationTargetException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;

import org.apache.commons.lang3.reflect.MethodUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.ApplicationContext;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.data.domain.*;

import com.google.common.collect.Lists;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.schedule.*;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.schedule.BaseListTaskTypeResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.schedule.BaseQueryScheduleResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.schedule.BaseQueryTaskTypeResponse;
import com.ruijie.rcos.base.sysmanage.module.def.common.Constant;
import com.ruijie.rcos.base.sysmanage.module.def.dto.ScheduleDTO;
import com.ruijie.rcos.base.sysmanage.module.def.enums.TaskCycle;
import com.ruijie.rcos.base.sysmanage.module.impl.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.impl.CronExpression;
import com.ruijie.rcos.base.sysmanage.module.impl.dao.ScheduleTaskDAO;
import com.ruijie.rcos.base.sysmanage.module.impl.dao.ScheduleTypeDAO;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.ScheduleTaskEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.ScheduleTypeEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.quartz.data.QuartzTaskData;
import com.ruijie.rcos.base.sysmanage.module.impl.service.impl.ScheduleServiceImpl;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.i18n.LocaleI18nResolver;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.quartz.Quartz;
import com.ruijie.rcos.sk.base.quartz.QuartzTask;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultPageResponse;
import com.ruijie.rcos.sk.modulekit.api.isolation.CrossComponentApplicationContext;

import mockit.*;
import mockit.integration.junit4.JMockit;

/**
 * Description: 任务调度api
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月22日
 *
 * @author yeyuzhong
 */
@RunWith(JMockit.class)
public class ScheduleAPIImplTest {

    @Tested
    private ScheduleAPIImpl scheduleAPI;

    @Injectable
    private ScheduleTaskDAO scheduleTaskDAO;

    @Injectable
    private ScheduleTypeDAO scheduleTypeDAO;

    @Injectable
    private ScheduleServiceImpl scheduleService;

    @Injectable
    private ApplicationContext applicationContext;

    @Injectable
    private CrossComponentApplicationContext crossComponentApplicationContext;

    @Capturing
    private Logger logger;

    /**
     * createCronExpressionIfArgsLegal方法抛出异常
     * <p>
     * 执行createCronExpressionIfArgsLegal方法的baseScheduleRequest.getTaskCycle() == TaskCycle.ONCE分支
     * <p>
     * cronExpression.isExpire()==true
     *
     * @param cronExpression 表达式
     */
    @Test
    public void testCreateScheduleCreateCronExpressionIfArgsLegal(@Mocked CronExpression cronExpression) {
        UUID typeId = UUID.randomUUID();
        BaseCreateScheduleRequest apiRequest = new BaseCreateScheduleRequest();
        apiRequest.setTaskTypeId(typeId);
        apiRequest.setTaskCycle(TaskCycle.ONCE);
        apiRequest.setScheduleTime("12:12:12");
        apiRequest.setScheduleDate("2019-01-22");
        new Expectations() {
            {
                cronExpression.isExpire();
                result = true;
            }
        };
        try {
            scheduleAPI.createSchedule(apiRequest);
            Assert.fail();
        } catch (Exception e) {
            Assert.assertEquals(e.toString(), new BusinessException(BusinessKey.BASE_SYS_MANAGE_SCHEDULE_TIME_EXPIRE).toString());
        }


    }

    /**
     * getScheduleTypeEntity方法中
     * scheduleTaskTypeEntityOptional.isPresent()==false分支
     */
    @Test
    public void testCreateScheduleException() {

        UUID typeId = UUID.randomUUID();
        BaseCreateScheduleRequest apiRequest = new BaseCreateScheduleRequest();
        apiRequest.setTaskTypeId(typeId);
        apiRequest.setTaskCycle(TaskCycle.DAY);
        apiRequest.setScheduleTime("12:12:12");
        try {
            scheduleAPI.createSchedule(apiRequest);
            Assert.fail();
        } catch (Exception e) {
            Assert.assertEquals(e.toString(), new BusinessException(BusinessKey.BASE_SYS_MANAGE_SCHEDULE_TYPE_NOT_EXIST).toString());
        }
    }


    /**
     * getLocalTime抛出异常
     *
     */
    @Test
    public void testCreateScheduleGetLocalTimeException() {

        UUID typeId = UUID.randomUUID();
        BaseCreateScheduleRequest apiRequest = new BaseCreateScheduleRequest();
        apiRequest.setTaskTypeId(typeId);
        apiRequest.setTaskCycle(TaskCycle.DAY);
        apiRequest.setScheduleTime("12:12:12");
        new Expectations(LocalTime.class) {
            {

                LocalTime.parse(anyString, (DateTimeFormatter) any);
                result = new DateTimeParseException("xxx", "x", 0);
            }
        };
        try {
            scheduleAPI.createSchedule(apiRequest);
            Assert.fail();
        } catch (BusinessException e) {
            Assert.assertEquals(e.getMessage(), BusinessKey.BASE_SYS_MANAGE_ILLEGAL_TIME_FORMAT);
        }
    }

    /**
     * 让getLocalDate类 抛出异常
     *
     */
    @Test
    public void testCreateScheduleGetLocalDateException() {

        UUID typeId = UUID.randomUUID();
        BaseCreateScheduleRequest apiRequest = new BaseCreateScheduleRequest();
        apiRequest.setTaskTypeId(typeId);
        apiRequest.setScheduleDate("3019-02-01");
        apiRequest.setTaskCycle(TaskCycle.ONCE);
        new Expectations(DateTimeFormatter.class, LocalTime.class) {
            {
                DateTimeFormatter.ofPattern((String) any);
                result = new DateTimeParseException("xxx", "x", 0);
            }
        };

        try {
            scheduleAPI.createSchedule(apiRequest);
            Assert.fail();
        } catch (BusinessException e) {
            Assert.assertEquals(e.getMessage(), BusinessKey.BASE_SYS_MANAGE_ILLEGAL_DATE_FORMAT);
        }
    }

    /**
     * 创建计划
     *
     * @param scheduleTaskTypeEntityOptional 类型
     * @param quartzTask 任务
     * @param scheduleTaskEntity 实体
     * @throws BusinessException 异常
     */
    @Test
    public void testCreateSchedule(@Mocked Optional<ScheduleTypeEntity> scheduleTaskTypeEntityOptional, @Mocked QuartzTask quartzTask,
            @Mocked ScheduleTaskEntity scheduleTaskEntity) throws BusinessException {

        UUID typeId = UUID.randomUUID();
        BaseCreateScheduleRequest apiRequest = new BaseCreateScheduleRequest();
        apiRequest.setTaskTypeId(typeId);
        apiRequest.setTaskCycle(TaskCycle.DAY);
        apiRequest.setScheduleTime("12:12:12");

        String cronExpr = "12 12 12 * * ? *";


        new Expectations() {
            {
                scheduleTaskTypeEntityOptional.isPresent();
                result = true;
                crossComponentApplicationContext.getBean(null);
                result = quartzTask;
                scheduleTaskDAO.save((ScheduleTaskEntity) any);
                result = null;

                scheduleTaskEntity.getId();
                result = UUID.randomUUID();
                scheduleTaskEntity.getTaskTypeId();
                result = typeId;
                scheduleTaskEntity.getCronExpression();
                result = cronExpr;

                scheduleService.addSchedule(anyString, anyString, anyString, (Map<String, QuartzTaskData>) any);
                result = null;

            }
        };
        scheduleAPI.createSchedule(apiRequest);

        new Verifications() {
            {
                scheduleTaskDAO.save((ScheduleTaskEntity) any);
                times = 1;
                scheduleService.addSchedule(anyString, anyString, anyString, (Map<String, QuartzTaskData>) any);
                times = 1;
            }
        };

    }

    /**
     * 整体业务逻辑
     *
     * @throws BusinessException 异常
     */
    @Test
    public void testQuerySchedule() throws BusinessException {
        BaseQueryScheduleRequest apiRequest = new BaseQueryScheduleRequest();
        UUID id = UUID.randomUUID();
        String cronExpr = "12 12 12 1 2 ? 2019";
        apiRequest.setId(id);

        ScheduleTaskEntity taskEntity = new ScheduleTaskEntity();
        taskEntity.setCronExpression(cronExpr);
        taskEntity.setTaskCycle(TaskCycle.ONCE);
        Optional<ScheduleTaskEntity> taskEntityOptional = Optional.of(taskEntity);

        new Expectations() {
            {
                scheduleTaskDAO.findById(id);
                result = taskEntityOptional;
            }
        };

        BaseQueryScheduleResponse response = scheduleAPI.querySchedule(apiRequest);

        Assert.assertEquals(response.getTaskCycle(), TaskCycle.ONCE);
        Assert.assertEquals(response.getScheduleTime(), LocalTime.of(12, 12, 12).toString());
    }

    /**
     * 当 optionalScheduleTaskEntity.isPresent()==false时，抛出异常
     *
     * @param optionalScheduleTaskEntity 实体
     * @throws BusinessException 异常
     */
    @Test
    public void testQueryScheduleException(@Mocked Optional<ScheduleTypeEntity> optionalScheduleTaskEntity) {
        BaseQueryScheduleRequest apiRequest = new BaseQueryScheduleRequest();
        UUID id = UUID.randomUUID();
        String cronExpr = "12 12 12 1 2 ? 2019";
        apiRequest.setId(id);

        ScheduleTaskEntity taskEntity = new ScheduleTaskEntity();
        taskEntity.setCronExpression(cronExpr);
        taskEntity.setTaskCycle(TaskCycle.ONCE);
        Optional<ScheduleTaskEntity> taskEntityOptional = Optional.of(taskEntity);

        new Expectations() {
            {
                scheduleTaskDAO.findById(id);
                result = taskEntityOptional;
                optionalScheduleTaskEntity.isPresent();
                result = false;
            }
        };
        try {
            scheduleAPI.querySchedule(apiRequest);
        } catch (Exception e) {
            Assert.assertEquals(e.toString(), new BusinessException(BusinessKey.BASE_SYS_MANAGE_SCHEDULE_TASK_NOT_EXIST).toString());
        }
    }

    /***
     * 开始测试 editSchedule类
     *
     * scheduleTaskEntityOptional.isPresent()==false时，抛出异常
     * 
     * @param scheduleTaskEntityOptional 实体
     */
    @Test
    public void testEditScheduleIsPresentFalse(@Mocked Optional<ScheduleTaskEntity> scheduleTaskEntityOptional) {
        BaseEditScheduleRequest apiRequest = new BaseEditScheduleRequest();
        UUID taskId = UUID.randomUUID();
        UUID typeId = UUID.randomUUID();
        apiRequest.setId(taskId);
        apiRequest.setTaskTypeId(typeId);
        apiRequest.setTaskCycle(TaskCycle.ONCE);
        apiRequest.setScheduleTime("12:12:12");
        apiRequest.setScheduleDate(LocalDate.now().plusYears(1).format(DateTimeFormatter.ofPattern(Constant.YYYY_MM_DD)));


        new Expectations() {
            {
                scheduleTaskDAO.findById((UUID) any);
                result = scheduleTaskEntityOptional;
                scheduleTaskEntityOptional.isPresent();
                result = false;
            }
        };
        try {
            scheduleAPI.editSchedule(apiRequest);
            Assert.fail();
        } catch (BusinessException e) {
            Assert.assertEquals(e.getMessage(), BusinessKey.BASE_SYS_MANAGE_SCHEDULE_TASK_NOT_EXIST);
        }

    }



    /**
     * 编辑
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testEditScheduleBoo() throws BusinessException {

        BaseEditScheduleRequest apiRequest = new BaseEditScheduleRequest();
        UUID taskId = UUID.randomUUID();
        UUID typeId = UUID.randomUUID();

        apiRequest.setId(taskId);
        apiRequest.setTaskTypeId(typeId);
        apiRequest.setTaskCycle(TaskCycle.DAY);
        apiRequest.setScheduleTime("12:12:12");

        ScheduleTaskEntity taskEntity = new ScheduleTaskEntity();
        taskEntity.setTaskTypeId(typeId);
        Optional<ScheduleTaskEntity> taskEntityOptional = Optional.of(taskEntity);

        Optional<ScheduleTypeEntity> scheduleTaskTypeEntityOptional = Optional.of(new ScheduleTypeEntity());
        new Expectations() {
            {
                scheduleTaskDAO.findById(taskId);
                result = taskEntityOptional;
                scheduleTypeDAO.findById((UUID) any);
                result = scheduleTaskTypeEntityOptional;
                scheduleTaskDAO.save((ScheduleTaskEntity) any);
                scheduleService.updateSchedule(anyString, anyString, anyString, (Map<String, QuartzTaskData>) any);
                result = null;
            }
        };

        scheduleAPI.editSchedule(apiRequest);

        new Verifications() {
            {
                scheduleTaskDAO.findById(taskId);
                times = 1;
                scheduleTypeDAO.findById((UUID) any);
                times = 1;
                scheduleTaskDAO.save((ScheduleTaskEntity) any);
                times = 1;
                scheduleService.updateSchedule(anyString, anyString, anyString, (Map<String, QuartzTaskData>) any);
                times = 1;
            }
        };
    }

    /**
     * 余下业务逻辑
     *
     * @throws BusinessException 异常
     */
    @Test
    public void testEditSchedule() throws BusinessException {

        BaseEditScheduleRequest apiRequest = new BaseEditScheduleRequest();
        UUID taskId = UUID.randomUUID();
        UUID typeId = UUID.randomUUID();

        apiRequest.setId(taskId);
        apiRequest.setTaskTypeId(typeId);
        apiRequest.setTaskCycle(TaskCycle.DAY);
        apiRequest.setScheduleTime("12:12:12");

        ScheduleTaskEntity taskEntity = new ScheduleTaskEntity();
        taskEntity.setTaskTypeId(UUID.randomUUID());
        Optional<ScheduleTaskEntity> taskEntityOptional = Optional.of(taskEntity);

        Optional<ScheduleTypeEntity> scheduleTaskTypeEntityOptional = Optional.of(new ScheduleTypeEntity());
        new Expectations() {
            {
                scheduleTaskDAO.findById(taskId);
                result = taskEntityOptional;
                scheduleTypeDAO.findById((UUID) any);
                result = scheduleTaskTypeEntityOptional;

                scheduleTaskDAO.save((ScheduleTaskEntity) any);
                result = null;

                scheduleService.updateSchedule(anyString, anyString, anyString, (Map<String, QuartzTaskData>) any);
                result = null;
            }
        };

        scheduleAPI.editSchedule(apiRequest);

        new Verifications() {
            {
                scheduleTaskDAO.save((ScheduleTaskEntity) any);
                times = 1;
                scheduleService.updateSchedule(anyString, anyString, anyString, (Map<String, QuartzTaskData>) any);
                times = 1;
            }
        };
    }

    /**
     * listSchedulec测试
     *
     * @param apiRequest api
     */
    @Test
    public void testListSchedule(@Tested BaseListScheduleRequest apiRequest) {

        int limit = 10;
        int total = 100;

        Pageable pageable = PageRequest.of(0, 10, Sort.by("createTime"));

        List<ScheduleTaskEntity> entityList = Lists.newArrayList();

        for (int i = 0; i < limit; i++) {
            ScheduleTaskEntity entity = new ScheduleTaskEntity();
            entity.setCronExpression("12 12 12 * * ? *");
            entity.setTaskCycle(TaskCycle.DAY);
            entityList.add(entity);
        }

        Page<ScheduleTaskEntity> entityPage = new PageImpl(entityList, pageable, total);

        new Expectations() {
            {
                scheduleTaskDAO.findAll((Pageable) any);
                result = entityPage;
            }
        };

        DefaultPageResponse<ScheduleDTO> response = scheduleAPI.listSchedule(apiRequest);

        Assert.assertEquals(response.getTotal(), total);
        Assert.assertEquals(response.getItemArr().length, limit);
        Assert.assertEquals(response.getItemArr()[0].getTaskCycle(), TaskCycle.DAY);
    }

    /**
     * deleteSchedule方法测试
     *
     * @throws BusinessException 异常
     */
    @Test
    public void testDeleteSchedule() throws BusinessException {
        BaseDeleteScheduleRequest apiRequest = new BaseDeleteScheduleRequest();
        UUID taskId = UUID.randomUUID();
        UUID typeId = UUID.randomUUID();

        apiRequest.setId(taskId);

        ScheduleTaskEntity taskEntity = new ScheduleTaskEntity();
        taskEntity.setId(taskId);
        taskEntity.setTaskTypeId(typeId);
        Optional<ScheduleTaskEntity> taskEntityOptional = Optional.of(taskEntity);

        new Expectations() {
            {
                scheduleTaskDAO.findById(taskId);
                result = taskEntityOptional;
                scheduleTaskDAO.deleteById(taskId);
                result = null;
                scheduleService.deleteSchedule(typeId.toString(), taskId.toString());
                result = null;
            }
        };

        scheduleAPI.deleteSchedule(apiRequest);

        new Verifications() {
            {
                scheduleTaskDAO.deleteById(taskId);
                times = 1;
                scheduleService.deleteSchedule(typeId.toString(), taskId.toString());
                times = 1;
            }
        };
    }

    /**
     * logger.isDebugEnabled()条件测试
     *
     * @throws BusinessException 异常
     */
    @Test
    public void testDeleteScheduleDebug() throws BusinessException {

        new Expectations() {
            {
                logger.isDebugEnabled();
                result = true;
            }
        };

        testDeleteSchedule();

        new Verifications() {
            {
                logger.isDebugEnabled();
                times = 1;
            }
        };
    }

    /**
     * listTaskType 方法
     */
    @Test
    public void testListTaskType() {
        BaseListTaskTypeRequest apiRequest = new BaseListTaskTypeRequest();

        int total = 10;

        List<ScheduleTypeEntity> entityList = Lists.newArrayList();

        for (int i = 0; i < total; i++) {
            ScheduleTypeEntity entity = new ScheduleTypeEntity();
            entity.setName("rebootTask");
            entityList.add(entity);
        }

        new Expectations() {
            {
                scheduleTypeDAO.findAll();
                result = entityList;
            }
        };

        BaseListTaskTypeResponse response = scheduleAPI.listTaskType(apiRequest);

        Assert.assertEquals(response.getItemArr().length, total);
        Assert.assertEquals(response.getItemArr()[0].getLabel(), "rebootTask");
        new Verifications() {
            {
                scheduleTypeDAO.findAll();
                times = 1;
            }
        };
    }

    /**
     * 测试queryTaskType方法中调用getScheduleTypeEntity无异常情况下
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testQueryTaskType() throws BusinessException {
        BaseQueryTaskTypeRequest apiRequest = new BaseQueryTaskTypeRequest();

        UUID typeId = UUID.randomUUID();
        apiRequest.setId(typeId);

        ScheduleTypeEntity entity = new ScheduleTypeEntity();
        entity.setId(typeId);
        entity.setName("rebootTask");
        Optional<ScheduleTypeEntity> scheduledTypeOptional = Optional.of(entity);

        new Expectations() {
            {
                scheduleTypeDAO.findById(typeId);
                result = scheduledTypeOptional;
            }
        };

        BaseQueryTaskTypeResponse response = scheduleAPI.queryTaskType(apiRequest);

        Assert.assertEquals(response.getId(), typeId);
        Assert.assertEquals(response.getLabel(), "rebootTask");
        new Verifications() {
            {
                scheduleTypeDAO.findById(typeId);
                times = 1;
            }
        };
    }

    /**
     * 测试queryTaskType方法中调用getScheduleTypeEntity异常
     */
    @Test
    public void testQueryTaskTypeEntityNotExists() {
        BaseQueryTaskTypeRequest apiRequest = new BaseQueryTaskTypeRequest();

        UUID typeId = UUID.randomUUID();
        apiRequest.setId(typeId);

        Optional<ScheduleTypeEntity> scheduledTypeOptional = Optional.empty();

        new Expectations() {
            {
                scheduleTypeDAO.findById(typeId);
                result = scheduledTypeOptional;
            }
        };

        try {
            scheduleAPI.queryTaskType(apiRequest);
            Assert.fail();
        } catch (BusinessException e) {
            Assert.assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_SCHEDULE_TYPE_NOT_EXIST);
        }
    }

    /**
     * 批量查询任务
     */
    @Test
    public void testBatchQueryTask() {
        BaseBatchQueryScheduleRequest baseBatchQueryScheduleRequest = new BaseBatchQueryScheduleRequest();
        baseBatchQueryScheduleRequest.setIdArr(new UUID[] {UUID.randomUUID()});

        List<ScheduleTaskEntity> scheduleTaskEntityList = new ArrayList<>();
        ScheduleTaskEntity scheduleTaskEntity = new ScheduleTaskEntity();
        scheduleTaskEntity.setId(UUID.randomUUID());
        scheduleTaskEntity.setTaskTypeId(UUID.randomUUID());
        scheduleTaskEntityList.add(scheduleTaskEntity);
        new Expectations() {
            {
                scheduleTaskDAO.findAllById((Iterable<UUID>) any);
                result = scheduleTaskEntityList;
            }
        };
        scheduleAPI.batchQueryTask(baseBatchQueryScheduleRequest);
        new Verifications() {
            {
                scheduleTaskDAO.findAllById((Iterable<UUID>) any);
                times = 1;

            }
        };

    }

    /**
     * 设置跨组件应用程序上下文
     * 
     * @param crossComponentApplicationContext 实体
     */
    @Test
    public void testSetCrossComponentApplicationContext(@Tested CrossComponentApplicationContext crossComponentApplicationContext) {
        scheduleAPI.setCrossComponentApplicationContext(crossComponentApplicationContext);
        Assert.assertTrue(true);

    }

    /**
     * 测试initComponentQuartzTask方法中quartz==null时
     */
    @Test
    public void testSafeInitQuartzIsNull() {

        List<QuartzTask> quartzTasksList = new ArrayList<>();
        quartzTasksList.add(new MyQuartz());
        quartzTasksList.add(new MyQuartz());
        new Expectations() {
            {
                logger.debug(anyString, any);
                result = null;
            }
        };

        new Expectations(AnnotationUtils.class) {
            {
                AnnotationUtils.findAnnotation((Class<?>) any, Quartz.class);
                result = null;
                crossComponentApplicationContext.getBeans(QuartzTask.class);
                result = quartzTasksList;
            }
        };
        scheduleAPI.safeInit();
        new Verifications() {
            {
                logger.debug(anyString, any);
                times = 3;
            }
        };
    }

    /**
     * 当name为空时，StringUtils.isBlank(name)为真，抛出异常
     */
    @Test
    public void testSafeInitNameIsBlank() {
        List<QuartzTask> quartzTasksList = new ArrayList<>();
        quartzTasksList.add(new MyQuartz());
        quartzTasksList.add(new MyQuartz());

        new Expectations(LocaleI18nResolver.class) {
            {
                crossComponentApplicationContext.getBeans(QuartzTask.class);
                result = quartzTasksList;
                LocaleI18nResolver.resolve(anyString);
                result = null;
            }
        };
        try {
            scheduleAPI.safeInit();
            Assert.fail();
        } catch (IllegalArgumentException e) {
            Assert.assertEquals(e.getMessage(), "类[" + MyQuartz.class + "]name字段为空为空");
        }
    }

    /**
     * 测试cron为空时（创建一个辅助测试类AuxiliaryTaskTest）
     */
    @Test
    public void testSafeInitCronIsNull() {
        List<QuartzTask> quartzTasksList = new ArrayList<>();
        quartzTasksList.add(new AuxiliaryTaskTest());
        quartzTasksList.add(new AuxiliaryTaskTest());

        new Expectations(LocaleI18nResolver.class) {
            {
                crossComponentApplicationContext.getBeans(QuartzTask.class);
                result = quartzTasksList;
                LocaleI18nResolver.resolve(anyString);
                result = "123";

            }
        };
        try {
            scheduleAPI.safeInit();
            Assert.fail();
        } catch (IllegalArgumentException e) {
            Assert.assertEquals(e.getMessage(), "类[" + AuxiliaryTaskTest.class + "]cron表达式为空");
        }
    }

    /**
     * 正常逻辑
     *
     * @throws BusinessException 异常
     */
    @Test
    public void testSafeInit() throws BusinessException {
        List<QuartzTask> quartzTasksList = new ArrayList<>();
        quartzTasksList.add(new MyQuartz());
        quartzTasksList.add(new MyQuartz());

        new Expectations(LocaleI18nResolver.class) {
            {
                crossComponentApplicationContext.getBeans(QuartzTask.class);
                result = quartzTasksList;
                LocaleI18nResolver.resolve(anyString);
                result = "CH";
                scheduleService.addSchedule(anyString, anyString, anyString, (Map<String, QuartzTaskData>) any);
            }
        };
        scheduleAPI.safeInit();
        new Verifications() {
            {
                scheduleService.addSchedule(anyString, anyString, anyString, (Map<String, QuartzTaskData>) any);
                times = 2;
            }
        };
    }

    /**
     * addSchedule方法抛出异常
     *
     * @throws BusinessException 异常
     */
    @Test
    public void testSafeInitBusinessException() throws BusinessException {
        List<QuartzTask> quartzTasksList = new ArrayList<>();
        quartzTasksList.add(new MyQuartz());
        quartzTasksList.add(new MyQuartz());
        new Expectations() {
            {
                logger.error(anyString, (BusinessException) any);
                result = null;
            }
        };
        new Expectations(LocaleI18nResolver.class) {
            {
                crossComponentApplicationContext.getBeans(QuartzTask.class);
                result = quartzTasksList;
                LocaleI18nResolver.resolve(anyString);
                result = "CH";
                scheduleService.addSchedule(anyString, anyString, anyString, (Map<String, QuartzTaskData>) any);
                result = new BusinessException("123");
            }
        };
        scheduleAPI.safeInit();
        new Verifications() {
            {
                logger.error(anyString, (BusinessException) any);
                times = 2;
            }
        };
    }

    /**
     * 、scheduleTaskEntityList为空，直接break；
     * 
     * @param scheduleTaskEntityPage 实体
     * @throws BusinessException 异常
     */
    @Test
    public void initConfigurableQuartzTask(@Mocked Page<ScheduleTaskEntity> scheduleTaskEntityPage) throws BusinessException {
        List<ScheduleTypeEntity> scheduleTypeEntityList = new ArrayList<>();
        ScheduleTypeEntity scheduleTypeEntity;
        for (int i = 0; i < 2; i++) {
            scheduleTypeEntity = new ScheduleTypeEntity();
            scheduleTypeEntity.setId(UUID.randomUUID());
            scheduleTypeEntityList.add(scheduleTypeEntity);
        }

        new Expectations() {
            {
                scheduleTypeDAO.findAll();
                result = scheduleTypeEntityList;
                scheduleTaskDAO.findAll((Pageable) any);
                result = scheduleTaskEntityPage;
                logger.debug(anyString, anyInt);
                result = null;
            }
        };
        testSafeInit();
        scheduleAPI.safeInit();
        new Verifications() {
            {
                logger.debug(anyString, anyInt);
                times = 2;
            }
        };
    }

    /**
     * cronExpression.isExpire()为真时
     *
     * @param scheduleTaskEntityPage 实体
     * @throws BusinessException 异常
     */
    @Test
    public void initConfigurableQuartzIsExpire(@Mocked Page<ScheduleTaskEntity> scheduleTaskEntityPage) throws BusinessException {
        List<ScheduleTypeEntity> scheduleTypeEntityList = new ArrayList<>();
        ScheduleTypeEntity scheduleTypeEntity;
        for (int i = 0; i < 2; i++) {
            scheduleTypeEntity = new ScheduleTypeEntity();
            scheduleTypeEntity.setId(UUID.randomUUID());
            scheduleTypeEntityList.add(scheduleTypeEntity);
        }
        List<ScheduleTaskEntity> scheduleTaskEntityList = new ArrayList<>();
        ScheduleTaskEntity scheduleTaskEntity = new ScheduleTaskEntity();
        scheduleTaskEntity.setTaskCycle(TaskCycle.ONCE);
        scheduleTaskEntity.setCronExpression("1 2 3 1 2 ? 2018");
        scheduleTaskEntityList.add(scheduleTaskEntity);

        new Expectations() {
            {
                scheduleTypeDAO.findAll();
                result = scheduleTypeEntityList;
                scheduleTaskDAO.findAll((Pageable) any);
                result = scheduleTaskEntityPage;
                scheduleTaskEntityPage.getContent();
                result = scheduleTaskEntityList;

            }
        };
        testSafeInit();
        scheduleAPI.safeInit();
        new Verifications() {
            {
                scheduleTaskDAO.findAll((Pageable) any);
                times = 2;
            }
        };
    }

    /**
     * Quartz添加计划业务
     * 
     * @param scheduleTaskEntityPage 实体
     * @throws BusinessException 异常
     */

    @Test
    public void initConfigurableQuartzAddScheduleBusiness(@Mocked Page<ScheduleTaskEntity> scheduleTaskEntityPage) throws BusinessException {
        List<QuartzTask> quartzTasksList = new ArrayList<>();
        quartzTasksList.add(new MyQuartz());
        quartzTasksList.add(new MyQuartz());


        List<ScheduleTypeEntity> scheduleTypeEntityList = new ArrayList<>();
        ScheduleTypeEntity scheduleTypeEntity;

        List<ScheduleTaskEntity> scheduleTaskEntityList = new ArrayList<>();
        ScheduleTaskEntity scheduleTaskEntity;
        for (int i = 0; i < 200; i++) {
            UUID uuid = UUID.randomUUID();
            scheduleTypeEntity = new ScheduleTypeEntity();
            scheduleTypeEntity.setId(uuid);
            scheduleTypeEntityList.add(scheduleTypeEntity);

            scheduleTaskEntity = new ScheduleTaskEntity();
            scheduleTaskEntity.setTaskCycle(TaskCycle.ONCE);
            scheduleTaskEntity.setCronExpression("1 2 3 1 2 ? 2999");
            scheduleTaskEntity.setTaskTypeId(uuid);
            scheduleTaskEntity.setId(UUID.randomUUID());
            scheduleTaskEntityList.add(scheduleTaskEntity);
        }

        /*
         * 处理initComponentQuartzTask()方法
         */
        new Expectations(AnnotationUtils.class) {
            {
                AnnotationUtils.findAnnotation((Class<?>) any, Quartz.class);
                result = null;
                crossComponentApplicationContext.getBeans(QuartzTask.class);
                result = quartzTasksList;
            }
        };

        new Expectations() {
            {
                scheduleTypeDAO.findAll();
                result = scheduleTypeEntityList;

                scheduleTaskDAO.findAll((Pageable) any);
                result = scheduleTaskEntityPage;

                scheduleTaskEntityPage.getContent();
                returns(scheduleTaskEntityList, new ArrayList<>());
                scheduleService.addSchedule(anyString, anyString, anyString, (Map<String, QuartzTaskData>) any);
                result = null;
            }
        };
        scheduleAPI.safeInit();

        new Verifications() {
            {

            }
        };

    }

    /**
     * ddSchedule BusinessException 异常
     *
     * @param scheduleTaskEntityPage 实体
     * @throws BusinessException 异常
     */

    @Test
    public void initConfigurableQuartza(@Mocked Page<ScheduleTaskEntity> scheduleTaskEntityPage) throws BusinessException {
        List<QuartzTask> quartzTasksList = new ArrayList<>();
        quartzTasksList.add(new MyQuartz());
        quartzTasksList.add(new MyQuartz());

        List<ScheduleTypeEntity> scheduleTypeEntityList = new ArrayList<>();
        ScheduleTypeEntity scheduleTypeEntity1 = new ScheduleTypeEntity();
        scheduleTypeEntity1.setId(UUID.randomUUID());
        scheduleTypeEntityList.add(scheduleTypeEntity1);

        ScheduleTypeEntity scheduleTypeEntity2 = new ScheduleTypeEntity();
        UUID uuid = UUID.randomUUID();
        scheduleTypeEntity2.setId(uuid);
        scheduleTypeEntity2.setBeanName("name");
        scheduleTypeEntity2.setBeanName("beanName");
        scheduleTypeEntityList.add(scheduleTypeEntity2);

        List<ScheduleTaskEntity> scheduleTaskEntityList = new ArrayList<>();
        ScheduleTaskEntity scheduleTaskEntity = new ScheduleTaskEntity();
        scheduleTaskEntity.setTaskCycle(TaskCycle.ONCE);
        scheduleTaskEntity.setCronExpression("1 2 3 1 2 ? 2999");
        scheduleTaskEntity.setTaskTypeId(uuid);
        scheduleTaskEntity.setId(UUID.randomUUID());
        scheduleTaskEntityList.add(scheduleTaskEntity);
        /*
         * 处理initComponentQuartzTask()方法
         */
        new Expectations(AnnotationUtils.class) {
            {
                AnnotationUtils.findAnnotation((Class<?>) any, Quartz.class);
                result = null;
                crossComponentApplicationContext.getBeans(QuartzTask.class);
                result = quartzTasksList;
            }
        };

        new Expectations() {
            {
                scheduleTypeDAO.findAll();
                result = scheduleTypeEntityList;
                scheduleTaskDAO.findAll((Pageable) any);
                result = scheduleTaskEntityPage;
                scheduleTaskEntityPage.getContent();
                result = scheduleTaskEntityList;
                scheduleService.addSchedule(anyString, anyString, anyString, (Map<String, QuartzTaskData>) any);
                result = new BusinessException("123");

                logger.error(anyString, (BusinessException) any);
                result = null;


            }
        };
        scheduleAPI.safeInit();

        new Verifications() {
            {
                logger.error(anyString, (BusinessException) any);
                times = 1;
            }
        };

    }

    /**
     * 获取当地时间
     * 
     * @throws NoSuchMethodException 找不到方法异常
     * @throws IllegalAccessException 非法访问异常
     */
    @Test
    public void testGetLocalTimeWithExpection() throws NoSuchMethodException, IllegalAccessException {

        String localTime = "12-12-12";

        try {
            MethodUtils.invokeMethod(scheduleAPI, true, "getLocalTime", new Object[] {localTime}, new Class[] {String.class});
            Assert.fail();
        } catch (InvocationTargetException e) {
            Assert.assertEquals(e.getTargetException().getClass(), BusinessException.class);
            Assert.assertEquals(((BusinessException) e.getTargetException()).getKey(), BusinessKey.BASE_SYS_MANAGE_ILLEGAL_TIME_FORMAT);
        }
    }

    /**
     * 获取本地日期 异常
     * 
     * @throws NoSuchMethodException 找不到方法异常
     * @throws IllegalAccessException 非法访问异常
     */
    @Test
    public void testGetLocalDateWithExpection() throws NoSuchMethodException, IllegalAccessException {

        String localDate = "12-12-12";

        try {
            MethodUtils.invokeMethod(scheduleAPI, true, "getLocalDate", new Object[] {localDate}, new Class[] {String.class});
            Assert.fail();
        } catch (InvocationTargetException e) {
            Assert.assertEquals(e.getTargetException().getClass(), BusinessException.class);
            Assert.assertEquals(((BusinessException) e.getTargetException()).getKey(), BusinessKey.BASE_SYS_MANAGE_ILLEGAL_DATE_FORMAT);
        }
    }

    @Test
    public void testSaveTaskTypeWhileArgIsNull() {
        try {
            scheduleAPI.saveTaskType(null);
            Assert.fail();
        } catch (IllegalArgumentException e) {
            Assert.assertEquals(e.getMessage(), "保存任务类型参数不能为空");
        }
    }

    @Test
    public void testSaveTaskType(@Mocked BaseSaveTaskTypeRequest saveTaskTypeRequest) {
        Optional<ScheduleTypeEntity> scheduleTypeEntityOptional = Optional.empty();
        new Expectations() {
            {
                scheduleTypeDAO.findByBeanName(anyString);
                result = scheduleTypeEntityOptional;
                scheduleTypeDAO.save((ScheduleTypeEntity) any);
            }
        };
        scheduleAPI.saveTaskType(saveTaskTypeRequest);
        new Verifications() {
            {
                scheduleTypeDAO.findByBeanName(anyString);
                times = 1;
                scheduleTypeDAO.save((ScheduleTypeEntity) any);
                times = 1;
            }
        };

    }

    @Quartz(cron = "0 0 0 * * ?", msgKey = "")
    class MyQuartz implements QuartzTask {

        @Override
        public void execute() throws Exception {

        }
    }
}


