package com.ruijie.rcos.base.sysmanage.module.impl.api;

import static org.junit.Assert.assertTrue;
import java.util.UUID;
import org.junit.Test;
import org.junit.runner.RunWith;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.BaseCreateDatFileRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.BaseUploadLicFileRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.license.BaseCreateDatFileResponse;
import com.ruijie.rcos.base.sysmanage.module.def.dto.license.BaseLicenseFeatureDTO;
import com.ruijie.rcos.base.sysmanage.module.def.spi.BaseLicenseSerialNumberSPI;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseGetLicenseSerianNumberRequest;
import com.ruijie.rcos.base.sysmanage.module.def.spi.response.BaseGetLicenseSerialNumberResponse;
import com.ruijie.rcos.base.sysmanage.module.impl.service.LicenseFileService;
import com.ruijie.rcos.base.sysmanage.module.impl.util.LicenseUtil;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.test.ThrowExceptionTester;
import mockit.Expectations;
import mockit.Injectable;
import mockit.Mocked;
import mockit.Tested;
import mockit.Verifications;
import mockit.integration.junit4.JMockit;

/**
 * Description: BaseLicenseFileMgmtAPIImpl测试类
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月10日
 * 
 * @author zouqi
 */
@RunWith(JMockit.class)
public class BaseLicenseFileMgmtAPIImplTest {
    
    @Tested
    private BaseLicenseMgmtAPIImpl licenseFileMgmtAPI;
    
    @Injectable
    private BaseLicenseSerialNumberSPI baseLicenseSerialNumberSPI;
    
    @Injectable
    private LicenseFileService licenseFileService;
    
    @Mocked
    private LicenseUtil licenseUtil;
    
    
    /**
     * 验证createDatFile()方法入参
     * 
     * @throws Exception 异常
     */
    @Test
    public void testCreateDatFileValidateParams() throws Exception {

        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseFileMgmtAPI.createDatFile(null), "请求参数不能为空");

        assertTrue(true);
    }
    
    /**
     * createDatFile 测试方法
     * 
     * @throws BusinessException 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCreateDatFile() throws BusinessException {

        BaseGetLicenseSerialNumberResponse spiResponse = new BaseGetLicenseSerialNumberResponse();
        spiResponse.setSerialId("G1MQ2TP000075");
        
        BaseCreateDatFileResponse response = new BaseCreateDatFileResponse();
        //组装文件内容
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        stringBuilder.append("<option>\n");
        stringBuilder.append("  <dev_id>");
        stringBuilder.append(spiResponse.getSerialId());
        stringBuilder.append("</dev_id>\n");
        stringBuilder.append("  <dev_code>");
        stringBuilder.append(UUID.randomUUID().toString());
        stringBuilder.append("</dev_code>\n");
        stringBuilder.append("</option>");
        response.setFileContent(stringBuilder.toString());
        response.setFiieName(spiResponse.getSerialId());
        
        new Expectations() {
            {
                baseLicenseSerialNumberSPI.getLicenseSerialNumber((BaseGetLicenseSerianNumberRequest)any);
                result = spiResponse;
                licenseUtil.createDatFileResponse((BaseGetLicenseSerialNumberResponse)any);
                result = response;
            }
        };

        licenseFileMgmtAPI.createDatFile(new BaseCreateDatFileRequest());

        new Verifications() {
            {
                baseLicenseSerialNumberSPI.getLicenseSerialNumber((BaseGetLicenseSerianNumberRequest)any);
                times = 1;
                licenseUtil.createDatFileResponse((BaseGetLicenseSerialNumberResponse)any);
                times = 1;
            }
        };
    }
    
    /**
     * 验证uploadLicFile()方法入参
     * 
     * @throws Exception 异常
     */
    @Test
    public void testUploadLicFileValidateParams() throws Exception {

        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseFileMgmtAPI.uploadLicFile(null), "请求参数不能为空");

        assertTrue(true);
    }
    
    /**
     * uploadLicFile 测试方法
     * 
     * @throws BusinessException 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testUploadLicFile() throws BusinessException {

        BaseUploadLicFileRequest request = new BaseUploadLicFileRequest();
        request.setFileName("123");
        request.setFileMd5("123");
        request.setFilePath("123");
        
        BaseLicenseFeatureDTO dto = new BaseLicenseFeatureDTO();
        dto.setFileName(request.getFileName());
        dto.setFileMd5(request.getFileMd5());
        dto.setFilePath(request.getFilePath());
        new Expectations() {
            {
                licenseUtil.createLicenseDTO((BaseUploadLicFileRequest)any);
                result = dto;
            }
        };

        licenseFileMgmtAPI.uploadLicFile(request);

        new Verifications() {
            {
                licenseFileService.uploadLicense((BaseLicenseFeatureDTO)any);
                times = 1;
                licenseUtil.createLicenseDTO((BaseUploadLicFileRequest)any);
                times = 1;
            }
        };
    }
}
