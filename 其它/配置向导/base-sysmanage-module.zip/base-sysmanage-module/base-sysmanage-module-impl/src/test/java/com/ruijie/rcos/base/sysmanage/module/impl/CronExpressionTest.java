package com.ruijie.rcos.base.sysmanage.module.impl;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import com.ruijie.rcos.sk.base.exception.BusinessException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.ruijie.rcos.base.sysmanage.module.def.enums.TaskCycle;
import com.ruijie.rcos.base.sysmanage.module.impl.util.ScheduleTaskUtil;

import mockit.Expectations;
import mockit.integration.junit4.JMockit;

/**
 * Description: Cron表达式测试
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月25日
 *
 * @author yeyuzhong
 */

@RunWith(JMockit.class)
public class CronExpressionTest {

    /**
     * 是否过期测试
     */
    @Test
    public void testIsExpire() throws BusinessException {
        TaskCycle taskCycle = TaskCycle.WEEK;
        LocalDate scheduleDate = LocalDate.parse("2999-01-01");
        LocalTime scheduleTime = LocalTime.parse("12:43:22");
        Integer[] dayOfWeekArr = new Integer[] {1, 2};
        new Expectations(ScheduleTaskUtil.class) {
            {
                ScheduleTaskUtil.validateScheduleTaskArgs((TaskCycle) any, (Integer[]) any, (LocalDate) any, (LocalTime) any);
            }
        };
        CronExpression cronExpression = new CronExpression(taskCycle, scheduleDate, scheduleTime, dayOfWeekArr);
        Assert.assertFalse(cronExpression.isExpire());
    }


    /**
     * 是否到期测试-ONCE
     */
    @Test
    public void testIsExpireONCE() throws BusinessException {
        TaskCycle taskCycle = TaskCycle.ONCE;
        LocalDate scheduleDate = LocalDate.parse("2999-01-01");
        LocalTime scheduleTime = LocalTime.parse("12:43:22");
        Integer[] dayOfWeekArr = new Integer[] {1, 2};

        new Expectations(ScheduleTaskUtil.class) {
            {
                ScheduleTaskUtil.validateScheduleTaskArgs((TaskCycle) any, (Integer[]) any, (LocalDate) any, (LocalTime) any);
            }
        };

        CronExpression cronExpression = new CronExpression(taskCycle, scheduleDate, scheduleTime, dayOfWeekArr);
        Assert.assertFalse(cronExpression.isExpire());
    }

    /**
     * 是否到期测试 ADY
     */
    @Test
    public void testIsExpireADY() throws BusinessException {
        TaskCycle taskCycle = TaskCycle.DAY;
        LocalDate scheduleDate = LocalDate.parse("2999-01-01");
        LocalTime scheduleTime = LocalTime.parse("12:43:22");
        Integer[] dayOfWeekArr = new Integer[] {1, 2};

        CronExpression cronExpression = new CronExpression(taskCycle, scheduleDate, scheduleTime, dayOfWeekArr);
        Assert.assertFalse(cronExpression.isExpire());
    }


    /**
     * 获取表达式测试
     */
    @Test
    public void testGetExpression() throws BusinessException {
        TaskCycle taskCycle = TaskCycle.ONCE;
        LocalDate scheduleDate = LocalDate.now();
        LocalTime scheduleTime = LocalTime.now();
        Integer[] dayOfWeekArr = new Integer[] {1, 2};
        new Expectations(ScheduleTaskUtil.class) {
            {
                ScheduleTaskUtil.validateScheduleTaskArgs((TaskCycle) any, (Integer[]) any, (LocalDate) any, (LocalTime) any);
            }
        };
        CronExpression cronExpression = new CronExpression(taskCycle, scheduleDate, scheduleTime, dayOfWeekArr);

        String cronTime = scheduleTime.format(DateTimeFormatter.ofPattern("s m H "));
        String cronExpressionDate = scheduleDate.format(DateTimeFormatter.ofPattern("d M ? yyyy"));
        Assert.assertEquals(cronTime + cronExpressionDate, cronExpression.getExpression());
    }

    /**
     * 获取任务周期
     */
    @Test
    public void testGetTaskCycle() throws BusinessException {
        TaskCycle taskCycle = TaskCycle.ONCE;
        LocalDate scheduleDate = LocalDate.now();
        LocalTime scheduleTime = LocalTime.now();
        Integer[] dayOfWeekArr = new Integer[] {1, 2};
        new Expectations(ScheduleTaskUtil.class) {
            {
                ScheduleTaskUtil.validateScheduleTaskArgs((TaskCycle) any, (Integer[]) any, (LocalDate) any, (LocalTime) any);
            }
        };
        CronExpression cronExpression = new CronExpression(taskCycle, scheduleDate, scheduleTime, dayOfWeekArr);
        Assert.assertEquals(taskCycle, cronExpression.getTaskCycle());

    }

    /**
     * 获取任务周期
     */
    @Test
    public void testSetTaskCycle() throws BusinessException {
        TaskCycle taskCycle = TaskCycle.WEEK;
        LocalDate scheduleDate = LocalDate.now();
        LocalTime scheduleTime = LocalTime.now();
        Integer[] dayOfWeekArr = new Integer[] {1, 2};
        new Expectations(ScheduleTaskUtil.class) {
            {
                ScheduleTaskUtil.validateScheduleTaskArgs((TaskCycle) any, (Integer[]) any, (LocalDate) any, (LocalTime) any);
            }
        };
        CronExpression cronExpression = new CronExpression(taskCycle, scheduleDate, scheduleTime, dayOfWeekArr);
        cronExpression.setTaskCycle(TaskCycle.DAY);
        Assert.assertEquals(TaskCycle.DAY, cronExpression.getTaskCycle());
    }

    /**
     * 获取计划日期
     */
    @Test
    public void testGetScheduleDate() throws BusinessException {
        TaskCycle taskCycle = TaskCycle.WEEK;
        LocalDate scheduleDate = LocalDate.now();
        LocalTime scheduleTime = LocalTime.now();
        Integer[] dayOfWeekArr = new Integer[] {1, 2};
        new Expectations(ScheduleTaskUtil.class) {
            {
                ScheduleTaskUtil.validateScheduleTaskArgs((TaskCycle) any, (Integer[]) any, (LocalDate) any, (LocalTime) any);
            }
        };
        CronExpression cronExpression = new CronExpression(taskCycle, scheduleDate, scheduleTime, dayOfWeekArr);

        Assert.assertEquals(LocalDate.now(), cronExpression.getScheduleDate());
    }

    /**
     * 获取计划时间
     */
    @Test
    public void testGetScheduleTime() throws BusinessException {
        TaskCycle taskCycle = TaskCycle.WEEK;
        LocalDate scheduleDate = LocalDate.now();
        LocalTime scheduleTime = LocalTime.parse("12:43:22");
        Integer[] dayOfWeekArr = new Integer[] {1, 2};
        new Expectations(ScheduleTaskUtil.class) {
            {
                ScheduleTaskUtil.validateScheduleTaskArgs((TaskCycle) any, (Integer[]) any, (LocalDate) any, (LocalTime) any);
            }
        };
        CronExpression cronExpression = new CronExpression(taskCycle, scheduleDate, scheduleTime, dayOfWeekArr);

        Assert.assertEquals(LocalTime.parse("12:43:22"), cronExpression.getScheduleTime());
    }

    /**
     * 获取计划周数
     */
    @Test
    public void testGetDayOfWeekArr() throws BusinessException {
        TaskCycle taskCycle = TaskCycle.WEEK;
        LocalDate scheduleDate = LocalDate.now();
        LocalTime scheduleTime = LocalTime.parse("12:43:22");
        Integer[] dayOfWeekArr = new Integer[] {1, 2};
        new Expectations(ScheduleTaskUtil.class) {
            {
                ScheduleTaskUtil.validateScheduleTaskArgs((TaskCycle) any, (Integer[]) any, (LocalDate) any, (LocalTime) any);
            }
        };
        CronExpression cronExpression = new CronExpression(taskCycle, scheduleDate, scheduleTime, dayOfWeekArr);

        Assert.assertArrayEquals(dayOfWeekArr, cronExpression.getDayOfWeekArr());
    }



    /**
     * 测试表达式 ONCE
     */
    @Test
    public void testCronExpressionONCE() {
        TaskCycle taskCycle = TaskCycle.ONCE;

        CronExpression cronExpression = new CronExpression(taskCycle, "5 17 9 22 1 ? 2019");
        Assert.assertEquals(LocalTime.parse("09:17:05"), cronExpression.getScheduleTime());
    }

    /**
     * 测试表达式 WEEK
     */
    @Test
    public void testCronExpressionWEEK() {
        TaskCycle taskCycle = TaskCycle.WEEK;

        CronExpression cronExpression = new CronExpression(taskCycle, "5 17 9 ? * 1,2 *");
        Assert.assertArrayEquals(new Integer[] {1, 2}, cronExpression.getDayOfWeekArr());
    }

    /**
     * 当周期为空时
     */
    @Test
    public void testCronExpressionWEEKNull() {
        TaskCycle taskCycle = TaskCycle.WEEK;
        CronExpression cronExpression = new CronExpression(taskCycle, "5 17 9 ? * 0,9 *");

        Assert.assertArrayEquals(null, cronExpression.getDayOfWeekArr());
    }

    /**
     * 处理IF条件
     */
    @Test
    public void testCronExpressionIf() {
        TaskCycle taskCycle = TaskCycle.DAY;
        CronExpression cronExpression = new CronExpression(taskCycle, "5 17 9 ? * 9 *");

        Assert.assertArrayEquals(null, cronExpression.getDayOfWeekArr());
    }



}
