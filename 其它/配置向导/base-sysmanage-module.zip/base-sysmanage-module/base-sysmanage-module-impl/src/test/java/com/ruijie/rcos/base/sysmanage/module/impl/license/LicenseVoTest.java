package com.ruijie.rcos.base.sysmanage.module.impl.license;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import java.io.UnsupportedEncodingException;
import org.junit.Test;
import org.junit.runner.RunWith;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.BaseCreateDatFileRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.BaseLicenseListRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.BaseUploadLicFileRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.CheckDuplicationWebRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.license.BaseCreateDatFileResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.license.BaseUploadLicFileResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.license.CheckDuplicationResponse;
import com.ruijie.rcos.base.sysmanage.module.def.dto.license.NotifyLicenseChangeDTO;
import com.ruijie.rcos.base.sysmanage.module.def.dto.license.ValidationLicenseDTO;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseGetLicenseSerianNumberRequest;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseLicenseChangeRequest;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseLicenseFeatureResolveRequest;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseValidateLicenseRequest;
import com.ruijie.rcos.base.sysmanage.module.def.spi.response.BaseGetLicenseSerialNumberResponse;
import com.ruijie.rcos.base.sysmanage.module.def.spi.response.BaseLicenseFeatureResolveResponse;
import com.ruijie.rcos.base.sysmanage.module.def.spi.response.BaseValidateLicenseResponse;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.LicenseFileEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.license.vo.LicCheckResult;
import com.ruijie.rcos.sk.base.test.GetSetTester;
import mockit.Mock;
import mockit.MockUp;
import mockit.Tested;
import mockit.integration.junit4.JMockit;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月25日
 * 
 * @author zouqi
 */
@RunWith(JMockit.class)
public class LicenseVoTest {

    @Tested
    BaseCreateDatFileResponse response;
    
    /**
     * LicCheckResult 測試類
     * 
     */
    @Test
    public void testLicCheckResult() {
        GetSetTester tester = new GetSetTester(LicCheckResult.class);
        tester.runTest();
        
        assertTrue(true);
    }
    
    /**
     * NotifyLicenseChangeDTO 測試類
     * 
     */
    @Test
    public void testNotifyLicenseChangeDTO() {
        GetSetTester tester = new GetSetTester(NotifyLicenseChangeDTO.class);
        tester.runTest();
        
        assertTrue(true);
    }
    
    /**
     * ValidationLicenseDTO 測試類
     * 
     */
    @Test
    public void testValidationLicenseDTO() {
        GetSetTester tester = new GetSetTester(ValidationLicenseDTO.class);
        tester.runTest();
        
        assertTrue(true);
    }
    
    /**
     * LicenseFileEntity 測試類
     * 
     */
    @Test
    public void testLicenseFileEntity() {
        GetSetTester tester = new GetSetTester(LicenseFileEntity.class);
        tester.runTest();
        
        assertTrue(true);
    }
    
    /**
     * BaseUploadLicFileRequest 測試類
     * 
     */
    @Test
    public void testBaseUploadLicFileRequest() {
        GetSetTester tester = new GetSetTester(BaseUploadLicFileRequest.class);
        tester.runTest();
        
        assertTrue(true);
    }
    
    /**
     * CheckDuplicationWebRequest 測試類
     * 
     */
    @Test
    public void testCheckDuplicationWebRequest() {
        GetSetTester tester = new GetSetTester(CheckDuplicationWebRequest.class);
        tester.runTest();
        
        assertTrue(true);
    }
    
    /**
     * BaseCreateDatFileResponse 測試類
     * 
     */
    @Test
    public void testBaseCreateDatFileResponse() {
        GetSetTester tester = new GetSetTester(BaseCreateDatFileResponse.class);
        tester.runTest();
        
        assertTrue(true);
    }
    
    /**
     * CheckDuplicationResponse 測試類
     * 
     */
    @Test
    public void testCheckDuplicationResponse() {
        GetSetTester tester = new GetSetTester(CheckDuplicationResponse.class);
        tester.runTest();
        
        assertTrue(true);
    }
    
    /**
     * BaseLicenseChangeRequest 測試類
     * 
     */
    @Test
    public void testBaseLicenseChangeRequest() {
        GetSetTester tester = new GetSetTester(BaseLicenseChangeRequest.class);
        tester.runTest();
        
        assertTrue(true);
    }
    
    /**
     * BaseLicenseFeatureResolveRequest 測試類
     * 
     */
    @Test
    public void testBaseLicenseFeatureResolveRequest() {
        GetSetTester tester = new GetSetTester(BaseLicenseFeatureResolveRequest.class);
        tester.runTest();
        
        assertTrue(true);
    }
    
    /**
     * BaseGetLicenseSerialNumberResponse 測試類
     * 
     */
    @Test
    public void testBaseValidateLicenseRequest() {
        GetSetTester tester = new GetSetTester(BaseValidateLicenseRequest.class);
        tester.runTest();
        
        assertTrue(true);
    }
    
    /**
     * LicCheckResult 測試類
     * 
     */
    @Test
    public void testBaseGetLicenseSerialNumberResponse() {
        GetSetTester tester = new GetSetTester(BaseGetLicenseSerialNumberResponse.class);
        tester.runTest();
        
        assertTrue(true);
    }
    
    /**
     * BaseLicenseFeatureResolveResponse 測試類
     * 
     */
    @Test
    public void testBaseLicenseFeatureResolveResponse() {
        GetSetTester tester = new GetSetTester(BaseLicenseFeatureResolveResponse.class);
        tester.runTest();
        
        assertTrue(true);
    }
    
    /**
     * BaseValidateLicenseResponse 測試類
     * 
     */
    @Test
    public void testBaseValidateLicenseResponse() {
        GetSetTester tester = new GetSetTester(BaseValidateLicenseResponse.class);
        tester.runTest();
        
        assertTrue(true);
    }
    
    /**
     * BaseGetLicenseSerianNumberRequest 測試類
     * 
     */
    @Test
    public void testBaseGetLicenseSerianNumberRequest() {
        GetSetTester tester = new GetSetTester(BaseGetLicenseSerianNumberRequest.class);
        tester.runTest();
        
        assertTrue(true);
    }
    
    /**
     * BaseCreateDatFileRequest 測試類
     * 
     */
    @Test
    public void testBaseCreateDatFileRequest() {
        GetSetTester tester = new GetSetTester(BaseCreateDatFileRequest.class);
        tester.runTest();
        
        assertTrue(true);
    }
    
    /**
     * BaseCreateDatFileRequest 測試類
     * 
     */
    @Test
    public void testBaseCreateDatFileRequest2() {
        GetSetTester tester = new GetSetTester(BaseUploadLicFileResponse.class);
        tester.runTest();
        
        assertTrue(true);
    }
    
    /**
     * BaseLicenseListRequest 測試類
     * 
     */
    @Test
    public void testBaseLicenseListRequest() {
        GetSetTester tester = new GetSetTester(BaseLicenseListRequest.class);
        tester.runTest();
        
        assertTrue(true);
    }
    
    /**
     * BaseCreateDatFileResponse 測試類
     * 
     */
    @Test
    public void testToInputStream() {
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>75</time_slot>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_onoff>on</cm_onoff>\n" + 
                "</option>";
        response.setFileContent(fileContent);
        response.toInputStream();
        
        assertTrue(true);
    }
    
    /**
     * BaseCreateDatFileResponse 測試類
     * 
     */
    @Test
    public void testToInputStream2() {
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>75</time_slot>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_onoff>on</cm_onoff>\n" + 
                "</option>";
        response.setFileContent(fileContent);
        new MockUp<String>() {
            @Mock
            public byte[] getBytes(String charsetName) throws UnsupportedEncodingException {
                throw new UnsupportedEncodingException();
            }

        };
        try {
            response.toInputStream();
            fail();
        } catch (Exception e) {
            assertTrue(true);
        }
        
    }
    
    /**
     * BaseCreateDatFileResponse 測試類
     * 
     */
    @Test
    public void testToString() {
        
        LicenseFileEntity entity = new LicenseFileEntity();
        entity.toString();

        assertTrue(true); 
    }
    
}
