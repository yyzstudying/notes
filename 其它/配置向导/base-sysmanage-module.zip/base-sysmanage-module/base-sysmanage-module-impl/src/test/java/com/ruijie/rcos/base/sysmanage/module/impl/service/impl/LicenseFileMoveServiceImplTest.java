package com.ruijie.rcos.base.sysmanage.module.impl.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import com.ruijie.rcos.base.sysmanage.module.def.dto.license.BaseLicenseFeatureDTO;
import com.ruijie.rcos.base.sysmanage.module.impl.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.impl.dao.LicenseFileDAO;
import com.ruijie.rcos.sk.base.config.ConfigFacade;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.test.ThrowExceptionTester;
import mockit.Capturing;
import mockit.Expectations;
import mockit.Injectable;
import mockit.Mock;
import mockit.MockUp;
import mockit.Mocked;
import mockit.Tested;
import mockit.Verifications;
import mockit.integration.junit4.JMockit;

/**
 * Description: license合法性校验实现，单元测试类
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月12日
 *
 * @author zouqi
 */

@RunWith(JMockit.class)
public class LicenseFileMoveServiceImplTest {

    @Tested
    private LicenseFileMoveServiceImpl licenseFileMoveService;
    
    @Injectable
    private LicenseFileDAO licenseFileDAO;
    
    @Injectable
    private ConfigFacade configFacade;
    
    @Capturing
    private Logger logger;
    
    /**
     * 验证licenseFileValidation()方法入参
     * 
     * @throws Exception 异常
     */
    @Test
    public void testLicenseFileValidationValidateParams() throws Exception {

        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseFileMoveService.licenseFileValidation(null), "BaseLicenseFeatureDTO 不能为空");
        
        BaseLicenseFeatureDTO licenseFeatureDTO = new BaseLicenseFeatureDTO();
        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseFileMoveService.licenseFileValidation(licenseFeatureDTO), "FileName 不能为空");
        licenseFeatureDTO.setFileName("123");
        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseFileMoveService.licenseFileValidation(licenseFeatureDTO), "FilePath 不能为空");
        licenseFeatureDTO.setFilePath("123");
        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseFileMoveService.licenseFileValidation(licenseFeatureDTO), "FileMd5 不能为空");

        assertTrue(true);
    }
    
    /**
     * licenseFileValidation 测试方法
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testLicenseFileValidation() throws BusinessException {

        BaseLicenseFeatureDTO dto = new BaseLicenseFeatureDTO();
        dto.setFileName("system.ini");
        dto.setFileMd5("123");
        dto.setFilePath("C:\\Windows\\");
        
        
        new Expectations() {
            {
                licenseFileDAO.existsByFileName((String)any);
                result = false;
                licenseFileDAO.existsByFileMd5((String)any);
                result = false;
            }
        };

        new MockUp<File>() {
            @Mock
            public boolean exists() {
                return true;
            }

            @Mock
            public long length() {
                return 107382L;
            }
            
        };
        
        licenseFileMoveService.licenseFileValidation(dto);
        
        new Verifications() {
            {
                licenseFileDAO.existsByFileName((String)any);
                times = 1;
                licenseFileDAO.existsByFileMd5((String)any);
                times = 1;
            }
        };
    }
    
    /**
     * licenseFileValidation 文件不存在情况
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testLicenseFileValidation2() throws BusinessException {
        BaseLicenseFeatureDTO dto = new BaseLicenseFeatureDTO();
        dto.setFileName("system.ini");
        dto.setFileMd5("123");
        dto.setFilePath("C:\\Windows\\");

        new MockUp<File>() {
            @Mock
            public boolean exists() {
                return false;
            }            
        };
        
        try {
            licenseFileMoveService.licenseFileValidation(dto);
            fail();
        } catch (BusinessException e) {
            Assert.assertEquals(BusinessKey.BASE_SYS_MANAGE_LICENSE_FILE_NOT_EXIST, e.getKey());
        }
       
    }
    
    /**
     * licenseFileValidation 文件大小超过1M
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testLicenseFileValidation3() throws BusinessException {
        BaseLicenseFeatureDTO dto = new BaseLicenseFeatureDTO();
        dto.setFileName("system.ini");
        dto.setFileMd5("123");
        dto.setFilePath("C:\\Windows\\");

        new MockUp<File>() {
            @Mock
            public boolean exists() {
                return true;
            }  
            
            @Mock
            public long length() {
                return 1048577L;
            }
        };
        
        try {
            licenseFileMoveService.licenseFileValidation(dto);
            fail();
        } catch (BusinessException e) {
            Assert.assertEquals(BusinessKey.BASE_SYS_MANAGE_LICENSE_FILE_OVERSIZE, e.getKey());
        }
       
    }
    
    /**
     * licenseFileValidation 文件名在数据库中已存在
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testLicenseFileValidation4() throws BusinessException {
        BaseLicenseFeatureDTO dto = new BaseLicenseFeatureDTO();
        dto.setFileName("system.ini");
        dto.setFileMd5("123");
        dto.setFilePath("C:\\Windows\\");
        
        new Expectations() {
            {
                licenseFileDAO.existsByFileName((String)any);
                result = true;                
            }
        };

        new MockUp<File>() {
            @Mock
            public boolean exists() {
                return true;
            }
            
            @Mock
            public long length() {
                return 102L;
            }
        };
        
        try {
            licenseFileMoveService.licenseFileValidation(dto);
            fail();
        } catch (BusinessException e) {
            Assert.assertEquals(BusinessKey.BASE_SYS_MANAGE_LICENSE_FILE_EXIST, e.getKey());
        }
       
    }
    
    /**
     * licenseFileValidation 文件MD5在数据库中已存在
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testLicenseFileValidation5() throws BusinessException {
        BaseLicenseFeatureDTO dto = new BaseLicenseFeatureDTO();
        dto.setFileName("system.ini");
        dto.setFileMd5("123");
        dto.setFilePath("C:\\Windows\\");
        
        new Expectations() {
            {
                licenseFileDAO.existsByFileName((String)any);
                result = false; 
                licenseFileDAO.existsByFileMd5((String)any);
                result = true; 
            }
        };

        new MockUp<File>() {
            @Mock
            public boolean exists() {
                return true;
            }     
            
            @Mock
            public long length() {
                return 102L;
            }
        };
        
        try {
            licenseFileMoveService.licenseFileValidation(dto);
            fail();
        } catch (BusinessException e) {
            Assert.assertEquals(BusinessKey.BASE_SYS_MANAGE_LICENSE_FILE_EXIST, e.getKey());
        }
       
    }
    
    /**
     * 验证cutLicenseFile()方法入参
     * 
     * @throws Exception 异常
     */
    @Test
    public void testCutLicenseFileValidateParams() throws Exception {

        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseFileMoveService.licenseFileValidation(null), "BaseLicenseFeatureDTO 不能为空");
        
        BaseLicenseFeatureDTO licenseFeatureDTO = new BaseLicenseFeatureDTO();
        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseFileMoveService.licenseFileValidation(licenseFeatureDTO), "FileName 不能为空");
        licenseFeatureDTO.setFileName("123");
        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseFileMoveService.licenseFileValidation(licenseFeatureDTO), "FilePath 不能为空");

        assertTrue(true);
    }
    
    /**
     * licenseFileValidation 测试方法
     * 
     * @param files  
     * @throws BusinessException 异常
     */
    @Test
    public void testCutLicenseFile(@Mocked Files files) throws BusinessException {

        BaseLicenseFeatureDTO dto = new BaseLicenseFeatureDTO();
        dto.setFileName("system.ini");
        dto.setFileMd5("123");
        dto.setFilePath("C:\\Windows\\");
        
        String filePath = "c:\\";
        
        new Expectations() {
            {
                logger.isDebugEnabled();
                result = true;
                configFacade.read("file.busiz.dir.license");
                result = filePath;
            }
        };

        new MockUp<File>() {
            @Mock
            public long length() {
                return 107382L;
            }
            
        };
        
        new MockUp<Files>() {
            @Mock
            public void move(Path source, Path target) {
            }
        };
        
        licenseFileMoveService.cutLicenseFile(dto);
        
        assertTrue(true);
    }
    
    /**
     * licenseFileValidation 测试方法
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testCutLicenseFile2() throws BusinessException {

        BaseLicenseFeatureDTO dto = new BaseLicenseFeatureDTO();
        dto.setFileName("system.ini");
        dto.setFileMd5("123");
        dto.setFilePath("C:\\Windows\\");
        
        String filePath = "c:\\";
        
        new Expectations() {
            {
                logger.isDebugEnabled();
                result = true;
                configFacade.read("file.busiz.dir.license");
                result = filePath;
            }
        };

        new MockUp<File>() {
            @Mock
            public long length() {
                return 107382L;
            }
            
        };
        try {
            licenseFileMoveService.cutLicenseFile(dto);
            fail();
        } catch (BusinessException e) {
            Assert.assertEquals(BusinessKey.BASE_SYS_MANAGE_LICENSE_FILE_MOVE_ERROR, e.getKey());
        }
    }
    
    /**
     * licenseFileValidation 测试文件移动过程中，大小不一致
     * 
     * @param file  
     * @param files  
     * @throws BusinessException 异常
     */
    @Test
    public void testCutLicenseFile3(@Mocked File file, @Mocked Files files) throws BusinessException {

        BaseLicenseFeatureDTO dto = new BaseLicenseFeatureDTO();
        dto.setFileName("system.ini");
        dto.setFileMd5("123");
        dto.setFilePath("C:\\Windows\\");
        
        String filePath = "c:\\";
        
        new Expectations() {
            {
                logger.isDebugEnabled();
                result = true;
                configFacade.read("file.busiz.dir.license");
                result = filePath;
                
                file.length();
                returns(1073L, 10737L, 10737418L);
            }
        };
        try {
            licenseFileMoveService.cutLicenseFile(dto);
            fail();
        } catch (BusinessException e) {
            Assert.assertEquals(BusinessKey.BASE_SYS_MANAGE_LICENSE_FILE_SIZE_UNEQUAL, e.getKey());
        }
    }
    
    /**
     * 验证deleteFile()方法入参
     * 
     * @throws Exception 异常
     */
    @Test
    public void testDeleteFileValidateParams() throws Exception {

        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseFileMoveService.licenseFileValidation(null), "BaseLicenseFeatureDTO 不能为空");
        
        BaseLicenseFeatureDTO licenseFeatureDTO = new BaseLicenseFeatureDTO();
        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseFileMoveService.licenseFileValidation(licenseFeatureDTO), "FileName 不能为空");

        assertTrue(true);
    }
    
    /**
     * deleteFile 测试方法
     * 
     * @param files  
     * @throws BusinessException 异常
     */
    @Test
    public void testDeleteFile(@Mocked Files files) throws BusinessException {

        BaseLicenseFeatureDTO dto = new BaseLicenseFeatureDTO();
        dto.setFileName("system.ini");
        dto.setFileMd5("123");
        dto.setFilePath("C:\\Windows\\");
        
        String filePath = "c:\\";
        
        new Expectations() {
            {
                logger.isDebugEnabled();
                result = true;
                configFacade.read("file.busiz.dir.license");
                result = filePath;
            }
        };

        new MockUp<File>() {
            @Mock
            public boolean exists() {
                return true;
            }     
            
        };
        
        new MockUp<Files>() {
            @Mock
            public void delete(Path path) {
            }
        };
        try {
            licenseFileMoveService.deleteFile(dto);
            assertTrue(true);
        } catch (Exception e) {
            fail();
        }
    }
    
    /**
     * deleteFile 测试方法
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testDeleteFile2() throws BusinessException {

        BaseLicenseFeatureDTO dto = new BaseLicenseFeatureDTO();
        dto.setFileName("system.ini");
        dto.setFileMd5("123");
        dto.setFilePath("C:\\Windows\\");
        
        String filePath = "c:\\";
        
        new Expectations() {
            {
                logger.isDebugEnabled();
                result = true;
                configFacade.read("file.busiz.dir.license");
                result = filePath;
            }
        };

        new MockUp<File>() {
            @Mock
            public boolean exists() {
                return true;
            }     
            
        };
        try {
            licenseFileMoveService.deleteFile(dto);
            fail();
        } catch (BusinessException e) {
            assertEquals(BusinessKey.BASE_SYS_MANAGE_LICENSE_FILE_DELETE_ERROR, e.getKey());
            
        }
    }
}
