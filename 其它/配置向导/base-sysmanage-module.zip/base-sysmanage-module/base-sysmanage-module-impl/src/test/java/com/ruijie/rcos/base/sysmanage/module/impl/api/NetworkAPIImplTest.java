package com.ruijie.rcos.base.sysmanage.module.impl.api;

import org.junit.Test;
import org.junit.runner.RunWith;

import com.ruijie.rcos.base.sysmanage.module.def.api.request.network.BaseDetailNetworkRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.network.BaseUpdateNetworkRequest;
import com.ruijie.rcos.base.sysmanage.module.def.dto.BaseNetworkDTO;
import com.ruijie.rcos.base.sysmanage.module.impl.service.impl.NetworkServiceImpl;
import com.ruijie.rcos.sk.base.exception.BusinessException;

import mockit.Expectations;
import mockit.Injectable;
import mockit.Tested;
import mockit.Verifications;
import mockit.integration.junit4.JMockit;

/**
 * Description:
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月25日
 *
 * @author fyq
 */

@RunWith(JMockit.class)
public class NetworkAPIImplTest {

    @Tested
    private NetworkAPIImpl netWorkCardAPI;

    @Injectable
    private NetworkServiceImpl networkConfigService;

    /**
     * 网络详情
     * 
     * @param apiRequest api
     * @throws BusinessException 异常
     */
    @Test
    public void testDetailNetwork(@Tested BaseDetailNetworkRequest apiRequest) throws BusinessException {

        BaseNetworkDTO networkCardDTO = new BaseNetworkDTO();

        new Expectations() {
            {
                networkConfigService.detailNetwork();
                result = networkCardDTO;
            }
        };

        netWorkCardAPI.detailNetwork(apiRequest);

        new Verifications() {
            {
                networkConfigService.detailNetwork();
                times = 1;
            }
        };
    }

    /**
     * 更新网络
     * 
     * @param apiRequest api
     * @throws BusinessException 异常
     */
    @Test
    public void testUpdateNetwork(@Tested BaseUpdateNetworkRequest apiRequest) throws BusinessException {

        apiRequest.setIp("192.168.1.2");
        apiRequest.setNetmask("255.255.255.0");
        apiRequest.setGateway("192.168.1.1");
        apiRequest.setDns("114.114.114.114");

        new Expectations() {
            {
                networkConfigService.updateNetwork(apiRequest);
            }
        };

        netWorkCardAPI.updateNetwork(apiRequest);

        new Verifications() {
            {
                networkConfigService.updateNetwork(apiRequest);
                times = 1;
            }
        };
    }
}
