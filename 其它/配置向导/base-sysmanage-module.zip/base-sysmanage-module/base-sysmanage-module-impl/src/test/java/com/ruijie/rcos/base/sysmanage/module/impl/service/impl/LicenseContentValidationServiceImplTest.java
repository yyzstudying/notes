package com.ruijie.rcos.base.sysmanage.module.impl.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import com.ruijie.rcos.base.sysmanage.module.def.dto.license.BaseLicenseFeatureDTO;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureStatus;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureType;
import com.ruijie.rcos.base.sysmanage.module.def.enums.ValidateLicenseStatus;
import com.ruijie.rcos.base.sysmanage.module.def.spi.BaseLicenseFeatureResolveSPI;
import com.ruijie.rcos.base.sysmanage.module.def.spi.BaseLicenseFeatureValidateSPI;
import com.ruijie.rcos.base.sysmanage.module.def.spi.BaseLicenseSerialNumberSPI;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseGetLicenseSerianNumberRequest;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseLicenseFeatureResolveRequest;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseValidateLicenseRequest;
import com.ruijie.rcos.base.sysmanage.module.def.spi.response.BaseGetLicenseSerialNumberResponse;
import com.ruijie.rcos.base.sysmanage.module.def.spi.response.BaseLicenseFeatureResolveResponse;
import com.ruijie.rcos.base.sysmanage.module.def.spi.response.BaseValidateLicenseResponse;
import com.ruijie.rcos.base.sysmanage.module.impl.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.impl.dao.LicenseFileDAO;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.LicenseFileEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.license.client.LicenseService;
import com.ruijie.rcos.base.sysmanage.module.impl.license.enums.FeatureTypeEnum;
import com.ruijie.rcos.base.sysmanage.module.impl.license.enums.LicenseTypeEnum;
import com.ruijie.rcos.base.sysmanage.module.impl.license.vo.LicCheckResult;
import com.ruijie.rcos.base.sysmanage.module.impl.license.vo.LicenseFeature;
import com.ruijie.rcos.base.sysmanage.module.impl.license.vo.LicenseInfo;
import com.ruijie.rcos.base.sysmanage.module.impl.util.LicenseUtil;
import com.ruijie.rcos.sk.base.config.ConfigFacade;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.test.ThrowExceptionTester;
import mockit.Capturing;
import mockit.Expectations;
import mockit.Injectable;
import mockit.Mocked;
import mockit.Tested;
import mockit.Verifications;
import mockit.integration.junit4.JMockit;

/**
 * Description: license合法性校验实现，单元测试类
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月25日
 *
 * @author fyq
 */

@RunWith(JMockit.class)
public class LicenseContentValidationServiceImplTest {

    @Tested
    private LicenseContentValidationServiceImpl licenseContentValidationService;
    
    @Injectable
    private LicenseFileDAO licenseFileDAO;
    
    @Injectable
    private BaseLicenseFeatureResolveSPI licenseFeatureResolveSPI;
    
    @Injectable
    private BaseLicenseFeatureValidateSPI licenseFeatureValidateSPI;
    
    @Injectable
    private BaseLicenseSerialNumberSPI licenseSerialNumberSPI;
    
    @Injectable
    private ConfigFacade configFacade;
    
    @Capturing
    private Logger logger;
    
    /**
     * 验证licenseFileValidation()方法入参
     * 
     * @throws Exception 异常
     */
    @Test
    public void testLicenseFileValidationValidateParams() throws Exception {

        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseContentValidationService.licenseContentValidation(null), "BaseLicenseFeatureDTO 不能为空");
        
        BaseLicenseFeatureDTO licenseFeatureDTO = new BaseLicenseFeatureDTO();
        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseContentValidationService.licenseContentValidation(licenseFeatureDTO), "FileName 不能为空");
        licenseFeatureDTO.setFileName("123");
        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseContentValidationService.licenseContentValidation(licenseFeatureDTO), "FilePath 不能为空");
        licenseFeatureDTO.setFilePath("123");
        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseContentValidationService.licenseContentValidation(licenseFeatureDTO), "FileMd5 不能为空");

        assertTrue(true);
    }
    
    /**
     * licenseFileValidation 测试方法
     * 
     * @param ls 
     * @param licenseUtil  
     * @throws BusinessException 异常
     */
    @SuppressWarnings({"unchecked", "static-access"})
    @Test
    public void testLicenseFileValidation(@Mocked LicenseService ls, @Mocked LicenseUtil licenseUtil) throws BusinessException {

        BaseLicenseFeatureDTO dto = new BaseLicenseFeatureDTO();
        dto.setFileName("system.ini");
        dto.setFileMd5("123");
        dto.setFilePath("C:\\Windows\\");
        
        BaseGetLicenseSerialNumberResponse response = new BaseGetLicenseSerialNumberResponse();
        response.setSerialId("RCC-CM-NUM");
        
        LicCheckResult lr = new LicCheckResult();
        LicenseInfo lf = new LicenseInfo();
        List<LicenseFeature> featureList = new ArrayList<LicenseFeature>();
        LicenseFeature feature = new LicenseFeature();
        feature.setDuration(900000L);
        feature.setName("123");
        feature.setOn(true);
        feature.setType(FeatureTypeEnum.ONOFF);
        feature.setValue(70);
        featureList.add(feature);
        lf.setFeatureList(featureList);
        lf.setDevCode("-1");
        lf.setDevSn("G1MQ2TP000075");
        lf.setDuration(900000L);
        lf.setProductName("RCC-CM-NUM");
        lf.setType(LicenseTypeEnum.COMMERCIAL);
        lr.setLicInfo(lf);
        lr.setResult(0);
        
        BaseLicenseFeatureResolveResponse licenseFeatureResolveResponse = new BaseLicenseFeatureResolveResponse();
        licenseFeatureResolveResponse.setFeatureCode("RCC-CM-NUM");
        licenseFeatureResolveResponse.setFeatureType(BaseFeatureType.TEMPORARY);
        
        List<LicenseFileEntity> licenseFileEntityList = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            LicenseFileEntity entity = new LicenseFileEntity();
            entity.setFeatureCode("RCC-CM-NUM");
            entity.setFeatureType(BaseFeatureType.TEMPORARY);
            entity.setFeatureStatus(BaseFeatureStatus.AVALIABLE);
            entity.setTrialDuration(19600000L);
            entity.setTrialRemainder(800000L);
            entity.setFileMd5("123");
            entity.setFileName("123");
            licenseFileEntityList.add(entity);
        }
        
        BaseValidateLicenseResponse validateLicenseResponse = new BaseValidateLicenseResponse();
        validateLicenseResponse.setLicenseStatus(ValidateLicenseStatus.OK);
        
        new Expectations() {
            {
                logger.isDebugEnabled();
                result = true;
                licenseSerialNumberSPI.getLicenseSerialNumber((BaseGetLicenseSerianNumberRequest)any);
                result = response;
                
                licenseUtil.isTempLicense((LicenseInfo)any);
                result = true;
                ls.check((File)any, (String)any);
                result = lr;
                licenseFeatureResolveSPI.getLicenseFeatureCode((BaseLicenseFeatureResolveRequest)any);
                result = licenseFeatureResolveResponse;
                licenseFileDAO.findByFeatureTypeAndFeatureCodeOrderByCreateTime((BaseFeatureType)any, (String)any);
                result = null;
                licenseFileDAO.findByFeatureCode((String)any);
                result = licenseFileEntityList;
                
                licenseFeatureValidateSPI.checkLicenseViolation((BaseValidateLicenseRequest)any);
                result = validateLicenseResponse;
            }
        };

        LicenseInfo licenseInfo = licenseContentValidationService.licenseContentValidation(dto);

        Assert.assertEquals(response.getSerialId(), dto.getFeatureCode());
        Assert.assertEquals(response.getSerialId(), licenseInfo.getProductName());
        Assert.assertEquals(licenseInfo.getProductName(), dto.getFeatureCode());
        
        new Verifications() {
            {

                licenseSerialNumberSPI.getLicenseSerialNumber((BaseGetLicenseSerianNumberRequest)any);
                times = 1;
                licenseUtil.isTempLicense((LicenseInfo)any);
                times = 1;
                licenseFeatureResolveSPI.getLicenseFeatureCode((BaseLicenseFeatureResolveRequest)any);
                times = 1;
                licenseFileDAO.findByFeatureTypeAndFeatureCodeOrderByCreateTime((BaseFeatureType)any, (String)any);
                times = 1;
                licenseFileDAO.findByFeatureCode((String)any);
                times = 1;
                licenseUtil.createBaseValidateLicenseRequest((List<LicenseFileEntity>)any, (LicenseInfo)any, (BaseLicenseFeatureDTO)any);
                times = 1;
                licenseFeatureValidateSPI.checkLicenseViolation((BaseValidateLicenseRequest)any);
                times = 1;
            }
        };
    }
    
    /**
     * licenseFileValidation 测试方法
     * 
     * @param ls 
     * @param licenseUtil  
     * @throws BusinessException 异常
     */
    @SuppressWarnings({"static-access"})
    @Test
    public void testLicenseFileValidation2(@Mocked LicenseService ls, @Mocked LicenseUtil licenseUtil) throws BusinessException {

        BaseLicenseFeatureDTO dto = new BaseLicenseFeatureDTO();
        dto.setFileName("system.ini");
        dto.setFileMd5("123");
        dto.setFilePath("C:\\Windows\\");
        
        BaseGetLicenseSerialNumberResponse response = new BaseGetLicenseSerialNumberResponse();
        response.setSerialId("RCC-CM-NUM");
        
        LicCheckResult lr = new LicCheckResult();
        LicenseInfo lf = new LicenseInfo();
        List<LicenseFeature> featureList = new ArrayList<LicenseFeature>();
        LicenseFeature feature = new LicenseFeature();
        feature.setDuration(0L);
        feature.setName("123");
        feature.setOn(true);
        feature.setType(FeatureTypeEnum.ONOFF);
        feature.setValue(70);
        featureList.add(feature);
        lf.setFeatureList(featureList);
        lf.setDevCode("-1");
        lf.setDevSn("G1MQ2TP000075");
        lf.setDuration(900000L);
        lf.setProductName("RCC-CM-NUM");
        lf.setType(LicenseTypeEnum.COMMERCIAL);
        lr.setLicInfo(lf);
        lr.setResult(0);
        
        BaseLicenseFeatureResolveResponse licenseFeatureResolveResponse = new BaseLicenseFeatureResolveResponse();
        licenseFeatureResolveResponse.setFeatureCode("RCC-CM-NUM");
        licenseFeatureResolveResponse.setFeatureType(BaseFeatureType.TEMPORARY);
        
        List<LicenseFileEntity> licenseFileEntityList = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            LicenseFileEntity entity = new LicenseFileEntity();
            entity.setFeatureCode("RCC-CM-NUM");
            entity.setFeatureType(BaseFeatureType.TEMPORARY);
            entity.setFeatureStatus(BaseFeatureStatus.AVALIABLE);
            entity.setTrialDuration(19600000L);
            entity.setTrialRemainder(800000L);
            entity.setFileMd5("123");
            entity.setFileName("123");
            licenseFileEntityList.add(entity);
        }
        
        BaseValidateLicenseResponse validateLicenseResponse = new BaseValidateLicenseResponse();
        validateLicenseResponse.setLicenseStatus(ValidateLicenseStatus.ERROR);
        validateLicenseResponse.setMessageKey("abc123");
        
        new Expectations() {
            {
                logger.isDebugEnabled();
                result = true;
                licenseSerialNumberSPI.getLicenseSerialNumber((BaseGetLicenseSerianNumberRequest)any);
                result = response;
                licenseUtil.isTempLicense((LicenseInfo)any);
                result = false;
                ls.check((File)any, (String)any);
                result = lr;
                licenseFeatureResolveSPI.getLicenseFeatureCode((BaseLicenseFeatureResolveRequest)any);
                result = licenseFeatureResolveResponse;
                licenseFileDAO.findByFeatureCode((String)any);
                result = licenseFileEntityList;
                
                licenseFeatureValidateSPI.checkLicenseViolation((BaseValidateLicenseRequest)any);
                result = validateLicenseResponse;
            }
        };

        try {
            licenseContentValidationService.licenseContentValidation(dto);
            fail();
        } catch (BusinessException e) {
            assertEquals(e.getKey(), "abc123");
        }
       
    }
    
    /**
     * licenseFileValidation 测试方法
     * 
     * @param ls 
     * @param licenseUtil  
     * @throws BusinessException 异常
     */
    @SuppressWarnings({"static-access"})
    @Test
    public void testLicenseFileValidation3(@Mocked LicenseService ls, @Mocked LicenseUtil licenseUtil) throws BusinessException {

        BaseLicenseFeatureDTO dto = new BaseLicenseFeatureDTO();
        dto.setFileName("system.ini");
        dto.setFileMd5("123");
        dto.setFilePath("C:\\Windows\\");
        
        BaseGetLicenseSerialNumberResponse response = new BaseGetLicenseSerialNumberResponse();
        response.setSerialId("RCC-CM-NUM");
        
        LicCheckResult lr = new LicCheckResult();
        LicenseInfo lf = new LicenseInfo();
        List<LicenseFeature> featureList = new ArrayList<LicenseFeature>();
        LicenseFeature feature = new LicenseFeature();
        feature.setDuration(900000L);
        feature.setName("123");
        feature.setOn(true);
        feature.setType(FeatureTypeEnum.ONOFF);
        feature.setValue(70);
        featureList.add(feature);
        lf.setFeatureList(featureList);
        lf.setDevCode("-1");
        lf.setDevSn("G1MQ2TP000075");
        lf.setDuration(900000L);
        lf.setProductName("RCC-CM-NUM");
        lf.setType(LicenseTypeEnum.COMMERCIAL);
        lr.setLicInfo(lf);
        lr.setResult(0);
        
        BaseLicenseFeatureResolveResponse licenseFeatureResolveResponse = new BaseLicenseFeatureResolveResponse();
        licenseFeatureResolveResponse.setFeatureCode("RCC-CM-NUM");
        licenseFeatureResolveResponse.setFeatureType(BaseFeatureType.TEMPORARY);
        
        List<LicenseFileEntity> licenseFileEntityList = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            LicenseFileEntity entity = new LicenseFileEntity();
            entity.setFeatureCode("RCC-CM-NUM");
            entity.setFeatureType(BaseFeatureType.TEMPORARY);
            entity.setFeatureStatus(BaseFeatureStatus.AVALIABLE);
            entity.setTrialDuration(19600000L);
            entity.setTrialRemainder(800000L);
            entity.setFileMd5("123");
            entity.setFileName("123");
            licenseFileEntityList.add(entity);
        }
        
        BaseValidateLicenseResponse validateLicenseResponse = new BaseValidateLicenseResponse();
        validateLicenseResponse.setLicenseStatus(ValidateLicenseStatus.OK);
        
        new Expectations() {
            {
                logger.isDebugEnabled();
                result = true;
                licenseSerialNumberSPI.getLicenseSerialNumber((BaseGetLicenseSerianNumberRequest)any);
                result = response;
                
                licenseUtil.isTempLicense((LicenseInfo)any);
                result = true;
                ls.check((File)any, (String)any);
                result = lr;
                licenseFeatureResolveSPI.getLicenseFeatureCode((BaseLicenseFeatureResolveRequest)any);
                result = licenseFeatureResolveResponse;
                licenseFileDAO.findByFeatureTypeAndFeatureCodeOrderByCreateTime((BaseFeatureType)any, (String)any);
                result = licenseFileEntityList;
            }
        };

        try {
            licenseContentValidationService.licenseContentValidation(dto);
            fail();
        } catch (BusinessException e) {
            assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_LICENSE_TYPE_CHANGE_ERROR);
        }
        

    }
        
    /**
     * 验证resolverLicenseFile()方法入参
     * 
     * @throws Exception 异常
     */
    @Test
    public void testResolverLicenseFileValidateParams() throws Exception {

        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseContentValidationService.licenseContentValidation(null), "BaseLicenseFeatureDTO 不能为空");

        assertTrue(true);
    }
    
    /**
     * 验证resolverLicenseFile()方法
     * 
     * @param ls 
     * @throws Exception 异常
     */
    @Test
    public void testResolverLicenseFile(@Mocked LicenseService ls) throws Exception {

        Date date = new Date();
        BaseLicenseFeatureDTO dto = new BaseLicenseFeatureDTO();
        dto.setFileName("system.ini");
        dto.setFileMd5("123");
        dto.setFilePath("C:\\Windows\\");
        
        BaseGetLicenseSerialNumberResponse response = new BaseGetLicenseSerialNumberResponse();
        response.setSerialId("RCC-CM-NUM");
        
        LicCheckResult lr = new LicCheckResult();
        LicenseInfo lf = new LicenseInfo();
        List<LicenseFeature> featureList = new ArrayList<LicenseFeature>();
        LicenseFeature feature = new LicenseFeature();
        feature.setDuration(900000L);
        feature.setName("123");
        feature.setOn(true);
        feature.setType(FeatureTypeEnum.ONOFF);
        feature.setValue(70);
        feature.setStartTime(date);
        featureList.add(feature);
        lf.setFeatureList(featureList);
        lf.setDevCode("-1");
        lf.setDevSn("G1MQ2TP000075");
        lf.setDuration(900000L);
        lf.setProductName("RCC-CM-NUM-70");
        lf.setType(LicenseTypeEnum.COMMERCIAL);
        lf.setStartTime(date);
        lr.setLicInfo(lf);
        lr.setResult(0);

        String filePath = "/data/web/rcdc/lic/";

        new Expectations() {
            {
                logger.isDebugEnabled();
                result = true;
                configFacade.read("file.busiz.dir.license");
                result = filePath;
                ls.check((File)any, (String)any);
                result = lr;
                licenseSerialNumberSPI.getLicenseSerialNumber((BaseGetLicenseSerianNumberRequest)any);
                result = response;
                
                
            }
        };

        LicenseInfo licenseInfo = licenseContentValidationService.licenseContentValidation(dto);
        
        Assert.assertEquals(licenseInfo.getProductName(), lf.getProductName());
        Assert.assertEquals(licenseInfo.getDevCode(), lf.getDevCode());
        Assert.assertEquals(licenseInfo.getDevSn(), lf.getDevSn());
        Assert.assertEquals(licenseInfo.getDuration(), lf.getDuration());
        Assert.assertEquals(licenseInfo.getStartTime(), lf.getStartTime());
        for (LicenseFeature featureDTO : licenseInfo.getFeatureList()) {
            Assert.assertEquals(featureDTO.getDuration(), feature.getDuration());
            Assert.assertEquals(featureDTO.getName(), feature.getName());
            Assert.assertEquals(featureDTO.getValue(), feature.getValue());
            Assert.assertEquals(featureDTO.getStartTime(), feature.getStartTime());
        }
        
        new Verifications() {
            {

                configFacade.read("file.busiz.dir.license");
                times = 1;
                ls.check((File)any, (String)any);
                times = 1;
                licenseSerialNumberSPI.getLicenseSerialNumber((BaseGetLicenseSerianNumberRequest)any);
                times = 1;
            }
        };
    }
    
    /**
     * 验证resolverLicenseFile()方法
     * 
     * @param ls 
     * @throws Exception 异常
     */
    @Test
    public void testResolverLicenseFile2(@Mocked LicenseService ls) throws Exception {

        BaseLicenseFeatureDTO dto = new BaseLicenseFeatureDTO();
        dto.setFileName("system.ini");
        dto.setFileMd5("123");
        dto.setFilePath("C:\\Windows\\");
        
        BaseGetLicenseSerialNumberResponse response = new BaseGetLicenseSerialNumberResponse();
        response.setSerialId("RCC-CM-NUM");
        
        LicCheckResult lr = new LicCheckResult();
        LicenseInfo lf = new LicenseInfo();
        lr.setLicInfo(lf);
        lr.setResult(1);
        
        String filePath = "/data/web/rcdc/lic/";

        new Expectations() {
            {
                logger.isDebugEnabled();
                result = true;
                configFacade.read("file.busiz.dir.license");
                result = filePath;
                ls.check((File)any, (String)any);
                result = lr;
                licenseSerialNumberSPI.getLicenseSerialNumber((BaseGetLicenseSerianNumberRequest)any);
                result = response;                              
            }
        };

        try {
            licenseContentValidationService.licenseContentValidation(dto);
            fail();
        } catch (BusinessException e) {
            Assert.assertEquals(BusinessKey.BASE_SYS_MANAGE_LICENSE_FILE_RESOLVE_ERROR, e.getKey());
        }
      
    }
}
