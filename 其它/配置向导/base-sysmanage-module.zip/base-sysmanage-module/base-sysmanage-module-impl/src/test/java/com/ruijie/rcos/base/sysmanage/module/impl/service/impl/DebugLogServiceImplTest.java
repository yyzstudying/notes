package com.ruijie.rcos.base.sysmanage.module.impl.service.impl;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;

import com.ruijie.rcos.sk.base.i18n.LocaleI18nResolver;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.ruijie.rcos.base.sysmanage.module.def.api.request.debuglog.BaseListDebugLogRequest;
import com.ruijie.rcos.base.sysmanage.module.impl.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.impl.common.Constants;
import com.ruijie.rcos.base.sysmanage.module.impl.dao.DebugLogDAO;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.DebugLogEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.service.query.DebugLogSpecification;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.filesystem.SkyengineFile;
import com.ruijie.rcos.sk.base.shell.ShellCommandRunner;
import com.ruijie.rcos.sk.base.test.GetSetTester;
import com.ruijie.rcos.sk.modulekit.api.tool.GlobalParameterAPI;

import mockit.*;
import mockit.integration.junit4.JMockit;

/**
 * Description: 调试日志服务实现类
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月25日
 *
 * @author fyq
 */

@RunWith(JMockit.class)
public class DebugLogServiceImplTest {

    @Tested
    private DebugLogServiceImpl debugLogService;

    @Injectable
    private DebugLogDAO debugLogDAO;

    @Injectable
    private GlobalParameterAPI globalParameterAPI;

    @Mocked
    private ShellCommandRunner runner;

    /**
     * 测试试题get与set
     */
    @Test
    public void testEntityGetSet() {
        GetSetTester getSetTester = new GetSetTester(DebugLogEntity.class);
        getSetTester.runTest();

        Assert.assertTrue(true);
    }

    /**
     * 创建log
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testCreateDebugLog() throws BusinessException {

        String fileName = "log.zip";

        new Expectations(LocaleI18nResolver.class) {
            {
                LocaleI18nResolver.resolve(anyString);
                result = "xxx";
                runner.execute();
                result = fileName;
                debugLogDAO.save((DebugLogEntity) any);
                result = null;
            }
        };

        debugLogService.createDebugLog();

        new Verifications() {
            {
                runner.setCommand(Constants.SH_LOG_COLLECT);
                times = 1;
                runner.execute();
                times = 1;
                debugLogDAO.save((DebugLogEntity) any);
                times = 1;
            }
        };
    }

    /**
     * 删除log
     * 
     * @param skyengineFile sky文件
     * @throws BusinessException 异常
     */
    @Test
    public void testDeleteDebugLog(@Mocked SkyengineFile skyengineFile) throws BusinessException {

        UUID id = UUID.randomUUID();

        DebugLogEntity entity = new DebugLogEntity();
        entity.setId(id);
        entity.setRealFileName("backup.zip");

        new Expectations(Files.class) {
            {
                debugLogDAO.getOne(id);
                result = entity;
                debugLogDAO.delete(entity);
                result = null;
                globalParameterAPI.findParameter(anyString);
                result = "/data/web/log";
                skyengineFile.delete(false);
                result = true;
            }
        };

        debugLogService.deleteDebugLog(id);

        new Verifications() {
            {
                skyengineFile.delete(false);
                times = 1;
            }
        };
    }

    /**
     * 删除
     */
    @Test
    public void testDeleteDebugLogEntityNull() {

        UUID id = UUID.randomUUID();

        new Expectations() {
            {
                debugLogDAO.getOne(id);
                result = null;
            }
        };

        try {
            debugLogService.deleteDebugLog(id);
            Assert.fail();
        } catch (BusinessException e) {
            Assert.assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_DEBUG_LOG_NOT_EXITS);
        }
    }

    /**
     * 删除失败
     * 
     * @param skyengineFile sky文件
     * @throws BusinessException 异常
     */
    @Test
    public void testDeleteBackupDeleteFileFail(@Mocked SkyengineFile skyengineFile) throws BusinessException {

        UUID id = UUID.randomUUID();

        DebugLogEntity entity = new DebugLogEntity();
        entity.setId(id);
        entity.setRealFileName("backup.zip");

        new Expectations() {
            {
                debugLogDAO.getOne(id);
                result = entity;
                debugLogDAO.delete(entity);
                result = null;
                globalParameterAPI.findParameter(anyString);
                result = "/data/web/log";
                skyengineFile.delete(false);
                result = false;
            }
        };
        debugLogService.deleteDebugLog(id);
        new Verifications() {
            {
                skyengineFile.delete(false);
                times = 1;
            }
        };
    }

    /**
     * 获取日志
     */
    @Test
    public void testGetDebugLog() {

        UUID id = UUID.randomUUID();

        new Expectations() {
            {
                debugLogDAO.getOne(id);
            }
        };

        debugLogService.detailDebugLog(id);

        new Verifications() {
            {
                debugLogDAO.getOne(id);
                times = 1;
            }
        };
    }

    /**
     * 获取日志列表
     * 
     * @param request 请求
     * @param debugLogEntityPage 实体
     */
    @Test
    public void testListDebugLog(@Tested BaseListDebugLogRequest request, @Tested Page<DebugLogEntity> debugLogEntityPage) {

        new Expectations() {
            {
                debugLogDAO.findAll((DebugLogSpecification) any, (Pageable) any);
                result = debugLogEntityPage;
            }
        };

        Page<DebugLogEntity> result = debugLogService.listDebugLog(request);

        Assert.assertEquals(result, debugLogEntityPage);
    }
}
