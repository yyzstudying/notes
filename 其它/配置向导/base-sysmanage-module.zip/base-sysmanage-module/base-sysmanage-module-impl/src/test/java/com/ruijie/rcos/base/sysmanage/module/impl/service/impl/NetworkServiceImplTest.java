package com.ruijie.rcos.base.sysmanage.module.impl.service.impl;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ScheduledFuture;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.alibaba.fastjson.JSON;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.network.BaseUpdateNetworkRequest;
import com.ruijie.rcos.base.sysmanage.module.def.dto.BaseNetworkDTO;
import com.ruijie.rcos.base.sysmanage.module.def.spi.BaseNetworkChangeAfterSPI;
import com.ruijie.rcos.base.sysmanage.module.def.spi.BaseNetworkChangeBeforeSPI;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseNetworkChangeAfterRequest;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseNetworkChangeBeforeRequest;
import com.ruijie.rcos.base.sysmanage.module.impl.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.impl.common.Constants;
import com.ruijie.rcos.sk.base.concorrent.SkyengineExecutors;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.shell.ShellCommandRunner;
import com.ruijie.rcos.sk.modulekit.api.comm.ModuleCommExpertAPI;

import mockit.*;
import mockit.integration.junit4.JMockit;

/**
 * Description: 网卡服务实现类
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月25日
 *
 * @author fyq
 */

@RunWith(JMockit.class)
public class NetworkServiceImplTest {

    @Tested
    private NetworkServiceImpl networkConfigService;

    @Injectable
    private BaseNetworkChangeBeforeSPI networkChangeBeforeSPI;

    @Injectable
    private BaseNetworkChangeAfterSPI networkChangeAfterSPI;

    @Injectable
    private ModuleCommExpertAPI moduleCommExpertAPI;

    @Mocked
    private ShellCommandRunner runner;

    /**
     * 获取网络初始化
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testGetNetworkInfo() throws BusinessException {

        BaseNetworkDTO networkDTO = new BaseNetworkDTO();
        networkDTO.setName("eth0");
        networkDTO.setIp("192.168.1.1");
        networkDTO.setNetmask("255.255.255.0");
        networkDTO.setGateway("192.168.1.1");
        networkDTO.setDns("8.8.8.8");
        networkDTO.setMac("11:22:33:44:55");
        networkDTO.setState("UP");

        new Expectations() {
            {
                runner.setCommand(Constants.SH_IP_INFO);
                times = 1;
                runner.execute();
                result = JSON.toJSONString(networkDTO);
            }
        };

        BaseNetworkDTO networkCardDTO = networkConfigService.detailNetwork();

        Assert.assertEquals(networkCardDTO.getName(), "eth0");
        Assert.assertEquals(networkCardDTO.getIp(), "192.168.1.1");
    }

    /**
     * 测试获取网络信息失败解析结果
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testGetNetworkInfoFailParseResult() throws BusinessException {

        String networkInfo = "{bad json}";

        new Expectations() {
            {
                runner.execute();
                result = networkInfo;
            }
        };

        try {
            networkConfigService.detailNetwork();
            Assert.fail();
        } catch (IllegalStateException e) {
            Assert.assertEquals(e.getMessage(), "解析网卡配置失败：" + networkInfo);
        }
    }


    /**
     * 更新网络
     * 
     * @param apiRequest api
     * @param skyengineExecutors sky
     * @throws Exception 异常
     */
    @Test
    public void testUpdateNetwork(@Tested BaseUpdateNetworkRequest apiRequest, @Mocked SkyengineExecutors skyengineExecutors) throws Exception {

        BaseNetworkDTO networkDTO = new BaseNetworkDTO();
        networkDTO.setName("eth0");
        networkDTO.setIp("192.168.1.1");
        networkDTO.setNetmask("255.255.255.0");
        networkDTO.setGateway("192.168.1.1");
        networkDTO.setDns("8.8.8.8");
        networkDTO.setMac("11:22:33:44:55");
        networkDTO.setState("UP");

        apiRequest.setIp("192.168.1.2");
        apiRequest.setNetmask("255.255.255.0");
        apiRequest.setGateway("192.168.1.1");
        apiRequest.setDns("8.8.8.8");

        Collection<String> beforeSpiKeyList = Arrays.asList("1", "2");

        new Expectations() {
            {
                runner.execute();
                returns(JSON.toJSONString(networkDTO), "");
                moduleCommExpertAPI.loadDispatcherKeys(BaseNetworkChangeBeforeSPI.class);
                result = beforeSpiKeyList;
            }
        };

        networkConfigService.updateNetwork(apiRequest);

        new Verifications() {
            {
                runner.setCommand(Constants.SH_IP_CONFIG);
                times = 1;
                runner.execute();
                times = 2;
                networkChangeBeforeSPI.beforeNetworkChange((BaseNetworkChangeBeforeRequest) any);
                times = 2;
                networkChangeAfterSPI.afterNetworkChange((BaseNetworkChangeAfterRequest) any);
                times = 1;
            }
        };
    }

    /**
     * 更新网络无变化 if条件1
     * 
     * @param apiRequest api
     * @param logger 日志
     * @throws BusinessException 异常
     */
    @Test
    public void testUpdateNetworkNoChange(@Tested BaseUpdateNetworkRequest apiRequest, @Capturing Logger logger) throws BusinessException {

        BaseNetworkDTO networkDTO = new BaseNetworkDTO();
        networkDTO.setName("eth0");
        networkDTO.setIp("192.168.1.1");
        networkDTO.setNetmask("255.255.255.0");
        networkDTO.setGateway("192.168.1.1");
        networkDTO.setDns("8.8.8.8");
        networkDTO.setMac("11:22:33:44:55");
        networkDTO.setState("UP");

        apiRequest.setIp("192.168.1.1");
        apiRequest.setNetmask("255.255.255.0");
        apiRequest.setDns("8.8.8.8");
        apiRequest.setGateway("192.168.1.1");

        new Expectations() {
            {
                runner.execute();
                returns(JSON.toJSONString(networkDTO), "");
            }
        };


        networkConfigService.updateNetwork(apiRequest);

        new Verifications() {
            {
                logger.error("【网卡配置服务】 修改网卡配置失败-未修改配置 原配置{}，新配置{}", any, any);
                times = 1;
            }
        };

    }



    /**
     * 更新网络失败
     * 
     * @param apiRequest api
     * @throws BusinessException 异常
     */
    @Test
    public void testUpdateNetworkBeforeSPIFail(@Tested BaseUpdateNetworkRequest apiRequest) throws BusinessException {

        BaseNetworkDTO networkDTO = new BaseNetworkDTO();
        networkDTO.setName("eth0");
        networkDTO.setIp("192.168.1.1");
        networkDTO.setNetmask("255.255.255.0");
        networkDTO.setGateway("192.168.1.1");
        networkDTO.setDns("8.8.8.8");
        networkDTO.setMac("11:22:33:44:55");
        networkDTO.setState("UP");

        apiRequest.setIp("192.168.1.2");
        apiRequest.setNetmask("255.255.255.0");
        apiRequest.setGateway("192.168.1.1");
        apiRequest.setDns("8.8.8.8");

        new Expectations() {
            {
                runner.execute();
                result = JSON.toJSONString(networkDTO);
            }
        };

        Collection<String> beforeSpiKeyList = Arrays.asList("1", "2");

        new Expectations() {
            {
                moduleCommExpertAPI.loadDispatcherKeys(BaseNetworkChangeBeforeSPI.class);
                result = beforeSpiKeyList;
                networkChangeBeforeSPI.beforeNetworkChange((BaseNetworkChangeBeforeRequest) any);
                result = new BusinessException(BusinessKey.BASE_SYS_MANAGE_UPDATE_SYSTEM_TIME_UNREACHABLE_NTP);
            }
        };

        try {
            networkConfigService.updateNetwork(apiRequest);
            Assert.fail();
        } catch (BusinessException e) {
            Assert.assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_UPDATE_SYSTEM_TIME_UNREACHABLE_NTP);
        }
    }



    /**
     * 更新网络故障Shell
     *
     * @param apiRequest api
     * @throws BusinessException 异常
     */
    @Test
    public void testUpdateNetworkFailShell(@Tested BaseUpdateNetworkRequest apiRequest) throws BusinessException {

        new Expectations() {
            {
                runner.execute();
                result = new BusinessException(BusinessKey.BASE_SYS_MANAGE_EXEC_COMMAND_ERROR);
            }
        };

        try {
            networkConfigService.updateNetwork(apiRequest);
            Assert.fail();
        } catch (BusinessException e) {
            Assert.assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_EXEC_COMMAND_ERROR);
        }
    }

    /**
     * 重新启动更新网络
     * 
     * @param apiRequest api
     * @throws Exception 异常
     */
    @Test
    public void testUpdateNetworkWithRestart(@Tested BaseUpdateNetworkRequest apiRequest) throws Exception {

        BaseNetworkDTO networkDTO = new BaseNetworkDTO();
        networkDTO.setName("eth0");
        networkDTO.setIp("192.168.1.1");
        networkDTO.setNetmask("255.255.255.0");
        networkDTO.setGateway("192.168.1.1");
        networkDTO.setDns("8.8.8.8");
        networkDTO.setMac("11:22:33:44:55");
        networkDTO.setState("UP");

        apiRequest.setIp("192.168.1.2");
        apiRequest.setNetmask("255.255.255.0");
        apiRequest.setGateway("192.168.1.1");
        apiRequest.setDns("8.8.8.8");

        new Expectations() {
            {
                runner.execute();
                result = JSON.toJSONString(networkDTO);
            }
        };

        new MockUp<SkyengineExecutors>() {
            @Mock
            protected ScheduledFuture<?> schedule(Runnable command, long delay, String threadName) {
                command.run();
                // mock了 不用返回什么
                return null;
            }
        };

        networkConfigService.updateNetwork(apiRequest);

        new Verifications() {
            {
                runner.setCommand(Constants.SH_RESTART_NETWORK);
                times = 1;
            }
        };
    }


    /**
     * 更新网络重启失败
     * 
     * @param apiRequest api
     * @param logger 日志
     * @throws Exception 异常
     */
    @Test
    public void testUpdateNetworkWithRestartFail(@Tested BaseUpdateNetworkRequest apiRequest, @Capturing Logger logger) throws Exception {

        BaseNetworkDTO networkDTO = new BaseNetworkDTO();
        networkDTO.setName("eth0");
        networkDTO.setIp("192.168.1.1");
        networkDTO.setNetmask("255.255.255.0");
        networkDTO.setGateway("192.168.1.1");
        networkDTO.setDns("8.8.8.8");
        networkDTO.setMac("11:22:33:44:55");
        networkDTO.setState("UP");

        apiRequest.setIp("192.168.1.2");
        apiRequest.setNetmask("255.255.255.0");
        apiRequest.setGateway("192.168.1.1");
        apiRequest.setDns("8.8.8.8");

        new MockUp<ShellCommandRunner>() {

            private int times = 0;
            private int rebootIndex = 3;

            @Mock
            public String execute() {
                times++;
                if (times == rebootIndex) {
                    throw new RuntimeException();
                } else {
                    return JSON.toJSONString(networkDTO);
                }
            }
        };

        new MockUp<SkyengineExecutors>() {
            @Mock
            protected ScheduledFuture<?> schedule(Runnable command, long delay, String threadName) {
                command.run();
                // mock了 不用返回什么
                return null;
            }
        };

        networkConfigService.updateNetwork(apiRequest);

        new Verifications() {
            {
                logger.error("重启网卡服务失败", (Exception) any);
                times = 1;
            }
        };
    }
}
