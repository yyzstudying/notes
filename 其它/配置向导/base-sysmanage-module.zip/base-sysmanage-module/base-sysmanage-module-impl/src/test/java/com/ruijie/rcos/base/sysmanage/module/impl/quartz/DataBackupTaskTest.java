package com.ruijie.rcos.base.sysmanage.module.impl.quartz;

import static com.ruijie.rcos.base.sysmanage.module.impl.common.Constants.GLOBAL_PARAM_DB_BACKUP_PATH;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;

import com.ruijie.rcos.base.sysmanage.module.impl.common.Constants;
import com.ruijie.rcos.base.sysmanage.module.impl.dao.DataBackupDAO;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.DataBackupEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.service.DataBackupService;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.filesystem.SkyengineFile;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.modulekit.api.tool.GlobalParameterAPI;

import mockit.*;
import mockit.integration.junit4.JMockit;

/**
 * Description: 数据库定时任务测试
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月25日
 *
 * @author fyq
 */
@RunWith(JMockit.class)
public class DataBackupTaskTest {

    @Tested
    private DataBackupTask dataBackupTask;

    @Injectable
    private DataBackupService dataBackupService;

    @Injectable
    private GlobalParameterAPI globalParameterAPI;

    @Injectable
    private DataBackupDAO dataBackupDAO;

    /**
     * 测试execute方法当目录不存在时
     *
     * @throws BusinessException 异常
     */
    @Test
    public void testExecuteWhileDirectoryNotExist(@Mocked DataBackupEntity dataBackupEntity, @Capturing Logger logger) throws BusinessException {
        List<DataBackupEntity> dataBackupEntityList = new ArrayList<>();
        dataBackupEntityList.add(dataBackupEntity);
        File[] fileArr = new File[] {};
        commonMock(fileArr, false);

        new Expectations() {
            {
                globalParameterAPI.findParameter(GLOBAL_PARAM_DB_BACKUP_PATH);
                result = "";
                dataBackupService.listExpireDataBackup((Date) any, true);
                result = dataBackupEntityList;
            }
        };
        dataBackupTask.execute();
        new Verifications() {
            {
                dataBackupService.createDataBackup(true);
                times = 1;
                dataBackupService.deleteDataBackup(dataBackupEntity.getId());
                times = 1;
                logger.info("数据库备份目录不存在：{}", "");
                times = 1;
            }
        };
    }

    /**
     * 测试execute方法当目录不包含备份文件时
     *
     * @throws BusinessException 异常
     */
    @Test
    public void testExecuteWhileDirectoryHasNoBakFile(@Mocked DataBackupEntity dataBackupEntity, @Capturing Logger logger) throws BusinessException {
        List<DataBackupEntity> dataBackupEntityList = new ArrayList<>();
        dataBackupEntityList.add(dataBackupEntity);
        File[] fileArr = new File[] {};
        commonMock(fileArr, true);
        new Expectations() {
            {
                globalParameterAPI.findParameter(GLOBAL_PARAM_DB_BACKUP_PATH);
                result = "";
                dataBackupService.listExpireDataBackup((Date) any, true);
                result = dataBackupEntityList;
            }
        };
        dataBackupTask.execute();
        new Verifications() {
            {
                dataBackupService.createDataBackup(true);
                times = 1;
                dataBackupService.deleteDataBackup(dataBackupEntity.getId());
                times = 1;
                logger.info("不存在备份的数据库文件");
                times = 1;
            }
        };
    }

    /**
     * 测试execute方法当数据库没记录时
     * 
     * @param dataBackupEntity 数据库备份实体
     * @param skyengineFile 文件对象
     * @throws BusinessException 异常
     */
    @Test
    public void testExecuteWhileDbHasNoRecord(@Mocked DataBackupEntity dataBackupEntity, @Capturing SkyengineFile skyengineFile)
            throws BusinessException {
        List<DataBackupEntity> dataBackupEntityList = new ArrayList<>();
        dataBackupEntityList.add(dataBackupEntity);
        File[] fileArr = new File[] {new File(""), new File("")};
        commonMock(fileArr, true);
        new Expectations() {
            {
                globalParameterAPI.findParameter(GLOBAL_PARAM_DB_BACKUP_PATH);
                result = "";
                dataBackupService.listExpireDataBackup((Date) any, true);
                result = dataBackupEntityList;
                dataBackupDAO.findAll();
                result = new ArrayList<>();
                globalParameterAPI.findParameter(Constants.GLOBAL_PARAM_DB_BACKUP_PATH);
                result = "";
            }
        };
        dataBackupTask.execute();
        new Verifications() {
            {
                dataBackupService.createDataBackup(true);
                times = 1;
                dataBackupService.deleteDataBackup(dataBackupEntity.getId());
                times = 1;
                skyengineFile.delete(true);
                times = 2;
            }
        };
    }

    /**
     * 测试execute方法
     * 
     * @param dataBackupEntity 数据库备份实体
     * @param skyengineFile 文件对象
     * @throws BusinessException 异常
     */
    @Test
    public void testExecute(@Mocked DataBackupEntity dataBackupEntity, @Capturing SkyengineFile skyengineFile) throws BusinessException {
        List<DataBackupEntity> dataBackupEntityList = new ArrayList<>();
        dataBackupEntityList.add(dataBackupEntity);
        File[] fileArr = new File[] {new File(""), new File("")};
        commonMock(fileArr, true);
        new Expectations() {
            {
                globalParameterAPI.findParameter(GLOBAL_PARAM_DB_BACKUP_PATH);
                result = "";
                dataBackupService.listExpireDataBackup((Date) any, true);
                result = dataBackupEntityList;
                dataBackupDAO.findAll();
                result = dataBackupEntityList;
                globalParameterAPI.findParameter(Constants.GLOBAL_PARAM_DB_BACKUP_PATH);
                result = "";
                dataBackupEntity.getRealFileName();
                returns("test", "");
            }
        };
        dataBackupTask.execute();
        new Verifications() {
            {
                dataBackupService.createDataBackup(true);
                times = 1;
                dataBackupService.deleteDataBackup(dataBackupEntity.getId());
                times = 1;
                skyengineFile.delete(true);
                times = 1;
                dataBackupEntity.getRealFileName();
                times = 2;
            }
        };
    }

    private void commonMock(File[] fileArr, boolean exist) throws BusinessException {
        new MockUp<File>() {
            @Mock
            public File[] listFiles(FilenameFilter filter) {
                return fileArr;
            }

            @Mock
            public boolean exists() {
                return exist;
            }
        };
    }


    // @Test
    // public void execute(@Injectable DataBackupEntity dataBackupEntity) throws Exception {
    // Assert.assertNotNull(dataBackupEntity);
    // List<DataBackupEntity> dataBackupEntityList = new ArrayList<>();
    // dataBackupEntityList.add(dataBackupEntity);
    //
    // new Expectations() {
    // {
    // dataBackupService.listExpireDataBackup((Date) any, true);
    // result = dataBackupEntityList;
    // }
    // };
    // dataBackupTask.execute();
    // new Verifications() {
    // {
    // dataBackupService.deleteDataBackup(dataBackupEntity.getId());;
    // }
    // };
    // }
    //
    // @Test
    // public void testExecuteWhileFileNotExist(@Capturing Logger logger) throws BusinessException {
    // new Expectations() {
    // {
    // globalParameterAPI.findParameter(Constants.GLOBAL_PARAM_DB_BACKUP_PATH);
    // result = "";
    // }
    // };
    // dataBackupTask.execute();
    // new Verifications() {
    // {
    // logger.info(anyString, anyString);
    // }
    // };
    // }
    //
    // @Test
    // public void testExecuteWhileDirectoryIsEmpty(@Capturing Logger logger) throws BusinessException {
    // new MockUp<File>() {
    // @Mock
    // public File[] listFiles(FilenameFilter filter) {
    // return new File[] {};
    // }
    //
    // @Mock
    // public boolean exists() {
    // return true;
    // }
    // };
    // new Expectations() {
    // {
    // globalParameterAPI.findParameter(Constants.GLOBAL_PARAM_DB_BACKUP_PATH);
    // result = "";
    // }
    // };
    // dataBackupTask.execute();
    // new Verifications() {
    // {
    // logger.info("不存在备份的数据库文件");
    // }
    // };
    // }
    //
    // @Test
    // public void testExecuteWhileDbHasNotRecord(@Capturing SkyengineFile skyengineFile) throws BusinessException {
    // new MockUp<File>() {
    // @Mock
    // public File[] listFiles(FilenameFilter filter) {
    // return new File[] {new File("")};
    // }
    //
    // @Mock
    // public boolean exists() {
    // return true;
    // }
    //
    // };
    // new Expectations() {
    // {
    // dataBackupDAO.findAll();
    // result = new ArrayList<>();
    // globalParameterAPI.findParameter(Constants.GLOBAL_PARAM_DB_BACKUP_PATH);
    // result = "";
    // }
    // };
    // dataBackupTask.execute();
    // new Verifications() {
    // {
    // skyengineFile.delete(true);
    // times = 1;
    // }
    // };
    // }
    //
    //
    // @Test
    // public void testExecute(@Capturing SkyengineFile skyengineFile, @Mocked DataBackupEntity dataBackupEntity) throws
    // BusinessException {
    // new MockUp<File>() {
    // @Mock
    // public File[] listFiles(FilenameFilter filter) {
    // return new File[] {new File(""), new File("")};
    // }
    //
    // @Mock
    // public boolean exists() {
    // return true;
    // }
    //
    // @Mock
    // public String getName() {
    // return "test";
    // }
    // };
    // List<DataBackupEntity> dataBackupEntityList = new ArrayList<>();
    // dataBackupEntityList.add(dataBackupEntity);
    // dataBackupEntityList.add(dataBackupEntity);
    // new Expectations() {
    // {
    // dataBackupDAO.findAll();
    // result = dataBackupEntityList;
    // globalParameterAPI.findParameter(Constants.GLOBAL_PARAM_DB_BACKUP_PATH);
    // result = "";
    // dataBackupEntity.getRealFileName();
    // returns("test", "");
    // }
    // };
    // dataBackupTask.execute();
    // new Verifications() {
    // {
    // skyengineFile.delete(true);
    // times = 1;
    // dataBackupEntity.getRealFileName();
    // times = 3;
    //
    // }
    // };
    // }

}
