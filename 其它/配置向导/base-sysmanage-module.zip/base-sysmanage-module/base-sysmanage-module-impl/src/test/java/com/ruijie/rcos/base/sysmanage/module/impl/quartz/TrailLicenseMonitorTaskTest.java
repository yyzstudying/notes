package com.ruijie.rcos.base.sysmanage.module.impl.quartz;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureStatus;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureType;
import com.ruijie.rcos.base.sysmanage.module.def.spi.BaseLicenseFeatureNotifySPI;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseLicenseChangeRequest;
import com.ruijie.rcos.base.sysmanage.module.impl.dao.LicenseFileDAO;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.LicenseFileEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.util.LicenseUtil;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.log.Logger;
import mockit.Capturing;
import mockit.Expectations;
import mockit.Injectable;
import mockit.Mocked;
import mockit.Tested;
import mockit.Verifications;
import mockit.integration.junit4.JMockit;

/**
 * Description: TrailLicenseMonitorTask测试类
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月10日
 * 
 * @author zouqi
 */
@RunWith(JMockit.class)
public class TrailLicenseMonitorTaskTest {
    
    @Tested
    private TrailLicenseMonitorTask task;
    
    @Injectable
    private LicenseFileDAO licenseFileDAO;
    
    @Injectable
    private BaseLicenseFeatureNotifySPI licenseFeatureNotifySPI;
    
    @Capturing
    private Logger logger;
    
    /**
     * execute 测试方法
     * 
     * @param licenseUtil 
     * 
     * @throws BusinessException 异常
     */
    @SuppressWarnings({"unchecked"})
    @Test
    public void testExecute(@Mocked LicenseUtil licenseUtil) throws BusinessException {

        //分組數據
        List<LicenseFileEntity> licenseFileEntitieList = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            LicenseFileEntity entity = new LicenseFileEntity();
            entity.setFeatureCode("G1MQ2TP000075" + i);
            licenseFileEntitieList.add(entity);
        }

        //每個組中有多少條數據
        List<LicenseFileEntity> licenseList = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            LicenseFileEntity entity = new LicenseFileEntity();
            entity.setFeatureCode("G1MQ2TP000075" + i);
            entity.setFeatureType(BaseFeatureType.TEMPORARY);
            entity.setFeatureStatus(BaseFeatureStatus.AVALIABLE);
            entity.setTrialDuration(19600000L);
            entity.setTrialRemainder(19600000L);
            entity.setFileMd5("123");
            entity.setFileName("123");
            licenseList.add(entity);
        }
        new Expectations() {
            {
                logger.isDebugEnabled();
                result = true;
                licenseFileDAO.findByFeatureStatusGroupByFeatureCode((BaseFeatureStatus)any);
                result = licenseFileEntitieList;
                licenseFileDAO.findByFeatureTypeAndFeatureCodeOrderByCreateTime((BaseFeatureType)any, (String)any);
                result = licenseList;
            }
        };

        task.execute();

        new Verifications() {
            {
                licenseFileDAO.findByFeatureStatusGroupByFeatureCode((BaseFeatureStatus)any);
                times = 1;
                licenseFileDAO.findByFeatureTypeAndFeatureCodeOrderByCreateTime((BaseFeatureType)any, (String)any);
                times = 2;
                licenseFileDAO.save((LicenseFileEntity)any);
                times = 2;
                LicenseUtil.createBaseLicenseChangeRequest((List<LicenseFileEntity>)any);
                times = 2;
                licenseFeatureNotifySPI.notifyLicenseChange((BaseLicenseChangeRequest)any);
                times = 2;
            }
        };
    }
    
    /**
     * execute 测试方法
     * 
     * @param licenseUtil 
     * 
     * @throws BusinessException 异常
     */
    @SuppressWarnings({"unchecked"})
    @Test
    public void testExecute2(@Mocked LicenseUtil licenseUtil) throws BusinessException {

        //分組數據
        List<LicenseFileEntity> licenseFileEntitieList = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            LicenseFileEntity entity = new LicenseFileEntity();
            entity.setFeatureCode("G1MQ2TP000075" + i);
            licenseFileEntitieList.add(entity);
        }

        //每個組中有多少條數據
        List<LicenseFileEntity> licenseList = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            LicenseFileEntity entity = new LicenseFileEntity();
            entity.setFeatureCode("G1MQ2TP000075" + i);
            entity.setFeatureType(BaseFeatureType.TEMPORARY);
            entity.setFeatureStatus(BaseFeatureStatus.AVALIABLE);
            entity.setTrialDuration(19600000L);
            entity.setTrialRemainder(800L);
            licenseList.add(entity);
        }
        new Expectations() {
            {
                logger.isDebugEnabled();
                result = true;
                licenseFileDAO.findByFeatureStatusGroupByFeatureCode((BaseFeatureStatus)any);
                result = licenseFileEntitieList;
                licenseFileDAO.findByFeatureTypeAndFeatureCodeOrderByCreateTime((BaseFeatureType)any, (String)any);
                result = licenseList;
            }
        };

        task.execute();

        new Verifications() {
            {
                licenseFileDAO.findByFeatureStatusGroupByFeatureCode((BaseFeatureStatus)any);
                times = 1;
                licenseFileDAO.findByFeatureTypeAndFeatureCodeOrderByCreateTime((BaseFeatureType)any, (String)any);
                times = 2;
                licenseFileDAO.save((LicenseFileEntity)any);
                times = 4;
                LicenseUtil.createBaseLicenseChangeRequest((List<LicenseFileEntity>)any);
                times = 2;
                licenseFeatureNotifySPI.notifyLicenseChange((BaseLicenseChangeRequest)any);
                times = 2;
            }
        };
    }
    
    /**
     * execute 测试方法
     * 
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testExecute3() throws BusinessException {

        //分組數據
        List<LicenseFileEntity> licenseFileEntitieList = new ArrayList<>();
        
        new Expectations() {
            {
                logger.isDebugEnabled();
                result = true;
                licenseFileDAO.findByFeatureStatusGroupByFeatureCode((BaseFeatureStatus)any);
                result = licenseFileEntitieList;
            }
        };

        task.execute();

        new Verifications() {
            {
                licenseFileDAO.findByFeatureStatusGroupByFeatureCode((BaseFeatureStatus)any);
                times = 1;
            }
        };
    }
    
    /**
     * execute 测试方法
     * 
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testExecute4() throws BusinessException {

        //分組數據
        List<LicenseFileEntity> licenseFileEntitieList = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            LicenseFileEntity entity = new LicenseFileEntity();
            entity.setFeatureCode("G1MQ2TP000075" + i);
            licenseFileEntitieList.add(entity);
        }

        //每個組中有多少條數據
        List<LicenseFileEntity> licenseList = new ArrayList<>();
        new Expectations() {
            {
                logger.isDebugEnabled();
                result = true;
                licenseFileDAO.findByFeatureStatusGroupByFeatureCode((BaseFeatureStatus)any);
                result = licenseFileEntitieList;
                licenseFileDAO.findByFeatureTypeAndFeatureCodeOrderByCreateTime((BaseFeatureType)any, (String)any);
                result = licenseList;
            }
        };

        try {
            task.execute();
            fail();
        } catch (Exception e) {
            assertEquals(e.getMessage(), "licenseFileEntityList长度不能为 0");
        }


        new Verifications() {
            {
                licenseFileDAO.findByFeatureStatusGroupByFeatureCode((BaseFeatureStatus)any);
                times = 1;
                licenseFileDAO.findByFeatureTypeAndFeatureCodeOrderByCreateTime((BaseFeatureType)any, (String)any);
                times = 1;
            }
        };
    }
}
