package com.ruijie.rcos.base.sysmanage.module.impl.util;

import static org.junit.Assert.assertTrue;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.BaseUploadLicFileRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.license.BaseCreateDatFileResponse;
import com.ruijie.rcos.base.sysmanage.module.def.dto.license.BaseLicenseFeatureDTO;
import com.ruijie.rcos.base.sysmanage.module.def.dto.license.NotifyLicenseChangeDTO;
import com.ruijie.rcos.base.sysmanage.module.def.dto.license.ValidationLicenseDTO;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureStatus;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureType;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseLicenseChangeRequest;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseValidateLicenseRequest;
import com.ruijie.rcos.base.sysmanage.module.def.spi.response.BaseGetLicenseSerialNumberResponse;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.LicenseFileEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.license.vo.LicenseFeature;
import com.ruijie.rcos.base.sysmanage.module.impl.license.vo.LicenseInfo;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.test.ThrowExceptionTester;
import mockit.Mock;
import mockit.MockUp;
import mockit.Mocked;
import mockit.Tested;
import mockit.integration.junit4.JMockit;

/**
 * Description: LicenseUtil测试类
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月12日
 * 
 * @author zouqi
 */
@RunWith(JMockit.class)
public class LicenseUtilTest {
    
    @Tested
    LicenseUtil licenseUtil;
    
    /**
     * 验证createBaseValidateLicenseRequest()方法入参
     * 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCreateBaseValidateLicenseRequestValidateParams() throws Exception {

        List<LicenseFileEntity> lfeList = new ArrayList<>(); 
        LicenseInfo lf = new LicenseInfo();
        BaseLicenseFeatureDTO licenseFeatureDTO = new BaseLicenseFeatureDTO();
        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseUtil.createBaseValidateLicenseRequest(null,lf,licenseFeatureDTO), "licenseFileEntityList不能为空");
        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseUtil.createBaseValidateLicenseRequest(lfeList,null,licenseFeatureDTO), "LicenseInfo 不能为空");
        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseUtil.createBaseValidateLicenseRequest(lfeList,lf,null), "licenseFeatureDTO不能为空");

        assertTrue(true);
    }
    
    /**
     * createBaseValidateLicenseRequest 测试方法
     * 
     * @throws BusinessException 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCreateBaseValidateLicenseRequest() throws BusinessException {
        BaseLicenseFeatureDTO dto = new BaseLicenseFeatureDTO();
        dto.setFileName("system.ini");
        dto.setFileMd5("123");
        dto.setFilePath("C:\\Windows\\");
        
        LicenseInfo lf = new LicenseInfo();
        List<LicenseFeature> featureList = new ArrayList<>();
        LicenseFeature feature = new LicenseFeature();
        feature.setDuration(900000L);
        feature.setName("123");
        feature.setOn(true);
        feature.setValue(70);
        featureList.add(feature);
        lf.setFeatureList(featureList);
        lf.setDevCode("-1");
        lf.setDevSn("G1MQ2TP000075");
        lf.setDuration(900000L);
        lf.setProductName("RCC-CM-NUM-70");
        
        List<LicenseFileEntity> licenseFileEntityList = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            LicenseFileEntity entity = new LicenseFileEntity();
            entity.setFeatureCode("RCC-CM-NUM");
            entity.setFeatureType(BaseFeatureType.TEMPORARY);
            entity.setFeatureStatus(BaseFeatureStatus.AVALIABLE);
            entity.setTrialDuration(19600000L);
            entity.setTrialRemainder(800000L);
            entity.setFileMd5("123");
            entity.setFileName("123");
            licenseFileEntityList.add(entity);
        }

        BaseValidateLicenseRequest request = licenseUtil.createBaseValidateLicenseRequest(licenseFileEntityList, lf, dto);
        int length = request.getFeatureDTOArr().length;        
        ValidationLicenseDTO licenseDTO = request.getFeatureDTOArr()[length - 1];
        Assert.assertEquals(licenseDTO.getFeatureCode(), lf.getProductName());
        Assert.assertEquals(licenseDTO.getFeatureStatus(), BaseFeatureStatus.AVALIABLE);
        Long trailRemainder = (feature.getDuration() * 60) + (800000 * 2);
        Assert.assertEquals(licenseDTO.getTrialRemainder(), trailRemainder);
    }
    
    /**
     * createBaseValidateLicenseRequest 测试方法
     * 
     * @throws BusinessException 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCreateBaseValidateLicenseRequest2() throws BusinessException {
        BaseLicenseFeatureDTO dto = new BaseLicenseFeatureDTO();
        dto.setFileName("system.ini");
        dto.setFileMd5("123");
        dto.setFilePath("C:\\Windows\\");
        
        LicenseInfo lf = new LicenseInfo();
        List<LicenseFeature> featureList = new ArrayList<>();
        LicenseFeature feature = new LicenseFeature();
        feature.setDuration(0L);
        feature.setName("123");
        feature.setOn(true);
        feature.setValue(70);
        featureList.add(feature);
        lf.setFeatureList(featureList);
        lf.setDevCode("-1");
        lf.setDevSn("G1MQ2TP000075");
        lf.setDuration(0L);
        lf.setProductName("RCC-CM-NUM-70");
        
        List<LicenseFileEntity> licenseFileEntityList = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            LicenseFileEntity entity = new LicenseFileEntity();
            entity.setFeatureCode("RCC-CM-NUM");
            entity.setFeatureType(BaseFeatureType.TEMPORARY);
            entity.setFeatureStatus(BaseFeatureStatus.AVALIABLE);
            entity.setTrialDuration(19600000L);
            entity.setTrialRemainder(800000L);
            entity.setFileMd5("123");
            entity.setFileName("123");
            licenseFileEntityList.add(entity);
        }

        BaseValidateLicenseRequest request = licenseUtil.createBaseValidateLicenseRequest(licenseFileEntityList, lf, dto);
        int length = request.getFeatureDTOArr().length;
        for (int i = 0; i < length - 1; i++) {
            ValidationLicenseDTO licenseDTO = request.getFeatureDTOArr()[i];
            Assert.assertEquals(licenseDTO.getFeatureCode(), licenseFileEntityList.get(i).getFeatureCode());
            Assert.assertEquals(licenseDTO.getFeatureStatus(), licenseFileEntityList.get(i).getFeatureStatus());
            Assert.assertEquals(licenseDTO.getFeatureType(), licenseFileEntityList.get(i).getFeatureType());
            Long trial = licenseFileEntityList.get(i).getTrialRemainder();
            Assert.assertEquals(licenseDTO.getTrialRemainder(), trial);
        }
        
        ValidationLicenseDTO licenseDTO = request.getFeatureDTOArr()[length - 1];
        Assert.assertEquals(licenseDTO.getFeatureCode(), lf.getProductName());
        Assert.assertEquals(licenseDTO.getFeatureStatus(), BaseFeatureStatus.AVALIABLE);
        Long trial = 0L;
        Assert.assertEquals(licenseDTO.getTrialRemainder(), trial);   
        Assert.assertEquals(licenseDTO.getFeatureType(), BaseFeatureType.PERPETUAL);   
    }
    
    /**
     * 验证createBaseLicenseChangeRequest()方法入参
     * 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCreateBaseLicenseChangeRequestValidateParams() throws Exception {

        List<LicenseFileEntity> lfeList = new ArrayList<>(); 
        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseUtil.createBaseLicenseChangeRequest(null), "licenseFileEntityList不能为空");
        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseUtil.createBaseLicenseChangeRequest(lfeList), "licenseFileEntityList长度不能为 0");

        assertTrue(true);
    }
    
    /**
     * createBaseLicenseChangeRequest 测试方法
     * 
     * @throws BusinessException 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCreateBaseLicenseChangeRequest() throws BusinessException {

        List<LicenseFileEntity> licenseFileEntityList = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            LicenseFileEntity entity = new LicenseFileEntity();
            entity.setFeatureCode("RCC-CM-NUM");
            entity.setFeatureType(BaseFeatureType.TEMPORARY);
            entity.setFeatureStatus(BaseFeatureStatus.AVALIABLE);
            entity.setTrialDuration(19600000L);
            entity.setTrialRemainder(800000L);
            entity.setFileMd5("123");
            entity.setFileName("123");
            licenseFileEntityList.add(entity);
        }

        BaseLicenseChangeRequest request = licenseUtil.createBaseLicenseChangeRequest(licenseFileEntityList);
        int length = request.getFeatureArr().length;        
        NotifyLicenseChangeDTO licenseDTO = request.getFeatureArr()[length - 1];
        Assert.assertEquals(licenseDTO.getFeatureCode(), licenseFileEntityList.get(0).getFeatureCode());
        Assert.assertEquals(licenseDTO.getFeatureType(), licenseFileEntityList.get(0).getFeatureType());
        Long trailRemainder = licenseFileEntityList.get(0).getTrialRemainder() + licenseFileEntityList.get(1).getTrialRemainder();
        Assert.assertEquals(licenseDTO.getTrialRemainder(), trailRemainder);
    }
    
    /**
     * createBaseValidateLicenseRequest 测试方法
     * 
     * @throws BusinessException 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCreateBaseLicenseChangeRequest2() throws BusinessException {

        List<LicenseFileEntity> licenseFileEntityList = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            LicenseFileEntity entity = new LicenseFileEntity();
            entity.setFeatureCode("RCC-CM-NUM");
            entity.setFeatureType(BaseFeatureType.PERPETUAL);
            entity.setFeatureStatus(BaseFeatureStatus.AVALIABLE);
            entity.setTrialDuration(19600000L);
            entity.setTrialRemainder(800000L);
            entity.setFileMd5("123");
            entity.setFileName("123");
            licenseFileEntityList.add(entity);
        }

        BaseLicenseChangeRequest request = licenseUtil.createBaseLicenseChangeRequest(licenseFileEntityList);
        int length = request.getFeatureArr().length;        
        for (int i = 0; i < length; i++) {
            NotifyLicenseChangeDTO licenseDTO = request.getFeatureArr()[i];
            Assert.assertEquals(licenseDTO.getFeatureCode(), licenseFileEntityList.get(i).getFeatureCode());
            Assert.assertEquals(licenseDTO.getFeatureType(), licenseFileEntityList.get(i).getFeatureType());
            Assert.assertEquals(licenseDTO.getTrialRemainder(), licenseDTO.getTrialRemainder());
        }
    }
    
    /**
     * 验证createEntity()方法入参
     * 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCreateEntityValidateParams() throws Exception {
        LicenseInfo lf = new LicenseInfo();
        BaseLicenseFeatureDTO licenseFeatureDTO = new BaseLicenseFeatureDTO();
        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseUtil.createEntity(null, lf), "BaseLicenseFeatureDTO不能为空");
        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseUtil.createEntity(licenseFeatureDTO, null), "LicenseInfo 不能为空");
        
        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseUtil.createEntity(licenseFeatureDTO, lf), "FeatureList 不能为空");

        assertTrue(true);
    }
    
    /**
     * createEntity 测试方法
     * 
     * @param date 
     * @throws BusinessException 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCreateEntity(@Mocked Date date) throws BusinessException {
        BaseLicenseFeatureDTO dto = new BaseLicenseFeatureDTO();
        dto.setFileName("system.ini");
        dto.setFileMd5("123");
        dto.setFilePath("C:\\Windows\\");
        
        LicenseInfo lf = new LicenseInfo();
        List<LicenseFeature> featureList = new ArrayList<>();
        LicenseFeature feature = new LicenseFeature();
        feature.setDuration(900000L);
        feature.setName("123");
        feature.setOn(true);
        feature.setValue(70);
        featureList.add(feature);
        lf.setFeatureList(featureList);
        lf.setDevCode("-1");
        lf.setDevSn("G1MQ2TP000075");
        lf.setDuration(900000L);
        lf.setProductName("RCC-CM-NUM-70");

        Date mDate = new Date();
        
        new MockUp<Date>() {
            @SuppressWarnings("unused")
            public Date $init() {
                return mDate;
            }
        };
        
        List<LicenseFileEntity> licenseFileEntityList = licenseUtil.createEntity(dto, lf);
       
        for (LicenseFileEntity entity : licenseFileEntityList) {
            
            Assert.assertEquals(entity.getFeatureType(), BaseFeatureType.TEMPORARY);
            Assert.assertEquals(entity.getFeatureStatus(), BaseFeatureStatus.AVALIABLE);
            Assert.assertEquals(entity.getCreateTime().getTime(), mDate.getTime());
            Assert.assertEquals(entity.getTrialDuration(), feature.getDuration() * 60);
            Assert.assertEquals(entity.getTrialRemainder(), feature.getDuration() * 60);
            Assert.assertEquals(entity.getTrailStartTime().getTime(), mDate.getTime());
            
            Assert.assertEquals(entity.getFeatureCode(), dto.getFeatureCode());
            Assert.assertEquals(entity.getFileName(), dto.getFileName());
            Assert.assertEquals(entity.getFileMd5(), dto.getFileMd5());
            Assert.assertEquals(entity.getFeatureDisplayName(), dto.getFeatureDisplayName());
            Assert.assertEquals(entity.getFeatureDescription(), dto.getFeatureDescription());
        }
        
    }
    
    /**
     * 验证featureEntityToFeatureDTO()方法入参
     * 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testFeatureEntityToFeatureDTOValidateParams() throws Exception {
        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseUtil.featureEntityToFeatureDTO(null), "LicenseFileEntity不能为空");

        assertTrue(true);
    }
    
    /**
     * featureEntityToFeatureDTO 测试方法
     * 
     * @throws BusinessException 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testFeatureEntityToFeatureDTO() throws BusinessException {
        

        LicenseFileEntity entity = new LicenseFileEntity();
        entity.setFeatureCode("RCC-CM-NUM");
        entity.setFeatureType(BaseFeatureType.TEMPORARY);
        entity.setFeatureStatus(BaseFeatureStatus.AVALIABLE);
        entity.setTrialDuration(19600000L);
        entity.setTrialRemainder(800000L);
        entity.setFileMd5("123");
        entity.setFileName("123");

        
        BaseLicenseFeatureDTO dto = licenseUtil.featureEntityToFeatureDTO(entity);
        
        Assert.assertEquals(dto.getFeatureCode(), entity.getFeatureCode());
        Assert.assertEquals(dto.getFeatureStatus(), entity.getFeatureStatus());
        Assert.assertEquals(dto.getFeatureType(), entity.getFeatureType());
        Assert.assertEquals(dto.getFileName(), entity.getFileName());
        Assert.assertEquals(dto.getFileMd5(), entity.getFileMd5());
        Assert.assertEquals(dto.getDurationLicense(), entity.getTrialDuration());
        
        
    } 
    
    /**
     * 验证createDatFileResponse()方法入参
     * 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCreateDatFileResponseValidateParams() throws Exception {
        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseUtil.createDatFileResponse(null), "BaseGetLicenseSerialNumberResponse不能为空");
        assertTrue(true);
    }
    
    /**
     * createDatFileResponse 测试方法
     * 
     * @throws BusinessException 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCreateDatFileResponse() throws BusinessException {
        
        BaseGetLicenseSerialNumberResponse spiResponse = new BaseGetLicenseSerialNumberResponse();
        spiResponse.setSerialId("G1MQ2TP000075");
        
        UUID id = UUID.fromString("bacd9ad0-ff0f-4460-b8db-5c61218a888d");
        
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        stringBuilder.append("<option>\n");
        stringBuilder.append("  <dev_id>");
        stringBuilder.append(spiResponse.getSerialId());
        stringBuilder.append("</dev_id>\n");
        stringBuilder.append("  <dev_code>");
        stringBuilder.append(id.toString());
        stringBuilder.append("</dev_code>\n");
        stringBuilder.append("</option>");
        
        new MockUp<UUID>() {
            @Mock
            public UUID randomUUID() {
                return id;
            }
        };
        
        BaseCreateDatFileResponse response = licenseUtil.createDatFileResponse(spiResponse);
        
        Assert.assertEquals(spiResponse.getSerialId(), response.getFiieName());
        Assert.assertEquals(stringBuilder.toString(), response.getFileContent());
        
    }
    
    /**
     * 验证createLicenseDTO()方法入参
     * 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCreateLicenseDTOValidateParams() throws Exception {
        
        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseUtil.createLicenseDTO(null), "BaseUploadLicFileRequest不能为空");
        assertTrue(true);
    }
    
    /**
     * createLicenseDTO 测试方法
     * 
     * @throws BusinessException 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCreateLicense() throws BusinessException {
        
        BaseUploadLicFileRequest request = new BaseUploadLicFileRequest();
        request.setFileName("123");
        request.setFileMd5("123");
        request.setFilePath("123");
        
        
        BaseLicenseFeatureDTO dto = licenseUtil.createLicenseDTO(request);
        Assert.assertEquals(request.getFileMd5(), dto.getFileMd5());
        Assert.assertEquals(request.getFileName(), dto.getFileName());
        Assert.assertEquals(request.getFilePath(), dto.getFilePath());
        
    }
}
