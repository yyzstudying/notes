package com.ruijie.rcos.base.sysmanage.module.impl.dao;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureStatus;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureType;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.log.LoggerFactory;

/**
 * Description: 测试licenseDao类
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月16日
 * 
 * @author zouqi
 */
@Service
public class LicenseFileDAOTest implements InitializingBean {
    
    private static final Logger  LOGGER = LoggerFactory.getLogger(LicenseFileDAOTest.class);
    
    @Autowired
    private LicenseFileDAO licenseFileDAO;

    @Override
    public void afterPropertiesSet() throws Exception {
        new Thread() {
            public void run() {
                licenseFileDAO.findByFeatureCode("xxx");
                LOGGER.info("licenseFileDAO.findByFeatureCode(\"xxx\") 执行了=================================================================");
                licenseFileDAO.findByFeatureTypeAndFeatureStatusOrderByCreateTime(BaseFeatureType.TEMPORARY, 
                        BaseFeatureStatus.AVALIABLE);
                LOGGER.info("licenseFileDAO.findByFeatureCode(\"xxx\") 执行了");
                licenseFileDAO.findByFeatureTypeAndFeatureStatusAndFeatureCodeOrderByCreateTime(BaseFeatureType.TEMPORARY, 
                        BaseFeatureStatus.AVALIABLE, "xxx");
                LOGGER.info("licenseFileDAO.findByFeatureCode(\"xxx\") 执行了");
                licenseFileDAO.findByFeatureTypeAndFeatureCodeOrderByCreateTime(BaseFeatureType.TEMPORARY, "xxx");
                LOGGER.info("licenseFileDAO.findByFeatureCode(\"xxx\") 执行了");
                
                licenseFileDAO.existsByFileName("xxx");
                LOGGER.info("licenseFileDAO.findByFeatureCode(\"xxx\") 执行了");
                licenseFileDAO.existsByFileMd5("xxx");
                LOGGER.info("existFileMd5(\"xxx\") 执行了");
                licenseFileDAO.findByFeatureStatusGroupByFeatureCode(BaseFeatureStatus.EXPIRED);
                LOGGER.info("findByFeatureStatus(BaseFeatureStatus.EXPIRED) 执行了");
                
            }
            
            ;
            
        }.start();

    }
}
