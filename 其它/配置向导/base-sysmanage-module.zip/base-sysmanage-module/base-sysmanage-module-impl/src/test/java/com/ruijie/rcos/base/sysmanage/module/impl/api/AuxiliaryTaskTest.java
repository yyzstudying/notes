package com.ruijie.rcos.base.sysmanage.module.impl.api;

import com.ruijie.rcos.base.sysmanage.module.impl.BusinessKey;
import com.ruijie.rcos.sk.base.quartz.Quartz;
import com.ruijie.rcos.sk.base.quartz.QuartzTask;
import com.ruijie.rcos.sk.modulekit.api.isolation.GlobalUniqueBean;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月23日
 *
 * @author yeyuzhong
 */
@GlobalUniqueBean("AuxiliaryTaskTest")
@Quartz(cron = "", msgKey = BusinessKey.BASE_SYS_MANAGE_DATA_BACKUP)
public class AuxiliaryTaskTest implements QuartzTask {

    @Override
    public void execute() throws Exception {

    }
}
