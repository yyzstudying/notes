package com.ruijie.rcos.base.sysmanage.module.impl.tx.impl;

import static org.junit.Assert.assertTrue;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import com.ruijie.rcos.base.sysmanage.module.def.dto.license.BaseLicenseFeatureDTO;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureStatus;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureType;
import com.ruijie.rcos.base.sysmanage.module.impl.dao.LicenseFileDAO;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.LicenseFileEntity;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.test.ThrowExceptionTester;
import mockit.Capturing;
import mockit.Expectations;
import mockit.Injectable;
import mockit.Tested;
import mockit.Verifications;

/**
 * Description: LicenseSaveTxImpl测试类
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月21日
 * 
 * @author zouqi
 */
public class LicenseSaveTxImplTest {

    @Tested
    LicenseSaveTxImpl licenseSaveTx;
    
    @Injectable
    private LicenseFileDAO licenseFileDAO;
    
    @Capturing
    private Logger logger;
    
    /**
     * 验证saveLicense()方法入参
     * 
     * @throws Exception 异常
     */
    @Test
    public void testSaveLicenseValidateParams() throws Exception {

        //BaseLicenseFeatureDTO licenseFeatureDTO, List<LicenseFileEntity> licenseFileEntityList
        List<LicenseFileEntity> lfeList = new ArrayList<>(); 
        BaseLicenseFeatureDTO licenseFeatureDTO = new BaseLicenseFeatureDTO();
        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseSaveTx.saveLicense(null, lfeList), "baseLicenseFeatureDTO 不能为空");
        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseSaveTx.saveLicense(licenseFeatureDTO, null), "List<LicenseFileEntity> 不能为空");
        
        assertTrue(true);
    }
    
    /**
     * saveLicense 测试方法
     * 
     * @throws BusinessException 异常
     */
    @SuppressWarnings({"unchecked"})
    @Test
    public void testSaveLicense() throws BusinessException {
        BaseLicenseFeatureDTO dto = new BaseLicenseFeatureDTO();
        dto.setFileName("system.ini");
        dto.setFileMd5("123");
        dto.setFilePath("C:\\Windows\\");
        
        List<LicenseFileEntity> licenseFileEntityList = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            LicenseFileEntity entity = new LicenseFileEntity();
            entity.setFeatureCode("RCC-CM-NUM");
            entity.setFeatureType(BaseFeatureType.TEMPORARY);
            entity.setFeatureStatus(BaseFeatureStatus.AVALIABLE);
            entity.setTrialDuration(19600000L);
            entity.setTrialRemainder(800000L);
            entity.setFileMd5("123");
            entity.setFileName("123");
            licenseFileEntityList.add(entity);
        }
        
        new Expectations() {
            {
                logger.isDebugEnabled();
                result = true;
                
                licenseFileDAO.findByFeatureTypeAndFeatureStatusAndFeatureCodeOrderByCreateTime((BaseFeatureType)any, 
                        (BaseFeatureStatus)any, (String)any);
                result = licenseFileEntityList;

            }
        };

        licenseSaveTx.saveLicense(dto, licenseFileEntityList);
        
        new Verifications() {
            {
                licenseFileDAO.save((LicenseFileEntity)any);
                times = 2;
                licenseFileDAO.saveAll((List<LicenseFileEntity>)any);
                times = 1;
            }
        };
    }
    
    /**
     * saveLicense 测试方法
     * 
     * @throws BusinessException 异常
     */
    @SuppressWarnings({"unchecked"})
    @Test
    public void testSaveLicense3() throws BusinessException {
        BaseLicenseFeatureDTO dto = new BaseLicenseFeatureDTO();
        dto.setFileName("system.ini");
        dto.setFileMd5("123");
        dto.setFilePath("C:\\Windows\\");
        
        List<LicenseFileEntity> licenseFileEntityList = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            LicenseFileEntity entity = new LicenseFileEntity();
            entity.setFeatureCode("RCC-CM-NUM");
            entity.setFeatureType(BaseFeatureType.TEMPORARY);
            entity.setFeatureStatus(BaseFeatureStatus.AVALIABLE);
            entity.setTrialDuration(19600000L);
            entity.setTrialRemainder(19600000L);
            entity.setFileMd5("123");
            entity.setFileName("123");
            licenseFileEntityList.add(entity);
        }
        
        new Expectations() {
            {
                logger.isDebugEnabled();
                result = true;
                
                licenseFileDAO.findByFeatureTypeAndFeatureStatusAndFeatureCodeOrderByCreateTime((BaseFeatureType)any, 
                        (BaseFeatureStatus)any, (String)any);
                result = licenseFileEntityList;

            }
        };

        licenseSaveTx.saveLicense(dto, licenseFileEntityList);
        
        new Verifications() {
            {
                licenseFileDAO.save((LicenseFileEntity)any);
                times = 2;
                licenseFileDAO.saveAll((List<LicenseFileEntity>)any);
                times = 1;
            }
        };
    }
    
    /**
     * saveLicense 测试方法
     * 
     * @throws BusinessException 异常
     */
    @SuppressWarnings({"unchecked"})
    @Test
    public void testSaveLicense2() throws BusinessException {
        BaseLicenseFeatureDTO dto = new BaseLicenseFeatureDTO();
        dto.setFileName("system.ini");
        dto.setFileMd5("123");
        dto.setFilePath("C:\\Windows\\");
        
        List<LicenseFileEntity> licenseFileEntityList = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            LicenseFileEntity entity = new LicenseFileEntity();
            entity.setFeatureCode("RCC-CM-NUM");
            entity.setFeatureType(BaseFeatureType.TEMPORARY);
            entity.setFeatureStatus(BaseFeatureStatus.AVALIABLE);
            entity.setTrialDuration(19600000L);
            entity.setTrialRemainder(800000L);
            entity.setFileMd5("123");
            entity.setFileName("123");
            licenseFileEntityList.add(entity);
        }
        
        new Expectations() {
            {
                logger.isDebugEnabled();
                result = true;
                
                licenseFileDAO.findByFeatureTypeAndFeatureStatusAndFeatureCodeOrderByCreateTime((BaseFeatureType)any, 
                        (BaseFeatureStatus)any, (String)any);
                result = new ArrayList<>();

            }
        };

        licenseSaveTx.saveLicense(dto, licenseFileEntityList);
        
        new Verifications() {
            {
                licenseFileDAO.saveAll((List<LicenseFileEntity>)any);
                times = 1;
            }
        };
    }
}
