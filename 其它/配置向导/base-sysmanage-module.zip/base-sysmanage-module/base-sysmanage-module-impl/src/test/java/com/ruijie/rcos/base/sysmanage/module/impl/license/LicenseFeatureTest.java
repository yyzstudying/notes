package com.ruijie.rcos.base.sysmanage.module.impl.license;

import static org.junit.Assert.assertTrue;
import java.util.Date;
import org.junit.Test;
import com.ruijie.rcos.base.sysmanage.module.impl.license.enums.FeatureTypeEnum;
import com.ruijie.rcos.base.sysmanage.module.impl.license.vo.LicenseFeature;
import mockit.Tested;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月25日
 * 
 * @author zouqi
 */
public class LicenseFeatureTest {

    @Tested 
    LicenseFeature licenseFeature;
    
    @Test
    public void testGetSetMethod() {
        licenseFeature.setName("123");
        licenseFeature.setDuration(12345L);
        licenseFeature.setOn(false);
        licenseFeature.setStartTime(new Date());
        licenseFeature.setType(FeatureTypeEnum.ONOFF);
        licenseFeature.setValue(0);
        licenseFeature.getDuration();
        licenseFeature.getName();
        licenseFeature.getStartTime();
        licenseFeature.getType();
        licenseFeature.getValue();
        licenseFeature.isOn();
        licenseFeature.setType(FeatureTypeEnum.DATA);
        licenseFeature.isOn();
        assertTrue(true);
    }
    
    
}
