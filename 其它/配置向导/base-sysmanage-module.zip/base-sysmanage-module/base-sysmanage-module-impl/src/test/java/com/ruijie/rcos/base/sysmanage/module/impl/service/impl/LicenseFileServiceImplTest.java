package com.ruijie.rcos.base.sysmanage.module.impl.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.jpa.domain.Specification;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.BaseLicenseListRequest;
import com.ruijie.rcos.base.sysmanage.module.def.dto.license.BaseLicenseFeatureDTO;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureStatus;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureType;
import com.ruijie.rcos.base.sysmanage.module.def.spi.BaseLicenseFeatureNotifySPI;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseLicenseChangeRequest;
import com.ruijie.rcos.base.sysmanage.module.impl.dao.LicenseFileDAO;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.LicenseFileEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.license.vo.LicenseFeature;
import com.ruijie.rcos.base.sysmanage.module.impl.license.vo.LicenseInfo;
import com.ruijie.rcos.base.sysmanage.module.impl.service.LicenseContentValidationService;
import com.ruijie.rcos.base.sysmanage.module.impl.service.LicenseFileMoveService;
import com.ruijie.rcos.base.sysmanage.module.impl.tx.LicenseSaveTx;
import com.ruijie.rcos.base.sysmanage.module.impl.util.LicenseUtil;
import com.ruijie.rcos.sk.base.config.ConfigFacade;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.test.ThrowExceptionTester;
import mockit.Capturing;
import mockit.Expectations;
import mockit.Injectable;
import mockit.Mock;
import mockit.MockUp;
import mockit.Mocked;
import mockit.Tested;
import mockit.Verifications;
import mockit.integration.junit4.JMockit;

/**
 * Description: license文件导入实现 单元测试类
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月25日
 *
 * @author fyq
 */

@RunWith(JMockit.class)
public class LicenseFileServiceImplTest {

    @Tested
    private LicenseFileServiceImpl licenseFileServiceImpl;
    
    @Injectable
    private LicenseFileDAO licenseFileDAO;
    
    @Injectable
    private LicenseContentValidationService licenseContentValidationService;

    @Injectable
    private BaseLicenseFeatureNotifySPI licenseFeatureNotifySPI;
    
    @Injectable
    private LicenseFileMoveService licenseFileMoveService;
    
    @Injectable
    private LicenseSaveTx licenseSaveTx;
    
    @Injectable
    private ConfigFacade configFacade;
    
    @Capturing
    private Logger logger;

    
    /**
     * 验证uploadLicense()方法入参
     * 
     * @throws Exception 异常
     */
    @Test
    public void testUploadLicenseValidateParams() throws Exception {

        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseFileServiceImpl.uploadLicense(null), "baseLicenseFeatureDTO 不能为空");

        assertTrue(true);
    }
    
    /**
     * uploadLicense 测试方法
     * 
     * @param licenseUtil 
     * @throws BusinessException 异常
     */
    @SuppressWarnings({"unchecked", "static-access"})
    @Test
    public void testUploadLicense(@Mocked LicenseUtil licenseUtil) throws BusinessException {

        BaseLicenseFeatureDTO dto = new BaseLicenseFeatureDTO();
        dto.setFileName("123");
        dto.setFileMd5("123");
        dto.setFilePath("123");
        
        List<LicenseFileEntity> licenseFileEntityList = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            LicenseFileEntity entity = new LicenseFileEntity();
            entity.setFeatureCode("RCC-CM-NUM");
            entity.setFeatureType(BaseFeatureType.TEMPORARY);
            entity.setFeatureStatus(BaseFeatureStatus.AVALIABLE);
            entity.setTrialDuration(19600000L);
            entity.setTrialRemainder(800000L);
            entity.setFileMd5("123");
            entity.setFileName("123");
            licenseFileEntityList.add(entity);
        }
        
        LicenseInfo licenseInfo = new LicenseInfo();
        List<LicenseFeature> featureResolveList = new ArrayList<LicenseFeature>();
        LicenseFeature featureDTO = new LicenseFeature();
        featureDTO.setDuration(900000L);
        featureDTO.setName("123");
        featureDTO.setOn(true);
        featureDTO.setValue(70);
        featureResolveList.add(featureDTO);
        licenseInfo.setFeatureList(featureResolveList);
        licenseInfo.setDevCode("-1");
        licenseInfo.setDevSn("G1MQ2TP000075");
        licenseInfo.setDuration(900000L);
        licenseInfo.setProductName("RCC-CM-NUM");
        
        new Expectations() {
            {
                logger.isDebugEnabled();
                result = true;
                
                licenseContentValidationService.licenseContentValidation((BaseLicenseFeatureDTO)any);
                result = licenseInfo;
                
                licenseUtil.createEntity((BaseLicenseFeatureDTO)any, (LicenseInfo)any);
                result = licenseFileEntityList;
                
                licenseSaveTx.saveLicense((BaseLicenseFeatureDTO)any, (List<LicenseFileEntity>)any);
                result = licenseFileEntityList;

            }
        };

        licenseFileServiceImpl.uploadLicense(dto);

        new Verifications() {
            {
              
                licenseFileMoveService.licenseFileValidation((BaseLicenseFeatureDTO)any);
                times = 1;
                
                licenseFileMoveService.cutLicenseFile((BaseLicenseFeatureDTO)any);
                times = 1;
                
                licenseContentValidationService.licenseContentValidation((BaseLicenseFeatureDTO)any);
                times = 1;
                
                licenseUtil.createEntity((BaseLicenseFeatureDTO)any, (LicenseInfo)any);
                times = 1;
                
                licenseSaveTx.saveLicense((BaseLicenseFeatureDTO)any, (List<LicenseFileEntity>)any);
                times = 1;
                
                licenseFeatureNotifySPI.notifyLicenseChange((BaseLicenseChangeRequest)any);
                times = 1;
                
                licenseUtil.createBaseLicenseChangeRequest((List<LicenseFileEntity>)any);
                times = 1;
                
                licenseFeatureNotifySPI.notifyLicenseChange((BaseLicenseChangeRequest)any);
                times = 1;
            }
        };
    }
    
    /**
     * uploadLicense 测试方法
     * 
     * @param licenseUtil 
     * @throws BusinessException 异常
     */
    @Test
    public void testUploadLicense2(@Mocked LicenseUtil licenseUtil) throws BusinessException {

        BaseLicenseFeatureDTO dto = new BaseLicenseFeatureDTO();
        dto.setFileName("123");
        dto.setFileMd5("123");
        dto.setFilePath("123");
        
        new Expectations() {
            {
                logger.isDebugEnabled();
                result = true;
                
                licenseContentValidationService.licenseContentValidation((BaseLicenseFeatureDTO)any);
                result = new BusinessException("123");
                

            }
        };

        try {
            licenseFileServiceImpl.uploadLicense(dto);
            fail();
        } catch (BusinessException e) {
            assertEquals(e.getKey(), "123");
        }
        

    }
    
    /**
     * initLicense 测试方法
     * @param licenseUtil 
     * @throws BusinessException 异常
     */
    @SuppressWarnings({"unchecked", "static-access"})
    @Test
    public void initLicenseTest(@Mocked LicenseUtil licenseUtil) throws BusinessException {
        
        List<LicenseFileEntity> licenseList = new ArrayList<>();
        for (int i = 0;i < 2; i++) {
            LicenseFileEntity entity = new LicenseFileEntity();
            entity.setFeatureCode("123");
            licenseList.add(entity);
        }
        BaseLicenseChangeRequest licenseChangeRequest = new BaseLicenseChangeRequest();
        licenseChangeRequest.setFeatureCode("123");
        
        new Expectations() {
            {
                
                logger.isDebugEnabled();
                result = true;
                
                licenseFileDAO.findByFeatureStatusGroupByFeatureCode((BaseFeatureStatus)any);
                result = licenseList;
                
                licenseFileDAO.findByFeatureTypeAndFeatureCodeOrderByCreateTime((BaseFeatureType)any, (String)any);
                result = licenseList;
                
                licenseUtil.createBaseLicenseChangeRequest((List<LicenseFileEntity>)any);
                result = licenseChangeRequest;

            }
        };

        licenseFileServiceImpl.initLicense();

        new Verifications() {
            {
                licenseFileDAO.findByFeatureStatusGroupByFeatureCode((BaseFeatureStatus)any);
                times = 1;
                licenseFileDAO.findByFeatureTypeAndFeatureCodeOrderByCreateTime((BaseFeatureType)any, (String)any);
                times = 2;
                licenseUtil.createBaseLicenseChangeRequest((List<LicenseFileEntity>)any);
                times = 2;
                licenseFeatureNotifySPI.notifyLicenseChange((BaseLicenseChangeRequest)any);
                times = 2;
               
            }
        };
    }
    
    /**
     * initLicense 测试方法
     * @param licenseUtil 
     * @throws BusinessException 异常
     */
    @Test
    public void initLicenseTest2(@Mocked LicenseUtil licenseUtil) throws BusinessException {
        
        List<LicenseFileEntity> licenseList = new ArrayList<>();
        for (int i = 0;i < 2; i++) {
            LicenseFileEntity entity = new LicenseFileEntity();
            entity.setFeatureCode("123");
            licenseList.add(entity);
        }
        BaseLicenseChangeRequest licenseChangeRequest = new BaseLicenseChangeRequest();
        licenseChangeRequest.setFeatureCode("123");
        
        new Expectations() {
            {
                
                logger.isDebugEnabled();
                result = true;
                
                licenseFileDAO.findByFeatureStatusGroupByFeatureCode((BaseFeatureStatus)any);
                result = new ArrayList<LicenseFileEntity>();
                
                

            }
        };

        licenseFileServiceImpl.initLicense();

        new Verifications() {
            {
                licenseFileDAO.findByFeatureStatusGroupByFeatureCode((BaseFeatureStatus)any);
                times = 1;    
            }
        };
    }

    /**
     * 验证licenseList()方法入参
     * 
     * @throws Exception 异常
     */
    @Test
    public void testLicenseListValidateParams() throws Exception {

        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseFileServiceImpl.licenseList(null), "request参数不能为空");

        assertTrue(true);
    }
    
    /**
     * licenseList 测试方法
     * @param request 
     * @throws BusinessException 异常
     */
    @SuppressWarnings("unchecked")
    @Test
    public void testLicenseList(@Mocked PageRequest request) throws BusinessException {
        
        BaseLicenseListRequest licenseListRequest = new BaseLicenseListRequest();
        
        new Expectations() {
            {
                
                logger.isDebugEnabled();
                result = true;
            }
        };
        
        new MockUp<PageRequest>() {
            
            @Mock
            public PageRequest of(int page, int size, Direction direction, String... properties) {
                //
                return null;
            }
        };

        licenseFileServiceImpl.licenseList(licenseListRequest);

        new Verifications() {
            {
                licenseFileDAO.findAll((Specification<LicenseFileEntity>)any, (Pageable)any);
                times = 1;    
            }
        };
    }
    
    /**
     * 验证checkDuplication()方法入参
     * 
     * @throws Exception 异常
     */
    @Test
    public void testCheckDuplicationValidateParams() throws Exception {

        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseFileServiceImpl.checkDuplication(null), "name is null");

        assertTrue(true);
    }
    
    /**
     * checkDuplication 测试方法
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testCheckDuplication() throws BusinessException {        
        
        licenseFileServiceImpl.checkDuplication("123");

        new Verifications() {
            {
                licenseFileDAO.existsByFileName((String)any);
                times = 1;    
            }
        };
    }
}
