package com.ruijie.rcos.base.sysmanage.module.impl.quartz;

import java.lang.annotation.Annotation;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.springframework.context.ApplicationContext;

import com.ruijie.rcos.base.sysmanage.module.impl.common.Constants;
import com.ruijie.rcos.base.sysmanage.module.impl.quartz.data.QuartzTaskData;
import com.ruijie.rcos.base.sysmanage.module.impl.quartz.dispatcher.JobDispatcher;
import com.ruijie.rcos.sk.base.annotation.Email;
import com.ruijie.rcos.sk.base.exception.AnnotationValidationException;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.quartz.QuartzTask;
import com.ruijie.rcos.sk.base.validation.BeanValidationUtil;

import mockit.*;
import mockit.integration.junit4.JMockit;

/**
 * Description: 业务工作测试
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月25日
 *
 * @author fyq
 */

@RunWith(JMockit.class)
public class BusinessJobTest {

    @Tested
    private BusinessJob businessJob;

    @Email
    private String annotation;

    @Capturing
    private Logger logger;

    /**
     * 执行注释验证异常
     *
     * @param context 作业执行上下文
     * @param applicationContext 应用场景
     * @throws AnnotationValidationException 注解异常
     * @throws NoSuchFieldException 异常
     */
    @Test
    public void testExecuteAnnotationException(@Mocked JobExecutionContext context, @Mocked ApplicationContext applicationContext)
            throws AnnotationValidationException, NoSuchFieldException {


        QuartzTaskData quartzTaskData = new QuartzTaskData();

        JobDataMap jobDataMap = new JobDataMap();
        jobDataMap.put(ApplicationContext.class.getSimpleName(), applicationContext);
        jobDataMap.put(Constants.SCHEDULE_DATA_KEY, quartzTaskData);

        QuartzTaskData quartzTaskData1 = (QuartzTaskData) jobDataMap.get(Constants.SCHEDULE_DATA_KEY);

        Annotation annotation = this.getClass().getDeclaredField("annotation").getAnnotation(Email.class);

        new Expectations(BeanValidationUtil.class) {
            {
                context.getJobDetail().getJobDataMap();
                result = jobDataMap;
                BeanValidationUtil.validateBean(quartzTaskData1.getClass(), any);
                result = new AnnotationValidationException("1", annotation, "1");
                logger.error(anyString, (AnnotationValidationException) any);
            }
        };

        businessJob.execute(context);

        new Verifications() {
            {
                context.getJobDetail().getJobDataMap();
                times = 1;
                logger.error(anyString, (AnnotationValidationException) any);
                times = 1;

            }
        };
    }

    /**
     * 执行注释验证异常
     *
     * @param context 上下文
     * @throws AnnotationValidationException 异常
     */
    @Test
    public void testExecuteWhileNotNeedExecute(@Mocked QuartzTask quartzTask, @Mocked JobExecutionContext context,
            @Mocked QuartzTaskData quartzTaskData) throws AnnotationValidationException {



        JobDataMap jobDataMap = new JobDataMap();
        jobDataMap.put(Constants.SCHEDULE_DATA_KEY, quartzTaskData);



        new Expectations(BeanValidationUtil.class) {
            {
                context.getJobDetail().getJobDataMap();
                result = jobDataMap;

                BeanValidationUtil.validateBean(quartzTaskData.getClass(), any);
                quartzTaskData.getQuartzTask();
                result = quartzTask;
                quartzTask.needExecute();
                result = false;
            }
        };

        businessJob.execute(context);

        new Verifications() {
            {
                context.getJobDetail().getJobDataMap();
                times = 1;
                BeanValidationUtil.validateBean(quartzTaskData.getClass(), any);
                times = 1;
                quartzTask.needExecute();
                times = 1;
                quartzTaskData.getJobDispatcher();
                times = 0;
            }
        };
    }

    @Test
    public void testExecute(@Mocked QuartzTask quartzTask, @Mocked JobExecutionContext context, @Mocked JobDispatcher jobDispatcher,
            @Mocked QuartzTaskData quartzTaskData) throws AnnotationValidationException {

        JobDataMap jobDataMap = new JobDataMap();
        jobDataMap.put(Constants.SCHEDULE_DATA_KEY, quartzTaskData);

        new Expectations(BeanValidationUtil.class) {
            {
                context.getJobDetail().getJobDataMap();
                result = jobDataMap;

                BeanValidationUtil.validateBean(quartzTaskData.getClass(), any);
                quartzTaskData.getQuartzTask();
                result = quartzTask;
                quartzTask.needExecute();
                result = true;
                quartzTaskData.getJobDispatcher();
                result = jobDispatcher;
            }
        };

        businessJob.execute(context);

        new Verifications() {
            {
                context.getJobDetail().getJobDataMap();
                times = 1;
                BeanValidationUtil.validateBean(quartzTaskData.getClass(), any);
                times = 1;
                quartzTask.needExecute();
                times = 1;
                quartzTaskData.getJobDispatcher();
                times = 1;
                jobDispatcher.dispatcher(context);
                times = 1;
            }
        };
    }
}
