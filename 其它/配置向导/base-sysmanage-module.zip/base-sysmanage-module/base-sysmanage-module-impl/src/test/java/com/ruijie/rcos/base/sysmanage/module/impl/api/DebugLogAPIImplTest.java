package com.ruijie.rcos.base.sysmanage.module.impl.api;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import com.ruijie.rcos.base.sysmanage.module.def.api.request.debuglog.BaseCreateDebugLogRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.debuglog.BaseDeleteDebugLogRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.debuglog.BaseDetailDebugLogRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.debuglog.BaseListDebugLogRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.debuglog.BaseCreateDebugLogResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.debuglog.BaseDetailDebugLogResponse;
import com.ruijie.rcos.base.sysmanage.module.def.dto.BaseDebugLogDTO;
import com.ruijie.rcos.base.sysmanage.module.impl.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.DebugLogEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.service.impl.DebugLogServiceImpl;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultPageResponse;

import mockit.*;
import mockit.integration.junit4.JMockit;

/**
 * Description: 调试日志服务类
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月25日
 *
 * @author fyq
 */
@RunWith(JMockit.class)
public class DebugLogAPIImplTest {

    @Tested
    private DebugLogAPIImpl debugLogAPI;

    @Injectable
    private DebugLogServiceImpl debugLogService;

    /**
     * 创建日志
     * 
     * @param apiRequest api
     * @throws BusinessException 异常
     */
    @Test
    public void testCreateDebugLog(@Tested BaseCreateDebugLogRequest apiRequest) throws BusinessException {

        new Expectations() {
            {
                debugLogService.createDebugLog();
            }
        };

        debugLogAPI.createDebugLog(apiRequest);

        new Verifications() {
            {
                debugLogService.createDebugLog();
                times = 1;
            }
        };
    }


    /**
     * 删除日志
     * 
     * @param apiRequest api
     * @throws BusinessException 异常
     */
    @Test
    public void testDeleteDebugLog(@Tested BaseDeleteDebugLogRequest apiRequest) throws BusinessException {

        UUID id = UUID.randomUUID();
        apiRequest.setId(id);

        new Expectations() {
            {
                debugLogService.deleteDebugLog(id);
            }
        };

        debugLogAPI.deleteDebugLog(apiRequest);

        new Verifications() {
            {
                debugLogService.deleteDebugLog(id);
                times = 1;
            }
        };
    }

    /**
     * 日志详情
     * 
     * @param apiRequest api
     * @param entity 实体
     * @throws BusinessException 异常
     */
    @Test
    public void testDetailDebugLog(@Tested BaseDetailDebugLogRequest apiRequest, @Tested DebugLogEntity entity) throws BusinessException {

        UUID id = UUID.randomUUID();
        apiRequest.setId(id);

        entity.setRealFileName("log.zip");

        new Expectations(Files.class) {
            {
                debugLogService.detailDebugLog(id);
                result = entity;
                debugLogService.getDebugLogPath();
                result = "/data/web/log";
                Files.exists((Path) any);
                result = true;
            }
        };

        BaseDetailDebugLogResponse response = debugLogAPI.detailDebugLog(apiRequest);

        Assert.assertEquals(response.getFilePath(), "/data/web/log" + File.separatorChar + "log.zip");
    }


    /**
     * 测试获取调试日志当文件不存在时
     * 
     * @param apiRequest 请求对象
     * @param entity 实体对象
     * @throws BusinessException 业务异常
     */
    @Test
    public void testDetailDebugLogWhileFileIsNotExist(@Tested BaseDetailDebugLogRequest apiRequest, @Tested DebugLogEntity entity) {

        UUID id = UUID.randomUUID();
        apiRequest.setId(id);

        entity.setRealFileName("log.zip");

        new Expectations(Files.class) {
            {
                debugLogService.detailDebugLog(id);
                result = entity;
                debugLogService.getDebugLogPath();
                result = "/data/web/log";
                Files.exists((Path) any);
                result = false;
            }
        };

        try {
            debugLogAPI.detailDebugLog(apiRequest);;
            Assert.fail();
        } catch (BusinessException e) {
            Assert.assertEquals(e.getMessage(), BusinessKey.BASE_SYS_MANAGE_LOG_FILE_NOT_EXIST);
        }


    }

    /**
     * list列表
     * 
     * @param apiRequest api
     *
     */
    @Test
    public void testListDebugLog(@Tested BaseListDebugLogRequest apiRequest) {

        int page = 0;
        int limit = 10;
        int total = 100;

        List<DebugLogEntity> entityList = new ArrayList<>();

        for (int i = 0; i < limit; i++) {
            entityList.add(new DebugLogEntity());
        }

        Page<DebugLogEntity> entityPage = new PageImpl(entityList, PageRequest.of(page, limit), total);

        new Expectations() {
            {
                debugLogService.listDebugLog(apiRequest);
                result = entityPage;
            }
        };

        DefaultPageResponse<BaseDebugLogDTO> response = debugLogAPI.listDebugLog(apiRequest);

        Assert.assertEquals(response.getItemArr().length, limit);
        Assert.assertEquals(response.getTotal(), total);
    }
}
