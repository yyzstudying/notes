package com.ruijie.rcos.base.sysmanage.module.impl.license;

import static org.junit.Assert.assertTrue;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.SimpleDateFormat;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import org.junit.Test;
import org.junit.runner.RunWith;
import com.ruijie.rcos.base.sysmanage.module.impl.license.utils.LicenseUtils;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.test.ThrowExceptionTester;
import mockit.Capturing;
import mockit.Expectations;
import mockit.Mock;
import mockit.MockUp;
import mockit.Mocked;
import mockit.Tested;
import mockit.integration.junit4.JMockit;

/**
 * Description: LicenseInitializer测试类
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月10日
 * 
 * @author zouqi
 */
@RunWith(JMockit.class)
public class LicenseUtilsTest {
    
    @Tested
    private LicenseUtils licenseUtils;
    
    @Capturing
    private Logger logger;
   
    /**
     * 验证sign()方法入参
     * 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testSignValidateParams() throws Exception {

        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseUtils.sign(null), "str 不能为空");

        assertTrue(true);
    }
    
    /**
     * sign 测试方法
     * 
     * @param messageDigest 
     * @param is 
     * @param cipher 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testSign(@Mocked MessageDigest messageDigest,@Mocked ObjectInputStream is, @Mocked Cipher cipher ) throws Exception {
        
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>75</time_slot>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_onoff>on</cm_onoff>\n" + 
                "</option>";
        byte[] contentArr = fileContent.getBytes();
        new Expectations() {
            {
                messageDigest.digest();
                result = contentArr;
                is.readObject();
                result = null;
                cipher.doFinal((byte[])any);
                result = contentArr;
                is.close();
                result = new IOException();
            }
        };

        
        licenseUtils.sign(fileContent);

        assertTrue(true);
    }
    
    /**
     * sign 测试方法
     * @param messageDigest 
     * @throws BusinessException 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testSign2(@Mocked MessageDigest messageDigest) throws BusinessException {
        
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>75</time_slot>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_onoff>on</cm_onoff>\n" + 
                "</option>";
        byte[] contentArr = fileContent.getBytes();
        new Expectations() {
            {
                messageDigest.digest();
                result = contentArr;
            }
        };
        
        licenseUtils.sign(fileContent);

        assertTrue(true);
    }
    
    /**
     * 验证checkSign()方法入参
     * 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCheckSignValidateParams() throws Exception {

        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseUtils.checkSign(null, ""), "info 不能为空");
        
        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseUtils.checkSign("", null), "sign 不能为空");

        assertTrue(true);
    }
    
    /**
     * checkSign 测试方法
     * @param messageDigest 
     * @param cipher 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCheckSign(@Mocked MessageDigest messageDigest, @Mocked Cipher cipher ) throws Exception {
        
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>75</time_slot>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_onoff>on</cm_onoff>\n" + 
                "</option>";
        byte[] contentArr = fileContent.getBytes();
        new Expectations() {
            {
                messageDigest.digest();
                result = contentArr;
            }
        };

        
        licenseUtils.checkSign(fileContent, "G1MQ2TP000075");

        assertTrue(true);
    }
    
    /**
     * checkSign 测试方法
     * @param messageDigest 
     * @param cipher 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCheckSign2(@Mocked MessageDigest messageDigest, @Mocked Cipher cipher ) throws Exception {
        
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>75</time_slot>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_onoff>on</cm_onoff>\n" + 
                "</option>";
        byte[] contentArr = fileContent.getBytes();
        new Expectations() {
            {
                messageDigest.digest();
                result = contentArr;
                cipher.doFinal((byte[])any);
                result = new byte[390];
            }
        };

        new MockUp<Integer>() {
            @Mock
            public int parseInt(String s, int radix) throws NumberFormatException {
                return 48;
            }
        };
        
        licenseUtils.checkSign(fileContent, "G1MQ2TP0000751111255");

        assertTrue(true);
    }
    
    /**
     * checkSign 测试方法
     * @param messageDigest 
     * @param cipher 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCheckSign3(@Mocked MessageDigest messageDigest, @Mocked Cipher cipher ) throws Exception {
        
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>75</time_slot>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_onoff>on</cm_onoff>\n" + 
                "</option>";
        byte[] contentArr = fileContent.getBytes();
        new Expectations() {
            {
                messageDigest.digest();
                result = contentArr;
            }
        };

        new MockUp<Integer>() {
            @Mock
            public int parseInt(String s, int radix) throws NumberFormatException {
                return 48;
            }
        };
        
        licenseUtils.checkSign(fileContent, "G1MQ2TP000075");

        assertTrue(true);
    }
    
    /**
     * checkSign 测试方法
     * @param messageDigest 
     * @param cipher 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCheckSign4(@Mocked MessageDigest messageDigest, @Mocked Cipher cipher ) throws Exception {
        
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>75</time_slot>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_onoff>on</cm_onoff>\n" + 
                "</option>";
        byte[] contentArr = fileContent.getBytes();
        new Expectations() {
            {
                messageDigest.digest();
                result = contentArr;
                cipher.doFinal((byte[])any);
                result = contentArr;
            }
        };

        new MockUp<Integer>() {
            @Mock
            public int parseInt(String s, int radix) throws NumberFormatException {
                return 48;
            }
        };
        
        licenseUtils.checkSign(fileContent, "G1MQ2TP0000751111255");

        assertTrue(true);
    }
    
    /**
     * checkSign 测试方法
     * @param messageDigest 
     * @param cipher 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCheckSign5(@Mocked MessageDigest messageDigest, @Mocked Cipher cipher ) throws Exception {
        
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>75</time_slot>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_onoff>on</cm_onoff>\n" + 
                "</option>";
        new Expectations() {
            {
                messageDigest.digest();
                result = null;
                cipher.doFinal((byte[])any);
                result = null;
            }
        };

        new MockUp<Integer>() {
            @Mock
            public int parseInt(String s, int radix) throws NumberFormatException {
                return 48;
            }
        };
        
        licenseUtils.checkSign(fileContent, "G1MQ2TP0000751111255");

        assertTrue(true);
    }
    
    /**
     * checkSign 测试方法
     * @param messageDigest 
     * @param cipher 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCheckSign7(@Mocked MessageDigest messageDigest, @Mocked Cipher cipher ) throws Exception {
        
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>75</time_slot>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_onoff>on</cm_onoff>\n" + 
                "</option>";
        byte[] contentArr = fileContent.getBytes();
        new Expectations() {
            {
                messageDigest.digest();
                result = contentArr;
                cipher.doFinal((byte[])any);
                result = null;
            }
        };

        new MockUp<Integer>() {
            @Mock
            public int parseInt(String s, int radix) throws NumberFormatException {
                return 48;
            }
        };
        
        licenseUtils.checkSign(fileContent, "G1MQ2TP0000751111255");

        assertTrue(true);
    }
    
    /**
     * checkSign 测试方法
     * @param messageDigest 
     * @param cipher 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testCheckSign8(@Mocked MessageDigest messageDigest, @Mocked Cipher cipher ) throws Exception {
        
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>75</time_slot>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_onoff>on</cm_onoff>\n" + 
                "</option>";
        byte[] contentArr = fileContent.getBytes();
        new Expectations() {
            {
                messageDigest.digest();
                result = null;
                cipher.doFinal((byte[])any);
                result = contentArr;
            }
        };

        new MockUp<Integer>() {
            @Mock
            public int parseInt(String s, int radix) throws NumberFormatException {
                return 48;
            }
        };
        
        licenseUtils.checkSign(fileContent, "G1MQ2TP0000751111255");

        assertTrue(true);
    }
    /**
     * checkSign 测试方法
     * @param messageDigest 
     * @param cipher 
     * @throws Exception 异常
     */
    
    @SuppressWarnings("static-access")
    @Test
    public void testCheckSign9(@Mocked MessageDigest messageDigest, @Mocked Cipher cipher ) throws Exception {
        
        String fileContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
                "\n" + 
                "<option>\n" + 
                "  <dev_id>G1MQ2TP000075</dev_id>\n" + 
                "  <feature_id>RCC-CM-NUM</feature_id>\n" + 
                "  <pak>RCC-CM-NUM-6000000192014003</pak>\n" + 
                "  <date>1551937394</date>\n" + 
                "  <time_slot>75</time_slot>\n" + 
                "  <dev_code>3697087b-a8f9-45d7-b745-cf08495a9cbd</dev_code>\n" + 
                "  <multi-inst>1</multi-inst>\n" + 
                "  <lic-class-id>2019030713395759280</lic-class-id>\n" + 
                "  <cm_onoff>on</cm_onoff>\n" + 
                "</option>";
        byte[] contentArr = fileContent.getBytes();
        new Expectations() {
            {
                messageDigest.digest();
                result = new byte[12];
                cipher.doFinal((byte[])any);
                result = contentArr;
            }
        };

        new MockUp<Integer>() {
            @Mock
            public int parseInt(String s, int radix) throws NumberFormatException {
                return 48;
            }
        };
        
        licenseUtils.checkSign(fileContent, "G1MQ2TP0000751111255");

        assertTrue(true);
    }
    
    /**
     * 验证decryptPaLic()方法入参
     * 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testDecryptPaLicValidateParams() throws Exception {

        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseUtils.decryptPaLic(null), "File 不能为空");

        assertTrue(true);
    }
    
    /**
     * decryptPaLic 测试方法
     * 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testDecryptPaLic() throws Exception {
        
        String filePath = Thread.currentThread().getContextClassLoader().getResource("").getPath() + "license/RCC-CM-NUM-6000000191027090-正式.lic";
        File file = new File(filePath);
        

        new MockUp<File>() {
            @Mock
            public boolean exists() {
                return true;
            }
        };
        
        licenseUtils.decryptPaLic(file);

        assertTrue(true);
    }
    
    /**
     * decryptPaLic 测试方法
     * 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testDecryptPaLic2() throws Exception {
        
        String filePath = Thread.currentThread().getContextClassLoader().getResource("").getPath() + "license/RCC-CM-NUM-6000000191027090-正式.lic";
        File file = new File(filePath);
        

        new MockUp<File>() {
            @Mock
            public boolean exists() {
                return false;
            }
        };
        
        licenseUtils.decryptPaLic(file);

        assertTrue(true);
    }
    
    /**
     * decryptPaLic 测试方法
     * 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testDecryptPaLic3() throws Exception {
        
        String filePath = Thread.currentThread().getContextClassLoader().getResource("").getPath() + "license/RCC-CM-NUM-6000000191027090-正式.lic";
        File file = new File(filePath);
        new MockUp<File>() {
            @Mock
            public boolean exists() {
                return true;
            }
        };
        
        licenseUtils.decryptPaLic(file);

        assertTrue(true);
    }
    
    /**
     * decryptPaLic 测试方法
     * @param cipher 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testDecryptPaLic4(@Mocked Cipher cipher ) throws Exception {
        
        String filePath = Thread.currentThread().getContextClassLoader().getResource("").getPath() + "license/RCC-CM-NUM-6000000191027090-正式.lic";
        File file = new File(filePath);
        
        new Expectations() {
            {
                cipher.doFinal((byte[])any);
                result = new NoSuchAlgorithmException();
            }
        };
        
        new MockUp<File>() {
            @Mock
            public boolean exists() {
                return true;
            }
        };
        
        licenseUtils.decryptPaLic(file);

        assertTrue(true);
    }
    
    /**
     * decryptPaLic 测试方法
     * @param cipher 
     * 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testDecryptPaLic5(@Mocked Cipher cipher ) throws Exception {
        
        String filePath = Thread.currentThread().getContextClassLoader().getResource("").getPath() + "license/RCC-CM-NUM-6000000191027090-正式.lic";
        File file = new File(filePath);
        
        new Expectations() {
            {
                cipher.doFinal((byte[])any);
                result = new InvalidKeySpecException();
            }
        };
        
        new MockUp<File>() {
            @Mock
            public boolean exists() {
                return true;
            }
        };
        
        licenseUtils.decryptPaLic(file);

        assertTrue(true);
    }
    
    /**
     * decryptPaLic 测试方法
     * @param cipher 
     * 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testDecryptPaLic6(@Mocked Cipher cipher ) throws Exception {
        
        String filePath = Thread.currentThread().getContextClassLoader().getResource("").getPath() + "license/RCC-CM-NUM-6000000191027090-正式.lic";
        File file = new File(filePath);
        
        new Expectations() {
            {
                cipher.doFinal((byte[])any);
                result = new NoSuchPaddingException();
            }
        };
        
        new MockUp<File>() {
            @Mock
            public boolean exists() {
                return true;
            }
        };
        
        licenseUtils.decryptPaLic(file);

        assertTrue(true);
    }
    
    /**
     * decryptPaLic 测试方法
     * @param cipher 
     * 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testDecryptPaLic7(@Mocked Cipher cipher ) throws Exception {
        
        String filePath = Thread.currentThread().getContextClassLoader().getResource("").getPath() + "license/RCC-CM-NUM-6000000191027090-正式.lic";
        File file = new File(filePath);
        
        new Expectations() {
            {
                cipher.doFinal((byte[])any);
                result = new BadPaddingException();
            }
        };
        
        new MockUp<File>() {
            @Mock
            public boolean exists() {
                return true;
            }
        };
        
        licenseUtils.decryptPaLic(file);

        assertTrue(true);
    }
    
    /**
     * decryptPaLic 测试方法
     * @param cipher 
     * 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testDecryptPaLic9(@Mocked Cipher cipher ) throws Exception {
        
        String filePath = Thread.currentThread().getContextClassLoader().getResource("").getPath() + "license/RCC-CM-NUM-6000000191027090-正式.lic";
        File file = new File(filePath);
        
        new Expectations() {
            {
                cipher.doFinal((byte[])any);
                result = new IllegalBlockSizeException();
            }
        };
        
        new MockUp<File>() {
            @Mock
            public boolean exists() {
                return true;
            }
        };
        
        licenseUtils.decryptPaLic(file);

        assertTrue(true);
    }
    
    /**
     * decryptPaLic 测试方法
     * @param cipher 
     * 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testDecryptPaLic10(@Mocked Cipher cipher ) throws Exception {
        
        String filePath = Thread.currentThread().getContextClassLoader().getResource("").getPath() + "license/RCC-CM-NUM-6000000191027090-正式.lic";
        File file = new File(filePath);
        
        new Expectations() {
            {
                cipher.doFinal((byte[])any);
                result = new InvalidKeyException();
            }
        };
        
        new MockUp<File>() {
            @Mock
            public boolean exists() {
                return true;
            }
        };
        
        licenseUtils.decryptPaLic(file);

        assertTrue(true);
    }
    
    /**
     * decryptPaLic 测试方法
     * @param cipher 
     * 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testDecryptPaLic11(@Mocked Cipher cipher ) throws Exception {
        
        String filePath = Thread.currentThread().getContextClassLoader().getResource("").getPath() + "license/RCC-CM-NUM-6000000191027090-正式.lic";
        File file = new File(filePath);
        
        new Expectations() {
            {
                cipher.doFinal((byte[])any);
                result = new IOException();
            }
        };
        
        new MockUp<File>() {
            @Mock
            public boolean exists() {
                return true;
            }
        };
        
        licenseUtils.decryptPaLic(file);

        assertTrue(true);
    }
    
    /**
     * 验证formateTime()方法入参
     * 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testFormateTimeValidateParams() throws Exception {

        ThrowExceptionTester.throwIllegalArgumentException(
            () -> licenseUtils.formateTime(null), "Date-String 不能为空");

        assertTrue(true);
    }
    
    /**
     * formateTime 测试方法
     * 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testFormateTime() throws Exception {
        
        String date = "2018-10-11";
        licenseUtils.formateTime(date);
        assertTrue(true);
    }
    
    /**
     * formateTime 测试方法
     * 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testFormateTime2() throws Exception {
        
        String date = "xs";
        licenseUtils.formateTime(date);
        assertTrue(true);
    }
    
    /**
     * formateTime 测试方法
     * @param sdf 
     * @throws Exception 异常
     */
    @SuppressWarnings("static-access")
    @Test
    public void testFormateTime3(@Mocked SimpleDateFormat sdf) throws Exception {
        
        String date = "xs";
        new Expectations() {
            {
                sdf.parse((String)any);
                result = null;
            }
        };
        licenseUtils.formateTime(date);
        assertTrue(true);
    }
}
