package com.ruijie.rcos.base.sysmanage.module.impl.quartz.dispatcher;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;

import com.ruijie.rcos.base.aaa.module.def.api.BaseSystemLogMgmtAPI;
import com.ruijie.rcos.base.aaa.module.def.api.request.systemlog.BaseCreateSystemLogRequest;
import com.ruijie.rcos.base.sysmanage.module.impl.common.Constants;
import com.ruijie.rcos.base.sysmanage.module.impl.quartz.data.ComponentQuartzTaskData;
import com.ruijie.rcos.sk.base.log.Logger;

import mockit.*;
import mockit.integration.junit4.JMockit;

/**
 * Description: 组件测试
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月25日
 *
 * @author fyq
 */

@RunWith(JMockit.class)
public class ComponentJobDispatcherTest {

    @Tested
    private ComponentJobDispatcher componentJobDispatcher;

    @Injectable
    private BaseSystemLogMgmtAPI baseSystemLogMgmtAPI;

    @Mocked
    private BaseCreateSystemLogRequest baseCreateSystemLogRequest;

    @Capturing
    Logger logger;

    /**
     *
     * @param context 上下文
     * @param quartzTaskData 任务数据
     */
    @Test
    public void testDispatcher(@Mocked JobExecutionContext context, @Mocked ComponentQuartzTaskData quartzTaskData) {

        JobDataMap jobDataMap = new JobDataMap();
        jobDataMap.put(Constants.SCHEDULE_DATA_KEY, quartzTaskData);

        new Expectations() {
            {
                context.getJobDetail().getJobDataMap();
                result = jobDataMap;
                baseSystemLogMgmtAPI.createSystemLog((BaseCreateSystemLogRequest) any);
                result = null;
            }
        };
        componentJobDispatcher.dispatcher(context);
        new Verifications() {
            {
                baseSystemLogMgmtAPI.createSystemLog((BaseCreateSystemLogRequest) any);
                times = 1;
            }
        };
    }

    /**
     *
     * @param context 上下问
     * @param quartzTask 任务
     */
    @Test
    public void testDispatcherExecuteFail(@Mocked JobExecutionContext context, @Mocked ComponentQuartzTaskData quartzTask) {

        JobDataMap jobDataMap = new JobDataMap();
        jobDataMap.put(Constants.SCHEDULE_DATA_KEY, quartzTask);

        new Expectations() {
            {
                context.getJobDetail().getJobDataMap();
                result = jobDataMap;
                baseSystemLogMgmtAPI.createSystemLog((BaseCreateSystemLogRequest) any);
                returns(new Throwable(), null);
                logger.error(anyString, (Throwable) any);

            }
        };

        componentJobDispatcher.dispatcher(context);


        new Verifications() {
            {
                context.getJobDetail().getJobDataMap();
                times = 1;
                logger.error(anyString, (Throwable) any);
                times = 1;
            }
        };
    }
}
