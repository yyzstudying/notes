package com.ruijie.rcos.base.sysmanage.module.impl.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import com.ruijie.rcos.base.sysmanage.module.impl.BusinessKey;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.ruijie.rcos.base.sysmanage.module.def.enums.TaskCycle;
import com.ruijie.rcos.sk.base.log.Logger;

import mockit.Capturing;
import mockit.Expectations;
import mockit.Tested;
import mockit.Verifications;
import mockit.integration.junit4.JMockit;

/**
 * Description: 计划工具类测试
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月25日
 *
 * @author yeyuzhong
 */
@RunWith(JMockit.class)
public class ScheduleTaskUtilTest {

    @Tested
    ScheduleTaskUtil scheduleTaskUtil;

    @Capturing
    Logger logger;

    /**
     * 定时任务参数校验
     */
    @Test
    public void testValidateScheduleTaskArgsWEEK() throws BusinessException {

        LocalDate scheduleDate = LocalDate.parse("2019-06-10");
        LocalTime scheduleTime = LocalTime.parse("12:12:12");
        new Expectations() {
            {
                logger.debug(anyString, (Integer[]) any);
            }
        };

        scheduleTaskUtil.validateScheduleTaskArgs(TaskCycle.WEEK, new Integer[] {1, 2}, scheduleDate, scheduleTime);
        new Verifications() {
            {
                logger.debug(anyString, (Integer[]) any);
                times = 1;
            }
        };
    }

    /**
     * 校验计划任务
     */
    @Test
    public void testValidateScheduleTaskArgsWEEKErr() throws BusinessException {

        LocalDate scheduleDate = LocalDate.parse("2019-06-10");
        LocalTime scheduleTime = LocalTime.parse("12:12:12");
        try {
            scheduleTaskUtil.validateScheduleTaskArgs(TaskCycle.WEEK, new Integer[] {1, 9}, scheduleDate, scheduleTime);

        } catch (IllegalStateException e) {
            Assert.assertEquals(e.getMessage(), "星期几参数格式错误");
        }
    }

    /**
     * 校验计划任务ONCE
     */
    @Test
    public void testValidateScheduleTaskArgsONCE() throws BusinessException {

        LocalDate scheduleDate = LocalDate.parse("2019-06-10");
        LocalTime scheduleTime = LocalTime.parse("12:12:12");
        scheduleTaskUtil.validateScheduleTaskArgs(TaskCycle.ONCE, new Integer[] {1, 2}, scheduleDate, scheduleTime);
        new Verifications() {
            {
                logger.debug(anyString, (Integer[]) any);
                times = 0;
            }
        };
    }

    /**
     * 其他类型
     */
    @Test
    public void testValidateScheduleTaskArgsOther() throws BusinessException {

        LocalDate scheduleDate = LocalDate.parse("2019-06-10");
        LocalTime scheduleTime = LocalTime.parse("12:12:12");

        scheduleTaskUtil.validateScheduleTaskArgs(TaskCycle.DAY, new Integer[] {1, 2}, scheduleDate, scheduleTime);
        new Verifications() {
            {
                logger.debug(anyString, (Integer[]) any);
                times = 0;
            }
        };
    }

    /**
     * 测试校验一次性任务时间不能超过100年
     * 
     * @throws BusinessException 业务异常
     */
    @Test
    public void testValidateScheduleTaskArgsWhileTimeOneHundredYearAfterNow() throws BusinessException {
        LocalDateTime localDateTime = LocalDateTime.now().plusYears(100).plusMinutes(30);

        LocalDate scheduleDate = localDateTime.toLocalDate();
        LocalTime scheduleTime = localDateTime.toLocalTime();
        try {
            scheduleTaskUtil.validateScheduleTaskArgs(TaskCycle.ONCE, new Integer[] {1, 2}, scheduleDate, scheduleTime);
            Assert.fail();
        } catch (BusinessException e) {
            Assert.assertEquals(e.getMessage(), BusinessKey.BASE_SYS_MANAGE_ONE_HUNDRED_YEAR_AFTER_NOW);
        }

        new Verifications() {
            {
                logger.debug(anyString, (Integer[]) any);
                times = 0;
            }
        };
    }
}
