package com.ruijie.rcos.base.sysmanage.module.impl.api;

import org.junit.Test;
import org.junit.runner.RunWith;

import com.ruijie.rcos.base.sysmanage.module.def.api.request.systemtime.BaseUpdateSystemTimeFromNtpRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.systemtime.BaseUpdateSystemTimeRequest;
import com.ruijie.rcos.base.sysmanage.module.impl.service.impl.SystemTimeServiceImpl;
import com.ruijie.rcos.sk.base.exception.BusinessException;

import mockit.Expectations;
import mockit.Injectable;
import mockit.Tested;
import mockit.Verifications;
import mockit.integration.junit4.JMockit;

/**
 * Description: 系统时间接口实现类
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月25日
 *
 * @author fyq
 */

@RunWith(JMockit.class)
public class SystemTimeAPIImplTest {

    @Tested
    private SystemTimeAPIImpl systemTimeAPI;

    @Injectable
    private SystemTimeServiceImpl systemTimeService;

    /**
     * 更新系统时间
     * 
     * @param apiRequest api
     * @throws BusinessException 异常
     */
    @Test
    public void testSystemTimeUpdate(@Tested BaseUpdateSystemTimeRequest apiRequest) throws BusinessException {

        apiRequest.setTime(System.currentTimeMillis());

        new Expectations() {
            {
                systemTimeService.updateSystemTime(anyLong);
            }
        };

        systemTimeAPI.updateSystemTime(apiRequest);

        new Verifications() {
            {
                systemTimeService.updateSystemTime(anyLong);
                times = 1;
            }
        };
    }

    /**
     * 、
     * 系统时间Nto
     * 
     * @param apiRequest api
     * @throws BusinessException 异常
     */
    @Test
    public void testSystemTimeUpdateFromNtp(@Tested BaseUpdateSystemTimeFromNtpRequest apiRequest) throws BusinessException {

        apiRequest.setNtpServer("ntp://xxx");

        new Expectations() {
            {
                systemTimeService.updateSystemTimeFromNtp(anyString);
            }
        };

        systemTimeAPI.updateSystemTimeFromNtp(apiRequest);

        new Verifications() {
            {
                systemTimeService.updateSystemTimeFromNtp(anyString);
                times = 1;
            }
        };
    }

}
