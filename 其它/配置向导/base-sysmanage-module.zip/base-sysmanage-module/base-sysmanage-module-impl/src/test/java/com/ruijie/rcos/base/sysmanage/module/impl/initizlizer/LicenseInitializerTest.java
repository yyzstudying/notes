package com.ruijie.rcos.base.sysmanage.module.impl.initizlizer;

import org.junit.Test;
import org.junit.runner.RunWith;
import com.ruijie.rcos.base.sysmanage.module.impl.service.LicenseFileService;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import mockit.Injectable;
import mockit.Tested;
import mockit.Verifications;
import mockit.integration.junit4.JMockit;

/**
 * Description: LicenseInitializer测试类
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月10日
 * 
 * @author zouqi
 */
@RunWith(JMockit.class)
public class LicenseInitializerTest {
    
    @Tested
    private LicenseInitializer licenseInitializer;
    
    @Injectable
    private LicenseFileService licenseFileService;
    
    
    /**
     * safeInit 测试方法
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testSafeInit() throws BusinessException {

        licenseInitializer.safeInit();

        new Verifications() {
            {
                licenseFileService.initLicense();
                times = 1;
            }
        };
    }
}
