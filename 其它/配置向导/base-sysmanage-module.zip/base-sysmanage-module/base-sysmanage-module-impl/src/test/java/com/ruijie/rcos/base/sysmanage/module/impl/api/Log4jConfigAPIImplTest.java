package com.ruijie.rcos.base.sysmanage.module.impl.api;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.apache.logging.log4j.Level;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.ruijie.rcos.base.sysmanage.module.def.api.request.log4jconfig.BaseAddLog4jConfigRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.log4jconfig.BaseDetailLog4jConfigRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.log4jconfig.BaseEditLog4jConfigRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.log4jconfig.BaseListLog4jConfigRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.log4jconfig.BaseRemoveLog4jConfigRequest;
import com.ruijie.rcos.base.sysmanage.module.impl.dao.Log4jConfigDAO;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.Log4jConfigEntity;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.log4j.SkyEngineLoggerManager;

import mockit.Deencapsulation;
import mockit.Expectations;
import mockit.Injectable;
import mockit.Mock;
import mockit.MockUp;
import mockit.Tested;
import mockit.Verifications;
import mockit.integration.junit4.JMockit;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年02月20日
 *
 * @author GuoZhouYue
 */
@RunWith(JMockit.class)
public class Log4jConfigAPIImplTest {

    @Tested
    Log4jConfigAPIImpl impl;

    @Injectable
    Log4jConfigDAO log4jConfigDAO;

    /**
     * testGetAll
     *
     * @param all all
     * @param request request
     */
    @Test
    public void testGetAll(@Injectable Page<Log4jConfigEntity> all, @Injectable BaseListLog4jConfigRequest request) {
        final SkyEngineLoggerManager manager = SkyEngineLoggerManager.getInstance();
        Deencapsulation.setField(impl, "loggerManager", manager);

        List<Log4jConfigEntity> resultList = new ArrayList<>();
        final Log4jConfigEntity entity = new Log4jConfigEntity();
        entity.setId(UUID.randomUUID());
        entity.setLoggerName("test");
        entity.setLoggerLevel("INFO");
        resultList.add(entity);

        new MockUp<SkyEngineLoggerManager>() {
            @Mock
            public void addCustomLogger(String name, Level level) {

            }
        };

        new Expectations() {
            {
                request.getPage();
                result = 0;

                request.getLimit();
                result = 10;

                log4jConfigDAO.findAll((Pageable) any);
                result = all;

                all.getContent();
                result = resultList;
            }
        };

        impl.getAll(request);
    }

    /**
     * testGetOne
     *
     * @param request request
     * @throws BusinessException BusinessException
     */
    @Test
    public void testGetOne(@Injectable BaseDetailLog4jConfigRequest request) throws BusinessException {

        final UUID uuid = UUID.randomUUID();
        final Log4jConfigEntity entity = new Log4jConfigEntity();
        new Expectations() {
            {
                request.getId();
                result = uuid;

                log4jConfigDAO.findById(uuid);
                result = Optional.ofNullable(entity);
            }
        };

        impl.getOne(request);
    }

    /**
     * testAddConfig
     *
     * @param request request
     * @throws BusinessException BusinessException
     */
    @Test
    public void testAddConfig(@Injectable BaseAddLog4jConfigRequest request) throws BusinessException {

        final SkyEngineLoggerManager manager = SkyEngineLoggerManager.getInstance();
        Deencapsulation.setField(impl, "loggerManager", manager);

        new Expectations() {
            {
                request.getLoggerName();
                result = "testLogger";

                request.getLoggerLevel();
                result = "ERROR";

                log4jConfigDAO.existsByLoggerName("testLogger");
                result = false;

                log4jConfigDAO.save((Log4jConfigEntity) any);

                manager.addCustomLogger("testLogger", Level.ERROR);
            }
        };

        impl.addConfig(request);

    }

    /**
     * testAddConfigExp
     *
     * @param request request
     * @throws BusinessException BusinessException
     */
    @Test(expected = BusinessException.class)
    public void testAddConfigExp(@Injectable BaseAddLog4jConfigRequest request) throws BusinessException {

        final SkyEngineLoggerManager manager = SkyEngineLoggerManager.getInstance();
        Deencapsulation.setField(impl, "loggerManager", manager);

        new Expectations() {
            {
                request.getLoggerName();
                result = "testLogger";

                request.getLoggerLevel();
                result = "ERROR";

                log4jConfigDAO.existsByLoggerName("testLogger");
                result = true;
            }
        };

        impl.addConfig(request);

    }

    /**
     * testRemoveConfig
     *
     * @param request request
     * @throws BusinessException BusinessException
     */
    @Test
    public void testRemoveConfig(@Injectable BaseRemoveLog4jConfigRequest request) throws BusinessException {
        final UUID uuid = UUID.randomUUID();
        final Log4jConfigEntity entity = new Log4jConfigEntity();
        entity.setId(uuid);
        entity.setLoggerName("loggerName");
        entity.setLoggerLevel("INFO");

        final SkyEngineLoggerManager manager = SkyEngineLoggerManager.getInstance();
        Deencapsulation.setField(impl, "loggerManager", manager);

        new MockUp<SkyEngineLoggerManager>() {
            @Mock
            public Level removeCustomLogger(String name) {
                return Level.INFO;
            }
        };

        new Expectations() {
            {
                log4jConfigDAO.findById((UUID) any);
                result = Optional.of(entity);
            }
        };

        impl.removeConfig(request);
    }

    /**
     * testEditConfig
     *
     * @throws BusinessException BusinessException
     */
    @Test
    public void testEditConfig() throws BusinessException {
        BaseEditLog4jConfigRequest request = new BaseEditLog4jConfigRequest();
        request.setLoggerName("edited");
        request.setLoggerLevel("INFO");

        final UUID uuid = UUID.randomUUID();
        final Log4jConfigEntity entity = new Log4jConfigEntity();
        entity.setId(uuid);
        entity.setLoggerName("test");
        entity.setLoggerLevel("ERROR");

        final SkyEngineLoggerManager loggerManager = Deencapsulation.getField(impl, "loggerManager");

        new MockUp<SkyEngineLoggerManager>() {
            @Mock
            public void editCustomLogger(String name, Level level) {

            }
        };

        new Expectations() {
            {
                request.getId();
                result = uuid;

                log4jConfigDAO.findById(request.getId());
                result = Optional.of(entity);

                log4jConfigDAO.save(entity);
            }
        };

        impl.editConfig(request);
        assertEquals("edited", entity.getLoggerName());
        assertEquals("INFO", entity.getLoggerLevel());

        new Verifications() {
            {

                log4jConfigDAO.save(entity);
                times = 1;

                loggerManager.editCustomLogger("edited", Level.INFO);
                times = 1;
            }
        };
    }

    /**
     * testSafeInit
     */
    @Test
    public void testSafeInit() {
        List<Log4jConfigEntity> initList = new ArrayList<>();
        final Log4jConfigEntity entity = new Log4jConfigEntity();
        entity.setId(UUID.randomUUID());
        entity.setLoggerName("test");
        entity.setLoggerLevel("ERROR");

        final SkyEngineLoggerManager loggerManager = Deencapsulation.getField(impl, "loggerManager");
        Deencapsulation.setField(impl,"loggerManager",  loggerManager);

        new MockUp<SkyEngineLoggerManager>() {
            @Mock
            public void addCustomLogger(String name, Level level) {

            }
        };

        new Expectations() {
            {
                log4jConfigDAO.findAll();
                result = initList;
            }
        };

        impl.safeInit();

        new Verifications() {
            {
                log4jConfigDAO.findAll();
                times = 1;

                loggerManager.addCustomLogger("test", Level.ERROR);
                times = 1;
            }
        };
    }
}
