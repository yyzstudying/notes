package com.ruijie.rcos.base.sysmanage.module.impl.api;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

import com.ruijie.rcos.base.sysmanage.module.def.api.request.debuglog.BaseCreateDebugLogRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.databackup.BaseCreateDataBackupResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.debuglog.BaseCreateDebugLogResponse;
import com.ruijie.rcos.base.sysmanage.module.impl.BusinessKey;
import mockit.*;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import com.ruijie.rcos.base.sysmanage.module.def.api.request.databackup.BaseCreateDataBackupRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.databackup.BaseDeleteDataBackupRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.databackup.BaseListDataBackupRequest;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.DataBackupEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.service.impl.DataBackupServiceImpl;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultPageResponse;

import mockit.integration.junit4.JMockit;

/**
 * Description: 数据库备份API实现
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月25日
 *
 * @author xgx
 */
@RunWith(JMockit.class)
public class DataBackupAPIImplTest {

    @Tested
    private DataBackupAPIImpl dataBackupAPI;

    @Injectable
    private DataBackupServiceImpl dataBackupService;

    /**
     * 数据库备份
     * 
     * @param apiRequest aoi
     * @throws BusinessException 异常
     */
    @Test
    public void testDataBackup(@Tested BaseCreateDataBackupRequest apiRequest) throws BusinessException {

        new Expectations() {
            {
                dataBackupService.createDataBackup(false);
            }
        };

        dataBackupAPI.createDataBackup(apiRequest);

        new Verifications() {
            {
                dataBackupService.createDataBackup(false);
                times = 1;
            }
        };
    }


    /**
     * 删除备份
     * 
     * @param apiRequest api
     * @throws BusinessException 异常
     */
    @Test
    public void testDeleteDataBackup(@Tested BaseDeleteDataBackupRequest apiRequest) throws BusinessException {

        UUID id = UUID.randomUUID();
        apiRequest.setId(id);

        new Expectations() {
            {
                dataBackupService.deleteDataBackup(id);
            }
        };

        dataBackupAPI.deleteDataBackup(apiRequest);

        new Verifications() {
            {
                dataBackupService.deleteDataBackup(id);
                times = 1;
            }
        };
    }

    /**
     * 查询备份
     * 
     * @param apiRequest api
     */
    @Test
    public void testListDataBackup(@Tested BaseListDataBackupRequest apiRequest) {

        int page = 1;
        int limit = 10;
        int total = 100;

        List<DataBackupEntity> entityList = new ArrayList<>();
        for (int i = 0; i < limit; i++) {
            entityList.add(new DataBackupEntity());
        }
        Page<DataBackupEntity> entityPage = new PageImpl<>(entityList, PageRequest.of(page, limit), total);

        new Expectations() {
            {
                dataBackupService.listDataBackup((BaseListDataBackupRequest) any);
                result = entityPage;
            }
        };

        DefaultPageResponse response = dataBackupAPI.listDataBackup(apiRequest);

        Assert.assertEquals(response.getItemArr().length, limit);
        Assert.assertEquals(response.getTotal(), total);
    }
}
