package com.ruijie.rcos.base.sysmanage.module.impl.service.impl;

import java.io.File;
import java.util.*;

import com.ruijie.rcos.sk.base.i18n.LocaleI18nResolver;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.DebugLogEntity;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import com.google.common.collect.Maps;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.databackup.BaseListDataBackupRequest;
import com.ruijie.rcos.base.sysmanage.module.impl.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.impl.common.Constants;
import com.ruijie.rcos.base.sysmanage.module.impl.dao.DataBackupDAO;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.DataBackupEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.service.query.DataBackupSpecification;
import com.ruijie.rcos.sk.base.config.ConfigFacade;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.filesystem.SkyengineFile;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.shell.ShellCommandRunner;
import com.ruijie.rcos.sk.base.test.GetSetTester;
import com.ruijie.rcos.sk.modulekit.api.tool.GlobalParameterAPI;

import mockit.*;
import mockit.integration.junit4.JMockit;

/**
 * Description: 数据库备份服务实现类
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月25日
 *
 * @author fyq
 */

@RunWith(JMockit.class)
public class DataBackupServiceImplTest {

    @Tested
    private DataBackupServiceImpl dataBackupService;

    @Injectable
    private DataBackupDAO dataBackupDAO;

    @Injectable
    private GlobalParameterAPI globalParameterAPI;

    @Injectable
    private ConfigFacade configFacade;

    @Capturing
    private ShellCommandRunner runner;

    @Capturing
    private Logger logger;

    /**
     * 测试实体
     */
    @Test
    public void testEntity() {
        GetSetTester getSetTester = new GetSetTester(DataBackupEntity.class);
        getSetTester.runTest();

        getSetTester = new GetSetTester(DebugLogEntity.class);
        getSetTester.runTest();

        new DataBackupEntity().toString();
        new DebugLogEntity().toString();

        Assert.assertTrue(true);
    }

    /**
     * 创建备份
     * 
     * @throws BusinessException 异常
     */
    @Test
    public void testCreateDataBackupConfigMapIsNull() throws BusinessException {


        Map<String, String> configMap = Maps.newHashMap();
        configMap.put("datasource.public.dbname", "skyengine");
        configMap.put("datasource.default.dbname", "rcdc");
        configMap.put("datasource.default.username", "postgres");
        configMap.put("datasource.default.backup", "false");

        new Expectations(LocaleI18nResolver.class) {
            {
                LocaleI18nResolver.resolve(anyString);
                result = "xxx";
                configFacade.readByPrefix("datasource");
                result = configMap;
                dataBackupDAO.save((DataBackupEntity) any);

            }
        };

        dataBackupService.createDataBackup(false);

        new Verifications() {
            {
                runner.setCommand(Constants.SH_DATA_BACKUP);
                times = 1;
                runner.appendArgs(anyString, anyString, anyString);
                times = 1;
                runner.execute();
                times = 1;
                dataBackupDAO.save((DataBackupEntity) any);
                times = 1;
                configFacade.readByPrefix("datasource");
                times = 1;
            }
        };
    }

    /**
     * 创建备份
     *
     * @throws BusinessException 异常
     */
    @Test
    public void testCreateDataBackup() throws BusinessException {

        String dbList = "skyengine";

        Map<String, String> configMap = Maps.newHashMap();
        configMap.put("datasource.public.dbname", "skyengine");
        configMap.put("datasource.default.dbname", "rcdc");
        configMap.put("datasource.default.username", "postgres");
        configMap.put("datasource.default.backup", "false");

        new Expectations(LocaleI18nResolver.class) {
            {
                LocaleI18nResolver.resolve(anyString);
                result = "xxx";
                configFacade.readByPrefix("datasource");
                result = configMap;
                dataBackupDAO.save((DataBackupEntity) any);
            }
        };

        dataBackupService.createDataBackup(false);

        new Verifications() {
            {
                runner.setCommand(Constants.SH_DATA_BACKUP);
                times = 1;
                runner.appendArgs(anyString, anyString, anyString);
                times = 1;
                runner.execute();
                times = 1;
                dataBackupDAO.save((DataBackupEntity) any);
                times = 1;
            }
        };
    }


    /**
     * 获取备份
     */
    @Test
    public void testListBackup() {

        int page = 1;
        int limit = 10;
        int total = 100;

        BaseListDataBackupRequest listDataBackupRequest = new BaseListDataBackupRequest();
        listDataBackupRequest.setPage(page);
        listDataBackupRequest.setLimit(limit);

        List<DataBackupEntity> entityList = new ArrayList<>();

        for (int i = 0; i < limit; i++) {
            entityList.add(new DataBackupEntity());
        }

        Page<DataBackupEntity> entityPage = new PageImpl<DataBackupEntity>(entityList, PageRequest.of(page, limit), total);

        new Expectations() {
            {
                dataBackupDAO.findAll((DataBackupSpecification) any, (Pageable) any);
                result = entityPage;
            }
        };

        Page<DataBackupEntity> response = dataBackupService.listDataBackup(listDataBackupRequest);

        Assert.assertEquals(response.getTotalElements(), total);
        Assert.assertEquals(response.getContent().size(), limit);
    }

    /**
     * 删除备份
     * 
     * @param skyengineFile sky文件
     * @throws BusinessException 异常
     */
    @Test
    public void testDeleteBackup(@Mocked SkyengineFile skyengineFile) throws BusinessException {

        UUID id = UUID.randomUUID();
        DataBackupEntity entity = new DataBackupEntity();
        entity.setId(id);
        entity.setRealFileName("backup.zip");

        new Expectations() {
            {
                dataBackupDAO.getOne(id);
                result = entity;
                dataBackupDAO.delete(entity);
                result = null;
                globalParameterAPI.findParameter(anyString);
                result = "/data/web/db";
                skyengineFile.delete();
                result = true;
            }
        };

        dataBackupService.deleteDataBackup(id);

        new Verifications() {
            {
                skyengineFile.delete();
                times = 1;
            }
        };
    }

    /**
     * 删除备份实体为空时
     */
    @Test
    public void testDeleteBackupEntityNull() {

        UUID id = UUID.randomUUID();

        new Expectations() {
            {
                dataBackupDAO.getOne(id);
                result = null;
            }
        };

        try {
            dataBackupService.deleteDataBackup(id);
            Assert.fail();
        } catch (BusinessException e) {
            Assert.assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_DATA_BACKUP_NOT_EXITS);
        }
    }

    /**
     * 删除文件错误
     * 
     * @param skyengineFile sky文件
     * @throws BusinessException 异常
     */
    @Test
    public void testDeleteBackupDeleteFileFail(@Mocked SkyengineFile skyengineFile) throws BusinessException {

        UUID id = UUID.randomUUID();
        DataBackupEntity entity = new DataBackupEntity();
        entity.setId(id);
        entity.setRealFileName("backup.zip");

        new Expectations() {
            {
                dataBackupDAO.getOne(id);
                result = entity;
                dataBackupDAO.delete(entity);
                result = null;
                globalParameterAPI.findParameter(anyString);
                result = "/data/web/db";
                skyengineFile.delete();
                result = false;
            }
        };

        dataBackupService.deleteDataBackup(id);

        new Verifications() {
            {
                skyengineFile.delete();
                times = 1;
            }
        };
    }

    @Test
    public void testListExpireDataBackup() {
        List<DataBackupEntity> dataBackupEntityList = new ArrayList<>();
        Date date = new Date();
        new Expectations() {
            {
                dataBackupService.listExpireDataBackup(date, true);
                result = dataBackupEntityList;
            }
        };
        dataBackupService.listExpireDataBackup(date, true);
        new Verifications() {
            {
                dataBackupDAO.findAllByCreateTimeLessThanEqualAndIsAutoEquals(date, true);
                times = 1;
            }
        };
    }
}
