package com.ruijie.rcos.base.sysmanage.module.impl.service.query;

import static org.junit.Assert.assertEquals;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.junit.Test;

import com.ruijie.rcos.base.sysmanage.module.def.api.request.debuglog.BaseListDebugLogRequest;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.DebugLogEntity;

import mockit.Injectable;
import mockit.Tested;

/**
 * Description: 日志规范测试
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月25日
 *
 * @author fyq
 */

public class DubugLogSpecificationTest {
    @Injectable
    private CriteriaBuilder builder;

    @Injectable
    private Root<DebugLogEntity> root;

    @Injectable
    private CriteriaQuery<?> query;

    /**
     * 测试toPredicate()方法，包含查询条件的情况
     * 
     * @param request 请求
     */
    @Test
    public void testToPredicateWhileHasSearchText(@Tested BaseListDebugLogRequest request) {


        DebugLogSpecification specification = new DebugLogSpecification(request);
        Predicate predicate = specification.toPredicate(root, query, builder);
        assertEquals(query.getRestriction(), predicate);
    }

    /**
     * 测试toPredicate()方法，没有查询条件
     * 
     * @param request 请求
     */
    @Test
    public void testToPredicateWhileNoSearchText(@Tested BaseListDebugLogRequest request) {

        DebugLogSpecification specification = new DebugLogSpecification(request);
        Predicate predicate = specification.toPredicate(root, query, builder);
        assertEquals(query.getRestriction(), predicate);
    }
}
