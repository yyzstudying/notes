package com.ruijie.rcos.base.sysmanage.module.impl.quartz;

import org.junit.Test;
import org.junit.runner.RunWith;

import com.ruijie.rcos.sk.base.shell.ShellCommandRunner;

import mockit.Expectations;
import mockit.Mocked;
import mockit.Tested;
import mockit.Verifications;
import mockit.integration.junit4.JMockit;

/**
 * Description: 关闭QuartzTask
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月25日
 *
 * @author fyq
 */

@RunWith(JMockit.class)
public class PowerOffQuartzTaskTest {

    @Tested
    private PowerOffQuartzTask powerOffQuartzTask;

    @Mocked
    private ShellCommandRunner runner;

    /**
     * 测试执行
     * 
     * @throws Exception 异常
     */
    @Test
    public void testExecute() throws Exception {
        new Expectations() {
            {
                runner.execute();
            }
        };

        powerOffQuartzTask.execute();

        new Verifications() {
            {
                runner.execute();
                times = 1;
            }
        };
    }
}
