package com.ruijie.rcos.base.sysmanage.module.impl.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.quartz.*;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;

import com.ruijie.rcos.base.sysmanage.module.impl.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.impl.dao.ScheduleTaskDAO;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.ScheduleLogEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.ScheduleTaskEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.ScheduleTypeEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.quartz.data.QuartzTaskData;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.test.GetSetTester;
import com.ruijie.rcos.sk.modulekit.api.isolation.CrossComponentApplicationContext;

import mockit.*;
import mockit.integration.junit4.JMockit;

/**
 * Description: 安排服务
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月25日
 *
 * @author yeyuzhong
 */

@RunWith(JMockit.class)
public class ScheduleServiceImplTest {

    @Tested
    private ScheduleServiceImpl scheduleService;

    @Injectable
    private SchedulerFactoryBean schedulerFactoryBean;

    @Injectable
    private ScheduleTaskDAO scheduleTaskDAO;

    @Injectable
    private Scheduler scheduler;

    @Injectable
    private CrossComponentApplicationContext crossComponentApplicationContext;

    @Injectable
    private ApplicationContext applicationContext;

    @Capturing
    private Logger logger;

    /**
     * 测试实体
     */
    @Test
    public void testEntity() {
        GetSetTester getSetTester = new GetSetTester(ScheduleTaskEntity.class);
        getSetTester.runTest();
        getSetTester = new GetSetTester(ScheduleTypeEntity.class);
        getSetTester.runTest();
        getSetTester = new GetSetTester(ScheduleLogEntity.class);
        getSetTester.runTest();

        Assert.assertTrue(true);
    }

    /**
     * 设置属性
     * 
     * @throws Exception 异常
     */
    @Test
    public void testAfterPropertiesSet() throws Exception {
        scheduleService.afterPropertiesSet();
        Assert.assertTrue(true);

    }

    /**
     * 添加安排
     * 
     * @throws SchedulerException 调度程序异常
     * @throws BusinessException 异常
     */
    @Test
    public void testAddSchedule() throws SchedulerException, BusinessException {
        String group = "group";
        String name = "name";
        String cronExpression = "12 12 12 * * ? *";
        Map<String, QuartzTaskData> dataMap = new HashMap<>();

        JobKey jobKey = JobKey.jobKey(name, group);

        new Expectations() {
            {
                scheduler.checkExists(jobKey);
                result = false;
                scheduler.scheduleJob((JobDetail) any, (Trigger) any);
                result = null;
            }
        };

        scheduleService.addSchedule(group, name, cronExpression, dataMap);


        new Verifications() {
            {
                scheduler.scheduleJob((JobDetail) any, (Trigger) any);
                times = 1;
            }
        };
    }

    /**
     * 添加计划已存在
     * 
     * @throws SchedulerException 调度程序异常
     * @throws BusinessException 异常
     */
    @Test
    public void testAddScheduleExists() throws SchedulerException, BusinessException {

        String group = "group";
        String name = "name";
        String cronExpression = "12 12 12 * * ? *";
        Map<String, QuartzTaskData> dataMap = new HashMap<>();

        JobKey jobKey = JobKey.jobKey(name, group);

        new Expectations() {
            {
                scheduler.checkExists(jobKey);
                result = true;
            }
        };

        try {
            scheduleService.addSchedule(group, name, cronExpression, dataMap);
            Assert.fail();
        } catch (BusinessException e) {
            Assert.assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_SCHEDULE_TASK_EXIST);
        }
    }

    /**
     * 添加异常
     * 
     * @throws SchedulerException 调度程序异常
     */
    @Test
    public void testAddScheduleSchedulerException() throws SchedulerException {

        String group = "group";
        String name = "name";
        String cronExpression = "12 12 12 * * ? *";
        Map<String, QuartzTaskData> dataMap = new HashMap<>();

        JobKey jobKey = JobKey.jobKey(name, group);

        new Expectations() {
            {
                scheduler.checkExists(jobKey);
                result = false;
                scheduler.scheduleJob((JobDetail) any, (Trigger) any);
                result = new SchedulerException("error");
            }
        };

        try {
            scheduleService.addSchedule(group, name, cronExpression, dataMap);
            Assert.fail();
        } catch (BusinessException e) {
            Assert.assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_CREATE_SCHEDULE_TASK_FALL);
        }

    }

    /**
     * 更新任务
     * 
     * @throws SchedulerException 调度程序异常
     * @throws BusinessException 异常
     */
    @Test
    public void testUpdateSchedule() throws SchedulerException, BusinessException {
        String group = "group";
        String name = "name";
        String cronExpression = "12 12 12 * * ? *";
        Map<String, QuartzTaskData> dataMap = new HashMap<>();

        new Expectations() {
            {
                scheduler.checkExists(JobKey.jobKey(name, group));
                result = false;
                scheduler.scheduleJob((JobDetail) any, (Trigger) any);
                result = null;

            }
        };
        scheduleService.updateSchedule(group, name, cronExpression, dataMap);
        new Verifications() {
            {
                scheduler.scheduleJob((JobDetail) any, (Trigger) any);
                times = 1;
            }
        };
    }

    /**
     * 更新计划为空
     * 
     * @throws SchedulerException 调度程序异常
     * @throws BusinessException 异常
     */
    @Test
    public void testUpdateScheduleExists() throws SchedulerException, BusinessException {
        String group = "group";
        String name = "name";
        String cronExpression = "12 12 12 * * ? *";
        Map<String, QuartzTaskData> dataMap = new HashMap<>();

        new Expectations() {
            {
                scheduler.checkExists(JobKey.jobKey(name, group));
                result = true;
                scheduler.scheduleJob((JobDetail) any, (Trigger) any);

            }
        };
        scheduleService.updateSchedule(group, name, cronExpression, dataMap);
        try {
            scheduleService.addSchedule(group, name, cronExpression, dataMap);
            Assert.fail();
        } catch (BusinessException e) {
            Assert.assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_SCHEDULE_TASK_EXIST);
        }
    }

    /**
     * 更新计划异常
     * 
     * @throws SchedulerException 调度程序异常
     */
    @Test
    public void testUpdateScheduleException() throws SchedulerException {

        String group = "group";
        String name = "name";
        String cronExpression = "12 12 12 * * ? *";
        Map<String, QuartzTaskData> dataMap = new HashMap<>();

        new Expectations() {
            {
                scheduler.checkExists(JobKey.jobKey(name, group));
                result = false;
                scheduler.scheduleJob((JobDetail) any, (Trigger) any);
                result = new SchedulerException("error");
            }
        };

        try {
            scheduleService.updateSchedule(group, name, cronExpression, dataMap);
            Assert.fail();
        } catch (BusinessException e) {
            Assert.assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_UPDATE_SCHEDULE_TASK_FALL);
        }
    }

    /**
     * 删除计划
     * 
     * @throws SchedulerException 调度程序异常
     * @throws BusinessException 异常
     */
    @Test
    public void testDeleteSchedule() throws SchedulerException, BusinessException {

        String group = "group";
        String name = "name";
        JobKey jobKey = JobKey.jobKey(name, group);

        new Expectations() {
            {
                scheduler.checkExists(jobKey);
                result = true;
            }
        };

        scheduleService.deleteSchedule(group, name);

        new Verifications() {
            {
                scheduler.deleteJob(jobKey);
                times = 1;
            }
        };
    }

    /**
     * 删除计划为空
     * 
     * @throws SchedulerException 调度程序异常
     * @throws BusinessException 异常
     */
    @Test
    public void testDeleteScheduleExists() throws SchedulerException, BusinessException {
        String group = "group";
        String name = "name";
        JobKey jobKey = JobKey.jobKey(name, group);

        new Expectations() {
            {
                scheduler.checkExists(jobKey);
                result = false;


            }
        };
        scheduleService.deleteSchedule(group, name);
        new Verifications() {
            {
                scheduler.deleteJob(jobKey);
                times = 0;
            }
        };
    }

    /**
     * 删除计划异常
     * 
     * @throws SchedulerException 程序调度异常
     */
    @Test
    public void testDeleteScheduleException() throws SchedulerException {

        String group = "group";
        String name = "name";

        new Expectations() {
            {
                scheduler.checkExists(JobKey.jobKey(name, group));
                result = true;
                scheduler.deleteJob(JobKey.jobKey(name, group));
                result = new SchedulerException("error");
            }
        };

        try {
            scheduleService.deleteSchedule(group, name);
            Assert.fail();
        } catch (BusinessException e) {
            String a = e.getKey();
            Assert.assertEquals(e.getKey(), BusinessKey.BASE_SYS_MANAGE_DELETE_SCHEDULE_TASK_FALL);
        }
    }
}
