package com.ruijie.rcos.base.sysmanage.module.impl.license.client;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.springframework.util.Assert;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import com.ruijie.rcos.base.sysmanage.module.impl.license.constants.LicConstants;
import com.ruijie.rcos.base.sysmanage.module.impl.license.enums.FeatureTypeEnum;
import com.ruijie.rcos.base.sysmanage.module.impl.license.enums.LicenseTypeEnum;
import com.ruijie.rcos.base.sysmanage.module.impl.license.utils.LicenseUtils;
import com.ruijie.rcos.base.sysmanage.module.impl.license.vo.LicCheckResult;
import com.ruijie.rcos.base.sysmanage.module.impl.license.vo.LicenseFeature;
import com.ruijie.rcos.base.sysmanage.module.impl.license.vo.LicenseInfo;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.log.LoggerFactory;
import com.ruijie.rcos.sk.base.util.StringUtils;


/**
 * Description: 解析lic文件类
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月18日
 * 
 * @author zouqi
 */
public class LicenseService {
    public static final int LIC_FILE_ERROR = LicCheckResult.LIC_FILE_ERROR;//文件非法
    
    public static final int LIC_OK = LicCheckResult.LIC_OK;//文件合法,校验通过
    
    public static final int LIC_SN_INVAILD = LicCheckResult.LIC_SN_INVAILD;//序列号错误
    
    public static final int LIC_SIGN_INVAILD = LicCheckResult.LIC_SIGN_INVAILD;//校验码错误
    
    private static final String SIGN_FLAG = "signature=";
    
    private static final String SN_FLAG = "license.sn=";
    
    private static final String DATA_POSTFIX = "_DATA";
    
    private static final String ONOFF_POSTFIX = "_ONOFF";
    
    private static final Logger LOGGER = LoggerFactory.getLogger(LicenseService.class);
	
	/**
     * 整理license信息
     * @param licInfo 
     * @return LicenseInfo
     */
    public LicenseInfo pickupLicense(String licInfo) {
        Assert.hasText(licInfo, "licInfo 不能为空");
	    
        licInfo = licInfo.trim();
        if (licInfo.lastIndexOf(SIGN_FLAG) != -1) {
            Properties p = new Properties();
            try {
				
                StringReader reader = new StringReader(licInfo);
                p.load(reader);
                return pickupLic(p);
            } catch (IOException e) {
                LOGGER.error("IOException", e);
            }
        } else {
            DocumentBuilderFactory factory = null;
            DocumentBuilder builder = null;
            Document doc = null;

            try {
                factory = DocumentBuilderFactory.newInstance();
                builder = factory.newDocumentBuilder();
                doc = builder.parse(new InputSource(new StringReader(licInfo)));
                return parsePaLic(doc);
            } catch (ParserConfigurationException e) {
                LOGGER.error("ParserConfigurationException", e);
            } catch (SAXException e) {
                LOGGER.error("SAXException", e);
            } catch (IOException e) {
                LOGGER.error("IOException", e);
            }

        }
		//
        return null;
    }
	
	/**
	 * 获取license信息 
	 * @param licFile 
	 * @return LicenseInfo
	 */
    public LicenseInfo pickupLicense(File licFile) {
        Assert.notNull(licFile, "licFile 不能为空");
        Properties p = new Properties();
        try {
            p.load(new FileInputStream(licFile));
            return pickupLic(p);
        } catch (FileNotFoundException e) {
            LOGGER.error("FileNotFoundException", e);
        } catch (IOException e) {
            LOGGER.error("IOException", e);
        }
        //
        return null;
    }
	
	/**
     * 整理license信息
     * @param p  Properties信息
     * @return LicenseInfo
     */
    protected LicenseInfo pickupLic(Properties p) {
        LicenseInfo lic = new LicenseInfo();
        String strLicType = p.getProperty(LicConstants.LIC_TYPE_KEY, LicenseTypeEnum.TEMP.name());
        LicenseTypeEnum licType = LicenseTypeEnum.valueOf(strLicType.toUpperCase());
        lic.setType(licType);
        
        String product = p.getProperty(LicConstants.LIC_PRODUCT, "LIC-RCC-CM2");
        lic.setProductName(product);
        
        String sn = p.getProperty(LicConstants.LIC_SN_KEY, "00001");
        lic.setDevSn(sn);
        
        String devCode = p.getProperty(LicConstants.LIC_PRODUCT_CODE);
        lic.setDevCode(devCode);
        
        String strStart = p.getProperty(LicConstants.LIC_START_KEY);
        if (strStart != null && !"".equals(strStart)) {
            lic.setStartTime(LicenseUtils.formateTime(strStart));
        }
        String time = p.getProperty(LicConstants.LIC_TIME_KEY);
        if (StringUtils.isNotEmpty(time)) {
            lic.setDuration(LicenseInfo.DURATION_NO_LIMIT);
        } else {
            long duration = Long.parseLong(time);
            if (duration > 0) {
            	duration = duration * 24 * 60;//
            } else {
            	duration = LicenseInfo.DURATION_NO_LIMIT;
            }
            lic.setDuration(duration);
        }
        for (Object key : p.keySet()) {
            String strKey = (String)key;
            if (strKey.startsWith(LicConstants.LIC_F_PRE_KEY)) {
            	LicenseFeature feature = new LicenseFeature();
            	String name = p.getProperty(strKey);
            	feature.setName(name);
            	String onOff = p.getProperty(LicConstants.LIC_F_ONOFF_PRE_KEY + name);
            	if (onOff != null) {
                    feature.setType(FeatureTypeEnum.ONOFF);
                    if (onOff.equalsIgnoreCase(LicConstants.LIC_F_ONOFF_ON)) {
                    	feature.setOn(true);
                    } else {
                    	feature.setOn(false);
                    }
            	} else {
                    String strData = p.getProperty(LicConstants.LIC_F_DATA_PRE_KEY + name);
                    if (strData != null) {
                    	feature.setType(FeatureTypeEnum.DATA);
                    	try {
                    	    long data = Long.parseLong(strData);
                    	    feature.setValue(data);
                    	} catch (NumberFormatException e) {
                    	    feature.setType(null);
                    	}
                    }
            	}
            	if (feature.getType() != null) {
            	    lic.addFeature(feature);
            	}
            }
        }
        
        return lic;
    }
	
    /**
     * 校验license合法性
     * @param licenseFile 文件
     * @param sns 进行比对的SN
     * @return LicCheckResult LIC_OK LIC_SN_INVAILD LIC_SIGN_INVAILD LIC_FILE_ERROR
     */
    public LicCheckResult check(File licenseFile, String... sns) {
        Assert.notNull(licenseFile, "licFile 不能为空");
        Assert.notNull(sns, "SN码不能为空");
    	LicCheckResult result = new LicCheckResult();
    	if (!licenseFile.exists() || licenseFile.isDirectory()) {
    	    result.setResult(LIC_FILE_ERROR);
    	    return result;
    	}
    	try {
            String content = new String (LicenseUtils.readFile(licenseFile));
            if (content.lastIndexOf(SIGN_FLAG) != -1) {
                String[] licLineArr = content.split("\r");
                List<String> lineList = new ArrayList<String>();
                for (String licLine : licLineArr) {
                    lineList.add(licLine.trim());
                }
                int value = checkLic(lineList, sns);
                result.setContent(content);
                result.setLicInfo(pickupLicense(licenseFile));
                result.setResult(value);
            } else {
                //PA系统的校验
                int value = checkPaLicAndParse(result, licenseFile, sns);
                result.setResult(value);
            }
    	} catch (FileNotFoundException e) {
    	    result.setResult(LIC_FILE_ERROR);
    	} catch (IOException e) {
    	    // 
    	    result.setResult(LIC_FILE_ERROR);
    	} 
    	return result;
    }
	
	/**
	 * 校验license合法性
	 * @param licenseInfo 文件内容
	 * @param sns 校验序列号，为空则只校验文件合法性
	 * @return
	 */
    private int checkLic(List<String> licLines, String... sns) {
    	StringBuilder sb = new StringBuilder();
    	for (String str : licLines) {
            if (str.startsWith(SN_FLAG)) {
                String licSnInfo = str.substring(str.indexOf('=') + 1).trim();
                if (sns.length > 0 && !checkSN(licSnInfo, sns)) {
                    return LIC_SN_INVAILD;
                }
                sb.append(str);
            } else if (str.startsWith(SIGN_FLAG)) {
                int index = str.indexOf('=') + 1;
                sb.append(str.substring(0,index));
                String sign = str.substring(index);
                if (LicenseUtils.checkSign(sb.toString(), sign)) {
                    return LIC_OK;
                } else {
                    return LIC_SIGN_INVAILD;
                }
            } else {
                sb.append(str);
            }
            sb.append('\r');
    	}
    	return LIC_FILE_ERROR;
    }
	
    protected int checkPaLicAndParse(LicCheckResult result, File licFile, String... sns) {
    	String str = LicenseUtils.decryptPaLic(licFile);
    	if (str == null) {
    	    result.setResult(LIC_SIGN_INVAILD);
    		
    	    return LIC_SIGN_INVAILD;
    	} else {
    	    result.setContent(str);
    	    DocumentBuilderFactory factory = null;
    	    DocumentBuilder builder = null;
    	    Document doc = null;
    
    	    try {
    	    	factory = DocumentBuilderFactory.newInstance();
    	      	builder = factory.newDocumentBuilder();
    	    } catch (ParserConfigurationException e) {
    	    	result.setResult(LIC_FILE_ERROR);
    	    	return LIC_FILE_ERROR;
    	    }
    
    	    try {
    	    	doc = builder.parse(new InputSource(new StringReader(str)));
    	    	NodeList devIdNodes = doc.getElementsByTagName("dev_id");
    	    	String licSn = null;
    	    	if (devIdNodes != null) {
    	    	    licSn = devIdNodes.item(0).getFirstChild().getNodeValue();
    	    	}
    	    	if (licSn == null) {
                    result.setResult(LIC_FILE_ERROR);
                    return LIC_FILE_ERROR;
    	    	} else if (!checkSN(licSn, sns)) {
                    result.setResult(LIC_SN_INVAILD);
                    return LIC_SN_INVAILD;
    	    	} else {
                    result.setResult(LIC_OK);
                    LicenseInfo licInfo = parsePaLic(doc);
                    result.setLicInfo(licInfo);
    	    	}
    	    } catch (SAXException e) {
    	    	
    	    	result.setResult(LIC_FILE_ERROR);
    	    	return LIC_FILE_ERROR;
    	    } catch (IOException e) {
    	    	
    	    	result.setResult(LIC_FILE_ERROR);
    	    	return LIC_FILE_ERROR;
    	    }
    		
    	}
    	return LIC_OK;
    }
	
    private boolean checkSN(String licSnInfo, String... sns) {
        if (licSnInfo.indexOf('&') >= 0) {
            String[] licSnArr = licSnInfo.split("&");
            for (String licSn : licSnArr) {
                licSn = licSn.trim();
                boolean isFlag = false;
                for (String sn : sns) {
                    if (licSn.equals(sn)) {
                        isFlag = true;
                        break;
                    }
                }
                if (!isFlag) {
                    return false;
                }
            }
            return true;
        } else { //允许多个SN，比如“ 0002|0004” 或者没有符号的
            for (String sn : sns) {
                if (licSnInfo.contains(sn)) {
                    return true;
                }
            }
        }
        return false;
    }
	
	/**
	 * 解析PA系统的license内容
	 * @param doc
	 * @return
	 */
    protected LicenseInfo parsePaLic(Document doc) {
    	LicenseInfo lic = new LicenseInfo();
    	NodeList nlist = doc.getElementsByTagName("*");
    	for (int i = 0; i < nlist.getLength() ; i ++) {
            Element node = (Element)nlist.item(i);
            String nodeName = node.getNodeName();
            if (nodeName.toUpperCase().endsWith(DATA_POSTFIX)) {
                lic.addFeature(parseDataFeature(nlist, node));
            } else if (nodeName.toUpperCase().endsWith(ONOFF_POSTFIX)) {
                lic.addFeature(parseOnoffFeature(nlist, node));
            } else if (nodeName.equals("date")) {
                String strDate = node.getFirstChild().getNodeValue();
                try {
                    long datel = Long.parseLong(strDate);
                    Date startDate = new Date();
                    startDate.setTime(datel * 1000);
                    lic.setStartTime(startDate);
                } catch (Exception e) {
                    LOGGER.error("Exception", e);
                }
            } else if (nodeName.equals("feature_id")) {
            	String productName = node.getFirstChild().getNodeValue();
            	lic.setProductName(productName);
            } else if (nodeName.equals("time_slot")) {
            	String strTime = node.getFirstChild().getNodeValue();
            	try {
                    long duration = Long.parseLong(strTime);
                    if (duration > 0) {
                    	duration = duration * 24 * 60;//
                    } else {
                    	duration = LicenseInfo.DURATION_NO_LIMIT;
                    }
                    lic.setDuration(duration);
            	} catch (Exception e) {
            	    LOGGER.error("Exception", e);
            	}
            } else if (nodeName.equals("dev_id")) {
            	String devSn = node.getFirstChild().getNodeValue();
            	lic.setDevSn(devSn);
            } else if (nodeName.equals("dev_code")) {
            	String devCode = node.getFirstChild().getNodeValue();
            	lic.setDevCode(devCode);
            }
    	}
    	return lic;
    }
	
    private LicenseFeature parseOnoffFeature(NodeList nlist, Element node) {
    	LicenseFeature feature = new LicenseFeature();
    	String nodeName = node.getNodeName().toUpperCase();
    	String name = nodeName.substring(0, nodeName.indexOf(ONOFF_POSTFIX));
    	feature.setName(name);
    	feature.setType(FeatureTypeEnum.ONOFF);
    	if (node.getFirstChild() != null && LicConstants.LIC_F_ONOFF_ON.equalsIgnoreCase(node.getFirstChild().getNodeValue())) {
    	    feature.setOn(true);
    	} else {
    	    feature.setOn(false);
    	}
    	for (int i = 0; i < nlist.getLength(); i ++) {
    	    Element item = (Element)nlist.item(i);
            if (item.getNodeName().equalsIgnoreCase("time_slot")) {
                //使用根级的time_slot
            	String strTime = item.getFirstChild().getNodeValue();
            	try {
                    long duration = Long.parseLong(strTime);
                    if (duration > 0) {
                    	duration = duration * 24 * 60;//
                    } else {
                    	duration = LicenseInfo.DURATION_NO_LIMIT;
                    }
                    feature.setDuration(duration);
            	} catch (Exception e) {
            	    LOGGER.error("Exception", e);
            	}
            } else if (item.getNodeName().equalsIgnoreCase("feature_id")) {
            	String productName = item.getFirstChild().getNodeValue();
            	Long value = LicenseUtils.productDataMap.get(productName);
            	if (value == null) {
            	    value = LicenseUtils.DEFAULT_DATA;
            	}
            	feature.setValue(value);
            }
    		
    	}
    	
    	return feature;
    }
    
    private LicenseFeature parseDataFeature(NodeList nlist, Element node) {
    	LicenseFeature feature = new LicenseFeature();
    	String nodeName = node.getNodeName().toUpperCase();
    	String name = nodeName.substring(0, nodeName.indexOf(DATA_POSTFIX));
    	feature.setName(name);
    	feature.setType(FeatureTypeEnum.DATA);
    	String strData = node.getFirstChild().getNodeValue();
    	
    	try {
    	    feature.setValue(Long.parseLong(strData));
    	} catch (NumberFormatException e) {
    	    LOGGER.error("NumberFormatException", e);
    	}
    	
    	for (int i = 0; i < nlist.getLength(); i ++) {
            Element item = (Element)nlist.item(i);
            
            if (item.getNodeName().equalsIgnoreCase("time_slot")) {
                //使用根级的time_slot
                String strTime = item.getFirstChild().getNodeValue();
                try {
                    long duration = Long.parseLong(strTime);
                    if (duration > 0) {
                    	duration = duration * 24 * 60;//
                    } else {
                    	duration = LicenseInfo.DURATION_NO_LIMIT;
                    }
                    feature.setDuration(duration);
                } catch (Exception e) {
                    LOGGER.error("Exception", e);
                }
            }
    	}
    	
    	return feature;
    }

    
}
