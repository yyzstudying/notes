package com.ruijie.rcos.base.sysmanage.module.impl.dao;

import com.ruijie.rcos.base.sysmanage.module.impl.entity.DataBackupEntity;
import com.ruijie.rcos.sk.modulekit.api.ds.SkyEngineJpaRepository;

import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * Description: 数据库备份DAO接口
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月06日
 *
 * @author fyq
 */
public interface DataBackupDAO extends SkyEngineJpaRepository<DataBackupEntity, UUID> {
    /**
     * 查询创建时间小于expireDate且是否字段备份字段为指定值列表
     * 
     * @param expireDate 过期时间
     * @param isAuto 是否自动备份
     * @return 记录列表
     */
    List<DataBackupEntity> findAllByCreateTimeLessThanEqualAndIsAutoEquals(Date expireDate, boolean isAuto);

}
