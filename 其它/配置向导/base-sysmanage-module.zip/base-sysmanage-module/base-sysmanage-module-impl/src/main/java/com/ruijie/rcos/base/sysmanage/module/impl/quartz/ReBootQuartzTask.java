package com.ruijie.rcos.base.sysmanage.module.impl.quartz;

import com.ruijie.rcos.base.sysmanage.module.impl.common.Constants;
import com.ruijie.rcos.sk.base.quartz.QuartzTask;
import com.ruijie.rcos.sk.base.shell.ShellCommandRunner;
import com.ruijie.rcos.sk.modulekit.api.isolation.GlobalUniqueBean;

/**
 * 
 * Description: 重启机子api实现
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年11月22日
 * 
 * @author hhx
 */
@GlobalUniqueBean("reBootQuartzTask")
public class ReBootQuartzTask implements QuartzTask {
    @Override
    public void execute() throws Exception {
        new ShellCommandRunner().setCommand(Constants.REBOOT_HOST_COMMD).execute();
    }
}
