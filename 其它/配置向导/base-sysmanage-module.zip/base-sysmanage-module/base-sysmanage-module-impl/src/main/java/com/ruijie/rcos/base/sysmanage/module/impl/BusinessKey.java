package com.ruijie.rcos.base.sysmanage.module.impl;

/**
 * 
 * Description: 国际化文件
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年11月9日
 * 
 * @author hhx
 */
public interface BusinessKey {

    /********************** 公用KEY *****************************/
    String BASE_SYS_MANAGE_EXEC_COMMAND_ERROR = "base-sys_manage_exec_command_error";

    /********************** 时间配置KEY *****************************/
    String BASE_SYS_MANAGE_UPDATE_SYSTEM_TIME_UNREACHABLE_NTP = "base-sys_manage_update_system_time_unreachable_ntp";

    /********************** 调试日志KEY *****************************/
    String BASE_SYS_MANAGE_DEBUG_LOG_NOT_EXITS = "base-sys_manage_debug_log_not_exits";

    /********************** 数据库备份KEY *****************************/
    String BASE_SYS_MANAGE_DATA_BACKUP_NOT_EXITS = "base-sys_manage_data_backup_not_exits";

    String BASE_SYS_MANAGE_DATA_BACKUP = "base-sys_manage_data_backup";

    /********************** 定时任务KEY *****************************/
    String BASE_SYS_MANAGE_SCHEDULE_TASK_EXIST = "base-sys_manage_schedule_task_exist";

    String BASE_SYS_MANAGE_SCHEDULE_TASK_NOT_EXIST = "base-sys_manage_schedule_task_not_exist";

    String BASE_SYS_MANAGE_CREATE_SCHEDULE_TASK_FALL = "base-sys_manage_create_schedule_task_fall";

    String BASE_SYS_MANAGE_UPDATE_SCHEDULE_TASK_FALL = "base-sys_manage_update_schedule_task_fall";

    String BASE_SYS_MANAGE_DELETE_SCHEDULE_TASK_FALL = "base-sys_manage_delete_schedule_task_fall";

    String BASE_SYS_MANAGE_SCHEDULE_TYPE_NOT_EXIST = "base-sys_manage_schedule_type_not_exist";

    String BASE_SYS_MANAGE_SCHEDULE_TIME_EXPIRE = "base-sys_manage_schedule_time_expire";

    String BASE_SYS_MANAGE_EXECUTE_SCHEDULE_SUCCESS = "base-sys_manage_execute_schedule_success";

    String BASE_SYS_MANAGE_EXECUTE_SCHEDULE_FAIL = "base-sys_manage_execute_schedule_fail";

    String BASE_SYS_MANAGE_ONE_HUNDRED_YEAR_AFTER_NOW = "base-sys_manage_one_hundred_year_after_now";


    String BASE_SYS_MANAGE_ILLEGAL_TIME_FORMAT = "base-sys_manage_illegal_time_format";

    String BASE_SYS_MANAGE_ILLEGAL_DATE_FORMAT = "base-sys_manage_illegal_date_format";

    String BASE_SYS_MANAGE_LOG_COLLECT_NOW = "base-sys_manage_log_collect_now";

    String BASE_SYS_MANAGE_LOG_FILE_NOT_EXIST = "base-sys_manage_log_file_not_exist";

    String BASE_SYS_MANAGE_DB_BACKUP_NOW = "base-sys_manage_db_backup_now";

    String BASE_SYS_MANAGE_LOG_BAK_NAME = "base-sys_manage_log_bak_name";

    String BASE_SYS_MANAGE_DB_BAK_NAME = "base-sys_manage_db_bak_name";

    /********************** log4j配置功能KEY *****************************/

    String BASE_SYS_MANAGE_LOG4J_CONFIG_RECORD_NOT_EXIST = "base-sys_manage_log4j_config_record_not_exist";

    String BASE_SYS_MANAGE_LOG4J_CONFIG_ALREADY_EXIST = "base-sys_manage_log4j_config_already_exist";
    
    /********************** license授权功能KEY *****************************/
    
    String BASE_SYS_MANAGE_LICENSE_FILE_NOT_EXIST = "base-sys_manage_license_file_not_exist";
    
    String BASE_SYS_MANAGE_LICENSE_FILE_OVERSIZE = "base-sys_manage_license_file_oversize";
    
    String BASE_SYS_MANAGE_LICENSE_FILE_EXIST = "base-sys_manage_license_file_exist";
    
    String BASE_SYS_MANAGE_LICENSE_FILE_MOVE_ERROR = "base-sys_manage_license_file_move_error";
    
    String BASE_SYS_MANAGE_LICENSE_FILE_SIZE_UNEQUAL = "base-sys_manage_license_file_size_unequal";
    
    String BASE_SYS_MANAGE_LICENSE_FILE_RESOLVE_ERROR = "base-sys_manage_license_file_resolve_error";
    
    String BASE_SYS_MANAGE_LICENSE_TYPE_CHANGE_ERROR = "base-sys_manage_license_type_change_error";
    
    String BASE_SYS_MANAGE_LICENSE_TYPE_NO_CHANGE = "base-sys_manage_license_type_no_change";
    
    String BASE_SYS_MANAGE_TEMP_LICENSE_SCHEDULE_TASK = "base-sys_manage_temp_license_schedule_task";
    
    String BASE_SYS_MANAGE_LICENSE_FILE_DELETE_ERROR = "base-sys_manage_license_file_delete_error";
    
}
