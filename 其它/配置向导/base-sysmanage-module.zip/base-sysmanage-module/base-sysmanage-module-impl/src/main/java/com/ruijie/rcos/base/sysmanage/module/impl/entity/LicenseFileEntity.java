package com.ruijie.rcos.base.sysmanage.module.impl.entity;

import java.util.Date;
import java.util.UUID;

import javax.persistence.*;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureStatus;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureType;

/**
 * Description: license文件信息表
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年03月04日
 *
 * @author zouqi
 */
@Entity
@Table(name = "t_base_license_file")
public class LicenseFileEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    /**License控制项编码  */
    private String featureCode;
    
    /**License文件名  */
    private String fileName;
    
    /**License文件的MD5  */
    private String fileMd5;
    
    /**License类型  */
    @Enumerated(EnumType.STRING)
    private BaseFeatureType featureType;

    /**License状态  */
    @Enumerated(EnumType.STRING)
    private BaseFeatureStatus featureStatus;

    /**创建时间  */
    private Date createTime;
    
    /**试用时长  */
    private long trialDuration;
    
    /**剩余时长  */
    private long trialRemainder;
    
    /**试用开始时间  */
    private Date trailStartTime;
    
    /**试用结束时间  */
    private Date trailEndTime;
    
    /**特性的中文名  */
    private String featureDisplayName;
    
    /**特性的其他描述  */
    private String featureDescription;

    @Version
    private Integer version;
    
    
    public UUID getId() {
        return id;
    }
    
    public void setId(UUID id) {
        this.id = id;
    }
    
    public String getFeatureCode() {
        return featureCode;
    }

    public void setFeatureCode(String featureCode) {
        this.featureCode = featureCode;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileMd5() {
        return fileMd5;
    }

    public void setFileMd5(String fileMd5) {
        this.fileMd5 = fileMd5;
    }

    public BaseFeatureType getFeatureType() {
        return featureType;
    }

    public void setFeatureType(BaseFeatureType featureType) {
        this.featureType = featureType;
    }

    public BaseFeatureStatus getFeatureStatus() {
        return featureStatus;
    }

    public void setFeatureStatus(BaseFeatureStatus featureStatus) {
        this.featureStatus = featureStatus;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public long getTrialDuration() {
        return trialDuration;
    }

    public void setTrialDuration(long trialDuration) {
        this.trialDuration = trialDuration;
    }

    public long getTrialRemainder() {
        return trialRemainder;
    }

    public void setTrialRemainder(long trialRemainder) {
        this.trialRemainder = trialRemainder;
    }

    public Date getTrailStartTime() {
        return trailStartTime;
    }

    public void setTrailStartTime(Date trailStartTime) {
        this.trailStartTime = trailStartTime;
    }

    public Date getTrailEndTime() {
        return trailEndTime;
    }

    public void setTrailEndTime(Date trailEndTime) {
        this.trailEndTime = trailEndTime;
    }

    public String getFeatureDisplayName() {
        return featureDisplayName;
    }

    public void setFeatureDisplayName(String featureDisplayName) {
        this.featureDisplayName = featureDisplayName;
    }

    public String getFeatureDescription() {
        return featureDescription;
    }

    public void setFeatureDescription(String featureDescription) {
        this.featureDescription = featureDescription;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    @Override
    public String toString() {
        return "LicenseFileEntity{" +
                "id=" + id +
                ", featureCode=" + featureCode +
                ", fileName=" + fileName +
                ", fileMd5=" + fileMd5 +
                ", featureType=" + featureType +
                ", featureStatus=" + featureStatus +
                ", createTime=" + createTime +
                ", trialDuration=" + trialDuration +
                ", trialRemainder=" + trialRemainder +
                ", trailStartTime=" + trailStartTime +
                ", trailEndTime='" + trailEndTime + '\'' +
                ", featureDisplayName='" + featureDisplayName + '\'' +
                ", featureDescription=" + featureDescription +
                ", version=" + version +
                '}';
    }
}
