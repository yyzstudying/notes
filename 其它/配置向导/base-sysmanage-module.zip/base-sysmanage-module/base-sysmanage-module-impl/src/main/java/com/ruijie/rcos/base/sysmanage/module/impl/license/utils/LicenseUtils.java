package com.ruijie.rcos.base.sysmanage.module.impl.license.utils;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.EncodedKeySpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import org.springframework.util.Assert;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.log.LoggerFactory;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月18日
 * 
 * @author zouqi
 */
public class LicenseUtils {
	
    private static final Logger LOGGER = LoggerFactory.getLogger(LicenseUtils.class);
    
    public static final Long DEFAULT_DATA = 70L;
    
    public static Map<String , Long> productDataMap = new HashMap<String, Long>();
    
    static {
        productDataMap.put("RCC-CM-NUM-35", 35L);
        productDataMap.put("RCC-CM-NUM-70", 70L);
    }
	
    /**
     * 解析 lic文件内容
     * @param str 
     * @return  String 
     */
    public static String sign(String str) {
        Assert.hasText(str, "str 不能为空");
        ObjectInputStream ois = null;
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("MD5");
            messageDigest.update(str.getBytes());
            byte[] strArr = messageDigest.digest();
            
            String filePath = Thread.currentThread().getContextClassLoader().getResource("").getPath() + "license/privateKey";
            File file = new File(filePath);
            InputStream inputStream = new FileInputStream(file);
            ois = new ObjectInputStream(inputStream);
            RSAPrivateKey privateKey = (RSAPrivateKey)ois.readObject();
            Cipher cipher = Cipher.getInstance("RSA");
            cipher.init(Cipher.ENCRYPT_MODE, privateKey); 
            byte[] signByteArr = cipher.doFinal(strArr); 
            return byte2String(signByteArr);
        } catch (Exception e) {
            LOGGER.error("sign fail.", e);
        } finally {
            if (ois != null) {
            	try {
            	    ois.close();
            	} catch (IOException e) {
            	    LOGGER.error("IOException", e);
            	}
            }
        }
        //
        return null;
    }
	
    private static String byte2String(byte[] array) {
    	StringBuilder sb = new StringBuilder();
    	for (byte b : array) {
    	    sb.append(String.format("%02X", b));
    	}
    	return sb.toString();
    }
	
	/**
	 * 校验license信息是否正确
	 * @param info 不包含签名的信息段，从文件开头到“signature=”
	 * @param sign  签名信息
	 * @return boolean 
	 */
    public static boolean checkSign(String info, String sign) {
        Assert.notNull(info, "info 不能为空");
        Assert.notNull(sign, "sign 不能为空");
        ObjectInputStream ois = null;
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("MD5");
            messageDigest.update(info.getBytes());
            byte[] md5Arr = messageDigest.digest();
            String filePath = Thread.currentThread().getContextClassLoader().getResource("").getPath() + "license/publicKey";
            File file = new File(filePath);
            InputStream inputStream = new FileInputStream(file);
            ois = new ObjectInputStream(inputStream);
            RSAPublicKey publicKey = (RSAPublicKey)ois.readObject();
            
            Cipher cipher = Cipher.getInstance("RSA");  
            cipher.init(Cipher.DECRYPT_MODE, publicKey);
            byte[] encryptByteArr = hex2bytes(sign);
            if (encryptByteArr == null) {
            	return false;
            } else {
            	byte[] decryptArr = cipher.doFinal(encryptByteArr);
            	if (byteArrayCompare(md5Arr,decryptArr)) {
            	    return true;
            	}
            }
        	
        } catch (Exception e) {
            LOGGER.error("Exception", e);
        }
        return false;
    }
	
    /**
     * 解析 lic文件内容
     * @param file  
     * @return  String 
     */
    public static String decryptPaLic(File file) {
        Assert.notNull(file, "File 不能为空");
        if (!file.exists()) {
            LOGGER.error("file is not exist. file :" + file);
            //
            return null;
        }
        
        try {
            byte[] dataArr = readFile(file);
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            byte[] publicKeyArr = readPaPublicKey();
            if (publicKeyArr == null) {
                System.err.println("publicKey is null. contact admin.");
                //
                return null;
            }
            EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(readPaPublicKey());
            PublicKey key = keyFactory.generatePublic(x509KeySpec);
            Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
            cipher.init(Cipher.DECRYPT_MODE, key);
            int step = 1024 / 8;
            byte[] dataReturnArr = new byte[] {};
            for (int i = 0; i < dataArr.length; i += step) {
                byte[] doFinalArr = cipher.doFinal(subArray(dataArr, i, i + step));
                dataReturnArr = appendByteArray(dataReturnArr, doFinalArr,0, doFinalArr.length);
            }
            String str = new String(dataReturnArr);
            return str;
        } catch (NoSuchAlgorithmException e) {
            LOGGER.error("NoSuchAlgorithmException", e);
        } catch (InvalidKeySpecException e) {
            LOGGER.error("InvalidKeySpecException", e);
        } catch (NoSuchPaddingException e) {
            LOGGER.error("NoSuchPaddingException", e);
        } catch (BadPaddingException e) {
            LOGGER.error("BadPaddingException", e);
        } catch (IllegalBlockSizeException e) {
            LOGGER.error("IllegalBlockSizeException", e);
        } catch (InvalidKeyException e) {
            LOGGER.error("InvalidKeyException", e);
        } catch (IOException e) {
            LOGGER.error("IOException", e);
        }
        //
        return null;
    }
	
    /**
     * 解析 lic文件内容
     * @param file  
     * @return byte[]  
     * @throws IOException 
     */
    public static byte[] readFile(File file) throws IOException {
        Assert.notNull(file, "File 不能为空");
        BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file));
        int bytes = (int) file.length();
        byte[] bufferArr = new byte[bytes];
       
        bis.read(bufferArr);
        bis.close();
        return bufferArr;
    }
	
    protected static byte[] readPaPublicKey() throws FileNotFoundException {
        String filePath = Thread.currentThread().getContextClassLoader().getResource("").getPath() + "license/publicKey_pa";
        File file = new File(filePath);
        InputStream inputStream = new FileInputStream(file);
        try {
            byte[] publicArr = new byte[] {};
            byte[] bufferArr = new byte[1024];
            int count = 0;
            // 解压
            while ((count = inputStream.read(bufferArr, 0, 1024)) != -1) {
                publicArr = appendByteArray(publicArr, bufferArr,0,count);
            }
            
            if (publicArr == null || publicArr.length == 0 ) {
                throw new IOException("read publickey error");
            }
            return publicArr;
        } catch (IOException e) {
            //
            return null;
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    LOGGER.error("IOException", e);
                }
            }
        }
    }
    
    private static byte[] appendByteArray(byte[] destArray, byte[] srcArray, int start, int size) {
    	byte[]resultArr = new byte[destArray.length + size];
    	System.arraycopy(destArray, 0, resultArr, 0, destArray.length);
    	System.arraycopy(srcArray, 0, resultArr, destArray.length, size);
    	return resultArr;
    }
	
    private static byte[] subArray(byte[] array, int startPos, int endPos) {
    	int realSize = Math.min(endPos - startPos, array.length - startPos);
    	byte[] resultArr = new byte[realSize];
    	for (int i = 0, j = resultArr.length; i < j; i++) {
    	    resultArr[i] = array[startPos + i];
    	}
    	return resultArr;
    }
    
    private static byte[] hex2bytes(String str) {
        byte[] resultArr = new byte[str.length() / 2];
        for (int i = 0, j = str.length(); i < j; i += 2) {
            try {
                resultArr[i / 2] = (byte)Integer.parseInt(str.substring(i, i + 2),16);
            } catch (NumberFormatException e) {
                LOGGER.error("NumberFormatException", e);
                //
                return null;
            }
        }
        return resultArr;
    }

    private static boolean byteArrayCompare(byte[] array1, byte[] array2) {
        if (array1 == null && array2 == null) {
            return true;
        }
        if (array1 == null && array2 != null) {
            return false;
        }
        if (array1 != null && array2 == null) {
            return false;
        }
        if (array1.length != array2.length) {
            return false;
        }
        for (int i = 0, j = array1.length; i < j; i++) {
            if (array1[i] != array2[i]) {
            	return false;
            }
        }
        return true;
    	
    }
	
    /**
     * 解析 lic文件内容
     * @param str   
     * @return Date  
     */
    public static Date formateTime(String str) {
        Assert.notNull(str, "Date-String 不能为空");
        Date date = null;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            date = sdf.parse(str);
        } catch (ParseException e) {
            LOGGER.error("ParseException", e);
        }
        if (date == null) {
            SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
            try {
            	date = sdf.parse(str);
            } catch (ParseException e) {
                LOGGER.error("ParseException", e);
            }
        }
        
        return date;
    	
    }
	
}
