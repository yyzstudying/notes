package com.ruijie.rcos.base.sysmanage.module.impl.api;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.ruijie.rcos.base.sysmanage.module.def.api.response.log4j.BaseDeleteLog4jConfigResponse;
import org.apache.logging.log4j.Level;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.util.Assert;

import com.ruijie.rcos.base.sysmanage.module.def.api.Log4jConfigAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.log4jconfig.*;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.log4j.BaseDetailLog4jConfigResponse;
import com.ruijie.rcos.base.sysmanage.module.def.dto.Log4jConfigDTO;
import com.ruijie.rcos.base.sysmanage.module.impl.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.impl.dao.Log4jConfigDAO;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.Log4jConfigEntity;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.log4j.SkyEngineLoggerManager;
import com.ruijie.rcos.sk.modulekit.api.bootstrap.SafetySingletonInitializer;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultPageResponse;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultResponse;


/**
 * Description: Function Description
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年02月19日
 *
 * @author GuoZhouYue
 */
public class Log4jConfigAPIImpl implements Log4jConfigAPI, SafetySingletonInitializer {

    @Autowired
    Log4jConfigDAO log4jConfigDAO;

    private SkyEngineLoggerManager loggerManager = SkyEngineLoggerManager.getInstance();

    @Override
    public DefaultPageResponse<Log4jConfigDTO> getAll(BaseListLog4jConfigRequest request) {
        Assert.notNull(request, "request must not be null");

        Pageable pageable = PageRequest.of(request.getPage(), request.getLimit(), Sort.by("loggerName"));
        final Page<Log4jConfigEntity> all = log4jConfigDAO.findAll(pageable);
        final List<Log4jConfigEntity> resultList = all.getContent();

        final List<Log4jConfigDTO> dtoList = new ArrayList<>();
        resultList.forEach(log4jConfigEntity -> {
            final Log4jConfigDTO log4jConfigDTO = new Log4jConfigDTO();
            BeanUtils.copyProperties(log4jConfigEntity, log4jConfigDTO);
            dtoList.add(log4jConfigDTO);
        });

        DefaultPageResponse<Log4jConfigDTO> response = new DefaultPageResponse<>();
        response.setItemArr(dtoList.toArray(new Log4jConfigDTO[dtoList.size()]));
        response.setTotal(all.getTotalElements());

        return response;
    }

    @Override
    public BaseDetailLog4jConfigResponse getOne(BaseDetailLog4jConfigRequest request) throws BusinessException {
        Assert.notNull(request, "request must not be null");

        final Optional<Log4jConfigEntity> optionalResult = log4jConfigDAO.findById(request.getId());
        optionalResult.orElseThrow(() -> new BusinessException(BusinessKey.BASE_SYS_MANAGE_LOG4J_CONFIG_RECORD_NOT_EXIST));

        final BaseDetailLog4jConfigResponse response = new BaseDetailLog4jConfigResponse();
        BeanUtils.copyProperties(optionalResult.get(), response);
        return response;
    }

    @Override
    public DefaultResponse addConfig(BaseAddLog4jConfigRequest request) throws BusinessException {
        Assert.notNull(request, "request must not be null");
        final String loggerName = request.getLoggerName();
        final String levelStr = request.getLoggerLevel();

        if (log4jConfigDAO.existsByLoggerName(loggerName)) {
            throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_LOG4J_CONFIG_ALREADY_EXIST);
        }

        final Log4jConfigEntity entity = new Log4jConfigEntity();
        entity.setId(UUID.randomUUID());
        BeanUtils.copyProperties(request, entity);

        log4jConfigDAO.save(entity);
        loggerManager.addCustomLogger(loggerName, Level.valueOf(levelStr));

        return DefaultResponse.Builder.success();
    }

    @Override
    public BaseDeleteLog4jConfigResponse removeConfig(BaseRemoveLog4jConfigRequest request) throws BusinessException {
        Assert.notNull(request, "request must not be null");

        final Optional<Log4jConfigEntity> optionalResult = log4jConfigDAO.findById(request.getId());

        optionalResult.orElseThrow(() -> new BusinessException(BusinessKey.BASE_SYS_MANAGE_LOG4J_CONFIG_RECORD_NOT_EXIST));

        BaseDeleteLog4jConfigResponse response = new BaseDeleteLog4jConfigResponse();
        optionalResult.ifPresent(entity -> {
            log4jConfigDAO.delete(entity);
            loggerManager.removeCustomLogger(entity.getLoggerName());
            BeanUtils.copyProperties(entity, response);
        });

        return response;
    }

    @Override
    public DefaultResponse editConfig(BaseEditLog4jConfigRequest request) throws BusinessException {
        Assert.notNull(request, "request must not be null");

        final Optional<Log4jConfigEntity> optionalResult = log4jConfigDAO.findById(request.getId());
        optionalResult.ifPresent(entity -> {
            BeanUtils.copyProperties(request, entity);
            log4jConfigDAO.save(entity);
            loggerManager.editCustomLogger(entity.getLoggerName(), Level.valueOf(entity.getLoggerLevel()));
        });
        optionalResult
                .orElseThrow(() -> new BusinessException(BusinessKey.BASE_SYS_MANAGE_LOG4J_CONFIG_RECORD_NOT_EXIST));

        return DefaultResponse.Builder.success();
    }

    @Override
    public void safeInit() {
        //初始化skyengine log4j 配置
        final List<Log4jConfigEntity> initList = log4jConfigDAO.findAll();
        initList.forEach(log4jConfigEntity -> {
            loggerManager.addCustomLogger(log4jConfigEntity.getLoggerName(), Level.valueOf(log4jConfigEntity.getLoggerLevel()));
        });
    }
}
