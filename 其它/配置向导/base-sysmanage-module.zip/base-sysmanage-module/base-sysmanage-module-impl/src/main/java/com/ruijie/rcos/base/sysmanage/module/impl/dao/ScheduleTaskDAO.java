package com.ruijie.rcos.base.sysmanage.module.impl.dao;

import java.util.UUID;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.ScheduleTaskEntity;
import com.ruijie.rcos.sk.modulekit.api.ds.SkyEngineJpaRepository;

/**
 * Description: 定时任务dao
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月05日
 *
 * @author xgx
 */
public interface ScheduleTaskDAO extends SkyEngineJpaRepository<ScheduleTaskEntity, UUID> {
    /**
     * 查询任务类型id对应任务记录是否存在
     * 
     * @param taskTypeId 任务类型id
     * @return true：存在，false：不存在
     */
    boolean existsByTaskTypeId(UUID taskTypeId);


}
