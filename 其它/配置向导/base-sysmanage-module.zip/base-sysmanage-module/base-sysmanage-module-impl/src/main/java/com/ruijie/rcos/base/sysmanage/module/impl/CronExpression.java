package com.ruijie.rcos.base.sysmanage.module.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.ruijie.rcos.sk.base.exception.BusinessException;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import com.google.common.collect.ImmutableMap;
import com.ruijie.rcos.base.sysmanage.module.def.enums.TaskCycle;
import com.ruijie.rcos.base.sysmanage.module.impl.util.ScheduleTaskUtil;

/**
 * Description: cron表达式工具类，此类中的所有功能都是基于业务实现（每天某一时刻，每周某一时刻，某天某一时刻格式的cron表达式）其他类型表达式传入可能得不到你想要的结果
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月28日
 *
 * @author xgx
 */
public class CronExpression {

    private static final String COMMA_SPLIT = ",";

    private static final DateTimeFormatter TIME_TO_STR_FORMAT = DateTimeFormatter.ofPattern("s m H ");

    /**
     * 一次性日期部分时间转字符串格式转换器
     */
    private static final String ONCE_DATE_FORMAT = "d M ? yyyy";

    /**
     * 天周期日期部分固定格式
     */
    private static final String DAY_DATE_FORMAT = "* * ? *";

    /**
     * 周周期日期部分时间固定格式
     */
    private static final String WEEK_DATE_FORMAT = "? * %s *";

    /**
     * 一次性任务字符串庄时间格式化器
     */
    private static final DateTimeFormatter ONCE_DATE_STR_TO_TIME_FORMATTER = DateTimeFormatter.ofPattern("d M yyyy");

    private static final DateTimeFormatter STR_TO_TIME_FORMAT = DateTimeFormatter.ofPattern("s m H");


    /**
     * 匹配时间
     */
    private static final Pattern TIME_PATTERN = Pattern.compile("^([0-9]\\s|[1-5][0-9]\\s){2}([0-9]\\s|1[0-9]|2[0-3]\\s)");

    /**
     * 一次性任务匹配周
     */
    private static final Pattern ONCE_PATTERN = Pattern.compile("\\s\\?\\s");

    /**
     * 周任务匹配周
     */
    private static final Pattern WEEK_PATTERN = Pattern.compile("([1-7],){0,6}[1-7]\\s");

    /**
     * 一次性任务日期部分匹配器
     */
    private static final Pattern ONCE_DATE_PARSE_PATTERN = Pattern.compile("\\s([0-9]|[1-2][0-9]|3[0-1])\\s([1-9]|(1[0-2]))\\s(\\?|\\*)\\s[0-9]{4}$");

    /**
     * 每天任务日期部分匹配器
     */
    private static final Pattern DAY_DATE_PARSE_PATTERN = Pattern.compile("\\s\\*\\s\\*\\s\\?\\s\\*$");

    /**
     * 每周任务日期部分匹配器
     */
    private static final Pattern WEEK_DATE_PARSE_PATTERN = Pattern.compile("\\s\\?\\s\\*\\s([1-7],){0,6}[1-7]\\s\\*$");

    private static final Map<TaskCycle, Pattern> CYCLE_TO_PATTERN_MAP =
            ImmutableMap.of(TaskCycle.ONCE, ONCE_DATE_PARSE_PATTERN, TaskCycle.DAY, DAY_DATE_PARSE_PATTERN, TaskCycle.WEEK, WEEK_DATE_PARSE_PATTERN);

    private static final String EMPTY_STR = " ";

    private String expression;

    private TaskCycle taskCycle;

    private LocalDate scheduleDate;

    private LocalTime scheduleTime;

    private Integer[] dayOfWeekArr;



    public CronExpression(TaskCycle taskCycle, LocalDate scheduleDate, LocalTime scheduleTime, Integer[] dayOfWeekArr) throws BusinessException {
        ScheduleTaskUtil.validateScheduleTaskArgs(taskCycle, dayOfWeekArr, scheduleDate, scheduleTime);
        this.taskCycle = taskCycle;
        this.scheduleDate = scheduleDate;
        this.scheduleTime = scheduleTime;
        this.dayOfWeekArr = dayOfWeekArr;
        this.expression = generalExpression(taskCycle, scheduleDate, scheduleTime, dayOfWeekArr);
    }

    public CronExpression(TaskCycle taskCycle, String expression) {
        Assert.notNull(taskCycle, "任务周期不能为空");
        Assert.hasText(expression, "cron表达式不能为空");
        this.expression = expression;
        this.taskCycle = taskCycle;
        this.scheduleTime = getLocalTime(expression);

        String taskCycleExpression = getCycleExpression(taskCycle, expression);

        if (taskCycle == TaskCycle.ONCE) {
            this.scheduleDate = getLocalDate(taskCycleExpression);
        } else if (taskCycle == TaskCycle.WEEK) {
            this.dayOfWeekArr = getDayOfWeek(taskCycleExpression);
        }
    }

    /**
     * 表达式是否过期
     * 
     * @return true：已过期，false:未过期
     */
    public boolean isExpire() {
        if (taskCycle == TaskCycle.ONCE) {
            LocalDateTime localDateTime = LocalDateTime.of(scheduleDate, scheduleTime);
            return LocalDateTime.now().isAfter(localDateTime);
        }
        return false;
    }

    public String getExpression() {
        return expression;
    }

    public TaskCycle getTaskCycle() {
        return taskCycle;
    }

    public void setTaskCycle(TaskCycle taskCycle) {
        this.taskCycle = taskCycle;
    }

    public LocalDate getScheduleDate() {
        return scheduleDate;
    }

    public LocalTime getScheduleTime() {
        return scheduleTime;
    }

    public Integer[] getDayOfWeekArr() {
        return dayOfWeekArr;
    }

    private Integer[] getDayOfWeek(String expression) {
        Matcher matcher = WEEK_PATTERN.matcher(expression);
        if (matcher.find()) {
            String daysOfWeek = matcher.group().trim();
            return Arrays.stream(daysOfWeek.split(COMMA_SPLIT)).map(Integer::new).distinct().toArray(Integer[]::new);
        }
        //
        return null;
    }

    private LocalDate getLocalDate(String expression) {
        String localDayStr = null;
        Matcher matcher = ONCE_PATTERN.matcher(expression);
        if (matcher.find()) {
            localDayStr = matcher.replaceFirst(EMPTY_STR);
        }
        return LocalDate.parse(localDayStr, ONCE_DATE_STR_TO_TIME_FORMATTER);
    }

    private String getCycleExpression(TaskCycle taskCycle, String expression) {
        String taskCycleExpression = "";
        Pattern pattern = CYCLE_TO_PATTERN_MAP.get(taskCycle);
        Matcher matcher = pattern.matcher(expression);
        if (matcher.find()) {
            taskCycleExpression = matcher.group().trim();
        }
        return taskCycleExpression;
    }

    private String generalExpression(TaskCycle taskCycle, LocalDate scheduleDate, LocalTime scheduleTime, Integer[] dayOfWeekArr) {
        String cronExpression = null;
        String cronTime = scheduleTime.format(TIME_TO_STR_FORMAT);
        if (taskCycle == TaskCycle.ONCE) {
            cronExpression = scheduleDate.format(DateTimeFormatter.ofPattern(ONCE_DATE_FORMAT));
        } else if (taskCycle == TaskCycle.DAY) {
            cronExpression = DAY_DATE_FORMAT;
        } else if (taskCycle == TaskCycle.WEEK) {
            String weeks = getWeeks(dayOfWeekArr);
            cronExpression = String.format(WEEK_DATE_FORMAT, weeks);
        }
        cronExpression = cronTime + cronExpression;
        return cronExpression;
    }

    private String getWeeks(Integer[] dayOfWeekArr) {
        String[] dayOfWeekListArr = Arrays.stream(dayOfWeekArr).distinct().sorted().map(dayOfWeek -> {
            Assert.state(1 <= dayOfWeek && dayOfWeek <= 7, "星期几必须在[1-7]范围内");
            return String.valueOf(dayOfWeek);
        }).toArray(String[]::new);
        return StringUtils.arrayToCommaDelimitedString(dayOfWeekListArr);
    }

    private static LocalTime getLocalTime(String cronExpression) {
        Assert.hasText(cronExpression, "cronExpression不能为空");
        Matcher matcher = TIME_PATTERN.matcher(cronExpression);
        LocalTime localTime = null;
        while (matcher.find()) {
            String localTimeStr = matcher.group();
            localTime = LocalTime.parse(localTimeStr.trim(), STR_TO_TIME_FORMAT);
        }
        return localTime;
    }

}
