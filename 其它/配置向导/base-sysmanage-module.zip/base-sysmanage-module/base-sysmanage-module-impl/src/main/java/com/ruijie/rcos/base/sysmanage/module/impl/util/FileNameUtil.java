package com.ruijie.rcos.base.sysmanage.module.impl.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.ruijie.rcos.base.sysmanage.module.def.common.Constant;
import com.ruijie.rcos.sk.modulekit.api.ds.SkyEngineJpaRepository;
import org.springframework.util.Assert;

/**
 * Description: 文件名获取工具类
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月29日
 *
 * @author xgx
 */
public class FileNameUtil {

    private static final String SPLIT_LINE = "_";

    /**
     * 获取文件名
     * 
     * @param prefix 前缀
     * @param jpaRepository jpa查询类
     * @return 文件名
     */
    public static String getFileName(String prefix, SkyEngineJpaRepository jpaRepository) {
        Assert.hasText(prefix, "prefix must have text");
        Assert.notNull(jpaRepository, "jpaRepository is null");
        String fileName = prefix + LocalDateTime.now().format(DateTimeFormatter.ofPattern(Constant.YYYY_MM_DD_HH_MM_SS));
        final String finalFileName = fileName;
        long count = jpaRepository.count((root, query, criteriaBuilder) -> criteriaBuilder.like(root.get("fileName"), finalFileName + "%"));
        if (count > 0) {
            fileName += SPLIT_LINE + count;
        }
        return fileName;
    }
}
