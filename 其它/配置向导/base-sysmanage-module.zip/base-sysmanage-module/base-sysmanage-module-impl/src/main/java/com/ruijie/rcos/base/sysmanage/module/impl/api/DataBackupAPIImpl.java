package com.ruijie.rcos.base.sysmanage.module.impl.api;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.util.Assert;

import com.ruijie.rcos.base.sysmanage.module.def.api.DataBackupAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.databackup.BaseCreateDataBackupRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.databackup.BaseDeleteDataBackupRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.databackup.BaseListDataBackupRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.databackup.BaseCreateDataBackupResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.databackup.BaseDeleteDataBackupResponse;
import com.ruijie.rcos.base.sysmanage.module.def.dto.BaseDataBackupDTO;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.DataBackupEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.service.DataBackupService;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultPageResponse;

/**
 * Description: 数据库备份API实现
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月06日
 *
 * @author fyq
 */
public class DataBackupAPIImpl implements DataBackupAPI {

    @Autowired
    private DataBackupService dataBackupService;

    @Override
    public BaseCreateDataBackupResponse createDataBackup(BaseCreateDataBackupRequest apiRequest) throws BusinessException {
        Assert.notNull(apiRequest, "请求参数不能为空");

        DataBackupEntity entity = dataBackupService.createDataBackup(false);
        BaseCreateDataBackupResponse apiResponse = new BaseCreateDataBackupResponse();
        BeanUtils.copyProperties(entity, apiResponse);
        return apiResponse;
    }

    @Override
    public BaseDeleteDataBackupResponse deleteDataBackup(BaseDeleteDataBackupRequest apiRequest) throws BusinessException {

        Assert.notNull(apiRequest, "请求参数不能为空");

        DataBackupEntity entity = dataBackupService.deleteDataBackup(apiRequest.getId());

        BaseDeleteDataBackupResponse apiResponse = new BaseDeleteDataBackupResponse();
        BeanUtils.copyProperties(entity, apiResponse);

        return apiResponse;
    }

    @Override
    public DefaultPageResponse<BaseDataBackupDTO> listDataBackup(BaseListDataBackupRequest apiRequest) {

        Assert.notNull(apiRequest, "请求参数不能为空");

        Page<DataBackupEntity> page = dataBackupService.listDataBackup(apiRequest);
        List<BaseDataBackupDTO> dataBackupDTOList = new ArrayList<BaseDataBackupDTO>();
        List<DataBackupEntity> dataBackupEntityList = page.getContent();

        for (DataBackupEntity entity : dataBackupEntityList) {
            BaseDataBackupDTO dataBackupDTO = new BaseDataBackupDTO();
            BeanUtils.copyProperties(entity, dataBackupDTO);
            dataBackupDTOList.add(dataBackupDTO);
        }

        DefaultPageResponse<BaseDataBackupDTO> response = new DefaultPageResponse<BaseDataBackupDTO>();
        response.setItemArr(dataBackupDTOList.toArray(new BaseDataBackupDTO[dataBackupDTOList.size()]));
        response.setTotal(page.getTotalElements());

        return response;
    }


}
