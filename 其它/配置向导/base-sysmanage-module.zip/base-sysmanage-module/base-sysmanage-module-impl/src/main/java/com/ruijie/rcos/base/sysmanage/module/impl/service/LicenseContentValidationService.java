package com.ruijie.rcos.base.sysmanage.module.impl.service;

import com.ruijie.rcos.base.sysmanage.module.def.dto.license.BaseLicenseFeatureDTO;
import com.ruijie.rcos.base.sysmanage.module.impl.license.vo.LicenseInfo;
import com.ruijie.rcos.sk.base.exception.BusinessException;

/**
 * Description: license合法性校验service
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月8日
 * 
 * @author zouqi
 */
public interface LicenseContentValidationService {
    
    /**
     * license内容 校验合法性
     * 
     * @param licenseFeatureDTO 用于验证的dto
     * 
     * @return LicenseInfo license解析后的内容;
     * 
     * @throws BusinessException 业务异常
     */
    LicenseInfo licenseContentValidation(BaseLicenseFeatureDTO licenseFeatureDTO) throws BusinessException;
    
    /**
     * license文件 解析内容
     * 
     * @param licenseFeatureDTO 参数 
     * @return LicenseInfo
     * @throws BusinessException 业务异常
     */
    LicenseInfo resolverLicenseFile(BaseLicenseFeatureDTO licenseFeatureDTO) throws BusinessException;
}
