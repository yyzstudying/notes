package com.ruijie.rcos.base.sysmanage.module.impl.dao;

import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.Query;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureStatus;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureType;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.LicenseFileEntity;
import com.ruijie.rcos.sk.modulekit.api.ds.SkyEngineJpaRepository;

/**
 * Description: License DAO类
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月4日
 * 
 * @author zouqi
 */
public interface LicenseFileDAO extends SkyEngineJpaRepository<LicenseFileEntity, UUID> {

    /**
     * license 文件MD5是否存在
     * @param fileMd5 文件的MD5
     * @return 是否存在
     */
    boolean existsByFileMd5(String fileMd5);
    
    /**
     * license 文件名是否存在
     * @param fileName 文件名
     * @return 是否存在
     */
    boolean existsByFileName(String fileName);
    
    /**
     * l根据 license类型 查找license信息
     * @param featureType license类型
     * @param featureStatus license状态
     * @return license信息
     */
    List<LicenseFileEntity> findByFeatureTypeAndFeatureStatusOrderByCreateTime(BaseFeatureType featureType, 
            BaseFeatureStatus featureStatus);
    
    /**
     * l根据 license类型 查找license信息
     * @param featureType license类型
     * @param featureStatus license状态
     * @param featureCode license控制项信息
     * @return license信息
     */
    List<LicenseFileEntity> findByFeatureTypeAndFeatureStatusAndFeatureCodeOrderByCreateTime(BaseFeatureType featureType, 
            BaseFeatureStatus featureStatus, String featureCode);
    
    /**
     * l根据License控制项编码 和 license类型 查找license信息
     * @param featureCode 根据License控制项编码 
     * @param featureType 根据license类型
     * @return license信息列表
     */
    List<LicenseFileEntity> findByFeatureTypeAndFeatureCodeOrderByCreateTime(BaseFeatureType featureType, String featureCode);
    
    /**
     * l根据License控制项编码 
     * @param featureCode 根据License控制项编码 
     * @return license信息列表
     */
    List<LicenseFileEntity> findByFeatureCode(String featureCode);
    
    /**
     * l根据 license状态 查找license信息
     * @param featureStatus license状态
     * @return license信息
     */
    @Query(value = "select featureCode from LicenseFileEntity where featureStatus = ?1 GROUP BY featureCode")
    List<LicenseFileEntity> findByFeatureStatusGroupByFeatureCode(BaseFeatureStatus featureStatus);
    
}
