package com.ruijie.rcos.base.sysmanage.module.impl.service;

import org.springframework.data.domain.Page;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.BaseLicenseListRequest;
import com.ruijie.rcos.base.sysmanage.module.def.dto.license.BaseLicenseFeatureDTO;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.LicenseFileEntity;
import com.ruijie.rcos.sk.base.exception.BusinessException;

/**
 * Description: license授权service
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月7日
 * 
 * @author zouqi
 */
public interface LicenseFileService {

    /**
     * license 文件上传
     * @param baseLicenseFeatureDTO 请求参数
     * @throws BusinessException 业务异常 
     */
    void uploadLicense(BaseLicenseFeatureDTO baseLicenseFeatureDTO) throws BusinessException;
    
    /**
     * 系统启动时初始化License信息
     */
    void initLicense();
    
    /**
     * 获取license列表信息
     * @param request 请求参数
     * @return 列表信息
     * @throws BusinessException 业务异常 
     */
    Page<LicenseFileEntity> licenseList(BaseLicenseListRequest request) throws BusinessException;
    
    /**
     * 获取license列表信息
     * @param name 文件名
     * @return 是否重名
     * @throws BusinessException 业务异常 
     */
    Boolean checkDuplication(String name);
}
