package com.ruijie.rcos.base.sysmanage.module.impl.api;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.util.Assert;
import com.ruijie.rcos.base.sysmanage.module.def.api.BaseLicenseMgmtAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.BaseCreateDatFileRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.BaseLicenseListRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.BaseUploadLicFileRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.CheckDuplicationWebRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.license.BaseCreateDatFileResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.license.BaseUploadLicFileResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.license.CheckDuplicationResponse;
import com.ruijie.rcos.base.sysmanage.module.def.dto.license.BaseLicenseFeatureDTO;
import com.ruijie.rcos.base.sysmanage.module.def.spi.BaseLicenseSerialNumberSPI;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseGetLicenseSerianNumberRequest;
import com.ruijie.rcos.base.sysmanage.module.def.spi.response.BaseGetLicenseSerialNumberResponse;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.LicenseFileEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.service.LicenseFileService;
import com.ruijie.rcos.base.sysmanage.module.impl.util.LicenseUtil;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultPageResponse;
import com.ruijie.rcos.sk.modulekit.api.tx.NoRollback;

/**
 * Description: BaseLicenseMgmtAPI的接口实现
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月4日
 * 
 * @author zouqi
 */
public class BaseLicenseMgmtAPIImpl implements BaseLicenseMgmtAPI {

    @Autowired
    private BaseLicenseSerialNumberSPI baseLicenseSerialNumberSPI;
    
    @Autowired
    private LicenseFileService licenseFileService;
    
    /**
     * l获取平台唯一码
     * @param request 导出平台唯一码信息request
     */
    @Override
    @NoRollback
    public BaseCreateDatFileResponse createDatFile(BaseCreateDatFileRequest request) {
        Assert.notNull(request, "请求参数不能为空");
        
        BaseGetLicenseSerialNumberResponse spiResponse = baseLicenseSerialNumberSPI.getLicenseSerialNumber(new BaseGetLicenseSerianNumberRequest());
        Assert.notNull(spiResponse, "response不能为空");
        Assert.notNull(spiResponse.getSerialId(), "硬件唯一码ID不能为空");
        //组装response
        BaseCreateDatFileResponse response = LicenseUtil.createDatFileResponse(spiResponse);
        
        return response;
    }

    
    /**
     * license 文件导入
     * @param request 验证License信息request
     * 
     * @return BaseUploadLicFileResponse license 文件导入应答结果
     * @throws BusinessException 
     */
    @Override
    @NoRollback
    public BaseUploadLicFileResponse uploadLicFile(BaseUploadLicFileRequest request) throws BusinessException {
        Assert.notNull(request, "请求参数不能为空");
        BaseLicenseFeatureDTO dto = LicenseUtil.createLicenseDTO(request);
        licenseFileService.uploadLicense(dto);
        BaseUploadLicFileResponse response = new BaseUploadLicFileResponse();
        return response;
    }


    /**
     * license 列表信息
     * @param apiRequest 列表request
     * 
     * @return 列表信息
     * @throws BusinessException 
     */
    @Override
    public DefaultPageResponse<BaseLicenseFeatureDTO> listLicenseFeature(BaseLicenseListRequest apiRequest) throws BusinessException {
        Assert.notNull(apiRequest, "请求参数不能为空");
        Page<LicenseFileEntity> page = licenseFileService.licenseList(apiRequest);

        List<LicenseFileEntity> licenseList = page.getContent();
        List<BaseLicenseFeatureDTO> licenseFeatureDTOList = new ArrayList<>();
        for (LicenseFileEntity entity : licenseList) {
            BaseLicenseFeatureDTO featureDTO = LicenseUtil.featureEntityToFeatureDTO(entity);
            licenseFeatureDTOList.add(featureDTO);
        }
        DefaultPageResponse<BaseLicenseFeatureDTO> response = new DefaultPageResponse<BaseLicenseFeatureDTO>();
        response.setItemArr(licenseFeatureDTOList.toArray(new BaseLicenseFeatureDTO[0]));
        response.setTotal(page.getTotalElements());

        return response;
    }


    /**
     * license 命名唯一性校验
     * @param request 列表request
     * 
     * @return CheckDuplicationResponse
     * @throws BusinessException 
     */
    @Override
    public CheckDuplicationResponse validationLicenseFeature(CheckDuplicationWebRequest request) throws BusinessException {
        Assert.notNull(request, "请求参数不能为空");
        CheckDuplicationResponse response = new CheckDuplicationResponse();
        Boolean  isExists = this.licenseFileService.checkDuplication(request.getName());
        response.setHasDuplication(isExists);
        return response;
    }
    


}
