package com.ruijie.rcos.base.sysmanage.module.impl.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.BaseLicenseListRequest;
import com.ruijie.rcos.base.sysmanage.module.def.dto.license.BaseLicenseFeatureDTO;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureStatus;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureType;
import com.ruijie.rcos.base.sysmanage.module.def.spi.BaseLicenseFeatureNotifySPI;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseLicenseChangeRequest;
import com.ruijie.rcos.base.sysmanage.module.impl.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.impl.common.Constants;
import com.ruijie.rcos.base.sysmanage.module.impl.dao.LicenseFileDAO;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.LicenseFileEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.license.vo.LicenseInfo;
import com.ruijie.rcos.base.sysmanage.module.impl.service.LicenseContentValidationService;
import com.ruijie.rcos.base.sysmanage.module.impl.service.LicenseFileMoveService;
import com.ruijie.rcos.base.sysmanage.module.impl.service.LicenseFileService;
import com.ruijie.rcos.base.sysmanage.module.impl.service.query.LicenseSpecification;
import com.ruijie.rcos.base.sysmanage.module.impl.tx.LicenseSaveTx;
import com.ruijie.rcos.base.sysmanage.module.impl.util.LicenseUtil;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.log.LoggerFactory;

/**
 * Description: license文件导入
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月5日
 * 
 * @author zouqi
 */
@Service
public class LicenseFileServiceImpl implements LicenseFileService {

    private final static Logger LOGGER = LoggerFactory.getLogger(LicenseFileServiceImpl.class);

    @Autowired
    private LicenseFileDAO licenseFileDAO;

    @Autowired
    private LicenseContentValidationService licenseValidationService;

    @Autowired
    private LicenseFileMoveService licenseFileMoveService;
    
    @Autowired
    private LicenseSaveTx licenseSaveTx;

    @Autowired
    private BaseLicenseFeatureNotifySPI licenseFeatureNotifySPI;

    /**
     * license 文件上传
     * 
     * @param licenseFeatureDTO 请求参数
     * @throws BusinessException 业务异常
     */
    @Override
    public void uploadLicense(BaseLicenseFeatureDTO licenseFeatureDTO) throws BusinessException {
        Assert.notNull(licenseFeatureDTO, "baseLicenseFeatureDTO 不能为空");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("开始处理license文件：{}", licenseFeatureDTO.getFileName());
        }

        // 移动文件到指定目录
        moveLicenseFile(licenseFeatureDTO);
        try {
            // license内容校验
            LicenseInfo lf = licenseValidationService.licenseContentValidation(licenseFeatureDTO);

            // license文件解析后，组成entity 用于保存。
            // 由于一个license文件，可能有多个feature信息，所以可能会保存多个feature信息
            List<LicenseFileEntity> licenseFileEntityList = LicenseUtil.createEntity(licenseFeatureDTO, lf);

            //保存license信息
            licenseSaveTx.saveLicense(licenseFeatureDTO, licenseFileEntityList);

            // 保存成功后 通知页面保存成功
            BaseLicenseChangeRequest changeRequest = LicenseUtil.createBaseLicenseChangeRequest(licenseFileEntityList);

            licenseFeatureNotifySPI.notifyLicenseChange(changeRequest);

        } catch (BusinessException e) {
            //如果文件内容校验失败，则需要删除已经移到指定目录的文件
            licenseFileMoveService.deleteFile(licenseFeatureDTO);
            throw new BusinessException(e.getKey(), e);
        } catch (Exception e) {
            licenseFileMoveService.deleteFile(licenseFeatureDTO);
            throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_LICENSE_FILE_RESOLVE_ERROR, e);
        }
    }

    /**
     * license 文件移动到指定目录
     * 
     * @param licenseFeatureDTO 请求参数
     * @throws BusinessException 业务异常
     */
    private void moveLicenseFile(BaseLicenseFeatureDTO licenseFeatureDTO) throws BusinessException {
        // 首先校验文件合法性
        licenseFileMoveService.licenseFileValidation(licenseFeatureDTO);
        // 然后移动文件到指定目录
        licenseFileMoveService.cutLicenseFile(licenseFeatureDTO);
    }

    /**
     * 初始化license状态
     */
    @Override
    public void initLicense() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("初始化license状态开始");
        }

        List<LicenseFileEntity> licenseFileEntitieList = this.licenseFileDAO.findByFeatureStatusGroupByFeatureCode(BaseFeatureStatus.AVALIABLE);
        if (CollectionUtils.isEmpty(licenseFileEntitieList)) {
            return;
        }
        // FIXME 这里的算法是错的
        for (LicenseFileEntity entity : licenseFileEntitieList) {
            List<LicenseFileEntity> entityList = licenseFileDAO.findByFeatureTypeAndFeatureCodeOrderByCreateTime(BaseFeatureType.TEMPORARY, 
                    entity.getFeatureCode());

            BaseLicenseChangeRequest changeRequest = LicenseUtil.createBaseLicenseChangeRequest(entityList);

            // 遍历通知业务层
            licenseFeatureNotifySPI.notifyLicenseChange(changeRequest);
        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("初始化license状态完成");
        }
    }

    /**
     * 获取license列表
     * 
     * @param request BaseLicenseListRequest
     * @return Page<LicenseFileEntity>
     * @throws BusinessException
     */
    @Override
    public Page<LicenseFileEntity> licenseList(BaseLicenseListRequest request) throws BusinessException {
        Assert.notNull(request, "request参数不能为空");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("获取license列表");
        }
        Pageable pageable = PageRequest.of(request.getPage(), request.getLimit(), Sort.Direction.DESC, Constants.LICNESE_CREATE_TIME_KEY);
        Specification<LicenseFileEntity> specification = new LicenseSpecification(request);
        return licenseFileDAO.findAll(specification, pageable);
    }

    /**
     * 验证文件名
     * 
     * @param name 文件名
     * @return boolean 是否重复
     */
    @Override
    public Boolean checkDuplication(String name) {
        Assert.hasText(name, "name is null");
        return this.licenseFileDAO.existsByFileName(name);
    }

}
