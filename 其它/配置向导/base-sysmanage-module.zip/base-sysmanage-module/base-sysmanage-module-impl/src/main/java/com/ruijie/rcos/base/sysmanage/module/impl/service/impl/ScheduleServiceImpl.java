package com.ruijie.rcos.base.sysmanage.module.impl.service.impl;

import java.util.Map;

import com.ruijie.rcos.base.sysmanage.module.impl.quartz.data.QuartzTaskData;
import org.quartz.*;
import org.quartz.impl.StdSchedulerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.ruijie.rcos.base.sysmanage.module.impl.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.impl.quartz.BusinessJob;
import com.ruijie.rcos.base.sysmanage.module.impl.service.ScheduleService;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.log.LoggerFactory;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月07日
 *
 * @author xgx
 */
@Service
public class ScheduleServiceImpl implements ScheduleService, InitializingBean {
    private static final Logger LOGGER = LoggerFactory.getLogger(ScheduleServiceImpl.class);

    private Scheduler scheduler;

    @Override
    public void afterPropertiesSet() throws Exception {
        scheduler = StdSchedulerFactory.getDefaultScheduler();
        scheduler.start();
    }

    @Override
    public void addSchedule(String group, String name, String cronExpression, Map<String, QuartzTaskData> dataMap) throws BusinessException {
        Assert.hasText(group, "任务组不能为空");
        Assert.hasText(name, "任务名不能为空");
        Assert.hasText(cronExpression, "cron表达式不能为空");
        Assert.notNull(dataMap, "任务数据不能为空");

        LOGGER.debug("【创建】开始添加定时器：[group:{}][name:[]][cron:{}]", group, name, cronExpression);

        JobDataMap jobDataMap = new JobDataMap(dataMap);
        JobKey jobKey = JobKey.jobKey(name, group);
        try {
            if (scheduler.checkExists(jobKey)) {
                LOGGER.error("【创建】定时器已存在");
                throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_SCHEDULE_TASK_EXIST);
            }
            JobDetail jobDetail = createJobDetail(jobKey, jobDataMap);
            Trigger trigger = createTrigger(group, name, cronExpression);
            scheduler.scheduleJob(jobDetail, trigger);
            LOGGER.debug("【创建】添加定时器group:{},name:{}成功", jobKey.getGroup(), jobKey.getName());
        } catch (SchedulerException e) {
            LOGGER.error("【创建】程序调度异常", e);
            throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_CREATE_SCHEDULE_TASK_FALL, e);
        }
        LOGGER.debug("【创建】添加定时器成功");
    }

    @Override
    public void updateSchedule(String group, String name, String cronExpression, Map<String, QuartzTaskData> dataMap) throws BusinessException {
        Assert.hasText(group, "任务组不能为空");
        Assert.hasText(name, "任务名不能为空");
        Assert.hasText(cronExpression, "cron表达式不能为空");
        Assert.notNull(dataMap, "任务数据不能为空");

        LOGGER.debug("【更新】开始更新定时器：[group:{}][name:[]][cron:{}]", group, name, cronExpression);

        JobKey jobKey = JobKey.jobKey(name, group);
        try {
            if (scheduler.checkExists(jobKey)) {
                scheduler.deleteJob(jobKey);
            } else {
                LOGGER.warn("【更新】定时器不存在");
            }

            LOGGER.debug("【更新】删除定时器group:{},name:{}成功", jobKey.getGroup(), jobKey.getName());
            JobDataMap jobDataMap = new JobDataMap(dataMap);
            JobDetail jobDetail = createJobDetail(jobKey, jobDataMap);
            Trigger trigger = createTrigger(group, name, cronExpression);
            scheduler.scheduleJob(jobDetail, trigger);
            LOGGER.debug("【更新】添加定时器group:{},name:{}成功", jobKey.getGroup(), jobKey.getName());
        } catch (SchedulerException e) {
            LOGGER.error("【更新】程序调度异常", e);
            throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_UPDATE_SCHEDULE_TASK_FALL, e);
        }
        LOGGER.debug("【更新】更新定时器成功");
    }

    @Override
    public void deleteSchedule(String group, String name) throws BusinessException {
        LOGGER.debug("【删除】开始删除定时器");
        Assert.hasText(group, "任务组不能为空");
        Assert.hasText(name, "任务名不能为空");
        try {
            JobKey jobKey = JobKey.jobKey(name, group);
            if (scheduler.checkExists(jobKey)) {
                scheduler.deleteJob(jobKey);
            } else {
                LOGGER.warn("【更新】定时器不存在");
            }
            LOGGER.debug("【删除】删除定时器group:{},name:{}成功", group, name);
        } catch (SchedulerException e) {
            LOGGER.error("【删除】程序调度异常", e);
            throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_DELETE_SCHEDULE_TASK_FALL, e);
        }
        LOGGER.debug("【删除】删除定时器成功");
    }

    private JobDetail createJobDetail(JobKey jobKey, JobDataMap jobDataMap) {
        return JobBuilder.newJob(BusinessJob.class).withIdentity(jobKey).setJobData(jobDataMap).build();
    }

    private Trigger createTrigger(String group, String name, String cronExpression) {
        TriggerKey triggerKey = TriggerKey.triggerKey(name, group);
        return TriggerBuilder.newTrigger().withIdentity(triggerKey).withSchedule(CronScheduleBuilder.cronSchedule(cronExpression)).build();
    }

}
