package com.ruijie.rcos.base.sysmanage.module.impl.service.query;

import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.Assert;
import com.google.common.collect.Lists;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.BaseLicenseListRequest;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.LicenseFileEntity;

/**
 * Description: license列表
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年03月19日
 *
 * @author zouqi
 */
public class LicenseSpecification implements Specification<LicenseFileEntity> {

    private static final long serialVersionUID = -3793052347986735339L;

    @SuppressWarnings("unused")
    private final BaseLicenseListRequest request;

    public LicenseSpecification(BaseLicenseListRequest request) {
        Assert.notNull(request, "BaseLicenseListRequest is null");
        this.request = request;
    }

    @Override
    public Predicate toPredicate(Root<LicenseFileEntity> root, CriteriaQuery<?> query,
            CriteriaBuilder criteriaBuilder) {
        Assert.notNull(root,"root参数不能为空");
        Assert.notNull(query,"query参数不能为空");
        Assert.notNull(criteriaBuilder,"builder参数不能为空");

        List<Predicate> predicateList = Lists.newArrayList();
        return query.where(predicateList.toArray(new Predicate[predicateList.size()])).getRestriction();
    }

}
