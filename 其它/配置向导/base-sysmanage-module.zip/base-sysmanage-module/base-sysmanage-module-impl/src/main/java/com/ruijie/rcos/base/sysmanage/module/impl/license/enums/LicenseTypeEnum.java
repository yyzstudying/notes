package com.ruijie.rcos.base.sysmanage.module.impl.license.enums;

/**
 * Description: license 类型 枚举类
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月18日
 * 
 * @author zouqi
 */
public enum LicenseTypeEnum {
	COMMERCIAL,//商业版
	TEMP,      //临时版
	DEVELOP,   //开发版
}
