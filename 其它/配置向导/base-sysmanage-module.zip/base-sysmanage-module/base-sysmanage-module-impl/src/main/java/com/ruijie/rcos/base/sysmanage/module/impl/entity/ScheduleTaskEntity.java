package com.ruijie.rcos.base.sysmanage.module.impl.entity;

import com.ruijie.rcos.base.sysmanage.module.def.enums.TaskCycle;

import java.util.Date;
import java.util.UUID;

import javax.persistence.*;

/**
 * Description: 定时任务
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月05日
 *
 * @author xgx
 */
@Entity
@Table(name = "t_base_sysmanage_schedule_task")
public class ScheduleTaskEntity {
    /**
     * 唯一标识
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    /**
     * 任务类型id
     */
    private UUID taskTypeId;

    /**
     * 任务周期
     */
    @Enumerated(value = EnumType.STRING)
    private TaskCycle taskCycle;

    /**
     * 定时器表达式
     */
    private String cronExpression;

    /**
     * 描述
     */
    private String description;


    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 版本号
     */
    @Version
    private int version;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public UUID getTaskTypeId() {
        return taskTypeId;
    }

    public void setTaskTypeId(UUID taskTypeId) {
        this.taskTypeId = taskTypeId;
    }

    public TaskCycle getTaskCycle() {
        return taskCycle;
    }

    public void setTaskCycle(TaskCycle taskCycle) {
        this.taskCycle = taskCycle;
    }

    public String getCronExpression() {
        return cronExpression;
    }

    public void setCronExpression(String cronExpression) {
        this.cronExpression = cronExpression;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }
}
