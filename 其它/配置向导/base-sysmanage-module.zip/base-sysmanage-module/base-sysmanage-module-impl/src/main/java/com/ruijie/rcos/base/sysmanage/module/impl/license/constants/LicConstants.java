package com.ruijie.rcos.base.sysmanage.module.impl.license.constants;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月18日
 * 
 * @author zouqi
 */
public interface LicConstants {
    
    String LIC_TYPE_KEY = "license.type";
    
    String LIC_PRODUCT = "license.product";
    
    String LIC_SN_KEY = "license.sn";
    
    String LIC_PRODUCT_CODE = "license.productcode";
    
    String LIC_SIGN_KEY = "signature";
    
    String LIC_START_KEY = "license.start";
    
    String LIC_TIME_KEY = "license.time";
    
    String LIC_F_PRE_KEY = "license.feature.";//Feature前置描述符
    
    String LIC_F_ONOFF_PRE_KEY = "feature.onoff.";//Feature功能开关前缀
    
    String LIC_F_DATA_PRE_KEY = "feature.data.";//Feature功能数据值前缀
    
    String LIC_F_START_PRE_KEY = "feature.start.";//Feature功能开始时间
    
    String LIC_F_TIME_PRE_KEY = "feature.time.";//Feature功能有效时长
    
    String LIC_F_ONOFF_ON = "on";//功能开关：打开
    
    String LIC_F_ONOFF_OFF = "off";//功能开关：关闭
	
}
