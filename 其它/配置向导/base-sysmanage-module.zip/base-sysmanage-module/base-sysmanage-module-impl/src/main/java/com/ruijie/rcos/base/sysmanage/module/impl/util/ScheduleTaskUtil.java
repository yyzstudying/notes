package com.ruijie.rcos.base.sysmanage.module.impl.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Arrays;

import com.ruijie.rcos.base.sysmanage.module.impl.BusinessKey;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import org.springframework.lang.Nullable;
import org.springframework.util.Assert;

import com.ruijie.rcos.base.sysmanage.module.def.enums.TaskCycle;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.log.LoggerFactory;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月14日
 *
 * @author xgx
 */
public class ScheduleTaskUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(ScheduleTaskUtil.class);

    /**
     * 定时任务参数校验
     * 
     * @param taskCycle 周期
     * @param dayOfWeekArr 周
     * @param scheduleDate 日期
     * @param scheduleTime 时间
     * @throws BusinessException 业务异常
     */
    public static void validateScheduleTaskArgs(TaskCycle taskCycle, @Nullable Integer[] dayOfWeekArr, @Nullable LocalDate scheduleDate,
            LocalTime scheduleTime) throws BusinessException {
        Assert.notNull(taskCycle, "周期不能为空");
        Assert.notNull(scheduleTime, "定时时间不能为空");
        if (TaskCycle.WEEK == taskCycle) {
            LOGGER.debug("【API校验】参数：{}, 开始周周期校验", dayOfWeekArr);
            Assert.notEmpty(dayOfWeekArr, "周期为WEEK，星期几触发参数不能为空");
            Arrays.stream(dayOfWeekArr).forEach((weekDay) -> Assert.state(weekDay > 0 && weekDay <= 7, "星期几参数格式错误"));
        } else if (TaskCycle.ONCE == taskCycle) {
            LOGGER.debug("【API校验】开始一次性定时任务校验：{}", scheduleDate);
            Assert.notNull(scheduleDate, "触发日期参数不能为空");
            LocalDateTime oneHundredYearBeforeConfigLocalDateTime = LocalDateTime.of(scheduleDate, scheduleTime).minusYears(100);
            if (oneHundredYearBeforeConfigLocalDateTime.isAfter(LocalDateTime.now())) {
                throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_ONE_HUNDRED_YEAR_AFTER_NOW);
            }
        }
    }
}
