package com.ruijie.rcos.base.sysmanage.module.impl.quartz.dispatcher;

import org.quartz.JobExecutionContext;

/**
 * Description: 任务分发器接口 可配置
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月28日
 *
 * @author xgx
 */
public interface JobDispatcher {
    /**
     * 任务分发器
     * 
     * @param context 定时器执行上下文
     */
    void dispatcher(JobExecutionContext context);
}
