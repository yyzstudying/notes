package com.ruijie.rcos.base.sysmanage.module.impl.service.impl;

import java.io.File;
import java.util.Date;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.ruijie.rcos.base.sysmanage.module.def.api.request.debuglog.BaseListDebugLogRequest;
import com.ruijie.rcos.base.sysmanage.module.impl.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.impl.common.Constants;
import com.ruijie.rcos.base.sysmanage.module.impl.dao.DebugLogDAO;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.DebugLogEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.service.DebugLogService;
import com.ruijie.rcos.base.sysmanage.module.impl.service.query.DebugLogSpecification;
import com.ruijie.rcos.base.sysmanage.module.impl.util.FileNameUtil;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.filesystem.SkyengineFile;
import com.ruijie.rcos.sk.base.i18n.LocaleI18nResolver;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.log.LoggerFactory;
import com.ruijie.rcos.sk.base.shell.ShellCommandRunner;
import com.ruijie.rcos.sk.modulekit.api.tool.GlobalParameterAPI;

/**
 * Description: 调试日志服务实现类
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月19日
 *
 * @author fyq
 */
@Service
public class DebugLogServiceImpl implements DebugLogService {

    private static final Logger LOGGER = LoggerFactory.getLogger(DebugLogServiceImpl.class);

    private static final String GLOBAL_PARAM_DEBUG_LOG_PATH = "debug_log_path";


    @Autowired
    private GlobalParameterAPI globalParameterAPI;

    @Autowired
    private DebugLogDAO debugLogDAO;

    @Override
    public DebugLogEntity createDebugLog() throws BusinessException {

        LOGGER.debug("【调试日志服务】 创建调试日志打包文件");

        String uuid = UUID.randomUUID().toString();
        final String realFileName = new ShellCommandRunner() //
                .setCommand(Constants.SH_LOG_COLLECT) //
                .appendArgs(uuid) //
                .execute();


        String fileName = FileNameUtil.getFileName(LocaleI18nResolver.resolve(BusinessKey.BASE_SYS_MANAGE_LOG_BAK_NAME), debugLogDAO);

        DebugLogEntity entity = new DebugLogEntity();
        entity.setRealFileName(realFileName);
        entity.setFileName(fileName);
        entity.setCreateTime(new Date());

        LOGGER.debug("【调试日志服务】 保存实体信息 {}", entity);

        return debugLogDAO.save(entity);
    }

    @Override
    public DebugLogEntity deleteDebugLog(UUID id) throws BusinessException {

        Assert.notNull(id, "参数不能为空");

        DebugLogEntity entity = debugLogDAO.getOne(id);

        if (entity == null) {
            LOGGER.error("【调试日志服务】 实体不存在 id:{}", id);
            throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_DEBUG_LOG_NOT_EXITS);
        }

        LOGGER.warn("【调试日志服务】 删除实体 {}", entity);
        debugLogDAO.delete(entity);

        final String path = getDebugLogPath();

        final File file = new File(path, entity.getRealFileName());
        final SkyengineFile skyengineFile = new SkyengineFile(file);

        boolean isDeleted = skyengineFile.delete(false);

        if (!isDeleted) {
            LOGGER.warn("【调试日志服务】 删除文件失败:{}", file.getAbsolutePath());
        }

        LOGGER.debug("【调试日志服务】 删除调试日志记录成功 {}", id);

        return entity;
    }

    @Override
    public DebugLogEntity detailDebugLog(UUID id) {
        Assert.notNull(id, "id参数不能为空");

        LOGGER.debug("【调试日志服务】 获取调试日志 {}", id);
        return debugLogDAO.getOne(id);
    }

    @Override
    public String getDebugLogPath() {
        return globalParameterAPI.findParameter(GLOBAL_PARAM_DEBUG_LOG_PATH);
    }

    @Override
    public Page<DebugLogEntity> listDebugLog(BaseListDebugLogRequest request) {
        Assert.notNull(request, "request参数不能为空");

        LOGGER.debug("【调试日志服务】 获取调试日志列表");

        Pageable pageable = PageRequest.of(request.getPage(), request.getLimit(), Sort.Direction.DESC, Constants.DEBUG_LOG_DEFAULT_ORDER);
        Specification<DebugLogEntity> specification = new DebugLogSpecification(request);
        return debugLogDAO.findAll(specification, pageable);
    }
}
