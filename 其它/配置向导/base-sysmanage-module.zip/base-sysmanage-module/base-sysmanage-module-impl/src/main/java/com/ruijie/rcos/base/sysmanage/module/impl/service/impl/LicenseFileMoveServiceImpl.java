package com.ruijie.rcos.base.sysmanage.module.impl.service.impl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import com.ruijie.rcos.base.sysmanage.module.def.dto.license.BaseLicenseFeatureDTO;
import com.ruijie.rcos.base.sysmanage.module.impl.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.impl.dao.LicenseFileDAO;
import com.ruijie.rcos.base.sysmanage.module.impl.service.LicenseFileMoveService;
import com.ruijie.rcos.sk.base.config.ConfigFacade;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.log.LoggerFactory;

/**
 * Description: license文件合法性校验service实现类
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月12日
 * 
 * @author zouqi
 */
@Service
public class LicenseFileMoveServiceImpl implements LicenseFileMoveService {

    private final static Logger LOGGER = LoggerFactory.getLogger(LicenseFileMoveServiceImpl.class);
    
    private final static String LICENSE_FILE_PATH = "file.busiz.dir.license";
    
    //上传文件大小先限制为1M
    private final static long FILE_SIZE_LIMIT = 1048576L;

    @Autowired
    private LicenseFileDAO licenseFileDAO;
    
    @Autowired
    private ConfigFacade configFacade;
    
    @Override
    public void licenseFileValidation(BaseLicenseFeatureDTO licenseFeatureDTO) throws BusinessException {
        Assert.notNull(licenseFeatureDTO, "BaseLicenseFeatureDTO 不能为空");
        Assert.notNull(licenseFeatureDTO.getFileName(), "FileName 不能为空");
        Assert.notNull(licenseFeatureDTO.getFilePath(), "FilePath 不能为空");
        Assert.notNull(licenseFeatureDTO.getFileMd5(), "FileMd5 不能为空");
        
        File tmpFile = new File(licenseFeatureDTO.getFilePath());
        //文件不存在，则抛出异常。
        if (tmpFile.exists() == false) {
            LOGGER.error("license文件不存在 ，license文件名 ：{}" , licenseFeatureDTO.getFileName());
            throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_LICENSE_FILE_NOT_EXIST);
        }
        //如果文件大小超过限定大小，则抛出异常。
        if (tmpFile.length() > FILE_SIZE_LIMIT) {
            LOGGER.error("license文件大小超过限定，license文件名：{}" , licenseFeatureDTO.getFileName());
            throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_LICENSE_FILE_OVERSIZE);
        }
        //数据库中文件名若已经存在，则并抛出异常。
        boolean isExistByFileName = licenseFileDAO.existsByFileName(licenseFeatureDTO.getFileName());
        if (isExistByFileName) {
            LOGGER.error("license已存在，license文件名：{}" , licenseFeatureDTO.getFileName() );
            throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_LICENSE_FILE_EXIST);
        }
        //数据库中文件MD5若已经存在，则并抛出异常。
        boolean isExistByFileMd5 = licenseFileDAO.existsByFileMd5(licenseFeatureDTO.getFileMd5());
        if (isExistByFileMd5) {
            LOGGER.error("license已存在，license文件名：{}" , licenseFeatureDTO.getFileName() );
            throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_LICENSE_FILE_EXIST);
        }

    }

    @Override
    public void cutLicenseFile(BaseLicenseFeatureDTO licenseFeatureDTO) throws BusinessException {
        Assert.notNull(licenseFeatureDTO, "BaseLicenseFeatureDTO 不能为空");
        Assert.notNull(licenseFeatureDTO.getFileName(), "FileName 不能为空");
        Assert.notNull(licenseFeatureDTO.getFilePath(), "FilePath 不能为空");
        
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("开始剪切license文件： {}",licenseFeatureDTO.getFileName());
        }

        String tmpFilePath = licenseFeatureDTO.getFilePath();
        File tmpFile = new File(tmpFilePath);
        String saveFilePath = configFacade.read(LICENSE_FILE_PATH) + licenseFeatureDTO.getFileName();
        File saveFile = new File(saveFilePath);
        long fileSize = tmpFile.length();
        try {
            // 移动文件到指定目录
            Files.move(tmpFile.toPath(), saveFile.toPath());
        } catch (IOException e) {
            throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_LICENSE_FILE_MOVE_ERROR,e);
        }
        
        long resultFileSize = saveFile.length();
        //如果license大小和前端上传的大小不一样，则表示文件上传过程中出错，则抛出异常。  
        if (resultFileSize != fileSize) {
            LOGGER.error("license文件移动出错，文件名：{}" , licenseFeatureDTO.getFileName());
            //移动文件出错删除文件
            deleteFile(licenseFeatureDTO);
            throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_LICENSE_FILE_SIZE_UNEQUAL,
                    licenseFeatureDTO.getFileName(),String.valueOf(fileSize),String.valueOf(resultFileSize));
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("完成剪切license文件 {}",licenseFeatureDTO.getFileName());
        }
    }

    @Override
    public void deleteFile(BaseLicenseFeatureDTO licenseFeatureDTO) throws BusinessException {
        Assert.notNull(licenseFeatureDTO, "BaseLicenseFeatureDTO 不能为空");
        Assert.notNull(licenseFeatureDTO.getFileName(), "FileName 不能为空");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("开始删除license文件 {}",licenseFeatureDTO.getFileName());
        }
        String saveFilePath = configFacade.read(LICENSE_FILE_PATH) + licenseFeatureDTO.getFileName();
        File saveFile = new File(saveFilePath);
        //文件不存在，则抛出异常。
        if (saveFile.exists() == false) {
            LOGGER.info("license文件不存在 ，license文件名 ：{}" , licenseFeatureDTO.getFileName());
            return;
        }
        try {
            // 移动文件到指定目录
            Files.delete(saveFile.toPath());
        } catch (IOException e) {
            LOGGER.error("license文件删除出错，文件名：{}" , licenseFeatureDTO.getFileName());
            throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_LICENSE_FILE_DELETE_ERROR, e);
        }
        
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("删除license文件完成 {}",licenseFeatureDTO.getFileName());
        }
    }

}
