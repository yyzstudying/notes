package com.ruijie.rcos.base.sysmanage.module.impl.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;

import com.ruijie.rcos.base.sysmanage.module.def.api.SystemTimeAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.systemtime.BaseUpdateSystemTimeFromNtpRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.systemtime.BaseUpdateSystemTimeRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.systemtime.BaseUpdateSystemTimeResponse;
import com.ruijie.rcos.base.sysmanage.module.impl.service.SystemTimeService;
import com.ruijie.rcos.sk.base.exception.BusinessException;

/**
 * Description: 系统时间接口实现类
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年11月28日
 *
 * @author fyq
 */
public class SystemTimeAPIImpl implements SystemTimeAPI {

    @Autowired
    private SystemTimeService systemTimeService;

    @Override
    public BaseUpdateSystemTimeResponse updateSystemTime(BaseUpdateSystemTimeRequest apiRequest) throws BusinessException {

        Assert.notNull(apiRequest, "请求参数不能为空");

        boolean shouldReboot = systemTimeService.updateSystemTime(apiRequest.getTime());

        return new BaseUpdateSystemTimeResponse(shouldReboot);
    }

    @Override
    public BaseUpdateSystemTimeResponse updateSystemTimeFromNtp(BaseUpdateSystemTimeFromNtpRequest apiRequest) throws BusinessException {

        Assert.notNull(apiRequest, "请求参数不能为空");

        boolean shouldReboot = systemTimeService.updateSystemTimeFromNtp(apiRequest.getNtpServer());

        return new BaseUpdateSystemTimeResponse(shouldReboot);
    }
}
