package com.ruijie.rcos.base.sysmanage.module.impl.quartz.dispatcher;

import java.util.concurrent.TimeUnit;

import com.ruijie.rcos.sk.base.exception.BusinessException;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.google.common.base.Stopwatch;
import com.ruijie.rcos.base.aaa.module.def.api.BaseSystemLogMgmtAPI;
import com.ruijie.rcos.base.aaa.module.def.api.request.systemlog.BaseCreateSystemLogRequest;
import com.ruijie.rcos.base.sysmanage.module.impl.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.impl.common.Constants;
import com.ruijie.rcos.base.sysmanage.module.impl.quartz.data.ComponentQuartzTaskData;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.log.LoggerFactory;
import com.ruijie.rcos.sk.base.quartz.QuartzTask;

/**
 * Description: Function Description 组件
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月28日
 *
 * @author xgx
 */
@Service(Constants.SCHEDULE_DISPATCHER_TYPE_COMPONENT)
public class ComponentJobDispatcher implements JobDispatcher {
    private static final Logger LOGGER = LoggerFactory.getLogger(ComponentJobDispatcher.class);

    @Autowired
    private BaseSystemLogMgmtAPI baseSystemLogMgmtAPI;

    @Override
    public void dispatcher(JobExecutionContext context) {
        Assert.notNull(context, "context不能为空");
        Stopwatch stopWatch = Stopwatch.createStarted();
        JobDataMap data = context.getJobDetail().getJobDataMap();
        ComponentQuartzTaskData quartzTaskData = (ComponentQuartzTaskData) data.get(Constants.SCHEDULE_DATA_KEY);
        QuartzTask quartzTask = quartzTaskData.getQuartzTask();
        try {
            quartzTask.execute();
            baseSystemLogMgmtAPI.createSystemLog(new BaseCreateSystemLogRequest(BusinessKey.BASE_SYS_MANAGE_EXECUTE_SCHEDULE_SUCCESS,
                    quartzTaskData.getName(), String.valueOf(stopWatch.elapsed(TimeUnit.MILLISECONDS))));
        } catch (Throwable e) {
            LOGGER.error("执行定时任务[" + quartzTaskData.getName() + "]失败", e);
            String errorMsg = e instanceof BusinessException ? ((BusinessException) e).getI18nMessage() : e.getMessage();
            baseSystemLogMgmtAPI.createSystemLog(new BaseCreateSystemLogRequest(BusinessKey.BASE_SYS_MANAGE_EXECUTE_SCHEDULE_FAIL,
                    quartzTaskData.getName(), String.valueOf(stopWatch.elapsed(TimeUnit.MILLISECONDS)), errorMsg));
        }
        stopWatch.stop();
    }
}
