package com.ruijie.rcos.base.sysmanage.module.impl.quartz;

import java.io.File;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.ObjectUtils;

import com.ruijie.rcos.base.sysmanage.module.impl.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.impl.common.Constants;
import com.ruijie.rcos.base.sysmanage.module.impl.dao.DataBackupDAO;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.DataBackupEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.service.DataBackupService;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.filesystem.SkyengineFile;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.log.LoggerFactory;
import com.ruijie.rcos.sk.base.quartz.Quartz;
import com.ruijie.rcos.sk.base.quartz.QuartzTask;
import com.ruijie.rcos.sk.modulekit.api.isolation.GlobalUniqueBean;
import com.ruijie.rcos.sk.modulekit.api.tool.GlobalParameterAPI;

/**
 * Description: 数据库备份定时任务
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月06日
 *
 * @author fyq
 */
@GlobalUniqueBean("dataBackupTask")
@Quartz(cron = "0 0 0 * * ? *", msgKey = BusinessKey.BASE_SYS_MANAGE_DATA_BACKUP)
public class DataBackupTask implements QuartzTask {
    private static final Logger LOGGER = LoggerFactory.getLogger(DataBackupTask.class);

    private static final int SEVEN_DAY = 7;

    @Autowired
    private GlobalParameterAPI globalParameterAPI;

    @Autowired
    private DataBackupService dataBackupService;

    @Autowired
    private DataBackupDAO dataBackupDAO;

    /**
     * 数据库备份定时自动备份任务
     *
     * @throws BusinessException 业务异常
     */
    @Override
    public void execute() throws BusinessException {
        dataBackupService.createDataBackup(true);
        deleteExpireData();
        deleteInvalidFile();
    }

    private void deleteExpireData() throws BusinessException {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        calendar.add(Calendar.DATE, -SEVEN_DAY);
        Date startTimeOfSevenDayBefore = calendar.getTime();

        List<DataBackupEntity> expireDataBackupList = dataBackupService.listExpireDataBackup(startTimeOfSevenDayBefore, true);
        for (DataBackupEntity dataBackupEntity : expireDataBackupList) {
            dataBackupService.deleteDataBackup(dataBackupEntity.getId());
        }
    }

    private void deleteInvalidFile() {
        String dataBackupPath = globalParameterAPI.findParameter(Constants.GLOBAL_PARAM_DB_BACKUP_PATH);
        File directory = new File(dataBackupPath);
        if (!directory.exists()) {
            LOGGER.info("数据库备份目录不存在：{}", dataBackupPath);
            return;
        }

        File[] fileArr = directory.listFiles((dir, name) -> name.endsWith(".tar.gz"));
        if (ObjectUtils.isEmpty(fileArr)) {
            LOGGER.info("不存在备份的数据库文件");
            return;
        }

        List<DataBackupEntity> dataBackupEntityList = dataBackupDAO.findAll();
        deleteInvalidFile(fileArr, dataBackupEntityList);
    }

    private void deleteInvalidFile(File[] files, List<DataBackupEntity> dataBackupEntityList) {
        if (ObjectUtils.isEmpty(dataBackupEntityList)) {
            Arrays.stream(files).forEach((file) -> new SkyengineFile(file).delete(true));
            return;
        }
        for (File file : files) {
            final String fileName = file.getName();
            if (isFileInvalid(dataBackupEntityList, fileName)) {
                new SkyengineFile(file).delete(true);
            }
        }
    }

    private boolean isFileInvalid(List<DataBackupEntity> dataBackupEntityList, String fileName) {
        for (DataBackupEntity dataBackupEntity : dataBackupEntityList) {
            if (fileName.equals(dataBackupEntity.getRealFileName())) {
                return false;
            }
        }
        return true;
    }
}
