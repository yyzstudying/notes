package com.ruijie.rcos.base.sysmanage.module.impl.service.query;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

import com.google.common.collect.Lists;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.databackup.BaseListDataBackupRequest;
import com.ruijie.rcos.base.sysmanage.module.impl.common.Constants;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.DataBackupEntity;
import org.springframework.util.Assert;

/**
 * Description: 数据库备份列表查询
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月19日
 *
 * @author fyq
 */
public class DataBackupSpecification implements Specification<DataBackupEntity> {

    private static final long serialVersionUID = -3793052347986735339L;

    private BaseListDataBackupRequest request;

    public DataBackupSpecification(BaseListDataBackupRequest request) {
        this.request = request;
    }

    @Override
    public Predicate toPredicate(Root<DataBackupEntity> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
        Assert.notNull(root,"root参数不能为空");
        Assert.notNull(query,"query参数不能为空");
        Assert.notNull(builder,"builder参数不能为空");

        List<Predicate> predicateList = Lists.newArrayList();

        if (request.getStartTime() != null) {
            predicateList.add(builder.greaterThanOrEqualTo(root.get(Constants.DATA_BACKUP_DATE_COLUMN), request.getStartTime()));
        }
        if (request.getEndTime() != null) {
            predicateList.add(builder.lessThanOrEqualTo(root.get(Constants.DATA_BACKUP_DATE_COLUMN), request.getEndTime()));
        }
        return query.where(predicateList.toArray(new Predicate[predicateList.size()])).getRestriction();
    }
}
