package com.ruijie.rcos.base.sysmanage.module.impl.quartz.dispatcher;

import java.util.Date;
import java.util.UUID;

import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.ruijie.rcos.base.sysmanage.module.impl.common.Constants;
import com.ruijie.rcos.base.sysmanage.module.impl.dao.ScheduleLogDAO;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.ScheduleLogEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.quartz.data.ConfigQuartzTaskData;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.log.LoggerFactory;
import com.ruijie.rcos.sk.base.quartz.QuartzTask;

/**
 * Description: 可配置任务分发器
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月28日
 *
 * @author xgx
 */
@Service(Constants.SCHEDULE_DISPATCHER_TYPE_CONFIGURABLE)
public class ConfigurableJobDispatcher implements JobDispatcher {
    private static final Logger LOGGER = LoggerFactory.getLogger(ConfigurableJobDispatcher.class);

    private static final int MAX_ERROR_MESSAGE_LENGTH = 256;

    @Autowired
    private ScheduleLogDAO scheduleLogDAO;


    @Override
    public void dispatcher(JobExecutionContext context) {
        LOGGER.debug("定时任务开始执行");
        Assert.notNull(context, "任务执行上下文不能为空");
        JobDetail jobDetail = context.getJobDetail();
        JobDataMap dataMap = jobDetail.getJobDataMap();
        ConfigQuartzTaskData quartzTaskData = (ConfigQuartzTaskData) dataMap.get(Constants.SCHEDULE_DATA_KEY);
        String name = jobDetail.getKey().getName();
        Date startTime = context.getFireTime();
        UUID id = UUID.fromString(name);
        String taskTypeName = quartzTaskData.getTaskTypeName();
        String expression = quartzTaskData.getExpression();

        // 获取定时任务配置
        QuartzTask quartzTask = quartzTaskData.getQuartzTask();

        LOGGER.debug("定时任务开始执行类型：{}, 表达式:{}", taskTypeName, expression);
        ScheduleLogEntity scheduleLogEntity = createScheduleLogEntity(id, expression, startTime, taskTypeName);

        try {
            quartzTask.execute();
        } catch (Throwable e) {
            LOGGER.error("定时任务执行异常，任务类型:[" + taskTypeName + "]", e);
            scheduleLogEntity.setExceptionMsg(getErrorMessage(e));
            scheduleLogEntity.setSuccess(false);
        } finally {
            scheduleLogEntity.setEndTime(new Date());
            scheduleLogDAO.save(scheduleLogEntity);
        }
        LOGGER.debug("定时任务执行结束");
    }

    private String getErrorMessage(Throwable e) {
        String message = e.getMessage();
        if (message.length() > MAX_ERROR_MESSAGE_LENGTH) {
            message = message.substring(0, MAX_ERROR_MESSAGE_LENGTH);
        }
        return message;
    }

    private ScheduleLogEntity createScheduleLogEntity(UUID id, String expression, Date startTime, String taskTypeName) {
        ScheduleLogEntity scheduleLogEntity = new ScheduleLogEntity();
        scheduleLogEntity.setTaskId(id);
        scheduleLogEntity.setCronExpression(expression);
        scheduleLogEntity.setStartTime(startTime);
        scheduleLogEntity.setSuccess(true);
        scheduleLogEntity.setTaskTypeName(taskTypeName);
        return scheduleLogEntity;
    }
}
