package com.ruijie.rcos.base.sysmanage.module.impl.service;

import java.util.UUID;

import org.springframework.data.domain.Page;

import com.ruijie.rcos.base.sysmanage.module.def.api.request.debuglog.BaseListDebugLogRequest;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.DebugLogEntity;
import com.ruijie.rcos.sk.base.exception.BusinessException;

/**
 * Description: 调试日志服务接口
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月19日
 *
 * @author fyq
 */
public interface DebugLogService {

    /**
     * 创建调试日志打包文件服务接口
     * 
     * @throws BusinessException 业务异常
     * @return 返回调试日志实体
     */
    DebugLogEntity createDebugLog() throws BusinessException;

    /**
     * 删除调试日志
     * 
     * @param id 调试日志id
     * @throws BusinessException 业务异常
     * @return 返回调试日志实体
     */
    DebugLogEntity deleteDebugLog(UUID id) throws BusinessException;

    /**
     * 获取调试日志
     *
     * @param id 记录id
     * @return 调试日志Entity
     */
    DebugLogEntity detailDebugLog(UUID id);

    /**
     * 获取调试日志的文件的存放路径
     * 
     * @return 存放路径
     */
    String getDebugLogPath();

    /**
     * 获取调试日志列表
     * 
     * @param listDebugLogRequest 获取调试日志列表请求
     * @return 调试日志列表
     */
    Page<DebugLogEntity> listDebugLog(BaseListDebugLogRequest listDebugLogRequest);
}
