package com.ruijie.rcos.base.sysmanage.module.impl.dao;

import java.util.UUID;

import com.ruijie.rcos.base.sysmanage.module.impl.entity.DebugLogEntity;
import com.ruijie.rcos.sk.modulekit.api.ds.SkyEngineJpaRepository;

/**
 * Description: 调试日志DAO接口
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月19日
 *
 * @author fyq
 */
public interface DebugLogDAO extends SkyEngineJpaRepository<DebugLogEntity, UUID> {
}
