package com.ruijie.rcos.base.sysmanage.module.impl.common;

/**
 * 
 * Description: 常量类
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年11月13日
 * 
 * @author hhx
 */
public interface Constants {


    /** 调用任务 */
    String KEY_TASK = "key_action";

    /** 重启机子 */
    String REBOOT_HOST_COMMD = "shutdown -r now";

    /** 关闭机子 */
    String POWEROFF_HOST_COMMD = "shutdown -h now";


    String SH_COMMAND_COMMON = "sh /data/web/rcdc/shell";

    /********************** 时间配置常量 *****************************/
    /** 修改系统时间 */
    String SH_TIME_CHANGE = SH_COMMAND_COMMON + "/changeTime.sh";

    /** 从NTP服务器同步系统时间 */
    String SH_TIME_CHANGE_FROM_NTP = SH_COMMAND_COMMON + "/changeTimeFromNtp.sh";

    /** 修改系统时间，重启系统脚本 */
    String SH_TIME_CHANGE_RESTART_SYSTEM = SH_COMMAND_COMMON + "/reboot.sh";

    /** 修改系统时间，重启系统延时 */
    int SH_TIME_CHANGE_RESTART_DELAY = 3000;

    /** 修改系统时间，重启系统任务名 */
    String SH_TIME_CHANGE_RESTART_TASK_NAME = "systemRebootTask";

    int SH_NTP_SERVER_UNREACHABLE_ERROR = 101;


    /********************** 网卡配置常量 *****************************/

    /** 获取网卡信息 */
    String SH_IP_INFO = SH_COMMAND_COMMON + "/networkInfo.sh";

    /** 设置网卡IP、掩码、网关、DNS信息 */
    String SH_IP_CONFIG = SH_COMMAND_COMMON + "/networkConfig.sh";

    /** 重启网卡服务 */
    String SH_RESTART_NETWORK = SH_COMMAND_COMMON + "/networkRestart.sh";

    /** 重启网卡服务延时 */
    int SH_IP_CHANGE_RESTART_DELAY = 3000;

    /** 重启网卡服务线程名 */
    String SH_IP_CHANGE_RESTART_TASK_NAME = "networkServiceRestartTask";



    /********************** 数据库备份常量 *****************************/

    /** 创建数据库备份 */
    String SH_DATA_BACKUP = SH_COMMAND_COMMON + "/pgBackup.sh";

    /** 数据库备份排序字段 */
    String DATA_BACKUP_DEFAULT_ORDER = "createTime";

    /** 数据库备份时间字段 */
    String DATA_BACKUP_DATE_COLUMN = "createTime";

    /** 数据库备份搜索字段 */
    String DATA_BACKUP_SEARCH_COLUMN = "fileName";

    /** 数据库备份回滚常量 */
    String DATA_BACKUP_ROLLBACK_FILENAME = "fileName";

    String GLOBAL_PARAM_DB_BACKUP_PATH = "db_backup_path";

    /********************** 调试日志常量 *****************************/

    /** 收集调试日志 */
    String SH_LOG_COLLECT = SH_COMMAND_COMMON + "/logCollect.sh";

    /** 调试日志排序字段 */
    String DEBUG_LOG_DEFAULT_ORDER = "createTime";

    /** 调试日志创建时间字段 */
    String DEBUG_LOG_DATE_COLUMN = "createTime";

    /** 调试日志搜索字段 */
    String DEBUG_LOG_SEARCH_COLUMN = "fileName";

    /** 调试日志回滚常量 */
    String DEBUG_LOG_ROLLBACK_FILENAME = "fileName";


    /********************** 公共常量 *****************************/
    /** 一分钟的毫秒数 */
    int ONE_MINUTE_MILLS = 60 * 1000;

    /** 空格，主要用于拼接命令参数 */
    String SPACE = " ";

    String SCHEDULE_DEFAULT_GROUP = "default";

    String SCHEDULE_DISPATCHER_BEAN_NAME = "dispatcherBeanName";

    String SCHEDULE_DISPATCHER_TYPE_COMPONENT = "componentJobDispatcher";

    String SCHEDULE_DISPATCHER_TYPE_CONFIGURABLE = "configurableJobDispatcher";

    String SCHEDULE_PROCESS_INSTANCE = "scheduleProcessInstance";


    String SCHEDULE_DATA_KEY = "schedule_data_key";
    
    String LICNESE_CREATE_TIME_KEY = "createTime";


}
