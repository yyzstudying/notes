package com.ruijie.rcos.base.sysmanage.module.impl.api;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.util.Assert;
import org.springframework.util.ObjectUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ruijie.rcos.base.sysmanage.module.def.api.ScheduleAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.schedule.*;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.schedule.BaseBatchQueryScheduleResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.schedule.BaseListTaskTypeResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.schedule.BaseQueryScheduleResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.schedule.BaseQueryTaskTypeResponse;
import com.ruijie.rcos.base.sysmanage.module.def.common.Constant;
import com.ruijie.rcos.base.sysmanage.module.def.dto.ScheduleDTO;
import com.ruijie.rcos.base.sysmanage.module.def.dto.ScheduleTypeDTO;
import com.ruijie.rcos.base.sysmanage.module.def.enums.TaskCycle;
import com.ruijie.rcos.base.sysmanage.module.impl.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.impl.CronExpression;
import com.ruijie.rcos.base.sysmanage.module.impl.common.Constants;
import com.ruijie.rcos.base.sysmanage.module.impl.dao.ScheduleTaskDAO;
import com.ruijie.rcos.base.sysmanage.module.impl.dao.ScheduleTypeDAO;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.ScheduleTaskEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.ScheduleTypeEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.quartz.data.ComponentQuartzTaskData;
import com.ruijie.rcos.base.sysmanage.module.impl.quartz.data.ConfigQuartzTaskData;
import com.ruijie.rcos.base.sysmanage.module.impl.quartz.data.QuartzTaskData;
import com.ruijie.rcos.base.sysmanage.module.impl.quartz.dispatcher.JobDispatcher;
import com.ruijie.rcos.base.sysmanage.module.impl.service.ScheduleService;
import com.ruijie.rcos.base.sysmanage.module.impl.util.ScheduleTaskUtil;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.i18n.LocaleI18nResolver;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.log.LoggerFactory;
import com.ruijie.rcos.sk.base.quartz.Quartz;
import com.ruijie.rcos.sk.base.quartz.QuartzTask;
import com.ruijie.rcos.sk.modulekit.api.bootstrap.SafetySingletonInitializer;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultPageResponse;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultResponse;
import com.ruijie.rcos.sk.modulekit.api.comm.Request;
import com.ruijie.rcos.sk.modulekit.api.isolation.CrossComponentApplicationContext;
import com.ruijie.rcos.sk.modulekit.api.isolation.CrossComponentApplicationContextAware;

/**
 * Description: 任务调度api
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年11月9日
 *
 * @author hhx
 */
public class ScheduleAPIImpl implements ScheduleAPI, CrossComponentApplicationContextAware, SafetySingletonInitializer {
    private static final Logger LOGGER = LoggerFactory.getLogger(ScheduleAPIImpl.class);

    /**
     * 任务调度持久对象
     */
    @Autowired
    private ScheduleTaskDAO scheduleTaskDAO;

    @Autowired
    private ScheduleTypeDAO scheduleTypeDAO;

    @Autowired
    private ScheduleService scheduleService;

    private CrossComponentApplicationContext crossComponentApplicationContext;

    @Autowired
    private ApplicationContext applicationContext;

    /**
     * 新增定时任务
     */
    @Override
    public DefaultResponse createSchedule(BaseCreateScheduleRequest createScheduleRequest) throws BusinessException {
        LOGGER.debug("【API创建】开始创建定时器");
        Assert.notNull(createScheduleRequest, "添加定时任务参数不能为空");

        CronExpression cronExpression = createCronExpressionIfArgsLegal(createScheduleRequest);
        ScheduleTypeEntity scheduleTypeEntity = getScheduleTypeEntity(createScheduleRequest.getTaskTypeId());

        Map<String, QuartzTaskData> dataMap =
                getDataMap(scheduleTypeEntity.getName(), scheduleTypeEntity.getBeanName(), cronExpression.getExpression());

        ScheduleTaskEntity scheduleTaskEntity = new ScheduleTaskEntity();
        scheduleTaskEntity.setCreateTime(new Date());
        wrapScheduleTaskEntity(createScheduleRequest, cronExpression.getExpression(), scheduleTaskEntity);
        scheduleTaskDAO.save(scheduleTaskEntity);
        LOGGER.debug("【API创建】保存配置成功");
        scheduleService.addSchedule(scheduleTaskEntity.getTaskTypeId().toString(), scheduleTaskEntity.getId().toString(),
                scheduleTaskEntity.getCronExpression(), dataMap);
        LOGGER.debug("【API创建】创建定时器结束");
        return DefaultResponse.Builder.success();
    }


    @Override
    public BaseQueryScheduleResponse querySchedule(BaseQueryScheduleRequest queryScheduleRequest) throws BusinessException {
        Assert.notNull(queryScheduleRequest, "查询定时任务参数不能为空");
        ScheduleTaskEntity scheduleTaskEntity = getScheduleTaskEntity(queryScheduleRequest.getId());
        CronExpression cronExpression = new CronExpression(scheduleTaskEntity.getTaskCycle(), scheduleTaskEntity.getCronExpression());
        BaseQueryScheduleResponse baseQueryScheduleResponse = new BaseQueryScheduleResponse();

        ScheduleDTO scheduleDTO = new ScheduleDTO(cronExpression.getTaskCycle(), cronExpression.getScheduleDate(), cronExpression.getScheduleTime(),
                cronExpression.getDayOfWeekArr());
        BeanUtils.copyProperties(scheduleTaskEntity, scheduleDTO);
        BeanUtils.copyProperties(scheduleDTO, baseQueryScheduleResponse);
        return baseQueryScheduleResponse;
    }

    /**
     * 更新定时任务
     */
    @Override
    public DefaultResponse editSchedule(BaseEditScheduleRequest editScheduleRequest) throws BusinessException {
        LOGGER.debug("【API更新】开始更新定时器");
        Assert.notNull(editScheduleRequest, "更新定时任务参数不能为空");
        CronExpression cronExpression = createCronExpressionIfArgsLegal(editScheduleRequest);

        ScheduleTaskEntity scheduleTaskEntity = getScheduleTaskEntity(editScheduleRequest.getId());

        ScheduleTypeEntity scheduleTypeEntity = getScheduleTypeEntity(editScheduleRequest.getTaskTypeId());
        Map<String, QuartzTaskData> dataMap =
                getDataMap(scheduleTypeEntity.getName(), scheduleTypeEntity.getBeanName(), cronExpression.getExpression());

        wrapScheduleTaskEntity(editScheduleRequest, cronExpression.getExpression(), scheduleTaskEntity);

        scheduleTaskDAO.save(scheduleTaskEntity);
        LOGGER.debug("【API更新】更新定时器成功");
        scheduleService.updateSchedule(scheduleTaskEntity.getTaskTypeId().toString(), scheduleTaskEntity.getId().toString(),
                cronExpression.getExpression(), dataMap);
        LOGGER.debug("【API更新】更新定时器结束");
        return DefaultResponse.Builder.success();
    }

    /**
     * 前端展示查询
     */
    @Override
    public DefaultPageResponse<ScheduleDTO> listSchedule(BaseListScheduleRequest listScheduleRequest) {
        LOGGER.debug("【API列表】开始获取定时器列表");
        Assert.notNull(listScheduleRequest, "获取定时器列表参数不能为空");
        Pageable pageable = PageRequest.of(listScheduleRequest.getPage(), listScheduleRequest.getLimit(), Sort.by("createTime"));
        Page<ScheduleTaskEntity> page = scheduleTaskDAO.findAll(pageable);

        List<ScheduleTaskEntity> scheduleTaskEntityList = Optional.ofNullable(page.getContent()).orElse(new ArrayList<>());
        ScheduleDTO[] scheduleDTOArr = scheduleTaskEntityList.stream().map((scheduleTaskEntity) -> {
            CronExpression cronExpression = new CronExpression(scheduleTaskEntity.getTaskCycle(), scheduleTaskEntity.getCronExpression());
            ScheduleDTO scheduleDTO = new ScheduleDTO(cronExpression.getTaskCycle(), cronExpression.getScheduleDate(),
                    cronExpression.getScheduleTime(), cronExpression.getDayOfWeekArr());
            BeanUtils.copyProperties(scheduleTaskEntity, scheduleDTO);
            return scheduleDTO;
        }).toArray(ScheduleDTO[]::new);

        DefaultPageResponse<ScheduleDTO> dtoDefaultPageResponse = new DefaultPageResponse<>();
        dtoDefaultPageResponse.setItemArr(scheduleDTOArr);
        dtoDefaultPageResponse.setTotal(page.getTotalElements());
        LOGGER.debug("【API列表】获取定时器列表结束");
        return dtoDefaultPageResponse;
    }

    /**
     * 删除定时任务
     *
     * @throws BusinessException
     */
    @Override
    public DefaultResponse deleteSchedule(BaseDeleteScheduleRequest deleteScheduleRequest) throws BusinessException {
        Assert.notNull(deleteScheduleRequest, "定时器删除请求参数不能为空");

        UUID id = deleteScheduleRequest.getId();

        ScheduleTaskEntity scheduleTaskEntity = getScheduleTaskEntity(id);
        scheduleTaskDAO.deleteById(id);
        scheduleService.deleteSchedule(scheduleTaskEntity.getTaskTypeId().toString(), scheduleTaskEntity.getId().toString());
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("【API删除】删除定时器成功[{}]", JSONObject.toJSONString(scheduleTaskEntity));
        }
        return DefaultResponse.Builder.success();
    }

    @Override
    public BaseListTaskTypeResponse listTaskType(BaseListTaskTypeRequest listTaskTypeRequest) {
        Assert.notNull(listTaskTypeRequest, "获取任务类型列表参数不能为空");
        LOGGER.debug("【API列表】开始获取定时器类型列表");
        List<ScheduleTypeEntity> scheduleTypeEntityList = scheduleTypeDAO.findAll();
        scheduleTypeEntityList = Optional.ofNullable(scheduleTypeEntityList).orElse(new ArrayList<>());
        ScheduleTypeDTO[] scheduleTypeDTOArr = scheduleTypeEntityList.stream().map(scheduleTypeEntity -> {
            ScheduleTypeDTO scheduleTypeDTO = new ScheduleTypeDTO();
            scheduleTypeDTO.setLabel(scheduleTypeEntity.getName());
            scheduleTypeDTO.setId(scheduleTypeEntity.getId());
            return scheduleTypeDTO;
        }).toArray(ScheduleTypeDTO[]::new);

        BaseListTaskTypeResponse baseListTaskTypeResponse = new BaseListTaskTypeResponse();
        baseListTaskTypeResponse.setItemArr(scheduleTypeDTOArr);
        LOGGER.debug("【API列表】开始获取定时器类型列表");
        return baseListTaskTypeResponse;
    }

    @Override
    public DefaultResponse saveTaskType(BaseSaveTaskTypeRequest saveTaskTypeRequest) {
        Assert.notNull(saveTaskTypeRequest, "保存任务类型参数不能为空");
        Optional<ScheduleTypeEntity> scheduleTypeEntityOptional = scheduleTypeDAO.findByBeanName(saveTaskTypeRequest.getBeanName());
        ScheduleTypeEntity scheduleTypeEntity = scheduleTypeEntityOptional.orElseGet(() -> new ScheduleTypeEntity());
        BeanUtils.copyProperties(saveTaskTypeRequest, scheduleTypeEntity, "version");
        scheduleTypeDAO.save(scheduleTypeEntity);
        return DefaultResponse.Builder.success();
    }

    @Override
    public BaseQueryTaskTypeResponse queryTaskType(BaseQueryTaskTypeRequest queryTaskTypeRequest) throws BusinessException {
        Assert.notNull(queryTaskTypeRequest, "请求参数不能为空");
        UUID typeId = queryTaskTypeRequest.getId();
        ScheduleTypeEntity scheduleTypeEntity = getScheduleTypeEntity(typeId);
        BaseQueryTaskTypeResponse queryTaskTypeResponse = new BaseQueryTaskTypeResponse();
        queryTaskTypeResponse.setId(scheduleTypeEntity.getId());
        queryTaskTypeResponse.setLabel(scheduleTypeEntity.getName());
        return queryTaskTypeResponse;
    }

    @Override
    public BaseBatchQueryScheduleResponse batchQueryTask(BaseBatchQueryScheduleRequest baseBatchQueryScheduleRequest) {
        Assert.notNull(baseBatchQueryScheduleRequest, "请求参数不能为空");
        List<UUID> uuidList = Arrays.asList(baseBatchQueryScheduleRequest.getIdArr());
        List<ScheduleTaskEntity> scheduleTaskEntityList = scheduleTaskDAO.findAllById(uuidList);
        ScheduleDTO[] scheduleDTOArr = scheduleTaskEntityList.stream().map(scheduleTaskEntity -> {
            ScheduleDTO scheduleDTO = new ScheduleDTO();
            BeanUtils.copyProperties(scheduleTaskEntity, scheduleDTO);
            return scheduleDTO;
        }).toArray(ScheduleDTO[]::new);
        return new BaseBatchQueryScheduleResponse(scheduleDTOArr);
    }

    @Override
    public void setCrossComponentApplicationContext(CrossComponentApplicationContext crossComponentApplicationContext) {
        this.crossComponentApplicationContext = crossComponentApplicationContext;
    }

    @Override
    public void safeInit() {
        initComponentQuartzTask();
        initConfigurableQuartzTask();
    }

    private void initComponentQuartzTask() {
        Collection<QuartzTask> quartzTasks = crossComponentApplicationContext.getBeans(QuartzTask.class);
        LOGGER.info("获取组件已配置定时任务：[{}]", JSON.toJSONString(quartzTasks));
        for (QuartzTask quartzTask : quartzTasks) {
            Class<?> targetClass = AopUtils.getTargetClass(quartzTask);
            Quartz quartz = AnnotationUtils.findAnnotation(targetClass, Quartz.class);

            if (null == quartz) {
                LOGGER.debug("类[{}]无Quartz注解", quartzTask.getClass());
                continue;
            }

            String name = LocaleI18nResolver.resolve(quartz.msgKey());
            if (StringUtils.isBlank(name)) {
                throw new IllegalArgumentException("类[" + targetClass + "]name字段为空为空");
            }
            String cron = quartz.cron();
            if (StringUtils.isBlank(cron)) {
                throw new IllegalArgumentException("类[" + targetClass + "]cron表达式为空");
            }
            try {

                Map<String, QuartzTaskData> jobDataMap = getComponentDataMap(quartzTask, name);
                scheduleService.addSchedule(Constants.SCHEDULE_DEFAULT_GROUP, quartzTask.getClass().getName(), cron, jobDataMap);
                LOGGER.debug("创建定时器[{}]成功", quartzTask.getClass());
            } catch (BusinessException e) {
                LOGGER.error("创建定时器[" + quartzTask.getClass() + "]失败", e);
            }
        }
    }

    private void initConfigurableQuartzTask() {
        LOGGER.info("【初始化】初始化定时器任务开始");
        List<ScheduleTypeEntity> scheduleTypeEntityList = scheduleTypeDAO.findAll();
        Map<UUID, ScheduleTypeEntity> scheduleType2ScheduleTypeMap = scheduleTypeEntityList.stream()
                .collect(Collectors.toMap(scheduleTypeEntity -> scheduleTypeEntity.getId(), scheduleTypeEntity -> scheduleTypeEntity));

        int currentPage = 0;
        int pageSize = 200;
        while (true) {
            Pageable pageable = PageRequest.of(currentPage, pageSize, Sort.by(Sort.Direction.ASC, "createTime"));
            Page<ScheduleTaskEntity> scheduleTaskEntityPage = scheduleTaskDAO.findAll(pageable);
            List<ScheduleTaskEntity> scheduleTaskEntityList = scheduleTaskEntityPage.getContent();
            if (ObjectUtils.isEmpty(scheduleTaskEntityList)) {
                LOGGER.debug("【初始化】currentPage:{}未获取到定时任务", currentPage);
                break;
            }
            LOGGER.debug("【初始化】获取定时器配置：,{}个,currentPage:{}", scheduleTaskEntityList.size(), currentPage);
            for (ScheduleTaskEntity taskEntity : scheduleTaskEntityList) {
                CronExpression cronExpression = new CronExpression(taskEntity.getTaskCycle(), taskEntity.getCronExpression());
                if (cronExpression.isExpire()) {
                    LOGGER.info("【创建】待添加定时器已失效,id:{}, 表达式:{}", taskEntity.getTaskTypeId(), taskEntity.getCronExpression());
                    return;
                }
                ScheduleTypeEntity scheduleTypeEntity = scheduleType2ScheduleTypeMap.get(taskEntity.getTaskTypeId());
                try {
                    Map<String, QuartzTaskData> dataMap =
                            getDataMap(scheduleTypeEntity.getName(), scheduleTypeEntity.getBeanName(), cronExpression.getExpression());
                    scheduleService.addSchedule(taskEntity.getTaskTypeId().toString(), taskEntity.getId().toString(), cronExpression.getExpression(),
                            dataMap);
                } catch (BusinessException e) {
                    LOGGER.error("【初始化】添加定时器：[" + taskEntity.getTaskTypeId() + "], 表达式;[" + taskEntity.getCronExpression() + "]失败", e);

                }

            }
            if (scheduleTaskEntityList.size() < pageSize) {
                LOGGER.debug("【初始化】currentPage:{},pageSize:{} 任务数:{}, ", currentPage, pageSize, scheduleTaskEntityList.size());
                break;
            }
            currentPage++;
        }
    }



    private CronExpression createCronExpressionIfArgsLegal(BaseScheduleRequest baseScheduleRequest) throws BusinessException {
        LocalDate scheduleDate = null;
        if (baseScheduleRequest.getTaskCycle() == TaskCycle.ONCE) {
            scheduleDate = getLocalDate(baseScheduleRequest.getScheduleDate());
        }
        LocalTime scheduleTime = getLocalTime(baseScheduleRequest.getScheduleTime());

        ScheduleTaskUtil.validateScheduleTaskArgs(baseScheduleRequest.getTaskCycle(), baseScheduleRequest.getDayOfWeekArr(), scheduleDate,
                scheduleTime);

        CronExpression cronExpression =
                new CronExpression(baseScheduleRequest.getTaskCycle(), scheduleDate, scheduleTime, baseScheduleRequest.getDayOfWeekArr());
        if (cronExpression.isExpire()) {
            throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_SCHEDULE_TIME_EXPIRE);
        }
        return cronExpression;
    }

    private ScheduleTaskEntity getScheduleTaskEntity(UUID id) throws BusinessException {
        Optional<ScheduleTaskEntity> optionalScheduleTaskEntity = scheduleTaskDAO.findById(id);
        if (!optionalScheduleTaskEntity.isPresent()) {
            throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_SCHEDULE_TASK_NOT_EXIST);
        }
        return optionalScheduleTaskEntity.get();
    }

    private void wrapScheduleTaskEntity(Request request, String cronExpression, ScheduleTaskEntity scheduleTaskEntity) {
        BeanUtils.copyProperties(request, scheduleTaskEntity);
        scheduleTaskEntity.setCronExpression(cronExpression);
        scheduleTaskEntity.setUpdateTime(new Date());
    }

    private LocalTime getLocalTime(String localTimeStr) throws BusinessException {
        try {
            return LocalTime.parse(localTimeStr, DateTimeFormatter.ofPattern(Constant.HH_MM_SS));
        } catch (DateTimeParseException e) {
            throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_ILLEGAL_TIME_FORMAT, e, "localTime");
        }
    }

    private LocalDate getLocalDate(String localDateStr) throws BusinessException {
        try {
            return LocalDate.parse(localDateStr, DateTimeFormatter.ofPattern(Constant.YYYY_MM_DD));
        } catch (DateTimeParseException e) {
            throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_ILLEGAL_DATE_FORMAT, e, "localDate");
        }
    }

    private Map<String, QuartzTaskData> getDataMap(String taskTypeName, String beanName, String cronExpression) {
        QuartzTask quartzTask = crossComponentApplicationContext.getBean(beanName);
        Map<String, QuartzTaskData> dataMap = getCommonJobMap(quartzTask, Constants.SCHEDULE_DISPATCHER_TYPE_CONFIGURABLE);
        ConfigQuartzTaskData configQuartzTaskData = new ConfigQuartzTaskData();
        BeanUtils.copyProperties(dataMap.get(Constants.SCHEDULE_DATA_KEY), configQuartzTaskData);
        configQuartzTaskData.setExpression(cronExpression);
        configQuartzTaskData.setTaskTypeName(taskTypeName);
        dataMap.put(Constants.SCHEDULE_DATA_KEY, configQuartzTaskData);
        return dataMap;
    }

    private Map<String, QuartzTaskData> getComponentDataMap(QuartzTask quartzTask, String name) {
        Map<String, QuartzTaskData> dataMap = getCommonJobMap(quartzTask, Constants.SCHEDULE_DISPATCHER_TYPE_COMPONENT);
        ComponentQuartzTaskData componentQuartzTaskData = new ComponentQuartzTaskData();
        BeanUtils.copyProperties(dataMap.get(Constants.SCHEDULE_DATA_KEY), componentQuartzTaskData);
        componentQuartzTaskData.setName(name);
        dataMap.put(Constants.SCHEDULE_DATA_KEY, componentQuartzTaskData);
        return dataMap;
    }

    private Map<String, QuartzTaskData> getCommonJobMap(QuartzTask quartzTask, String dispatcherBeanName) {
        JobDispatcher jobDispatcher = applicationContext.getBean(dispatcherBeanName, JobDispatcher.class);
        QuartzTaskData quartzTaskData = new QuartzTaskData();
        quartzTaskData.setJobDispatcher(jobDispatcher);
        quartzTaskData.setQuartzTask(quartzTask);

        Map<String, QuartzTaskData> dataMap = new HashMap<>(10);
        dataMap.put(Constants.SCHEDULE_DATA_KEY, quartzTaskData);
        return dataMap;
    }

    private ScheduleTypeEntity getScheduleTypeEntity(UUID taskTypeId) throws BusinessException {
        Optional<ScheduleTypeEntity> scheduleTaskTypeEntityOptional = scheduleTypeDAO.findById(taskTypeId);
        if (!scheduleTaskTypeEntityOptional.isPresent()) {
            throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_SCHEDULE_TYPE_NOT_EXIST);
        }
        return scheduleTaskTypeEntityOptional.get();
    }


}
