package com.ruijie.rcos.base.sysmanage.module.impl.tx.impl;

import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import com.ruijie.rcos.base.sysmanage.module.def.dto.license.BaseLicenseFeatureDTO;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureStatus;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureType;
import com.ruijie.rcos.base.sysmanage.module.impl.dao.LicenseFileDAO;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.LicenseFileEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.tx.LicenseSaveTx;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.log.LoggerFactory;

/**
 * Description: license文件导入
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月5日
 * 
 * @author zouqi
 */
@Service
public class LicenseSaveTxImpl implements LicenseSaveTx {

    private final static Logger LOGGER = LoggerFactory.getLogger(LicenseSaveTxImpl.class);

    @Autowired
    private LicenseFileDAO licenseFileDAO;


    /**
     * license 文件上传
     * 
     * @param licenseFeatureDTO 请求参数
     * @param licenseFileEntityList 
     * @throws BusinessException 业务异常
     */
    @Override
    public void saveLicense(BaseLicenseFeatureDTO licenseFeatureDTO, List<LicenseFileEntity> licenseFileEntityList) {
        Assert.notNull(licenseFeatureDTO, "baseLicenseFeatureDTO 不能为空");
        Assert.notNull(licenseFileEntityList, "List<LicenseFileEntity> 不能为空");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("开始处理license文件：{}", licenseFeatureDTO.getFileName());
        }
        // 如果状态需要变更，则先更新库中其他数据
        changeLicenseType(licenseFeatureDTO);
        //保存数据
        licenseFileDAO.saveAll(licenseFileEntityList);

    }


    /**
     * license授权类型变更
     * 
     * @param licenseFeatureDTO 请求DTO
     * @return List<LicenseFileEntity>
     */
    private void changeLicenseType(BaseLicenseFeatureDTO licenseFeatureDTO) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("开始更新license状态：{}", licenseFeatureDTO.getFileName());
        }
        //如果license文件授权方式是正式授权，并且数据库中存在临时授权数据，则表示需要改变授权方式
        List<LicenseFileEntity> licenseTempList = this.licenseFileDAO.findByFeatureTypeAndFeatureStatusAndFeatureCodeOrderByCreateTime(
                BaseFeatureType.TEMPORARY, BaseFeatureStatus.AVALIABLE, licenseFeatureDTO.getFeatureCode());
        if (CollectionUtils.isEmpty(licenseTempList)) {
            return;
        }
            
        for (LicenseFileEntity entity : licenseTempList) {
            entity.setFeatureStatus(BaseFeatureStatus.EXPIRED);
            // 试用开始的 license 需要加上 试用结束时间
            if (entity.getTrialDuration() != entity.getTrialRemainder()) {
                entity.setTrailEndTime(new Date());
            }
            // 将更新后的entity 更新到数据库
            this.licenseFileDAO.save(entity);
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("更新license状态结束：{}", licenseFeatureDTO.getFileName());
        }

    }

}
