package com.ruijie.rcos.base.sysmanage.module.impl.license.vo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.util.Assert;
import com.ruijie.rcos.base.sysmanage.module.impl.license.enums.LicenseTypeEnum;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月18日
 * 
 * @author zouqi
 */
public class LicenseInfo {
    public static final long DURATION_NO_LIMIT = 0;
    
    private LicenseTypeEnum type = LicenseTypeEnum.COMMERCIAL;
    
    private String productName;
    
    private String devSn;
    
    private String devCode;//
    
    private Date startTime;
    
    private long duration = DURATION_NO_LIMIT;//持续时间长度  精确到分钟,0表示无限制
    
    List<LicenseFeature> featureList = new ArrayList<LicenseFeature>();
    
    public LicenseTypeEnum getType() {
    	return type;
    }
    
    public void setType(LicenseTypeEnum type) {
    	this.type = type;
    }
    
    public String getProductName() {
    	return productName;
    }
    
    public void setProductName(String productName) {
    	this.productName = productName;
    }
    
    public String getDevSn() {
    	return devSn;
    }
    
    public void setDevSn(String devSn) {
    	this.devSn = devSn;
    }
    
    public String getDevCode() {
    	return devCode;
    }
    
    public void setDevCode(String devCode) {
    	this.devCode = devCode;
    }
    
    public Date getStartTime() {
    	return startTime;
    }
    
    public void setStartTime(Date startTime) {
    	this.startTime = startTime;
    }
    
    public long getDuration() {
    	return duration;
    }
    
    public boolean isNoTimeLimit() {
    	return duration <= DURATION_NO_LIMIT;
    }
    
    public void setDuration(long duration) {
    	this.duration = duration;
    }
    
    public List<LicenseFeature> getFeatureList() {
    	return featureList;
    }
    
    public void setFeatureList(List<LicenseFeature> features) {
    	this.featureList = features;
    }
    
    /**
     * 添加feature信息
     * @param feature 
     */
    public void addFeature(LicenseFeature feature) {
        Assert.notNull(feature, "LicenseFeature 不能为空");
        featureList.add(feature);
    }
}
