package com.ruijie.rcos.base.sysmanage.module.impl.tx;

import java.util.List;
import com.ruijie.rcos.base.sysmanage.module.def.dto.license.BaseLicenseFeatureDTO;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.LicenseFileEntity;

/**
 * Description: license授权service
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月7日
 * 
 * @author zouqi
 */
public interface LicenseSaveTx {

    /**
     * 保存license信息
     * @param licenseFeatureDTO 
     * @param licenseFileEntityList 请求参数
     */
    void saveLicense(BaseLicenseFeatureDTO licenseFeatureDTO, List<LicenseFileEntity> licenseFileEntityList);
   
}
