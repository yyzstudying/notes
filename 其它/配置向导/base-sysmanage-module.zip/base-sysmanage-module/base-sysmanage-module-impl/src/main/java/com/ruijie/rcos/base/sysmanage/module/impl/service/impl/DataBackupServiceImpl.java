package com.ruijie.rcos.base.sysmanage.module.impl.service.impl;

import java.io.File;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.google.common.collect.Maps;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.databackup.BaseListDataBackupRequest;
import com.ruijie.rcos.base.sysmanage.module.impl.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.impl.common.Constants;
import com.ruijie.rcos.base.sysmanage.module.impl.dao.DataBackupDAO;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.DataBackupEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.service.DataBackupService;
import com.ruijie.rcos.base.sysmanage.module.impl.service.query.DataBackupSpecification;
import com.ruijie.rcos.base.sysmanage.module.impl.util.FileNameUtil;
import com.ruijie.rcos.sk.base.config.ConfigFacade;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.filesystem.SkyengineFile;
import com.ruijie.rcos.sk.base.i18n.LocaleI18nResolver;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.log.LoggerFactory;
import com.ruijie.rcos.sk.base.shell.ShellCommandRunner;
import com.ruijie.rcos.sk.modulekit.api.tool.GlobalParameterAPI;

/**
 * Description: 数据库备份服务实现类
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月06日
 *
 * @author fyq
 */

@Service
public class DataBackupServiceImpl implements DataBackupService {

    private static final Logger LOGGER = LoggerFactory.getLogger(DataBackupServiceImpl.class);

    private static final String CONFIG_DATA_SOURCE_PREFIX = "datasource";

    private static final String CONFIG_DB_NAME_SUFFIX = ".dbname";

    private static final String CONFIG_NO_BACK_SUFFIX = ".backup";

    @Autowired
    private GlobalParameterAPI globalParameterAPI;

    @Autowired
    private DataBackupDAO dataBackupDAO;

    @Autowired
    private ConfigFacade configFacade;

    @Override
    public DataBackupEntity createDataBackup(boolean isAuto) throws BusinessException {

        LOGGER.debug("【数据库备份服务】 创建数据库备份 isAuto:{}", isAuto);

        final String dbList = getDbList();

        LOGGER.debug("【数据库备份服务】 创建数据库备份 dbList:{}", dbList);
        String uuid = UUID.randomUUID().toString();
        final String backupFileName = new ShellCommandRunner() //
                .setCommand(Constants.SH_DATA_BACKUP) //
                .appendArgs("-d", dbList, uuid) //
                .execute();

        String fileName = FileNameUtil.getFileName(LocaleI18nResolver.resolve(BusinessKey.BASE_SYS_MANAGE_DB_BAK_NAME), dataBackupDAO);

        DataBackupEntity entity = new DataBackupEntity();
        entity.setRealFileName(backupFileName);
        entity.setFileName(fileName);
        entity.setCreateTime(new Date());
        entity.setAuto(isAuto);

        LOGGER.debug("【数据库备份服务】 保存实体信息 {}", entity);

        return dataBackupDAO.save(entity);
    }


    @Override
    public DataBackupEntity deleteDataBackup(UUID id) throws BusinessException {

        Assert.notNull(id, "id不能为空");

        DataBackupEntity entity = dataBackupDAO.getOne(id);

        if (entity == null) {
            LOGGER.error("【数据库备份服务】 实体不存在 id:{}", id);
            throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_DATA_BACKUP_NOT_EXITS);
        }

        LOGGER.warn("【数据库备份服务】 删除实体 {}", entity);

        dataBackupDAO.delete(entity);

        final String dbPath = globalParameterAPI.findParameter(Constants.GLOBAL_PARAM_DB_BACKUP_PATH);

        final File file = new File(dbPath, entity.getRealFileName());
        final SkyengineFile skyengineFile = new SkyengineFile(file);

        boolean isDeleted = skyengineFile.delete();

        if (!isDeleted) {
            LOGGER.error("【数据库备份服务】 删除文件失败:{}", file.getAbsolutePath());
        }

        LOGGER.warn("【数据库备份服务】 删除数据库备份成功 {}", id);

        return entity;
    }


    @Override
    public Page<DataBackupEntity> listDataBackup(BaseListDataBackupRequest request) {

        Assert.notNull(request, "请求参数不能为空");

        LOGGER.debug("【数据库备份服务】 获取数据库备份列表");

        Pageable pageable = PageRequest.of(request.getPage(), request.getLimit(), Sort.Direction.DESC, Constants.DATA_BACKUP_DEFAULT_ORDER);
        Specification<DataBackupEntity> specification = new DataBackupSpecification(request);
        return dataBackupDAO.findAll(specification, pageable);
    }

    @Override
    public List<DataBackupEntity> listExpireDataBackup(Date expireDate, boolean isAutoBackup) {
        Assert.notNull(expireDate, "expireDate can not be null");
        return dataBackupDAO.findAllByCreateTimeLessThanEqualAndIsAutoEquals(expireDate, isAutoBackup);
    }

    private String getDbList() {

        Map<String, String> configMap = configFacade.readByPrefix(CONFIG_DATA_SOURCE_PREFIX);

        Map<String, String> dbNameConfigMap = Maps.newHashMap();
        Map<String, String> noBackupConfigMap = Maps.newHashMap();

        // 把datasource.xxxx.dbname -> dbName 变成 datasrouce.xxxx -> dbName放到dbNameConfigMap里
        // 把datasource.xxxx.backup -> false 变成 datasource.xxxx —> false放到noBackupConfigMap里
        configMap.forEach((key, value) -> {
            if (key.endsWith(CONFIG_DB_NAME_SUFFIX)) {
                dbNameConfigMap.put(key.substring(0, key.length() - CONFIG_DB_NAME_SUFFIX.length()), value);
            } else if (key.endsWith(CONFIG_NO_BACK_SUFFIX) && value.equals("false")) {
                noBackupConfigMap.put(key.substring(0, key.length() - CONFIG_NO_BACK_SUFFIX.length()), value);
            }
        });

        // 移除dbNameConfigMap中的不需要备份的键值对
        noBackupConfigMap.forEach((key, value) -> {
            dbNameConfigMap.remove(key);
        });

        return StringUtils.join(dbNameConfigMap.values().toArray(), ",");
    }
}
