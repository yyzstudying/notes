package com.ruijie.rcos.base.sysmanage.module.impl.service;

import com.ruijie.rcos.base.sysmanage.module.def.api.request.network.BaseUpdateNetworkRequest;
import com.ruijie.rcos.base.sysmanage.module.def.dto.BaseNetworkDTO;
import com.ruijie.rcos.sk.base.exception.BusinessException;

/**
 * Description: 网卡服务
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年11月28日
 *
 * @author fyq
 */
public interface NetworkService {

    /**
     * 获取网卡IP、网关、子网掩码、DNS、设备名、速率和最大速率等信息
     * 
     * @return 网卡信息
     * @throws BusinessException 请求异常
     */
    BaseNetworkDTO detailNetwork() throws BusinessException;

    /**
     * 更新网卡IP、网关、子网掩码、DNS信息，更新完会重启网卡
     * 
     * @param request 更新请求
     * @throws BusinessException 请求异常
     */
    void updateNetwork(BaseUpdateNetworkRequest request) throws BusinessException;
}
