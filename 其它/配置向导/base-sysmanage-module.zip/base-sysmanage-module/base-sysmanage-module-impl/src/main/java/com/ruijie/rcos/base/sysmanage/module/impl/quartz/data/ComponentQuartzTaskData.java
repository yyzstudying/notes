package com.ruijie.rcos.base.sysmanage.module.impl.quartz.data;

import com.ruijie.rcos.sk.base.annotation.NotBlank;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月22日
 *
 * @author xgx
 */
public class ComponentQuartzTaskData extends QuartzTaskData {
    @NotBlank
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
