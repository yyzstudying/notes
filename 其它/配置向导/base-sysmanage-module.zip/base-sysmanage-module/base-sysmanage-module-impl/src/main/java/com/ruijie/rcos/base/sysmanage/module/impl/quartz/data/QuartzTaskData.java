package com.ruijie.rcos.base.sysmanage.module.impl.quartz.data;

import com.ruijie.rcos.base.sysmanage.module.impl.quartz.dispatcher.JobDispatcher;
import com.ruijie.rcos.sk.base.annotation.NotNull;
import com.ruijie.rcos.sk.base.quartz.QuartzTask;

/**
 * Description: 定时任务公共数据类
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月19日
 *
 * @author xgx
 */
public class QuartzTaskData {
    @NotNull
    private JobDispatcher jobDispatcher;

    @NotNull
    private QuartzTask quartzTask;

    public JobDispatcher getJobDispatcher() {
        return jobDispatcher;
    }

    public void setJobDispatcher(JobDispatcher jobDispatcher) {
        this.jobDispatcher = jobDispatcher;
    }

    public QuartzTask getQuartzTask() {
        return quartzTask;
    }

    public void setQuartzTask(QuartzTask quartzTask) {
        this.quartzTask = quartzTask;
    }
}
