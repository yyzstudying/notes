package com.ruijie.rcos.base.sysmanage.module.impl.service.impl;

import java.text.SimpleDateFormat;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.ruijie.rcos.base.sysmanage.module.def.common.Constant;
import com.ruijie.rcos.base.sysmanage.module.def.spi.BaseSystemTimeChangeAfterSPI;
import com.ruijie.rcos.base.sysmanage.module.def.spi.BaseSystemTimeChangeBeforeSPI;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseSystemTimeChangeAfterRequest;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseSystemTimeChangeBeforeRequest;
import com.ruijie.rcos.base.sysmanage.module.impl.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.impl.common.Constants;
import com.ruijie.rcos.base.sysmanage.module.impl.service.SystemTimeService;
import com.ruijie.rcos.sk.base.concorrent.SkyengineExecutors;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.log.LoggerFactory;
import com.ruijie.rcos.sk.base.shell.ShellCommandRunner;
import com.ruijie.rcos.sk.modulekit.api.comm.ModuleCommExpertAPI;

/**
 * Description: 系统时间服务实现类
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年11月28日
 *
 * @author fyq
 */
@Service
public class SystemTimeServiceImpl implements SystemTimeService {

    private static final Logger LOGGER = LoggerFactory.getLogger(SystemTimeServiceImpl.class);

    @Autowired
    private BaseSystemTimeChangeBeforeSPI systemTimeChangeBeforeSPI;

    @Autowired
    private BaseSystemTimeChangeAfterSPI systemTimeChangeAfterSPI;

    @Autowired
    private ModuleCommExpertAPI moduleCommExpertAPI;

    @Override
    public boolean updateSystemTime(Long time) throws BusinessException {

        Assert.notNull(time, "时间参数不能为空");

        LOGGER.warn("【系统时间服务】 设置系统时间 {}", time);

        SimpleDateFormat sdf = new SimpleDateFormat(Constant.YYYY_MM_DD_HH_MM_SS);
        String strTime = sdf.format(time);
        String[] dateTimeArr = strTime.split(" ");
        ShellCommandRunner runner = new ShellCommandRunner();
        runner.setCommand(Constants.SH_TIME_CHANGE);
        runner.appendArgs(dateTimeArr[0]);
        runner.appendArgs(dateTimeArr[1]);

        boolean shouldReboot = updateSystemTimeWithShell(runner);

        return shouldReboot;
    }

    @Override
    public boolean updateSystemTimeFromNtp(String ntpServer) throws BusinessException {

        Assert.hasText(ntpServer, "NTP地址参数不能为空");

        LOGGER.warn("【系统时间服务】 从NTP设置系统时间 {}", ntpServer);

        ShellCommandRunner runner = new ShellCommandRunner();
        runner.setCommand(Constants.SH_TIME_CHANGE_FROM_NTP);
        runner.appendArgs(ntpServer);
        runner.addErrorHandler((String command, Integer exitValue, String outStr) -> {
            if (exitValue == Constants.SH_NTP_SERVER_UNREACHABLE_ERROR) {
                throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_UPDATE_SYSTEM_TIME_UNREACHABLE_NTP);
            }
        });
        boolean shouldReboot = updateSystemTimeWithShell(runner);

        return shouldReboot;

    }

    /**
     * 执行更新时间的脚本
     * 
     * @param shell 更新脚本，设置时间或者从ntp更新时间
     * @return 是否需要重启系统
     */
    private boolean updateSystemTimeWithShell(ShellCommandRunner shell) throws BusinessException {

        beforeSystemTimeUpdate();

        long oldTime = System.currentTimeMillis();

        shell.execute();

        long curTime = System.currentTimeMillis();

        afterSystemTimeUpdate();

        if (Math.abs(curTime - oldTime) >= Constants.ONE_MINUTE_MILLS) {
            rebootSystem(Constants.SH_TIME_CHANGE_RESTART_DELAY);
            return true;
        }

        return false;
    }


    /**
     * 更新系统时候后时间大于间隔大于一分钟重启系统！
     * 
     * @param delay 重启等待时延
     */
    private void rebootSystem(int delay) {

        LOGGER.warn("【系统时间服务】 重启系统");

        SkyengineExecutors.schedule(() -> {
            try {
                new ShellCommandRunner().setCommand(Constants.SH_TIME_CHANGE_RESTART_SYSTEM).execute();
            } catch (Exception e) {
                LOGGER.error("重启系统失败", e);
            }
        }, delay, Constants.SH_TIME_CHANGE_RESTART_TASK_NAME);

    }

    /**
     * 更新系统时间前发送spi通知，如果有组件抛出异常则不允许更新
     * 
     * @throws BusinessException 组件抛出的异常
     */
    private void beforeSystemTimeUpdate() throws BusinessException {

        Collection<String> beforeSpiKeyList = moduleCommExpertAPI.loadDispatcherKeys(BaseSystemTimeChangeBeforeSPI.class);

        LOGGER.debug("【系统时间服务】 修改前通知 {}", beforeSpiKeyList);

        for (String key : beforeSpiKeyList) {

            BaseSystemTimeChangeBeforeRequest request = new BaseSystemTimeChangeBeforeRequest();
            request.setRequestKey(key);

            systemTimeChangeBeforeSPI.beforeSystemTimeChange(request);
        }
    }

    /**
     * 系统时间修改后发送spi通知
     */
    private void afterSystemTimeUpdate() {

        LOGGER.debug("【系统时间服务】 修改后通知");

        BaseSystemTimeChangeAfterRequest request = new BaseSystemTimeChangeAfterRequest();
        request.setSystemTime(System.currentTimeMillis());
        systemTimeChangeAfterSPI.afterSystemTimeChange(request);
    }
}
