package com.ruijie.rcos.base.sysmanage.module.impl.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;

import com.ruijie.rcos.base.sysmanage.module.def.api.NetworkAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.network.BaseDetailNetworkRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.network.BaseUpdateNetworkRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.network.BaseDetailNetworkInfoResponse;
import com.ruijie.rcos.base.sysmanage.module.def.dto.BaseNetworkDTO;
import com.ruijie.rcos.base.sysmanage.module.impl.service.NetworkService;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultResponse;

/**
 * Description: 网卡配置接口实现
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年11月28日
 *
 * @author fyq
 */
public class NetworkAPIImpl implements NetworkAPI {

    @Autowired
    private NetworkService networkConfigService;

    @Override
    public BaseDetailNetworkInfoResponse detailNetwork(BaseDetailNetworkRequest apiRequest) throws BusinessException {

        Assert.notNull(apiRequest, "请求参数不能为空");

        BaseNetworkDTO networkCardDTO = networkConfigService.detailNetwork();

        BaseDetailNetworkInfoResponse response = new BaseDetailNetworkInfoResponse();
        response.setNetworkDTO(networkCardDTO);

        return response;
    }

    @Override
    public DefaultResponse updateNetwork(BaseUpdateNetworkRequest apiRequest) throws BusinessException {

        Assert.notNull(apiRequest, "请求参数不能为空");

        networkConfigService.updateNetwork(apiRequest);
        return new DefaultResponse();
    }
}
