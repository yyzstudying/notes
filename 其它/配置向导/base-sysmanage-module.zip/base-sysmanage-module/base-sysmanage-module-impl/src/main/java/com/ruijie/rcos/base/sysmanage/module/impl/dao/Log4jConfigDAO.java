package com.ruijie.rcos.base.sysmanage.module.impl.dao;

import java.util.UUID;

import com.ruijie.rcos.base.sysmanage.module.impl.entity.Log4jConfigEntity;
import com.ruijie.rcos.sk.modulekit.api.ds.SkyEngineJpaRepository;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年02月19日
 *
 * @author GuoZhouYue
 */
public interface Log4jConfigDAO extends SkyEngineJpaRepository<Log4jConfigEntity, UUID> {

    /**
     * logger 是否存在
     * @param loggerName loggerName
     * @return 是否存在
     */
    boolean existsByLoggerName(String loggerName);
}
