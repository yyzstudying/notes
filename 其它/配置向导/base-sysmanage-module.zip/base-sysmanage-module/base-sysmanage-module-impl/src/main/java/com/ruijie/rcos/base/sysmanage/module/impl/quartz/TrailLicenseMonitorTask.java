package com.ruijie.rcos.base.sysmanage.module.impl.quartz;

import java.util.List;
import java.util.Queue;
import java.util.concurrent.TimeUnit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import com.google.common.collect.Lists;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureStatus;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureType;
import com.ruijie.rcos.base.sysmanage.module.def.spi.BaseLicenseFeatureNotifySPI;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseLicenseChangeRequest;
import com.ruijie.rcos.base.sysmanage.module.impl.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.impl.dao.LicenseFileDAO;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.LicenseFileEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.tx.impl.LicenseSaveTxImpl;
import com.ruijie.rcos.base.sysmanage.module.impl.util.LicenseUtil;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.log.LoggerFactory;
import com.ruijie.rcos.sk.base.quartz.Quartz;
import com.ruijie.rcos.sk.base.quartz.QuartzTask;
import com.ruijie.rcos.sk.modulekit.api.isolation.GlobalUniqueBean;

/**
 * Description: 试用license是否到期的定时器
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月4日
 * 
 * @author zouqi
 */
@GlobalUniqueBean("trailLicenseMonitorTask")
@Quartz(cron = "0 */15 * * * ? *", msgKey = BusinessKey.BASE_SYS_MANAGE_TEMP_LICENSE_SCHEDULE_TASK)
public class TrailLicenseMonitorTask implements QuartzTask {

    private final static Logger LOGGER = LoggerFactory.getLogger(LicenseSaveTxImpl.class);

    // 十五分钟
    private static final long FIFTEEN_MILLIS = TimeUnit.MINUTES.toSeconds(15);

    @Autowired
    private LicenseFileDAO licenseFileDAO;

    @Autowired
    private BaseLicenseFeatureNotifySPI licenseFeatureNotifySPI;

    @Override
    public void execute() throws BusinessException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("开始自动扣减license时长定时器任务");
        }
        List<LicenseFileEntity> licenseFileEntitieList = this.licenseFileDAO.findByFeatureStatusGroupByFeatureCode(BaseFeatureStatus.AVALIABLE);
        if (CollectionUtils.isEmpty(licenseFileEntitieList)) {
            return;
        }

        licenseFileEntitieList.stream() //
                .map(entity -> entity.getFeatureCode()) //
                .forEach(featureCode -> {
                    final List<LicenseFileEntity> entityList = licenseFileDAO
                            .findByFeatureTypeAndFeatureCodeOrderByCreateTime(BaseFeatureType.TEMPORARY, featureCode);
                    final Queue<LicenseFileEntity> entityQueue = Lists.newLinkedList(entityList);

                    long residueTime = FIFTEEN_MILLIS;
                    while (!entityQueue.isEmpty() && residueTime > 0) {
                        final LicenseFileEntity entity = entityQueue.poll();
                        // 当前试用时长
                        final long oldTrialRemainder = entity.getTrialRemainder();
                        // 减去本次循环后的剩余试用时间
                        final long newTrialRemainder = oldTrialRemainder - residueTime;
                        // 当前license不够扣减的试用时长
                        residueTime -= oldTrialRemainder;

                        
                        if (newTrialRemainder < 0) {
                            entity.setTrialRemainder(0);
                        } else {
                            entity.setTrialRemainder(newTrialRemainder);
                        }
                        licenseFileDAO.save(entity);
                    }

                    BaseLicenseChangeRequest changeRequest = LicenseUtil.createBaseLicenseChangeRequest(entityList);

                    // 遍历通知业务层
                    licenseFeatureNotifySPI.notifyLicenseChange(changeRequest);
                });

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("完成自动扣减license时长定时器任务");
        }
    }
}
