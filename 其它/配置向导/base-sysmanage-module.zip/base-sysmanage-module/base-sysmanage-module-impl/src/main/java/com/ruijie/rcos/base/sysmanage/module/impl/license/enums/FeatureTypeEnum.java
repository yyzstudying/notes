package com.ruijie.rcos.base.sysmanage.module.impl.license.enums;

/**
 * Description: feature 类型 枚举类
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月18日
 * 
 * @author zouqi
 */
public enum FeatureTypeEnum {
	ONOFF,//开关，标识功能是打开还是关闭
	DATA, //数据，标识支持个数，如最大用户数、最大在线人数等
}
