package com.ruijie.rcos.base.sysmanage.module.impl.service;

import com.ruijie.rcos.sk.base.exception.BusinessException;

/**
 * Description: 系统时间服务
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年11月28日
 *
 * @author fyq
 */
public interface SystemTimeService {

    /**
     * 更新系统时间
     * 
     * @param time 时间
     * @throws BusinessException 请求异常
     * @return 是否需要重启系统
     */
    boolean updateSystemTime(Long time) throws BusinessException;

    /**
     * 从NTP服务器更新系统时间
     * 
     * @param ntpServer NTP服务器
     * @throws BusinessException 请求异常
     * @return 是否需要重启系统
     */
    boolean updateSystemTimeFromNtp(String ntpServer) throws BusinessException;
}
