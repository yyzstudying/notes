package com.ruijie.rcos.base.sysmanage.module.impl.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import org.springframework.beans.BeanUtils;
import org.springframework.util.Assert;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.license.BaseUploadLicFileRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.license.BaseCreateDatFileResponse;
import com.ruijie.rcos.base.sysmanage.module.def.dto.license.BaseLicenseFeatureDTO;
import com.ruijie.rcos.base.sysmanage.module.def.dto.license.NotifyLicenseChangeDTO;
import com.ruijie.rcos.base.sysmanage.module.def.dto.license.ValidationLicenseDTO;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureStatus;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureType;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseLicenseChangeRequest;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseValidateLicenseRequest;
import com.ruijie.rcos.base.sysmanage.module.def.spi.response.BaseGetLicenseSerialNumberResponse;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.LicenseFileEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.license.vo.LicenseFeature;
import com.ruijie.rcos.base.sysmanage.module.impl.license.vo.LicenseInfo;
import com.ruijie.rcos.sk.base.exception.BusinessException;

/**
 * Description: license 工具类
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月12日
 * 
 * @author zouqi
 */
public class LicenseUtil {
    
    /**
     * 创建BaseValidateLicenseRequest
     * @param lfeList 数据库的license信息
     * @param licenseResolve 文件的license信息
     * @param licenseFeatureDTO 
     * @return BaseValidateLicenseRequest
     */
    public static BaseValidateLicenseRequest createBaseValidateLicenseRequest(List<LicenseFileEntity> lfeList, LicenseInfo licenseResolve, 
            BaseLicenseFeatureDTO licenseFeatureDTO) {
        Assert.notNull(lfeList, "licenseFileEntityList不能为空");
        Assert.notNull(licenseResolve, "LicenseInfo 不能为空");
        Assert.notNull(licenseFeatureDTO, "licenseFeatureDTO不能为空");
        if (isTempLicense(licenseResolve)) {
            BaseValidateLicenseRequest validateLicenseRequest = 
                    getLicenseFeatureDTOArrByLicenseTypeIsTemp(lfeList, licenseResolve, licenseFeatureDTO);
            return validateLicenseRequest;
        }
        
        BaseValidateLicenseRequest validateLicenseRequest = 
                getLicenseFeatureDTOArrByLicenseTypeIsPerpetual(lfeList, licenseResolve, licenseFeatureDTO);
        return validateLicenseRequest;
    }
    
    /**
     * 试用授权获取BaseValidateLicenseRequest
     * @param lfeList 数据库的license信息
     * @param licenseResolve 文件的license信息
     * @param licenseFeatureDTO 
     * @return BaseValidateLicenseRequest
     */
    private static BaseValidateLicenseRequest getLicenseFeatureDTOArrByLicenseTypeIsTemp(List<LicenseFileEntity> lfeList, 
            LicenseInfo licenseResolve, 
            BaseLicenseFeatureDTO licenseFeatureDTO) {
        
        Assert.notNull(lfeList, "licenseFileEntityList不能为空");
        Assert.notNull(licenseResolve, "LicenseInfo 不能为空");
        Assert.notNull(licenseFeatureDTO, "licenseFeatureDTO不能为空");
        
        BaseValidateLicenseRequest validateLicenseRequest = new BaseValidateLicenseRequest();
        List<ValidationLicenseDTO> licenseList = new ArrayList<>();
        long trialRemainder = 0;
        for (LicenseFileEntity entity : lfeList) {
            trialRemainder += entity.getTrialRemainder();
        }
        //新上传的值
        ValidationLicenseDTO dto = new ValidationLicenseDTO();
        dto.setFeatureCode(licenseResolve.getProductName());
        dto.setFeatureStatus(BaseFeatureStatus.AVALIABLE);
        BaseFeatureType type = getBaseFeatureType(licenseResolve);
        dto.setFeatureType(type);
        trialRemainder = trialRemainder + (licenseResolve.getDuration() * 60);
        dto.setTrialRemainder(trialRemainder);
        licenseList.add(dto);
        
        ValidationLicenseDTO[] licenseFeatureDTOArr = new ValidationLicenseDTO[licenseList.size()];
        licenseFeatureDTOArr = licenseList.toArray(licenseFeatureDTOArr);
        validateLicenseRequest.setFeatureDTOArr(licenseFeatureDTOArr);
        return validateLicenseRequest;
        
    }
    
    /**
     * 正式授权获取licenseFeatureDTOArr
     * @param lfeList 数据库的license信息
     * @param licenseResolve 文件的license信息
     * @param licenseFeatureDTO 
     * @return BaseValidateLicenseRequest
     */
    private static BaseValidateLicenseRequest getLicenseFeatureDTOArrByLicenseTypeIsPerpetual(List<LicenseFileEntity> lfeList, 
            LicenseInfo licenseResolve, 
            BaseLicenseFeatureDTO licenseFeatureDTO) {
        Assert.notNull(lfeList, "licenseFileEntityList不能为空");
        Assert.notNull(licenseResolve, "LicenseInfo 不能为空");
        Assert.notNull(licenseFeatureDTO, "licenseFeatureDTO不能为空");
        
        BaseValidateLicenseRequest validateLicenseRequest = new BaseValidateLicenseRequest();
        List<ValidationLicenseDTO> licenseList = new ArrayList<>();
        for (LicenseFileEntity entity : lfeList) {
            ValidationLicenseDTO dto = new ValidationLicenseDTO();
            BeanUtils.copyProperties(entity, dto);
            licenseList.add(dto);
        }
        //新上传的值
        ValidationLicenseDTO dto = new ValidationLicenseDTO();
        dto.setFeatureCode(licenseResolve.getProductName());
        dto.setFeatureStatus(BaseFeatureStatus.AVALIABLE);
        BaseFeatureType type = getBaseFeatureType(licenseResolve);
        dto.setFeatureType(type);
        dto.setTrialRemainder(0L);
        licenseList.add(dto);
        
        ValidationLicenseDTO[] licenseFeatureDTOArr = new ValidationLicenseDTO[licenseList.size()];
        licenseFeatureDTOArr = licenseList.toArray(licenseFeatureDTOArr);
        validateLicenseRequest.setFeatureDTOArr(licenseFeatureDTOArr);
        return validateLicenseRequest;
    }
    
    
    /**
     * 创建BaseLicenseChangeRequest
     * @param lfeList 数据库的license信息
     * @return BaseLicenseChangeRequest
     */
    public static BaseLicenseChangeRequest createBaseLicenseChangeRequest(List<LicenseFileEntity> lfeList) {
        Assert.notNull(lfeList, "licenseFileEntityList不能为空");
        Assert.notEmpty(lfeList,"licenseFileEntityList长度不能为 0");
        LicenseFileEntity entity = lfeList.get(0);
        if (BaseFeatureType.TEMPORARY.equals(entity.getFeatureType())) {
            BaseLicenseChangeRequest licenseChangeRequest = getBaseLicenseChangeRequestByLicenseTypeIsTemp(lfeList);
            return licenseChangeRequest;
        }
        
        BaseLicenseChangeRequest licenseChangeRequest = getBaseLicenseChangeRequestByLicenseTypeIsPerpetual(lfeList);
        return licenseChangeRequest;
    }
    
    /**
     * 试用授权获取BaseValidateLicenseRequest
     * @param lfeList 数据库的license信息
     * @return BaseValidateLicenseRequest
     */
    private static BaseLicenseChangeRequest getBaseLicenseChangeRequestByLicenseTypeIsTemp(List<LicenseFileEntity> lfeList) {
        
        BaseLicenseChangeRequest licenseChangeRequest = new BaseLicenseChangeRequest();
        List<NotifyLicenseChangeDTO> licenseList = new ArrayList<>();
        long trialRemainder = 0;
        for (LicenseFileEntity entity : lfeList) {
            trialRemainder += entity.getTrialRemainder();
        }
        NotifyLicenseChangeDTO dto = new NotifyLicenseChangeDTO();
        dto.setFeatureCode(lfeList.get(0).getFeatureCode());
        dto.setFeatureType(lfeList.get(0).getFeatureType());
        dto.setTrialRemainder(trialRemainder);
        licenseList.add(dto);
        
        NotifyLicenseChangeDTO[] licenseFeatureDTOArr = new NotifyLicenseChangeDTO[licenseList.size()];
        licenseFeatureDTOArr = licenseList.toArray(licenseFeatureDTOArr);
        licenseChangeRequest.setFeatureArr(licenseFeatureDTOArr);
        licenseChangeRequest.setFeatureCode(lfeList.get(0).getFeatureCode());
        return licenseChangeRequest;
        
    }
    
    /**
     * 正式授权获取licenseFeatureDTOArr
     * @param lfeList 数据库的license信息
     * @return BaseValidateLicenseRequest
     */
    private static BaseLicenseChangeRequest getBaseLicenseChangeRequestByLicenseTypeIsPerpetual(List<LicenseFileEntity> lfeList) {
        
        BaseLicenseChangeRequest validateLicenseRequest = new BaseLicenseChangeRequest();
        List<NotifyLicenseChangeDTO> licenseList = new ArrayList<>();
        for (LicenseFileEntity entity : lfeList) {
            NotifyLicenseChangeDTO dto = new NotifyLicenseChangeDTO();
            BeanUtils.copyProperties(entity, dto);
            licenseList.add(dto);
        }
        
        NotifyLicenseChangeDTO[] licenseFeatureDTOArr = new NotifyLicenseChangeDTO[licenseList.size()];
        licenseFeatureDTOArr = licenseList.toArray(licenseFeatureDTOArr);
        validateLicenseRequest.setFeatureArr(licenseFeatureDTOArr);
        validateLicenseRequest.setFeatureCode(lfeList.get(0).getFeatureCode());
        
        return validateLicenseRequest;
    }
    
    /**
     * license文件 解析内容后，转化为entity
     * @param licenseFeatureDTO 请求DTO
     * @param lf License信息内容
     * 
     * @return List<LicenseFileEntity>
     * @throws BusinessException 
     */
    public static List<LicenseFileEntity> createEntity(BaseLicenseFeatureDTO licenseFeatureDTO, LicenseInfo lf) {
        
        Assert.notNull(licenseFeatureDTO, "BaseLicenseFeatureDTO不能为空");
        Assert.notNull(lf, "LicenseInfo 不能为空");
        Assert.notEmpty(lf.getFeatureList(), "FeatureList 不能为空");

        //获取license信息
        List<LicenseFileEntity> licenseFileEntityList = new ArrayList<LicenseFileEntity>();
        for (LicenseFeature feature : lf.getFeatureList()) {
            LicenseFileEntity entity = featureDTOToFeatureEntity(licenseFeatureDTO);
            licenseInfoToFeatureEntity(lf, feature, entity);
            licenseFileEntityList.add(entity);
        }
        return licenseFileEntityList;
    }
    
    
    /**
     *  DTO 转化为 Entity
     * @param dto license实体类
     * @return BaseLicenseFeatureDTO
     * @throws BusinessException 业务异常
     */
    private static LicenseFileEntity featureDTOToFeatureEntity(BaseLicenseFeatureDTO dto) {
        Assert.notNull(dto, "BaseLicenseFeatureDTO不能为空");
        LicenseFileEntity entity = new LicenseFileEntity();
        entity.setFeatureCode(dto.getFeatureCode());
        entity.setFileName(dto.getFileName());
        entity.setFileMd5(dto.getFileMd5());
        entity.setFeatureDisplayName(dto.getFeatureDisplayName());
        entity.setFeatureDescription(dto.getFeatureDescription());
        
        return entity;
    }
    
    /**
     *  licenseInfo 转化为 Entity
     * @param lf 
     * @param feature   
     * @param entity 
     * @return LicenseFileEntity
     */
    private static LicenseFileEntity licenseInfoToFeatureEntity(LicenseInfo lf, LicenseFeature feature, LicenseFileEntity entity) {
        Assert.notNull(lf, "LicenseInfo不能为空");
        Assert.notNull(feature, "LicenseFeature不能为空");
        Assert.notNull(entity, "LicenseFileEntity不能为空");
        //是否 试用授权
        boolean isTemp = isTempLicense(lf);
        
        BaseFeatureType type = getBaseFeatureType(lf);
        entity.setFeatureType(type);
        //首次导入 license状态为可用状态
        entity.setFeatureStatus(BaseFeatureStatus.AVALIABLE);
        entity.setCreateTime(new Date());
        //是否 试用授权
        if (isTemp) {
            //由于解析后的license信息，只有Duration（持续时间），且持续时间单位为分钟，而数据库需要换算成秒
            long trialDuration = feature.getDuration() * 60;
            entity.setTrialDuration(trialDuration);
            //首次导入license时，剩余试用时间（trialRemainder） 和 持续时间（trialDuration） 相等
            entity.setTrialRemainder(trialDuration);
            //首次导入试用license TRAIL_START_TIME(试用开始时间)为当前时间
            entity.setTrailStartTime(new Date());
        }
        
        return entity;
    }
    
    /**
     * Entity 转化为 DTO
     * @param entity license实体类
     * @return BaseLicenseFeatureDTO
     * @throws BusinessException 业务异常
     */
    public static BaseLicenseFeatureDTO featureEntityToFeatureDTO(LicenseFileEntity entity) {
        
        Assert.notNull(entity, "LicenseFileEntity不能为空");
        
        BaseLicenseFeatureDTO dto = new BaseLicenseFeatureDTO();
        dto.setFeatureCode(entity.getFeatureCode());
        dto.setFeatureStatus(entity.getFeatureStatus());
        dto.setFeatureType(entity.getFeatureType());
        dto.setFileName(entity.getFileName());
        dto.setFileMd5(entity.getFileMd5());
        dto.setDurationLicense(entity.getTrialDuration());
        
        return dto;
        
    }
    
    /**
     * l组装BaseCreateDatFileResponse 内容
     * @param spiResponse spi请求结果
     * 
     * @return BaseCreateDatFileResponse 
     */
    public static BaseCreateDatFileResponse createDatFileResponse(BaseGetLicenseSerialNumberResponse spiResponse) {
        
        Assert.notNull(spiResponse, "BaseGetLicenseSerialNumberResponse不能为空");
        BaseCreateDatFileResponse response = new BaseCreateDatFileResponse();
        //组装文件内容
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        stringBuilder.append("<option>\n");
        stringBuilder.append("  <dev_id>");
        stringBuilder.append(spiResponse.getSerialId());
        stringBuilder.append("</dev_id>\n");
        stringBuilder.append("  <dev_code>");
        stringBuilder.append(UUID.randomUUID().toString());
        stringBuilder.append("</dev_code>\n");
        stringBuilder.append("</option>");
        response.setFileContent(stringBuilder.toString());
        response.setFiieName(spiResponse.getSerialId());
        return response;
    }
    
    /**
     * 创建licenseDTO
     * @param request 
     * @return BaseLicenseFeatureDTO
     */
    public static BaseLicenseFeatureDTO createLicenseDTO(BaseUploadLicFileRequest request) {
        Assert.notNull(request, "BaseUploadLicFileRequest不能为空");
        BaseLicenseFeatureDTO dto = new BaseLicenseFeatureDTO();
        dto.setFileName(request.getFileName());
        dto.setFileMd5(request.getFileMd5());
        dto.setFilePath(request.getFilePath());
        return dto;
    }
    
    /**
     * 是否试用license授权
     * @param licenseResolve License信息内容
     * 
     * @return boolean 是否试用license授权
     */
    public static boolean isTempLicense(LicenseInfo licenseResolve) {
        Assert.notNull(licenseResolve, "LicenseInfo不能为空");
        return licenseResolve.getDuration() > 0 ? true : false;
    }
    
    /**
     * 获取license授权类型
     * @param licenseResolve License信息内容
     * 
     * @return boolean 是否试用license授权
     */
    private static BaseFeatureType getBaseFeatureType(LicenseInfo licenseResolve) {
        Assert.notNull(licenseResolve, "LicenseInfo不能为空");
        BaseFeatureType type = licenseResolve.getDuration() == 0 ?  BaseFeatureType.PERPETUAL :  BaseFeatureType.TEMPORARY;
        return type;
    }
}
