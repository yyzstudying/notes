package com.ruijie.rcos.base.sysmanage.module.impl.api;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.util.Assert;

import com.ruijie.rcos.base.sysmanage.module.def.api.DebugLogAPI;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.debuglog.BaseCreateDebugLogRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.debuglog.BaseDeleteDebugLogRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.debuglog.BaseDetailDebugLogRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.debuglog.BaseListDebugLogRequest;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.debuglog.BaseCreateDebugLogResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.debuglog.BaseDeleteDebugLogResponse;
import com.ruijie.rcos.base.sysmanage.module.def.api.response.debuglog.BaseDetailDebugLogResponse;
import com.ruijie.rcos.base.sysmanage.module.def.dto.BaseDebugLogDTO;
import com.ruijie.rcos.base.sysmanage.module.impl.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.DebugLogEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.service.DebugLogService;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.log.LoggerFactory;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultPageResponse;

/**
 * Description: 调试日志服务类
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月19日
 *
 * @author fyq
 */
public class DebugLogAPIImpl implements DebugLogAPI {

    private static final Logger LOGGER = LoggerFactory.getLogger(DebugLogAPIImpl.class);

    @Autowired
    private DebugLogService debugLogService;

    @Override
    public BaseCreateDebugLogResponse createDebugLog(BaseCreateDebugLogRequest apiRequest) throws BusinessException {
        Assert.notNull(apiRequest, "请求参数不能为空");
        LOGGER.debug("开始收集日志");
        DebugLogEntity entity = debugLogService.createDebugLog();
        BaseCreateDebugLogResponse apiResponse = new BaseCreateDebugLogResponse();
        BeanUtils.copyProperties(entity, apiResponse);
        return apiResponse;
    }

    @Override
    public BaseDeleteDebugLogResponse deleteDebugLog(BaseDeleteDebugLogRequest apiRequest) throws BusinessException {

        Assert.notNull(apiRequest, "请求参数不能为空");

        DebugLogEntity entity = debugLogService.deleteDebugLog(apiRequest.getId());

        BaseDeleteDebugLogResponse apiResponse = new BaseDeleteDebugLogResponse();
        BeanUtils.copyProperties(entity, apiResponse);

        return apiResponse;
    }

    @Override
    public BaseDetailDebugLogResponse detailDebugLog(BaseDetailDebugLogRequest apiRequest) throws BusinessException {

        Assert.notNull(apiRequest, "请求参数不能为空");

        DebugLogEntity entity = debugLogService.detailDebugLog(apiRequest.getId());

        String logPath = debugLogService.getDebugLogPath();

        BaseDetailDebugLogResponse apiResponse = new BaseDetailDebugLogResponse();
        BeanUtils.copyProperties(entity, apiResponse);

        if (!Files.exists(Paths.get(logPath + File.separatorChar + entity.getRealFileName()))) {
            throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_LOG_FILE_NOT_EXIST);
        }
        apiResponse.setFilePath(logPath + File.separatorChar + entity.getRealFileName());

        return apiResponse;
    }

    @Override
    public DefaultPageResponse<BaseDebugLogDTO> listDebugLog(BaseListDebugLogRequest apiRequest) {

        Assert.notNull(apiRequest, "请求参数不能为空");

        Page<DebugLogEntity> page = debugLogService.listDebugLog(apiRequest);

        List<DebugLogEntity> debugLogEntityList = page.getContent();
        List<BaseDebugLogDTO> debugLogDTOList = new ArrayList<>();

        for (DebugLogEntity entity : debugLogEntityList) {
            BaseDebugLogDTO debugLogDTO = new BaseDebugLogDTO();
            BeanUtils.copyProperties(entity, debugLogDTO);
            debugLogDTOList.add(debugLogDTO);
        }

        DefaultPageResponse<BaseDebugLogDTO> response = new DefaultPageResponse<BaseDebugLogDTO>();
        response.setItemArr(debugLogDTOList.toArray(new BaseDebugLogDTO[0]));
        response.setTotal(page.getTotalElements());

        return response;
    }
}
