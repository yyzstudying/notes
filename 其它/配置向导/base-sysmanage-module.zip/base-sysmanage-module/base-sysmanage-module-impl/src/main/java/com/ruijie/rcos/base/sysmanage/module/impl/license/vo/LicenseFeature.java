package com.ruijie.rcos.base.sysmanage.module.impl.license.vo;

import java.util.Date;
import com.ruijie.rcos.base.sysmanage.module.impl.license.enums.FeatureTypeEnum;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月18日
 * 
 * @author zouqi
 */
public class LicenseFeature {
	
    private String name; //名称
    
    private FeatureTypeEnum type;
    
    private Date startTime;
    
    private long duration;
    
    private boolean isOn;//true : on  false  off; 对于FeatureTypeEnum.ONOFF
    
    private long value;//特性的值  FeatureTypeEnum.DATA
    
    public String getName() {
    	return name;
    }
    
    public void setName(String name) {
    	this.name = name;
    }
    
    public FeatureTypeEnum getType() {
    	return type;
    }
    
    public void setType(FeatureTypeEnum type) {
    	this.type = type;
    }
    
    public Date getStartTime() {
    	return startTime;
    }
    
    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }
    
    public long getDuration() {
    	return duration;
    }
    
    public void setDuration(long duration) {
    	this.duration = duration;
    }
    
    public boolean isOn() {
    	return FeatureTypeEnum.ONOFF == type && isOn;
    }
    
    public void setOn(boolean isOn) {
    	this.isOn = isOn;
    }
    
    public long getValue() {
    	return value;
    }
    
    public void setValue(long value) {
    	this.value = value;
    }
}
