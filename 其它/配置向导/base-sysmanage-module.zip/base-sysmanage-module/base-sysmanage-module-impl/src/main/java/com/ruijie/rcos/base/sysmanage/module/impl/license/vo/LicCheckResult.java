package com.ruijie.rcos.base.sysmanage.module.impl.license.vo;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月18日
 * 
 * @author zouqi
 */
public class LicCheckResult {
    
    public static final int LIC_FILE_ERROR = -1;//文件非法
    
    public static final int LIC_OK = 0;//文件合法,校验通过
    
    public static final int LIC_SN_INVAILD = 1;//序列号错误
    
    public static final int LIC_SIGN_INVAILD = 2;//校验码错误
    
    private int result;
    
    private String content;
    
    private LicenseInfo licInfo;
    
    
    public int getResult() {
    	return result;
    }
    
    public void setResult(int result) {
    	this.result = result;
    }
    
    public String getContent() {
    	return content;
    }
    
    public void setContent(String content) {
    	this.content = content;
    }
    
    public LicenseInfo getLicInfo() {
    	return licInfo;
    }
    
    public void setLicInfo(LicenseInfo licInfo) {
    	this.licInfo = licInfo;
    }
}
