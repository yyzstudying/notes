package com.ruijie.rcos.base.sysmanage.module.impl.initizlizer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruijie.rcos.base.sysmanage.module.impl.service.LicenseFileService;
import com.ruijie.rcos.sk.modulekit.api.bootstrap.SafetySingletonInitializer;

/**
 * Description: 当前组件的初始化业务，用于系统启动时向上层业务通知当前的license信息
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月4日
 * 
 * @author zouqi
 */
@Service
public class LicenseInitializer implements SafetySingletonInitializer {

    @Autowired
    private LicenseFileService licenseFileService;

    @Override
    public void safeInit() {
        licenseFileService.initLicense();
    }
       
}
