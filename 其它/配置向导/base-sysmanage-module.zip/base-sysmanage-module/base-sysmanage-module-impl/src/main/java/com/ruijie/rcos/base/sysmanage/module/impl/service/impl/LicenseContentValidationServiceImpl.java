package com.ruijie.rcos.base.sysmanage.module.impl.service.impl;

import java.io.File;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import com.ruijie.rcos.base.sysmanage.module.def.dto.license.BaseLicenseFeatureDTO;
import com.ruijie.rcos.base.sysmanage.module.def.enums.BaseFeatureType;
import com.ruijie.rcos.base.sysmanage.module.def.enums.ValidateLicenseStatus;
import com.ruijie.rcos.base.sysmanage.module.def.spi.BaseLicenseFeatureResolveSPI;
import com.ruijie.rcos.base.sysmanage.module.def.spi.BaseLicenseFeatureValidateSPI;
import com.ruijie.rcos.base.sysmanage.module.def.spi.BaseLicenseSerialNumberSPI;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseGetLicenseSerianNumberRequest;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseLicenseFeatureResolveRequest;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseValidateLicenseRequest;
import com.ruijie.rcos.base.sysmanage.module.def.spi.response.BaseGetLicenseSerialNumberResponse;
import com.ruijie.rcos.base.sysmanage.module.def.spi.response.BaseLicenseFeatureResolveResponse;
import com.ruijie.rcos.base.sysmanage.module.def.spi.response.BaseValidateLicenseResponse;
import com.ruijie.rcos.base.sysmanage.module.impl.BusinessKey;
import com.ruijie.rcos.base.sysmanage.module.impl.dao.LicenseFileDAO;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.LicenseFileEntity;
import com.ruijie.rcos.base.sysmanage.module.impl.license.client.LicenseService;
import com.ruijie.rcos.base.sysmanage.module.impl.license.vo.LicCheckResult;
import com.ruijie.rcos.base.sysmanage.module.impl.license.vo.LicenseInfo;
import com.ruijie.rcos.base.sysmanage.module.impl.service.LicenseContentValidationService;
import com.ruijie.rcos.base.sysmanage.module.impl.util.LicenseUtil;
import com.ruijie.rcos.sk.base.config.ConfigFacade;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.log.LoggerFactory;

/**
 * Description: license合法性校验serviceImpl
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月8日
 * 
 * @author zouqi
 */
@Service
public class LicenseContentValidationServiceImpl implements LicenseContentValidationService {
    
    private final static Logger LOGGER = LoggerFactory.getLogger(LicenseContentValidationServiceImpl.class);
    
    private final static String LICENSE_FILE_PATH = "file.busiz.dir.license";

    @Autowired
    private LicenseFileDAO licenseFileDAO;
    
    @Autowired
    private ConfigFacade configFacade;
    
    @Autowired
    private BaseLicenseFeatureResolveSPI licenseFeatureResolveSPI;
    
    @Autowired
    private BaseLicenseFeatureValidateSPI licenseFeatureValidateSPI;
    
    @Autowired
    private BaseLicenseSerialNumberSPI licenseSerialNumberSPI;
    
    /**
     * license文件 校验合法性
     * @param licenseFeatureDTO
     * @param tmpFile
     * @throws BusinessException
     */
    @Override
    public LicenseInfo licenseContentValidation(BaseLicenseFeatureDTO licenseFeatureDTO) throws BusinessException {

        Assert.notNull(licenseFeatureDTO, "BaseLicenseFeatureDTO 不能为空");
        Assert.hasText(licenseFeatureDTO.getFileName(), "FileName 不能为空");
        Assert.hasText(licenseFeatureDTO.getFilePath(), "FilePath 不能为空");
        Assert.hasText(licenseFeatureDTO.getFileMd5(), "FileMd5 不能为空");
        
        //解析lic文件内容
        LicenseInfo lf = resolverLicenseFile(licenseFeatureDTO);
        
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("根据featureId获取featureCode开始,featureId：{}", lf.getProductName());
        }
        //根据license文件里的 featureId 获取LicenseFeatureCode
        BaseLicenseFeatureResolveResponse licenseFeatureResolveResponse = getFeatureCode(lf, licenseFeatureDTO);
        
        licenseFeatureDTO.setFeatureCode(licenseFeatureResolveResponse.getFeatureCode());
        
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("根据featureId获取featureCode结束,featureCode：{}", licenseFeatureResolveResponse.getFeatureCode());
        }

        //是否 试用授权
        boolean isTemp = LicenseUtil.isTempLicense(lf);
        //如果临时授权的话，需要数据库查询是否也是临时授权（临时授权可以变更为 永久授权，反之不行）
        if (isTemp) {
            List<LicenseFileEntity> licenseFileEntityList = this.licenseFileDAO
                    .findByFeatureTypeAndFeatureCodeOrderByCreateTime(BaseFeatureType.PERPETUAL, licenseFeatureResolveResponse.getFeatureCode()); 
            //说明库里存在了 永久授权 
            if (null != licenseFileEntityList && licenseFileEntityList.size() > 0) {
                LOGGER.error("永久授权无法改为临时授权，license文件名 {}",licenseFeatureDTO.getFileName());
                throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_LICENSE_TYPE_CHANGE_ERROR);
            }
        }
        //根据FeatureCode 获取FeatureCode信息
        List<LicenseFileEntity> lfeList = this.licenseFileDAO.findByFeatureCode(licenseFeatureResolveResponse.getFeatureCode());
        
        BaseValidateLicenseRequest request = LicenseUtil.createBaseValidateLicenseRequest(lfeList, lf, licenseFeatureDTO);
        
        //SPI验证license是否合法
        BaseValidateLicenseResponse validateLicenseResponse = licenseFeatureValidateSPI.checkLicenseViolation(request);
        
        //验证不通过
        if (validateLicenseResponse.getLicenseStatus() == ValidateLicenseStatus.ERROR) {
            LOGGER.error("license验证失败,license文件名{}",licenseFeatureDTO.getFileName());
            throw new BusinessException(validateLicenseResponse.getMessageKey());
        }
        
        return lf;
    }

    /**
     * license文件 解析内容
     * @param licenseResolve 
     * @param licenseFeatureDTO
     * 
     * @return BaseLicenseFeatureResolveResponse
     */
    private BaseLicenseFeatureResolveResponse getFeatureCode(LicenseInfo licenseResolve, BaseLicenseFeatureDTO licenseFeatureDTO) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("根据featureId获取featureCode开始,featureId：{}", licenseResolve.getProductName());
        }
        //根据featureId获取featureCode
        BaseLicenseFeatureResolveRequest licenseFeatureResolveRequest = new BaseLicenseFeatureResolveRequest();
        licenseFeatureResolveRequest.setFeatureId(licenseResolve.getProductName());
        //根据license文件里的 featureId 获取LicenseFeatureCode
        BaseLicenseFeatureResolveResponse licenseFeatureResolveResponse = licenseFeatureResolveSPI
                .getLicenseFeatureCode(licenseFeatureResolveRequest);
        licenseFeatureDTO.setFeatureCode(licenseFeatureResolveResponse.getFeatureCode());
        
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("根据featureId获取featureCode结束,featureCode：{}", licenseFeatureResolveResponse.getFeatureCode());
        }
        
        return licenseFeatureResolveResponse;
    }
    
    /**
     * license文件 解析内容
     * @param licenseFeatureDTO
     * @param tmpFile
     * 
     * @return LicenseInfo
     * @throws BusinessException 
     */
    @Override
    public LicenseInfo resolverLicenseFile(BaseLicenseFeatureDTO licenseFeatureDTO) throws BusinessException {
        
        Assert.notNull(licenseFeatureDTO, "BaseLicenseFeatureDTO 不能为空");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("开始解析license文件： {}",licenseFeatureDTO.getFileName());
        }
        LicenseInfo licenseInfo = null;
        LicenseService ls = new LicenseService();
        String saveFilePath = configFacade.read(LICENSE_FILE_PATH) + licenseFeatureDTO.getFileName();
        File file = new File(saveFilePath);
        //
        BaseGetLicenseSerialNumberResponse response = licenseSerialNumberSPI.getLicenseSerialNumber(new BaseGetLicenseSerianNumberRequest());
        
        //验证lic文件的合法性
        LicCheckResult  lcr = ls.check(file, response.getSerialId());
        int result = lcr.getResult();
        if (result == 0) {
            //获取license信息
            licenseInfo = lcr.getLicInfo();
            return licenseInfo;
        } else {
            //如果根据硬件唯一码 去校验lic文件 还是不合法，表示不是lic文件或者lic文件的SN码和及其唯一码 不一致
            LOGGER.error("license文件解析失败 {}",licenseFeatureDTO.getFileName());
            throw new BusinessException(BusinessKey.BASE_SYS_MANAGE_LICENSE_FILE_RESOLVE_ERROR);
        }
    }
    


}
