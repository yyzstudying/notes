package com.ruijie.rcos.base.sysmanage.module.impl.service;

import java.util.Map;

import com.ruijie.rcos.base.sysmanage.module.impl.quartz.data.QuartzTaskData;
import com.ruijie.rcos.sk.base.exception.BusinessException;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月07日
 *
 * @author xgx
 */
public interface ScheduleService {
    /**
     * 添加定时器
     * 
     * @param group 组
     * @param name 任务名
     * @param cronExpression 定时器表达式
     * @param jobDataMap 任务数据
     * @throws BusinessException 业务异常
     */
    void addSchedule(String group, String name, String cronExpression, Map<String, QuartzTaskData> jobDataMap) throws BusinessException;

    /**
     * 更新定时任务
     *
     * @param group 组标识
     * @param name 任务标识
     * @param cronExpression 定时器表达式
     * @param jobDataMap 任务数据
     * @throws BusinessException 业务异常
     */
    void updateSchedule(String group, String name, String cronExpression, Map<String, QuartzTaskData> jobDataMap) throws BusinessException;

    /**
     * 删除定时任务
     *
     * @param group 组标识
     * @param name 任务标识
     * @throws BusinessException 业务异常
     */
    void deleteSchedule(String group, String name) throws BusinessException;


}
