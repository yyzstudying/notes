package com.ruijie.rcos.base.sysmanage.module.impl.service;

import com.ruijie.rcos.base.sysmanage.module.def.dto.license.BaseLicenseFeatureDTO;
import com.ruijie.rcos.sk.base.exception.BusinessException;

/**
 * Description: license文件合法性校验service
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年3月8日
 * 
 * @author zouqi
 */
public interface LicenseFileMoveService {
    
    /**
     * license文件 校验合法性
     * 
     * @param licenseFeatureDTO 用于验证的dto
     * @throws BusinessException 业务异常
     */
    void licenseFileValidation(BaseLicenseFeatureDTO licenseFeatureDTO) throws BusinessException;
    
    /**
     * 剪切license文件到指定目录
     * 
     * @param licenseFeatureDTO 参数 
     * @throws BusinessException 业务异常
     */
    void cutLicenseFile(BaseLicenseFeatureDTO licenseFeatureDTO) throws BusinessException;
    
    /**
     * 剪切license文件到指定目录
     * 
     * @param licenseFeatureDTO 参数 
     * @throws BusinessException 业务异常
     */
    void deleteFile(BaseLicenseFeatureDTO licenseFeatureDTO) throws BusinessException;
}
