package com.ruijie.rcos.base.sysmanage.module.impl.service;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.data.domain.Page;

import com.ruijie.rcos.base.sysmanage.module.def.api.request.databackup.BaseListDataBackupRequest;
import com.ruijie.rcos.base.sysmanage.module.impl.entity.DataBackupEntity;
import com.ruijie.rcos.sk.base.exception.BusinessException;

/**
 * Description: 数据库备份服务接口
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月06日
 *
 * @author fyq
 */
public interface DataBackupService {

    /**
     * 创建数据库备份
     * 
     * @param isAuto 是否为定时任务的自动备份，自动备份的会自动删除七天前的数据
     * @throws BusinessException 业务异常
     * @return 返回数据库备份实体
     */
    DataBackupEntity createDataBackup(boolean isAuto) throws BusinessException;


    /**
     * 删除数据库备份
     * 
     * @param id 备份id
     * @throws BusinessException 业务异常
     * @return 返回数据库备份实体
     */
    DataBackupEntity deleteDataBackup(UUID id) throws BusinessException;

    /**
     * 分页获取数据库备份列表
     *
     * @param listDataBackupRequest 获取请求
     * @return 备份列表
     */
    Page<DataBackupEntity> listDataBackup(BaseListDataBackupRequest listDataBackupRequest);

    /**
     * 获取已超期的数据库备份列表
     * 
     * @param expireDate 超期时间
     * @param isAutoBackup 是否自动备份
     * @return 超期的数据库备份数据列表
     */
    List<DataBackupEntity> listExpireDataBackup(Date expireDate, boolean isAutoBackup);

}
