package com.ruijie.rcos.base.sysmanage.module.impl.quartz.data;

import com.ruijie.rcos.sk.base.annotation.NotBlank;
import com.ruijie.rcos.sk.base.annotation.NotNull;

/**
 * Description: 定时任务数据类
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019年01月19日
 *
 * @author xgx
 */
public class ConfigQuartzTaskData extends QuartzTaskData {
    @NotBlank
    private String expression;

    @NotNull
    private String taskTypeName;


    public String getExpression() {
        return expression;
    }

    public void setExpression(String expression) {
        this.expression = expression;
    }

    public String getTaskTypeName() {
        return taskTypeName;
    }

    public void setTaskTypeName(String taskTypeName) {
        this.taskTypeName = taskTypeName;
    }
}
