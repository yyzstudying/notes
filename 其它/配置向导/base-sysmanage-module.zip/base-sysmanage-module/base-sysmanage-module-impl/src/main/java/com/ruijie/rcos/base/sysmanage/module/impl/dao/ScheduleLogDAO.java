package com.ruijie.rcos.base.sysmanage.module.impl.dao;

import java.util.UUID;

import com.ruijie.rcos.base.sysmanage.module.impl.entity.ScheduleLogEntity;
import com.ruijie.rcos.sk.modulekit.api.ds.SkyEngineJpaRepository;

/**
 * Description: 定时任务日志dao
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月05日
 *
 * @author xgx
 */
public interface ScheduleLogDAO extends SkyEngineJpaRepository<ScheduleLogEntity, UUID> {
}
