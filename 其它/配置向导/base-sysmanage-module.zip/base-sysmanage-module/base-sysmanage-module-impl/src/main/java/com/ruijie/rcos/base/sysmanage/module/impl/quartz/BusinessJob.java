package com.ruijie.rcos.base.sysmanage.module.impl.quartz;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.springframework.util.Assert;

import com.alibaba.fastjson.JSON;
import com.ruijie.rcos.base.sysmanage.module.impl.common.Constants;
import com.ruijie.rcos.base.sysmanage.module.impl.quartz.data.QuartzTaskData;
import com.ruijie.rcos.base.sysmanage.module.impl.quartz.dispatcher.JobDispatcher;
import com.ruijie.rcos.sk.base.exception.AnnotationValidationException;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.log.LoggerFactory;
import com.ruijie.rcos.sk.base.validation.BeanValidationUtil;

/**
 * 
 * Description: job类
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年11月13日
 * 
 * @author hhx
 */
@DisallowConcurrentExecution
public class BusinessJob implements Job {

    protected final static Logger LOGGER = LoggerFactory.getLogger(BusinessJob.class);

    /**
     * 任务调度执行主方法
     */
    @Override
    public void execute(JobExecutionContext context) {
        LOGGER.debug("定时任务开始执行");
        Assert.notNull(context, "任务执行上下文不能为空");
        JobDataMap data = context.getJobDetail().getJobDataMap();
        QuartzTaskData quartzTaskData = (QuartzTaskData) data.get(Constants.SCHEDULE_DATA_KEY);
        try {
            BeanValidationUtil.validateBean(quartzTaskData.getClass(), quartzTaskData);
        } catch (AnnotationValidationException e) {
            LOGGER.error("非法的定时任务参数[" + (JSON.toJSONString(quartzTaskData)) + "]", e);
            return;
        }
        if (!quartzTaskData.getQuartzTask().needExecute()) {
            LOGGER.info("定时器：{}不需要执行", quartzTaskData.getQuartzTask().getClass().getName());
            return;
        }
        JobDispatcher jobDispatcher = quartzTaskData.getJobDispatcher();
        jobDispatcher.dispatcher(context);
    }
}
