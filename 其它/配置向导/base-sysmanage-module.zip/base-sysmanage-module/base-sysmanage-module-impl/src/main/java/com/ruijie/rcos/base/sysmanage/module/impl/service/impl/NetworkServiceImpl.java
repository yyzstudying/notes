package com.ruijie.rcos.base.sysmanage.module.impl.service.impl;

import java.util.Collection;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONException;
import com.ruijie.rcos.base.sysmanage.module.def.api.request.network.BaseUpdateNetworkRequest;
import com.ruijie.rcos.base.sysmanage.module.def.dto.BaseNetworkDTO;
import com.ruijie.rcos.base.sysmanage.module.def.spi.BaseNetworkChangeAfterSPI;
import com.ruijie.rcos.base.sysmanage.module.def.spi.BaseNetworkChangeBeforeSPI;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseNetworkChangeAfterRequest;
import com.ruijie.rcos.base.sysmanage.module.def.spi.request.BaseNetworkChangeBeforeRequest;
import com.ruijie.rcos.base.sysmanage.module.impl.common.Constants;
import com.ruijie.rcos.base.sysmanage.module.impl.service.NetworkService;
import com.ruijie.rcos.sk.base.concorrent.SkyengineExecutors;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.base.log.Logger;
import com.ruijie.rcos.sk.base.log.LoggerFactory;
import com.ruijie.rcos.sk.base.shell.ShellCommandRunner;
import com.ruijie.rcos.sk.modulekit.api.comm.ModuleCommExpertAPI;
import org.springframework.util.StringUtils;

/**
 * Description: 网卡服务实现类
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年11月28日
 *
 * @author fyq
 */
@Service
public class NetworkServiceImpl implements NetworkService {

    private static final Logger LOGGER = LoggerFactory.getLogger(NetworkServiceImpl.class);

    @Autowired
    private BaseNetworkChangeBeforeSPI networkChangeBeforeSPI;

    @Autowired
    private BaseNetworkChangeAfterSPI networkChangeAfterSPI;

    @Autowired
    private ModuleCommExpertAPI moduleCommExpertAPI;

    @Override
    public BaseNetworkDTO detailNetwork() throws BusinessException {

        LOGGER.debug("【网卡配置服务】 获取网卡配置");

        String networkInfo = new ShellCommandRunner().setCommand(Constants.SH_IP_INFO).execute();

        try {
            BaseNetworkDTO networkDTO = JSON.parseObject(networkInfo, BaseNetworkDTO.class);

            LOGGER.debug("【网卡配置服务】 获取网卡配置成功 {}", networkDTO);
            return networkDTO;

        } catch (JSONException e) {
            LOGGER.error("【网卡配置服务】 解析网卡配置失败：{}，网卡信息：{}", e.getMessage(), networkInfo);
            throw new IllegalStateException("解析网卡配置失败：" + networkInfo, e);
        }
    }

    @Override
    public void updateNetwork(BaseUpdateNetworkRequest request) throws BusinessException {

        Assert.notNull(request, "请求参数不能为空");

        LOGGER.warn("【网卡配置服务】 修改网卡配置{}", request);

        BaseNetworkDTO oldNetworkDto = detailNetwork();

        if (request.getIp().equals(oldNetworkDto.getIp())//
                && request.getNetmask().equals(oldNetworkDto.getNetmask())//
                && request.getGateway().equals(oldNetworkDto.getGateway())//
                && request.getDns().equals(oldNetworkDto.getDns())) {

            LOGGER.error("【网卡配置服务】 修改网卡配置失败-未修改配置 原配置{}，新配置{}", oldNetworkDto, request);

            return;
        }

        // 更新网卡配置前发送spi通知，如果有组件抛出异常则不允许修改网卡配置
        Collection<String> beforeSpiKeyList = moduleCommExpertAPI.loadDispatcherKeys(BaseNetworkChangeBeforeSPI.class);

        LOGGER.debug("【网卡配置服务】 修改网卡配置前通知 {}", beforeSpiKeyList);

        for (String key : beforeSpiKeyList) {
            // 通知过程不让更新的组件会抛出异常
            networkChangeBeforeSPI.beforeNetworkChange(new BaseNetworkChangeBeforeRequest(key));
        }

        ShellCommandRunner runner = new ShellCommandRunner();
        runner.setCommand(Constants.SH_IP_CONFIG);
        runner.appendArgs("-i", request.getIp());
        runner.appendArgs("-n", request.getNetmask());
        runner.appendArgs("-g", request.getGateway());
        if (!StringUtils.isEmpty(request.getDns())) {
            runner.appendArgs("-f", request.getDns());
        }
        runner.execute();

        LOGGER.debug("【网卡配置服务】 修改网卡配置后通知");

        BaseNetworkChangeAfterRequest networkChangeAfterRequest = new BaseNetworkChangeAfterRequest();
        BeanUtils.copyProperties(request, networkChangeAfterRequest);
        networkChangeAfterSPI.afterNetworkChange(networkChangeAfterRequest);

        restartNetwork(Constants.SH_IP_CHANGE_RESTART_DELAY);
    }

    /**
     * 重启网卡服务
     */
    private void restartNetwork(int delay) {

        LOGGER.warn("【网卡配置服务】 重启网卡");

        SkyengineExecutors.schedule(() -> {
            try {
                new ShellCommandRunner().setCommand(Constants.SH_RESTART_NETWORK).execute();
            } catch (Exception e) {
                LOGGER.error("重启网卡服务失败", e);
            }
        }, delay, Constants.SH_IP_CHANGE_RESTART_TASK_NAME);
    }
}
