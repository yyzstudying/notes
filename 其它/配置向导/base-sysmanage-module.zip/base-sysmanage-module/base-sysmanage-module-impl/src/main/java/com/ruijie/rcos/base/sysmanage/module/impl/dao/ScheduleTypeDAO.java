package com.ruijie.rcos.base.sysmanage.module.impl.dao;

import java.util.Optional;
import java.util.UUID;

import com.ruijie.rcos.base.sysmanage.module.impl.entity.ScheduleTypeEntity;
import com.ruijie.rcos.sk.modulekit.api.ds.SkyEngineJpaRepository;

/**
 * Description: 任务类型dao
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月05日
 *
 * @author xgx
 */
public interface ScheduleTypeDAO extends SkyEngineJpaRepository<ScheduleTypeEntity, UUID> {
    /**
     * 通过beanName查询任务类型
     *
     * @param beanName spring容器中bean唯一标识
     * @return optional对象
     */
    Optional<ScheduleTypeEntity> findByBeanName(String beanName);
}
