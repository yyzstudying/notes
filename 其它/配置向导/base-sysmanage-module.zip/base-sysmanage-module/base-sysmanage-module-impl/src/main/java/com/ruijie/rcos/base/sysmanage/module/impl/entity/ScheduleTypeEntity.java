package com.ruijie.rcos.base.sysmanage.module.impl.entity;

import java.util.UUID;

import javax.persistence.*;

/**
 * Description: Function Description
 * Copyright: Copyright (c) 2018
 * Company: Ruijie Co., Ltd.
 * Create Time: 2018年12月05日
 *
 * @author xgx
 */
@Entity
@Table(name = "t_base_sysmanage_schedule_type")
public class ScheduleTypeEntity {
    /**
     * 唯一标识
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    /**
     * 任务类型名称
     */
    private String name;

    /**
     * 容器bean标识
     */
    private String beanName;

    /**
     * 版本号
     */
    @Version
    private int version;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBeanName() {
        return beanName;
    }

    public void setBeanName(String beanName) {
        this.beanName = beanName;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }
}
