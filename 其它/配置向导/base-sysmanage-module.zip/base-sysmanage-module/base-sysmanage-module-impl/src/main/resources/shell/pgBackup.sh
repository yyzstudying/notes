#!/bin/bash

cd /data/web/rcdc/shell

#include files
. ./pgconfig.conf

#include files
. ./common.sh

export PGPASSWORD=$PASSWORD

TIME=$(date +%s)
BAKNAME=$3.tar.gz
TMPDIR=${BAKDIR}/${TIME}

while getopts "d:o:f:" arg;do
  case $arg in
    d)
    DBARRAY=(${OPTARG//,/ })
    ;;
    o)
    BAKDIR=$OPTARG
    ;;
    f)
    BAKNAME=$OPTARG
    ;;
    esac
done

if [ "$DBARRAY" = "" ];then
    fail 1 "no database to backup"
fi
 
    mk_dir $TMPDIR

    for dbname in ${DBARRAY[*]};do

        echo "$(date '+%Y-%m-%d %H:%M:%S') start dump $dbname" 1>>$LOG

        pg_dump -h $HOST -p $PORT -U $USER $dbname -C -f ${TMPDIR}/${dbname}.sql 1>>$LOG 2>>$LOG_ERR

        if [ $? -ne 0 ];then

            rm_dir ${TMPDIR}

            fail 2 "backup ${dbname} failed"
        fi

    done

    tar_dir ${TMPDIR} ${BAKDIR}/${BAKNAME}
    rm_dir ${TMPDIR}


    echo -n $BAKNAME

