#!/bin/bash

cd /data/web/rcdc/shell

#include files
. ./common.sh

ip=$(ping $1 -c 1|head -1|awk -F '[()]' '{print $2}')

if [ "$ip" == "" ];then
  fail 101 "ping $1 failed"
fi

ntpdate $1 1>_ok.tmp 2>_err.tmp

if [ $? -ne 0 ];then
  fail 1 "ntp update failed"
else
  hwclock -w
  printf "success"
fi
