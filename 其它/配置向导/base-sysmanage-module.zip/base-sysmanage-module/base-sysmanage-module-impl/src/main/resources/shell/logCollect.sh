#!/bin/bash

cd /data/web/rcdc/shell

#include files
. ./common.sh

TIME=$(date +%s)

LOG_DIR=/var/log
TMP_DIR=/data/web/log/tmp_${TIME}
COLLECT_DIR=/data/web/log
COLLECT_NAME=$1.tar.gz

mk_dir $COLLECT_DIR
rm_dir $TMP_DIR
mk_dir $TMP_DIR

cp -r $LOG_DIR/* $TMP_DIR

tar_dir $TMP_DIR $COLLECT_DIR/$COLLECT_NAME

rm_dir $TMP_DIR

echo -n $COLLECT_NAME

exit 0
