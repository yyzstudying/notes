#!/bin/bash

cd /data/web/rcdc/shell

DEVICE="eth0"

ETHCONFIG=/etc/sysconfig/network-scripts/ifcfg-${DEVICE}
DNSCONFIG=/etc/resolv.conf

#include files
. ./common.json

ipaddr=$(ip addr show $DEVICE)

inet=$(echo "$ipaddr" | grep inet | grep -v inet6 | awk '{print $2}')

ip=$(echo "$inet" | cut -f1 -d/)
netmask=$(ipcalc -m $inet | awk -F '=' '{print $2}')
gateway=$(ip route | grep default | awk '{print $3}')

name=$(cat $ETHCONFIG | grep DEVICE | awk -F '=' '{print $2}' | sed s/\"/''/g)

dns=$(cat $DNSCONFIG | awk '/^nameserver/{print $2}' | sed -n '1p')
dns2=$(cat $DNSCONFIG | awk '/^nameserver/{print $2}' | sed -n '2p')

mac=$(echo "$ipaddr" |  grep ether | awk '{print $2}')
state=$(echo "$ipaddr" | grep state | awk '{print $9}')

#ip=$(cat $ETHCONFIG | grep IPADDR | awk -F '=' '{print $2}' | sed s/\"/''/g)
#netmask=$(cat $ETHCONFIG | grep NETMASK | awk -F '=' '{print $2}' | sed s/\"/''/g)
#gateway=$(cat $ETHCONFIG | grep GATEWAY | awk -F '=' '{print $2}' | sed s/\"/''/g)
#dns1=$(cat $ETHCONFIG | grep DNS1 | awk -F '=' '{print $2}' | sed s/\"/''/g)
#dns2=$(cat $ETHCONFIG | grep DNS2 | awk -F '=' '{print $2}' | sed s/\"/''/g)

e_json name "$name" ip "$ip" netmask "$netmask" gateway "$gateway" dns "$dns" dns2 "$dns2" mac "$mac" state "$state"
