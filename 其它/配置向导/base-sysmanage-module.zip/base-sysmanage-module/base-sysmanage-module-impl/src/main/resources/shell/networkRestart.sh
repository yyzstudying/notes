#!/bin/bash

cd /data/web/rcdc/shell

## restart the network
systemctl restart network

## restart tomcat
systemctl restart tomcat

