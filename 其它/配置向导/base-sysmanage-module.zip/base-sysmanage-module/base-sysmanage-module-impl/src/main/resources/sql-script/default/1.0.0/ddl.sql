-- 定时任务配置表
create table t_base_sysmanage_schedule_task
(
  id              uuid                       not null
    constraint t_base_sysmanage_schedule_task_pkey primary key,
  task_type_id    uuid                       not null,
  cron_expression varchar(32)                not null,
  task_cycle      varchar(32)                not null,
  description     varchar(256),
  update_time     timestamp(6) default now(),
  create_time     timestamp(6) default now() not null,
  version         int4         default 0     not null
);
comment
on
column
t_base_sysmanage_schedule_task
.
id
is
'主键';
comment
on
column
t_base_sysmanage_schedule_task
.
task_type_id
is
'任务类型id';
comment
on
column
t_base_sysmanage_schedule_task
.
cron_expression
is
'定时器表达式';
comment
on
column
t_base_sysmanage_schedule_task
.
task_cycle
is
'任务周期';
comment
on
column
t_base_sysmanage_schedule_task
.
description
is
'任务描述';
comment
on
column
t_base_sysmanage_schedule_task
.
update_time
is
'更新时间';
comment
on
column
t_base_sysmanage_schedule_task
.
version
is
'版本号';


-- 定时任务类型表
create table t_base_sysmanage_schedule_type
(
  id        uuid           not null
    constraint t_base_sysmanage_schedule_type_pkey primary key,
  name      varchar(32)    not null,
  bean_name varchar(32)    not null,
  version   int4 default 0 not null
);
comment
on
column
t_base_sysmanage_schedule_type
.
id
is
'主键';
comment
on
column
t_base_sysmanage_schedule_type
.
name
is
'名称';
comment
on
column
t_base_sysmanage_schedule_type
.
bean_name
is
'容器中组件标识';
comment
on
column
t_base_sysmanage_schedule_type
.
version
is
'版本号';


-- 定时任务日志表
create table t_base_sysmanage_schedule_log
(
  id              uuid                not null
    constraint t_base_sysmanage_schedule_log_pkey primary key,
  task_id         uuid                not null,
  task_type_name  varchar(32),
  cron_expression varchar(32),
  start_time      timestamp default now(),
  end_time        timestamp,
  execute_time    timestamp,
  exception_msg   varchar(256),
  is_success      boolean             not null,
  version         int4      default 0 not null
);
comment
on
column
t_base_sysmanage_schedule_log
.
id
is
'id';
comment
on
column
t_base_sysmanage_schedule_log
.
task_id
is
'定时任务id';
comment
on
column
t_base_sysmanage_schedule_log
.
task_type_name
is
'任务类型名称';
comment
on
column
t_base_sysmanage_schedule_log
.
cron_expression
is
'定时器表达式';
comment
on
column
t_base_sysmanage_schedule_log
.
start_time
is
'定时器开始执行时间';
comment
on
column
t_base_sysmanage_schedule_log
.
end_time
is
'任务执行结束时间';
comment
on
column
t_base_sysmanage_schedule_log
.
execute_time
is
'定时器执行时间';
comment
on
column
t_base_sysmanage_schedule_log
.
exception_msg
is
'异常信息';
comment
on
column
t_base_sysmanage_schedule_log
.
is_success
is
'是否成功';
comment
on
column
t_base_sysmanage_schedule_log
.
version
is
'版本号';

-- 日志文件表
create table t_base_sysmanage_log_file
(
  id             uuid           not null
    constraint t_base_sysmanage_log_file_pkey primary key,
  file_name      varchar(32)    not null,
  real_file_name varchar(64)    not null,
  create_time    timestamp(0)   not null,
  version        int4 default 0 not null
);

-- 数据备份表
create table t_base_sysmanage_db_backup
(
  id             uuid           not null
    constraint t_base_sysmanage_db_backup_pkey primary key,
  real_file_name varchar(64)    not null,
  file_name      varchar(32)    not null,
  is_auto        boolean        not null,
  create_time    timestamp(0)   not null,
  version        int4 default 0 not null
);

-- log4j配置表

create table t_base_sysmanage_log4j_config
(
  id           uuid        not null
    constraint t_base_sysmanage_log4j_config_pk
    primary key,
  logger_name  varchar(128) not null,
  logger_level varchar(10) not null,
  version      bigint
);







