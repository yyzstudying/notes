function fail(){
  echo "$2"
  exit $1
}

function success(){
  exit $0
}

function mk_dir(){
  if [ ! -d $1 ];then
    mkdir -p $1
  fi
}

function rm_dir(){
  rm -rf $1
}

function tar_dir(){
  cur=$(pwd)
  cd $1
  tar -czf $2 -C $1 *
  cd $cur
}

function untar_dir(){
  tar -xf $1 -C $2
}