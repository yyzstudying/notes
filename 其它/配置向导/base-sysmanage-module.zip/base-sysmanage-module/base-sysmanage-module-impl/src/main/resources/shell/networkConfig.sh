#!/bin/bash

cd /data/web/rcdc/shell

#include files
. ./common.json

#include files
. ./common.sh

DEVICE="eth0"

BAKDIR="/data/web/backup/network"
ETHCONFIG="/etc/sysconfig/network-scripts/ifcfg-${DEVICE}"

while getopts "i:n:g:f:s" arg;do
  case $arg in
    i)
    IPADDR=$OPTARG
    ;;
    n)
    NETMASK=$OPTARG
    ;;
    g)
    GATEWAY=$OPTARG
    ;;
    f)
    DNS1=$OPTARG
    ;;
    s)
    DNS2=$OPTARG
    ;;
    esac
done

## backup origin config file

mk_dir $BAKDIR

cp $ETHCONFIG ${BAKDIR}/${DEVICE}$(date +%s)

## set ip mode
sed -i s/^BOOTPROTO=.*/BOOTPROTO=static/g $ETHCONFIG

## set ip netmask gateway
if `grep -q -i 'static' $ETHCONFIG` ;then
  sed -i s/^IPADDR=.*/IPADDR=$IPADDR/g $ETHCONFIG
  sed -i s/^NETMASK=.*/NETMASK=$NETMASK/g $ETHCONFIG
  sed -i s/^GATEWAY=.*/GATEWAY=$GATEWAY/g $ETHCONFIG
else
  echo IPADDR=$IPADDR/ >> $ETHCONFIG
  echo NETMASK=$NETMASK >> $ETHCONFIG
  echo GATEWAY=$GATEWAY >> $ETHCONFIG
fi

## set dns1
if `grep -q -i  'DNS1' $ETHCONFIG` ;then
  sed -i s/^DNS1=.*/DNS1=$DNS1/g $ETHCONFIG
else
  echo DNS1=$DNS1 >> $ETHCONFIG
fi

## set dns2
if `grep -q  -i  'DNS2' $ETHCONFIG` ;then
  sed -i s/^DNS2=.*/DNS2=$DNS2/g $ETHCONFIG
  printf "success"
else
  echo DNS2=$DNS2 >> $ETHCONFIG
fi
