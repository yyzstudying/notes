/*
Navicat PGSQL Data Transfer

Source Server         : 172.21.129.171
Source Server Version : 100500
Source Host           : localhost:5432
Source Database       : rcdc_default
Source Schema         : public

Target Server Type    : PGSQL
Target Server Version : 100500
File Encoding         : 65001

Date: 2019-03-04 15:23:00
*/


-- ----------------------------
-- Table structure for t_base_license_file
-- ----------------------------
CREATE TABLE "t_base_license_file" (
"id" uuid NOT NULL,
"feature_code" varchar(64) COLLATE "default" NOT NULL,
"file_name" varchar(64) COLLATE "default" NOT NULL,
"file_md5" varchar(64) COLLATE "default" NOT NULL,
"feature_type" varchar(16) COLLATE "default" NOT NULL,
"feature_status" varchar(16) COLLATE "default" NOT NULL,
"create_time" date NOT NULL,
"trial_duration" int8,
"trial_remainder" int8,
"trail_start_time" date,
"trail_end_time" date,
"feature_display_name" varchar(64) COLLATE "default" NOT NULL,
"feature_description" varchar(256) COLLATE "default",
"version" int4
)
WITH (OIDS=FALSE)

;
COMMENT ON COLUMN "t_base_license_file"."id" IS 'ID';
COMMENT ON COLUMN "t_base_license_file"."feature_code" IS 'License控制项编码';
COMMENT ON COLUMN "t_base_license_file"."file_name" IS 'License文件名';
COMMENT ON COLUMN "t_base_license_file"."file_md5" IS 'License文件的MD5';
COMMENT ON COLUMN "t_base_license_file"."feature_type" IS 'License类型';
COMMENT ON COLUMN "t_base_license_file"."feature_status" IS 'License状态';
COMMENT ON COLUMN "t_base_license_file"."create_time" IS '创建时间';
COMMENT ON COLUMN "t_base_license_file"."trial_duration" IS '试用时长';
COMMENT ON COLUMN "t_base_license_file"."trial_remainder" IS '剩余时长';
COMMENT ON COLUMN "t_base_license_file"."trail_start_time" IS '试用开始时间';
COMMENT ON COLUMN "t_base_license_file"."trail_end_time" IS '试用结束时间';
COMMENT ON COLUMN "t_base_license_file"."feature_display_name" IS '特性的中文名';
COMMENT ON COLUMN "t_base_license_file"."feature_description" IS '特性的其他描述';
COMMENT ON COLUMN "t_base_license_file"."version" IS '版本号';

-- ----------------------------
-- Alter Sequences Owned By 
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table t_base_license_file
-- ----------------------------
ALTER TABLE "t_base_license_file" ADD PRIMARY KEY ("id");
