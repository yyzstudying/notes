#!/bin/bash

cd /data/web/rcdc/shell

#include files
. ./common.sh

date -s "$1 $2" 1>_ok.tmp 2>_err.tmp

if [ $? -ne 0 ];then
  fail 1 "update time fail."
else
  hwclock -w
  printf "success"
fi
