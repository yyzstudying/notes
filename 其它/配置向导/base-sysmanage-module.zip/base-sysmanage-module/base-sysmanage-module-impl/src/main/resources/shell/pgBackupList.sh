#!/bin/bash

cd /data/web/rcdc/shell

#include files
. ./pgconfig.conf

bak_list=$(ls ${BAKDIR}/db_*.tar)

for file in $bak_list;do

    if test -f $file ;then
        echo $file
    fi

done
