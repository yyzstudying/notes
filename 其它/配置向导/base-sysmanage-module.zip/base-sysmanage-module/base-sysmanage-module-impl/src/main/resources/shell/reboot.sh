#!/bin/bash

sh -c "sleep 5 && reboot" &