INSERT INTO t_sk_global_parameter ("id", "param_key", "param_value", "default_value", "create_time", "update_time", "version") VALUES ('3d1a635b-bf90-45b2-ac2f-73a9041589bb', 'debug_log_path', '/data/web/log', '/data/web/log', '2019-01-16', '2019-01-16', '0');
INSERT INTO t_sk_global_parameter ("id", "param_key", "param_value", "default_value", "create_time", "update_time", "version") VALUES ('8c6c9979-d16a-4442-9711-9e02c46b0b55', 'db_backup_path', '/data/web/db', '/data/web/db', '2019-01-16', '2019-01-16', '0');

