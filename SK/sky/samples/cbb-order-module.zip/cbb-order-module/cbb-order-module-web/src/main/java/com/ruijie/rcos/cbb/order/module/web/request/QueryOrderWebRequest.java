package com.ruijie.rcos.cbb.order.module.web.request;

import com.ruijie.rcos.sk.base.annotation.NotNull;
import com.ruijie.rcos.sk.webmvc.api.request.PageWebRequest;

import java.util.UUID;

/**
 * Description: TODO 写点注释吧
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019/2/28
 *
 * @author ChenQuan
 */
public class QueryOrderWebRequest extends PageWebRequest {

    @NotNull
    private UUID userId;

    public UUID getUserId() {
        return userId;
    }

    public void setUserId(UUID userId) {
        this.userId = userId;
    }
}
