package com.ruijie.rcos.cbb.order.module.web.ctrl;

import com.ruijie.rcos.cbb.order.module.def.api.OrderAPI;
import com.ruijie.rcos.cbb.order.module.def.api.request.order.CreateOrderRequest;
import com.ruijie.rcos.cbb.order.module.def.api.request.order.GetOrderRequest;
import com.ruijie.rcos.cbb.order.module.def.api.request.order.QueryOrderRequest;
import com.ruijie.rcos.cbb.order.module.def.api.response.order.GetOrderResponse;
import com.ruijie.rcos.cbb.order.module.def.dto.OrderDTO;
import com.ruijie.rcos.cbb.order.module.web.request.CreateOrderWebRequest;
import com.ruijie.rcos.cbb.order.module.web.request.GetOrderWebRequest;
import com.ruijie.rcos.cbb.order.module.web.request.QueryOrderWebRequest;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultPageResponse;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultResponse;
import com.ruijie.rcos.sk.webmvc.api.annotation.NoAuthUrl;
import com.ruijie.rcos.sk.webmvc.api.response.DefaultWebResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.UUID;

/**
 * Description: TODO 写点注释吧
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019/2/22
 *
 * @author ChenQuan
 */
@Controller
@RequestMapping("/order")
public class OrderController {

    @Autowired
    private OrderAPI orderAPI;

    /**
     * 查询订单信息
     *
     * @param request 订单查询对象
     * @return DefaultWebResponse
     * @throws BusinessException 订单不存在时
     */
    @NoAuthUrl
    @RequestMapping(value = "", method = RequestMethod.POST)
    public DefaultWebResponse getOrder(GetOrderWebRequest request) throws BusinessException {
        Assert.notNull(request, "get order request parameter cannot be null");
        GetOrderRequest orderRequest = new GetOrderRequest(request.getOrderId());
        GetOrderResponse response = orderAPI.getOrderById(orderRequest);

        return DefaultWebResponse.Builder.success(response);
    }

    /**
     * 生成新订单
     *
     * @param request 订单信息
     * @return DefaultWebResponse
     * @throws BusinessException 生成新订单失败时
     */
    @NoAuthUrl
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    public DefaultWebResponse createOrder(CreateOrderWebRequest request) throws BusinessException {
        Assert.notNull(request, "create order request parameter cannot be null");
        CreateOrderRequest orderRequest = new CreateOrderRequest(request.getUserId(), request.getOrderAmount());
        GetOrderResponse response = orderAPI.create(orderRequest);

        return DefaultWebResponse.Builder.success(response);
    }

    /**
     * 删除订单
     *
     * @param request 订单查询对象
     * @return DefaultWebResponse
     * @throws BusinessException 删除订单失败时
     */
    @NoAuthUrl
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    public DefaultWebResponse deleteOrder(GetOrderWebRequest request) throws BusinessException {
        Assert.notNull(request, "delete order request parameter cannot be null");
        orderAPI.delete(new GetOrderRequest(request.getOrderId()));

        return DefaultWebResponse.Builder.success();
    }

    /**
     * 完成订单
     *
     * @param request 订单查询对象
     * @return DefaultWebResponse
     * @throws BusinessException 订单不存在时
     */
    @NoAuthUrl
    @RequestMapping(value = "/finish", method = RequestMethod.POST)
    public DefaultWebResponse finishOrder(GetOrderWebRequest request) throws BusinessException {
        Assert.notNull(request, "finish order request parameter cannot be null");
        DefaultResponse response = orderAPI.finish(new GetOrderRequest(request.getOrderId()));

        return DefaultWebResponse.Builder.success();
    }

    /**
     * 列出用户所有订单信息
     *
     * @param request 用户查询对象
     * @return DefaultWebResponse
     * @throws BusinessException 查询异常时
     */
    @NoAuthUrl
    @RequestMapping(value = "/list", method = RequestMethod.POST)
    public DefaultWebResponse queryOrderByOrderStatus(QueryOrderWebRequest request) throws BusinessException {
        Assert.notNull(request, "query order request parameter cannot be null");

        QueryOrderRequest orderRequest = new QueryOrderRequest();
        orderRequest.setUserId(request.getUserId());
        orderRequest.setLimit(request.getLimit());
        orderRequest.setPage(request.getPage());

        DefaultPageResponse<OrderDTO> response = orderAPI.queryOrderByUserId(orderRequest);

        return DefaultWebResponse.Builder.success(response);
    }
}
