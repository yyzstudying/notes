package com.ruijie.rcos.cbb.order.module.def.api.request.order;

import com.ruijie.rcos.sk.base.annotation.NotNull;
import com.ruijie.rcos.sk.modulekit.api.comm.Request;

import java.util.UUID;

/**
 * Description: TODO 写点注释吧
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019/2/28
 *
 * @author ChenQuan
 */
public class CreateOrderRequest implements Request {

    @NotNull
    private UUID userId;

    @NotNull
    private Double orderAmount;

    public Double getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(Double orderAmount) {
        this.orderAmount = orderAmount;
    }

    public UUID getUserId() {
        return userId;
    }

    public void setUserId(UUID userId) {
        this.userId = userId;
    }

    public CreateOrderRequest(UUID userId, double orderAmount) {
        this.userId = userId;
        this.orderAmount = orderAmount;
    }

    public CreateOrderRequest() {

    }
}
