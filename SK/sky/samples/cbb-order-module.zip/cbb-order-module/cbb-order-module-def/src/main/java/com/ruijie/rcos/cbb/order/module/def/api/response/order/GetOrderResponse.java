package com.ruijie.rcos.cbb.order.module.def.api.response.order;

import com.ruijie.rcos.cbb.order.module.def.dto.OrderDTO;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultResponse;

/**
 * Description: TODO 写点注释吧
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019/2/22
 *
 * @author ChenQuan
 */
public class GetOrderResponse extends DefaultResponse {

    private OrderDTO orderDTO;

    public OrderDTO getOrderDTO() {
        return orderDTO;
    }

    public void setOrderDTO(OrderDTO orderDTO) {
        this.orderDTO = orderDTO;
    }

    public GetOrderResponse(OrderDTO orderDTO) {
        this.orderDTO = orderDTO;
    }

    public GetOrderResponse() {

    }
}
