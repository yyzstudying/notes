package com.ruijie.rcos.cbb.order.module.def.enums;

/**
 * Description: TODO 写点注释吧
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019/2/28
 *
 * @author ChenQuan
 */
public enum OrderStatus {

    NEW(0, "新下单"), FINISH(1, "已完结"), CANCEL(2, "已取消"),;

    private Integer code;

    private String message;

    OrderStatus(Integer code, String message) {
        this.code = code;
        this.message = message;
    }
}
