package com.ruijie.rcos.cbb.order.module.def.api;

import com.ruijie.rcos.cbb.order.module.def.api.request.order.CreateOrderRequest;
import com.ruijie.rcos.cbb.order.module.def.api.request.order.GetOrderRequest;
import com.ruijie.rcos.cbb.order.module.def.api.request.order.QueryOrderRequest;
import com.ruijie.rcos.cbb.order.module.def.api.response.order.GetOrderResponse;
import com.ruijie.rcos.cbb.order.module.def.dto.OrderDTO;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultPageResponse;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultResponse;
import com.ruijie.rcos.sk.modulekit.api.tx.NoRollback;
import com.ruijie.rcos.sk.modulekit.api.tx.Rollback;

/**
 * Description: TODO 写点注释吧
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019/2/22
 *
 * @author ChenQuan
 */
public interface OrderAPI {

    /**
     * 根据订单ID查询订单信息
     *
     * @param orderRequest 订单查询对象
     * @return GetOrderResponse
     * @throws BusinessException 订单不存在时抛出异常
     */
    @NoRollback
    GetOrderResponse getOrderById(GetOrderRequest orderRequest) throws BusinessException;

    /**
     * 生成新订单
     *
     * @param orderRequest 订单信息
     * @return 订单信息
     * @throws BusinessException 生成订单失败时
     */
    @NoRollback
    GetOrderResponse create(CreateOrderRequest orderRequest) throws BusinessException;

    /**
     * 删除订单
     *
     * @param orderRequest 订单查询对象
     * @return DefaultResponse
     * @throws BusinessException 删除订单失败时
     */
    @NoRollback
    DefaultResponse delete(GetOrderRequest orderRequest) throws BusinessException;

    /**
     * 完成订单
     *
     * @param orderRequest 订单查询对象
     * @return DefaultResponse
     * @throws BusinessException 订单不存在时
     */
    @NoRollback
    DefaultResponse finish(GetOrderRequest orderRequest) throws BusinessException;

    /**
     * 列出用户下的所有订单
     *
     * @param query 分页查询参数
     * @return DefaultPageResponse
     * @throws BusinessException 查询异常时
     */
    @NoRollback
    DefaultPageResponse<OrderDTO> queryOrderByUserId(QueryOrderRequest query) throws BusinessException;
}
