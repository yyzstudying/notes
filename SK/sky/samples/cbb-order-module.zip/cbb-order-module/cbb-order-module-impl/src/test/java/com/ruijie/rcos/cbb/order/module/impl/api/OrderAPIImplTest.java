package com.ruijie.rcos.cbb.order.module.impl.api;

import com.ruijie.rcos.cbb.order.module.def.api.request.order.GetOrderRequest;
import com.ruijie.rcos.cbb.order.module.def.api.response.order.GetOrderResponse;
import com.ruijie.rcos.cbb.order.module.impl.dao.OrderDAO;
import com.ruijie.rcos.cbb.order.module.impl.entity.OrderEntity;
import com.ruijie.rcos.sk.base.test.ThrowExceptionTester;
import mockit.Expectations;
import mockit.Injectable;
import mockit.Tested;
import mockit.Verifications;
import mockit.integration.junit4.JMockit;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.UUID;

/**
 * Description: TODO 写点注释吧
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019/2/28
 *
 * @author ChenQuan
 */
@RunWith(JMockit.class)
public class OrderAPIImplTest {

    @Injectable
    private OrderDAO orderDAO;

    @Tested
    private OrderAPIImpl orderAPI;

    @Test
    public void testGetOrderById() throws Exception {
        final UUID orderId = UUID.randomUUID();
        OrderEntity entity = new OrderEntity();
        entity.setOrderId(orderId);
        new Expectations() {{
            orderDAO.getOne(orderId);
            result = entity;
        }};

        GetOrderResponse orderResponse = orderAPI.getOrderById(new GetOrderRequest(orderId));

        new Verifications(){{
            orderDAO.getOne(orderId);
            times = 1;
        }};
    }
}
