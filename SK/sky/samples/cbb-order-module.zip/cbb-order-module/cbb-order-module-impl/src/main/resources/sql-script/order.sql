DROP TABLE IF EXISTS "public"."t_order_master";
CREATE TABLE "public"."t_order_master" (
"order_id" uuid NOT NULL,
"user_id" uuid NOT NULL,
"order_amount" int8 NOT NULL,
"order_status" int4 NOT NULL,
"create_time" timestamp(6),
"update_time" timestamp(6),
"version" int4 DEFAULT 1
)
WITH (OIDS=FALSE)

;

ALTER TABLE "public"."t_order_master" ADD PRIMARY KEY ("order_id");