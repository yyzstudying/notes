package com.ruijie.rcos.cbb.order.module.impl.dao;

import com.ruijie.rcos.cbb.order.module.def.enums.OrderStatus;
import com.ruijie.rcos.cbb.order.module.impl.entity.OrderEntity;
import com.ruijie.rcos.sk.modulekit.api.ds.SkyEngineJpaRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

/**
 * Description: TODO 写点注释吧
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019/2/22
 *
 * @author ChenQuan
 */
public interface OrderDAO extends SkyEngineJpaRepository<OrderEntity, UUID> {

    /**
     * 更新订单表订单状态字段
     * @param orderId 订单ID
     * @param orderStatus 订单状态
     * @param version 版本号
     * @return 影响的行数
     */
    @Transactional
    @Modifying
    @Query("update OrderEntity set orderStatus = ?2, updateTime=CURRENT_TIMESTAMP, version = version + 1 where orderId = ?1 and version = ?3")
    int updateOrderStatusById(UUID orderId, OrderStatus orderStatus, int version);

    /**
     * 列出用户订单列表
     * @param userId 用户ID
     * @param pageable 分页信息
     * @return 订单列表
     */
    Page<OrderEntity> findByUserId(UUID userId, Pageable pageable);
}
