package com.ruijie.rcos.cbb.order.module.impl;

/**
 * Description: TODO 写点注释吧
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019/2/22
 *
 * @author ChenQuan
 */
public interface BusinessKey {

    String CBB_ORDER_ORDER_NOT_EXISTS = "cbb-order_order_not_exists";
}
