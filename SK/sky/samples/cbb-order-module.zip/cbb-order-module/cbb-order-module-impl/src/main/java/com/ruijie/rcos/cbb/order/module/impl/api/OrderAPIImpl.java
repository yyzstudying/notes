package com.ruijie.rcos.cbb.order.module.impl.api;

import com.ruijie.rcos.cbb.order.module.def.api.OrderAPI;
import com.ruijie.rcos.cbb.order.module.def.api.request.order.CreateOrderRequest;
import com.ruijie.rcos.cbb.order.module.def.api.request.order.GetOrderRequest;
import com.ruijie.rcos.cbb.order.module.def.api.request.order.QueryOrderRequest;
import com.ruijie.rcos.cbb.order.module.def.api.response.order.GetOrderResponse;
import com.ruijie.rcos.cbb.order.module.def.dto.OrderDTO;
import com.ruijie.rcos.cbb.order.module.def.enums.OrderStatus;
import com.ruijie.rcos.cbb.order.module.impl.BusinessKey;
import com.ruijie.rcos.cbb.order.module.impl.dao.OrderDAO;
import com.ruijie.rcos.cbb.order.module.impl.entity.OrderEntity;
import com.ruijie.rcos.sk.base.exception.BusinessException;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultPageResponse;
import com.ruijie.rcos.sk.modulekit.api.comm.DefaultResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.util.Assert;

import java.util.Date;

/**
 * Description: TODO 写点注释吧
 * Copyright: Copyright (c) 2019
 * Company: Ruijie Co., Ltd.
 * Create Time: 2019/2/22
 *
 * @author ChenQuan
 */
public class OrderAPIImpl implements OrderAPI {

    @Autowired
    private OrderDAO orderDAO;

    @Override
    public GetOrderResponse getOrderById(GetOrderRequest orderRequest) throws BusinessException {
        Assert.notNull(orderRequest, "order request parameter cannot be null");
        OrderEntity orderEntity = orderDAO.getOne(orderRequest.getOrderId());
        if (null == orderEntity) {
            throw new BusinessException(BusinessKey.CBB_ORDER_ORDER_NOT_EXISTS);
        }
        OrderDTO orderDTO = parseOrderEntityToDTO(orderEntity);
        return new GetOrderResponse(orderDTO);
    }

    @Override
    public GetOrderResponse create(CreateOrderRequest orderRequest) throws BusinessException {
        Assert.notNull(orderRequest, "order create parameter cannot be null");
        Date nowDate = new Date();
        OrderEntity orderEntity = new OrderEntity();
        orderEntity.setUserId(orderRequest.getUserId());
        orderEntity.setOrderAmount((int) (orderRequest.getOrderAmount() * 100));
        orderEntity.setCreateTime(nowDate);
        orderEntity.setUpdateTime(nowDate);
        orderDAO.save(orderEntity);
        OrderDTO orderDTO = parseOrderEntityToDTO(orderEntity);
        return new GetOrderResponse(orderDTO);
    }

    @Override
    public DefaultResponse delete(GetOrderRequest orderRequest) throws BusinessException {
        Assert.notNull(orderRequest, "order delete parameter cannot be null");
        orderDAO.deleteById(orderRequest.getOrderId());
        return DefaultResponse.Builder.success();
    }

    @Override
    public DefaultResponse finish(GetOrderRequest orderRequest) throws BusinessException {
        Assert.notNull(orderRequest, "order finish parameter cannot be null");
        OrderEntity orderEntity = orderDAO.getOne(orderRequest.getOrderId());
        if (null == orderEntity) {
            throw new BusinessException(BusinessKey.CBB_ORDER_ORDER_NOT_EXISTS);
        }
        int result = orderDAO.updateOrderStatusById(orderEntity.getOrderId(), OrderStatus.FINISH, orderEntity.getVersion());

        return result > 0 ? DefaultResponse.Builder.success() : DefaultResponse.Builder.fail();
    }

    @Override
    public DefaultPageResponse<OrderDTO> queryOrderByUserId(QueryOrderRequest query) throws BusinessException {
        Assert.notNull(query, "order finish parameter cannot be null");
        PageRequest pageRequest = PageRequest.of(query.getPage(), query.getLimit());
        Page<OrderEntity> orderList = orderDAO.findByUserId(query.getUserId(), pageRequest);

        DefaultPageResponse<OrderDTO> response = new DefaultPageResponse<>();
        OrderDTO[] objects = orderList.getContent().stream().map(x -> {
            return parseOrderEntityToDTO(x);
        }).toArray(OrderDTO[]::new);
        response.setItemArr(objects);
        response.setTotal(orderList.getTotalElements());

        return response;
    }

    private OrderDTO parseOrderEntityToDTO(OrderEntity orderEntity) {
        double amount = orderEntity.getOrderAmount() / 100.0;
        OrderDTO orderDTO = new OrderDTO();
        orderDTO.setUserId(orderEntity.getUserId());
        orderDTO.setCreateTime(orderEntity.getCreateTime());
        orderDTO.setOrderAmount(amount);
        orderDTO.setOrderStatus(orderEntity.getOrderStatus());
        orderDTO.setOrderId(orderEntity.getOrderId());
        return orderDTO;
    }
}
